package com.changyang.plugin.tiktok.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.changyang.plugin.tiktok.R;
import com.rk.progressbutton.RkProgressButton;

import org.xutils.view.annotation.ViewInject;


public class LoginActivity extends BaseActivity {

    @ViewInject(R.id.btn_login)
    RkProgressButton btn_login;

    @ViewInject(R.id.et_username)
    EditText et_username;
    @ViewInject(R.id.et_password)
    EditText et_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        configStausBar();
        btn_login.setOnProgressClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(et_username.getText().toString())) {
                    Toast.makeText(LoginActivity.this, "请输入手机号", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (TextUtils.isEmpty(et_password.getText().toString())) {
                    Toast.makeText(LoginActivity.this, "请输入密码", Toast.LENGTH_SHORT).show();
                    return;
                }

                btn_login.progressAnimation();
                btn_login.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        btn_login.doneAnimation();
                        new Handler().postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                startActivity(new Intent(LoginActivity.this, ScriptListActivity.class));
                                finish();
                            }
                        }, 600);


                    }
                }, 2000);

            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    protected void configStausBar() {

        if (hasKitKat() && !hasLollipop()) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        } else if (hasLollipop()) {
            Window window = getWindow();
            window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
                    | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(Color.parseColor("#00ffffff"));
        }

    }


    @Override
    public boolean hasTitleBar() {
        return false;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_login;
    }

}
