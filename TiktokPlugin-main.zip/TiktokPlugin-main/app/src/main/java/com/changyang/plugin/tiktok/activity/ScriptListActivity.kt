package com.changyang.plugin.tiktok.activity

import android.Manifest
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.changyang.plugin.tiktok.R
import com.changyang.plugin.tiktok.autojs.AccessibilityServiceTool
import com.changyang.plugin.tiktok.autojs.AutoJs
import com.changyang.plugin.tiktok.launch.*
import com.changyang.plugin.tiktok.widget.Status
import com.changyang.plugin.tiktok.widget.TitleBar
import com.changyang.plugin.tiktok.widget.dialog.PromptDialog
import com.permissionx.guolindev.PermissionX
import kotlinx.android.synthetic.main.activity_script_list.*
import java.lang.ref.WeakReference


class ScriptListActivity : AppCompatActivity(), View.OnClickListener {

    private var promptDialog: PromptDialog? = null
    private val mUiHandler: com.changyang.util.UiHandler =
        com.changyang.util.UiHandler(this)
    val COUNTDOWN_TIME_CODE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_script_list)
        initView()
    }

    private fun initView() {
        title_bar.setTitle("集美报养号")
        title_bar.setTitleColor(Color.WHITE);
        title_bar.setSubTitleColor(Color.WHITE);
        title_bar.setDividerColor(Color.GRAY);
        title_bar.setActionTextColor(Color.WHITE);
        title_bar.addAction(object : TitleBar.TextAction("帮助") {
            override fun performAction(view: View) {
                val bundle = Bundle()
                bundle.putString("url", "file:///android_asset/help/help.html")
                bundle.putString("title", "使用帮助")
                val intent = Intent(applicationContext, WebActivity::class.java);
                intent.putExtras(bundle)
                startActivity(intent)

            }
        })
        PermissionX.init(this@ScriptListActivity)
            .permissions(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            )
            .request { allGranted, grantedList, deniedList ->
                if (allGranted) {
                    //Toast.makeText(this, "All permissions are granted", Toast.LENGTH_LONG).show()
                } else {
                    //Toast.makeText(this, "These permissions are denied: $deniedList", Toast.LENGTH_LONG).show()
                }
            }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (Settings.canDrawOverlays(this@ScriptListActivity)) {
                switch_float_window.toggleOn()
            }else{
                switch_float_window.setToggleOff()
            }
        }
        val enableAccessibility = AccessibilityServiceTool.isAccessibilityServiceEnabled(this)
        if (enableAccessibility) {
            status_accessible.tv_content_success.setText("已开启无障碍服务")
            switch_accessible.setToggleOn()
            status_accessible.setStatus(Status.COMPLETE)
        } else {
            status_accessible.tv_content_error.setText("未开启无障碍服务")
            switch_accessible.setToggleOff()
            status_accessible.setStatus(Status.ERROR)
        }

        switch_accessible.setOnClickListener(View.OnClickListener {
            AccessibilityServiceTool.goToAccessibilitySetting()
        })

        switch_float_window.setOnClickListener(View.OnClickListener {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            intent.data = Uri.parse("package:" + this@ScriptListActivity.getPackageName())
            this@ScriptListActivity.startActivityForResult(intent, 1)
        })

    }

    /**
     * 检测是否开启无障碍无法
     */
    private fun checkAccessibility(): Boolean {
        val enableAccessibility = AccessibilityServiceTool.isAccessibilityServiceEnabled(this)
        if (enableAccessibility) {
            status_accessible.tv_content_success.setText("已开启无障碍服务")
            switch_accessible.toggle(true)
            status_accessible.setStatus(Status.COMPLETE)
            return true
        } else {
            status_accessible.tv_content_error.setText("未开启无障碍服务")
            switch_accessible.toggle(false)
            status_accessible.setStatus(Status.ERROR)
            val builder = AlertDialog.Builder(this)
            // 设置参数
            builder.setMessage("无障碍服务未开启，去开启无障碍服务？")
                .setTitle("提示")
                .setPositiveButton("确定") { dialog, which ->
                    AccessibilityServiceTool.goToAccessibilitySetting()
                }
            // 创建对话框
            val dialog = builder.create()
            dialog.show()
        }
        return false
    }

    override fun onRestart() {
        super.onRestart()

    }

    override fun onPause() {
        super.onPause()
        promptDialog?.dismiss()
    }

    override fun onResume() {
        super.onResume()

        WeakHandler(this@ScriptListActivity).postDelayed(Runnable {
            val enableAccessibility = AccessibilityServiceTool.isAccessibilityServiceEnabled(this)
            if (enableAccessibility) {
                status_accessible.tv_content_success.setText("已开启无障碍服务")
                switch_accessible.toggleOn()
                status_accessible.setStatus(Status.COMPLETE)
            } else {
                status_accessible.tv_content_error.setText("未开启无障碍服务")
                switch_accessible.toggleOff()
                status_accessible.setStatus(Status.ERROR)
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (Settings.canDrawOverlays(this@ScriptListActivity)) {
                    switch_float_window.toggleOn()
                }else{
                    switch_float_window.toggleOff()
                }
            }

        },500)

    }


    /**
     * Called when a view has been clicked.
     *
     * @param v The view that was clicked.
     */
    override fun onClick(v: View?) {
        v?.let {
            when (v.id) {
                // 快手
                R.id.bt_kuaishou -> {
                    if (!checkAccessibility()) {
                        return
                    }
                    GlobalKuaiShouLauncher.launch(this)
                }
                // 抖音
                R.id.bt_car -> {
                    if (!checkAccessibility()) {
                        return
                    }
                    promptDialog = PromptDialog(this)
                    promptDialog?.showLoading("正在启动抖音")
                    GlobalTiktokLauncher.launch(this)
                }
                // 启动无障碍
                R.id.bt_accessibility -> {
                    AccessibilityServiceTool.goToAccessibilitySetting()
                }

                R.id.bt_float_window -> {
                    Toast.makeText(applicationContext, "bt_float_window", Toast.LENGTH_SHORT).show()
                }

                // 停止所有服务
                R.id.bt_stop_scrip -> {
                    AutoJs.instance.run { scriptEngineService.stopAllAndToast() }
                }

                else -> {
                    Log.e("", "")
                }
            }
        }
    }

    /**
     * 是否有悬浮窗权限
     */
    private fun canDrawOverlays(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                mUiHandler.toast("当前无权限，请授权")
                startActivityForResult(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + packageName)
                    ), 0
                )
                return false
            }
        }
        return true
    }


    private fun notificationListenerEnable(): Boolean {
        var enable = false
        val packageName = packageName
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        if (flat != null) {
            enable = flat.contains(packageName)
        }
        return enable
    }


    /**
     * 开启通知栏
     */
    private fun gotoNotificationAccessSetting(context: Context): Boolean {
        try {
            val intent = Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return true
        } catch (e: ActivityNotFoundException) {
            try {
                val intent = Intent()
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                val cn = ComponentName(
                    "com.android.settings",
                    "com.android.settings.Settings.NotificationAccessSettingsActivity"
                )
                intent.component = cn
                intent.putExtra(":settings:show_fragment", "NotificationAccessSettings")
                context.startActivity(intent)
                return true
            } catch (ex: Exception) {
                ex.printStackTrace()
            }
            return false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        AutoJs.instance.run { scriptEngineService.stopAllAndToast() }
    }


    /**
     * 权限申请
     */
    fun windowPermission() {
        // 进行权限申请
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // 如果是api23以上版本，则进行权限申请
            if (!Settings.canDrawOverlays(this@ScriptListActivity)) {
                val builder = androidx.appcompat.app.AlertDialog.Builder(this@ScriptListActivity)
                builder.setTitle("提示")
                builder.setMessage("需要申请系统悬浮窗权限！")
                builder.setPositiveButton(
                    "确定"
                ) { dialog, which ->
                    dialog.dismiss()
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
                    intent.data = Uri.parse("package:" + this@ScriptListActivity.getPackageName())
                    this@ScriptListActivity.startActivityForResult(intent, 1)
                }
                builder.setNegativeButton(
                    "取消"
                ) { dialog, which -> dialog.dismiss() }
                builder.show()
            } else {
                Toast.makeText(this@ScriptListActivity, "已经申请过悬浮窗权限了", Toast.LENGTH_SHORT).show()

            }
        } else {
            // 如果是api23以下版本，不需要申请权限
            Toast.makeText(this@ScriptListActivity, "api23以下版本不需要申请悬浮窗权限", Toast.LENGTH_SHORT).show()

        }
    }


    class WeakHandler internal constructor(activity: ScriptListActivity?) : Handler() {
        val weakReference: WeakReference<ScriptListActivity>
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            val activity: ScriptListActivity? = weakReference.get()
            when (msg.what) {
//                COUNTDOWN_TIME_CODE -> {
//                    var value: Int = msg.arg1
//                    activity.tv.setText(value--.toString())
//                    if (value > MIN_COUNT) {
//                        val message: Message = Message.obtain()
//                        message.what = COUNTDOWN_TIME_CODE
//                        message.arg1 = value
//                        sendMessageDelayed(message, DELAY_MILLIS)
//                    }
//                }
            }
        }

        companion object {
            const val MIN_COUNT = 0
        }

        init {
            weakReference = WeakReference(activity)
        }
    }


}
