package com.changyang.plugin.tiktok.activity;

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.changyang.plugin.tiktok.R;

import org.xutils.view.annotation.ViewInject;


public class WebActivity extends BaseActivity {

    private boolean autoRemove;
    @ViewInject(R.id.webview)
    WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        initViews();

    }

    private void initViews() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        webView.addJavascriptInterface(this, "WebActivity");
        webView.loadUrl(getIntent().getStringExtra("url"));
        titleBar.setTitle(getIntent().getStringExtra("title"));
    }

    @Override
    public boolean hasTitleBar() {
        return true;
    }

    @Override
    public int getLayoutId() {
        return R.layout.activity_web;
    }

    @JavascriptInterface
    public boolean getAutoRemove() {
        return autoRemove;
    }

    @JavascriptInterface
    public void setAutoRemove(boolean b) {
        autoRemove = b;
    }

    @JavascriptInterface
    public void chooseService() {
//        Intent intent_abs = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
//        intent_abs.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent_abs);
    }

}
