package com.changyang.plugin.tiktok.autojs

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils

import com.changyang.app.GlobalAppContext
import com.changyang.autojs.core.util.ProcessShell
import com.changyang.view.accessibility.AccessibilityServiceUtils

import java.util.Locale


object AccessibilityServiceTool {
    private val sAccessibilityServiceClass =
        com.changyang.autojs.core.accessibility.AccessibilityService::class.java

    private val cmd = "enabled=$(settings get secure enabled_accessibility_services)\n" +
            "pkg=%s\n" +
            "if [[ \$enabled == *\$pkg* ]]\n" +
            "then\n" +
            "echo already_enabled\n" +
            "else\n" +
            "enabled=\$pkg:\$enabled\n" +
            "settings put secure enabled_accessibility_services \$enabled\n" +
            "fi"

    fun enableAccessibilityServiceByRoot(
        context: Context,
        accessibilityService: Class<out AccessibilityService>
    ): Boolean {
        val serviceName = context.packageName + "/" + accessibilityService.name
        return try {
            TextUtils.isEmpty(
                com.changyang.autojs.core.util.ProcessShell.execCommand(
                    String.format(
                        Locale.getDefault(),
                        cmd,
                        serviceName
                    ), true
                ).error
            )
        } catch (ignored: Exception) {
            false
        }

    }

    fun enableAccessibilityServiceByRootAndWaitFor(context: Context, timeOut: Long): Boolean {
        if (enableAccessibilityServiceByRoot(
                context,
                com.changyang.view.accessibility.AccessibilityService::class.java
            )
        ) {
            com.changyang.view.accessibility.AccessibilityService.waitForEnabled(timeOut)
            return true
        }
        return false
    }

    fun goToAccessibilitySetting() {
        com.changyang.app.GlobalAppContext.get()
            .startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }


    fun isAccessibilityServiceEnabled(context: Context): Boolean {
        return AccessibilityServiceUtils.isAccessibilityServiceEnabled(
            context,
            sAccessibilityServiceClass
        )
    }

}
