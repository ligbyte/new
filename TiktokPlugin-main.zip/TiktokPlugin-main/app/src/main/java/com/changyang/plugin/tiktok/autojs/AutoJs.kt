package com.changyang.plugin.tiktok.autojs

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import com.changyang.plugin.tiktok.R
import com.changyang.plugin.tiktok.activity.LogActivity
import com.changyang.plugin.tiktok.activity.SettingsActivity
import com.changyang.plugin.tiktok.utils.Pref
import com.changyang.view.accessibility.AccessibilityService
import com.changyang.view.accessibility.AccessibilityServiceUtils


class AutoJs private constructor(application: Application) :
    com.changyang.autojs.AutoJs(application) {

    init {
        scriptEngineService.registerGlobalScriptExecutionListener(ScriptExecutionGlobalListener())
    }

    override fun createAppUtils(context: Context): com.changyang.autojs.runtime.api.AppUtils {
        return com.changyang.autojs.runtime.api.AppUtils(
            context,
            context.packageName + ".fileprovider"
        )
    }


    override fun ensureAccessibilityServiceEnabled() {
        if (AccessibilityService.instance != null) {
            return
        }
        var errorMessage: String? = null
        if (AccessibilityServiceUtils.isAccessibilityServiceEnabled(
                application,
                AccessibilityService::class.java
            )
        ) {
            errorMessage =
                com.changyang.app.GlobalAppContext.getString(R.string.text_auto_operate_service_enabled_but_not_running)
        } else {
            if (Pref.shouldEnableAccessibilityServiceByRoot()) {
                if (!AccessibilityServiceTool.enableAccessibilityServiceByRootAndWaitFor(
                        application,
                        2000
                    )
                ) {
                    errorMessage =
                        com.changyang.app.GlobalAppContext.getString(R.string.text_enable_accessibility_service_by_root_timeout)
                }
            } else {
                errorMessage =
                    com.changyang.app.GlobalAppContext.getString(R.string.text_no_accessibility_permission)
            }
        }
        if (errorMessage != null) {
            AccessibilityServiceTool.goToAccessibilitySetting()
            throw com.changyang.autojs.runtime.exception.ScriptException(
                errorMessage
            )
        }
    }

    override fun waitForAccessibilityServiceEnabled() {
        if (AccessibilityService.instance != null) {
            return
        }
        var errorMessage: String? = null
        if (AccessibilityServiceUtils.isAccessibilityServiceEnabled(
                application,
                AccessibilityService::class.java
            )
        ) {
            errorMessage =
                com.changyang.app.GlobalAppContext.getString(R.string.text_auto_operate_service_enabled_but_not_running)
        } else {
            if (Pref.shouldEnableAccessibilityServiceByRoot()) {
                if (!AccessibilityServiceTool.enableAccessibilityServiceByRootAndWaitFor(
                        application,
                        2000
                    )
                ) {
                    errorMessage =
                        com.changyang.app.GlobalAppContext.getString(R.string.text_enable_accessibility_service_by_root_timeout)
                }
            } else {
                errorMessage =
                    com.changyang.app.GlobalAppContext.getString(R.string.text_no_accessibility_permission)
            }
        }
        if (errorMessage != null) {
            AccessibilityServiceTool.goToAccessibilitySetting()
            if (!AccessibilityService.waitForEnabled(-1)) {
                throw com.changyang.autojs.runtime.exception.ScriptInterruptedException()
            }
        }
    }

    override fun initScriptEngineManager() {
        super.initScriptEngineManager()
        scriptEngineManager.registerEngine(com.changyang.autojs.script.JavaScriptSource.ENGINE) {
            val engine = XJavaScriptEngine(application)
            engine.runtime = createRuntime()
            engine
        }
    }

    override fun createRuntime(): com.changyang.autojs.runtime.ScriptRuntime {
        val runtime = super.createRuntime()
        runtime.putProperty("class.settings", SettingsActivity::class.java)
        runtime.putProperty("class.console", LogActivity::class.java)
        return runtime
    }

    companion object {

        @SuppressLint("StaticFieldLeak")
        lateinit var instance: AutoJs
            private set

        fun initInstance(application: Application) {
            instance = AutoJs(application)
        }
    }
}
