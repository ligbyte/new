package com.changyang.plugin.tiktok.autojs

import com.changyang.app.GlobalAppContext
import com.changyang.plugin.tiktok.R
import com.changyang.autojs.execution.ScriptExecution
import com.changyang.autojs.execution.ScriptExecutionListener


class ScriptExecutionGlobalListener :
    com.changyang.autojs.execution.ScriptExecutionListener {

    override fun onStart(execution: com.changyang.autojs.execution.ScriptExecution) {
        execution.engine.setTag(ENGINE_TAG_START_TIME, System.currentTimeMillis())
    }

    override fun onSuccess(
        execution: com.changyang.autojs.execution.ScriptExecution,
        result: Any?
    ) {
        onFinish(execution)
    }

    private fun onFinish(execution: com.changyang.autojs.execution.ScriptExecution) {
        val millis = execution.engine.getTag(ENGINE_TAG_START_TIME) as Long? ?: return
        val seconds = (System.currentTimeMillis() - millis) / 1000.0
        AutoJs.instance.scriptEngineService.globalConsole
            .verbose(
                com.changyang.app.GlobalAppContext.getString(R.string.text_execution_finished),
                execution.source.toString(),
                seconds
            )
    }

    override fun onException(
        execution: com.changyang.autojs.execution.ScriptExecution,
        e: Throwable
    ) {
        onFinish(execution)
    }

    companion object {
        private const val ENGINE_TAG_START_TIME = "start_time"
    }

}
