package com.changyang.plugin.tiktok.autojs

import android.content.Context
import com.changyang.autojs.engine.LoopBasedJavaScriptEngine
import com.changyang.autojs.engine.encryption.ScriptEncryption
import com.changyang.autojs.script.EncryptedScriptFileHeader
import com.changyang.autojs.script.JavaScriptFileSource
import com.changyang.autojs.script.ScriptSource
import com.changyang.autojs.script.StringScriptSource
import com.changyang.pio.PFiles
import java.io.File
import java.security.GeneralSecurityException

class XJavaScriptEngine(context: Context) :
    com.changyang.autojs.engine.LoopBasedJavaScriptEngine(context) {


    override fun execute(
        source: com.changyang.autojs.script.ScriptSource,
        callback: ExecuteCallback?
    ) {
        if (source is com.changyang.autojs.script.JavaScriptFileSource) {
            try {
                if (execute(source.file)) {
                    return
                }
            } catch (e: Throwable) {
                e.printStackTrace()
                return
            }
        }
        super.execute(source, callback)
    }

    private fun execute(file: File): Boolean {
        val bytes = com.changyang.pio.PFiles.readBytes(file.path)
        if (!EncryptedScriptFileHeader.isValidFile(bytes)) {
            return false
        }
        try {
            super.execute(
                com.changyang.autojs.script.StringScriptSource(
                    file.name,
                    String(ScriptEncryption.decrypt(bytes, EncryptedScriptFileHeader.BLOCK_SIZE))
                )
            )
        } catch (e: GeneralSecurityException) {
            e.printStackTrace()
        }
        return true
    }

}