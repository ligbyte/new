package com.changyang.plugin.tiktok.launch

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.text.TextUtils

import com.changyang.plugin.tiktok.BuildConfig
import com.changyang.plugin.tiktok.autojs.AutoJs
import com.changyang.autojs.engine.encryption.ScriptEncryption
import com.changyang.autojs.execution.ExecutionConfig
import com.changyang.autojs.execution.ScriptExecution
import com.changyang.autojs.project.ProjectConfig
import com.changyang.autojs.script.JavaScriptFileSource
import com.changyang.autojs.script.JavaScriptSource
import com.changyang.pio.PFiles
import com.changyang.pio.UncheckedIOException
import com.changyang.util.MD5

import java.io.File
import java.io.IOException


open class AssetsProjectLauncher(
    private val mAssetsProjectDir: String,
    private val mActivity: Context
) {
    private val mProjectDir: String = File(mActivity.filesDir, "$mAssetsProjectDir/").path
    private val mProjectConfig: com.changyang.autojs.project.ProjectConfig =
        com.changyang.autojs.project.ProjectConfig.fromAssets(
            mActivity,
            com.changyang.autojs.project.ProjectConfig.configFileOfDir(mAssetsProjectDir)
        )
    private val mMainScriptFile: File = File(mProjectDir, mProjectConfig.mainScriptFile)
    private val mHandler: Handler = Handler(Looper.getMainLooper())
    private var mScriptExecution: com.changyang.autojs.execution.ScriptExecution? = null

    init {
        prepare()
    }

    fun launch(activity: Activity) {
        runScript(activity)
    }

    private fun runScript(activity: Activity?) {
        if (mScriptExecution != null && mScriptExecution!!.engine != null &&
            !mScriptExecution!!.engine.isDestroyed
        ) {
            return
        }
        try {
            val source = com.changyang.autojs.script.JavaScriptFileSource(
                "main",
                mMainScriptFile
            )
            val config = ExecutionConfig(workingDirectory = mProjectDir)
            if (source.executionMode and com.changyang.autojs.script.JavaScriptSource.EXECUTION_MODE_UI != 0) {
                config.intentFlags =
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_TASK_ON_HOME
            }
            mScriptExecution = AutoJs.instance.scriptEngineService.execute(source, config)
        } catch (e: Exception) {
            AutoJs.instance.globalConsole.error(e)
        }

    }

    private fun prepare() {
        val projectConfigPath = com.changyang.pio.PFiles.join(
            mProjectDir,
            com.changyang.autojs.project.ProjectConfig.CONFIG_FILE_NAME
        )
        val projectConfig = com.changyang.autojs.project.ProjectConfig.fromFile(projectConfigPath)
        if (!BuildConfig.DEBUG && projectConfig != null &&
            TextUtils.equals(projectConfig.buildInfo.buildId, mProjectConfig.buildInfo.buildId)
        ) {
            initKey(projectConfig)
            return
        }
        initKey(mProjectConfig)
        com.changyang.pio.PFiles.deleteRecursively(File(mProjectDir))
        try {
            com.changyang.pio.PFiles.copyAssetDir(
                mActivity.assets,
                mAssetsProjectDir,
                mProjectDir,
                null
            )
        } catch (e: IOException) {
            throw com.changyang.pio.UncheckedIOException(e)
        }
    }

    private fun initKey(projectConfig: com.changyang.autojs.project.ProjectConfig) {
        val key =
            com.changyang.util.MD5.md5(projectConfig.packageName + projectConfig.versionName + projectConfig.mainScriptFile)
        val vec = com.changyang.util.MD5.md5(projectConfig.buildInfo.buildId + projectConfig.name)
            .substring(0, 16)
        try {
            val fieldKey = ScriptEncryption::class.java.getDeclaredField("mKey")
            fieldKey.isAccessible = true
            fieldKey.set(null, key)
            val fieldVector = ScriptEncryption::class.java.getDeclaredField("mInitVector")
            fieldVector.isAccessible = true
            fieldVector.set(null, vec)
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

}
