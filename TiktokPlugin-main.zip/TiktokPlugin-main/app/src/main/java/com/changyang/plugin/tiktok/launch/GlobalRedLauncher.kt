package com.changyang.plugin.tiktok.launch

import android.annotation.SuppressLint
import com.changyang.app.GlobalAppContext


@SuppressLint("StaticFieldLeak")
object GlobalKuaiShouLauncher :
    AssetsProjectLauncher("kuaishou", com.changyang.app.GlobalAppContext.get())

@SuppressLint("StaticFieldLeak")
object GlobalTiktokLauncher :
    AssetsProjectLauncher("douyin", com.changyang.app.GlobalAppContext.get())

@SuppressLint("StaticFieldLeak")
object GlobalNotificationLuncher :
    AssetsProjectLauncher("notification", com.changyang.app.GlobalAppContext.get())
