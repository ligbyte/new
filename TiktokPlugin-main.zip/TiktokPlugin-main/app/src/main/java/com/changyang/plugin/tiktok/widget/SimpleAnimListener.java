package com.changyang.plugin.tiktok.widget;

import android.view.animation.Animation;


public abstract class SimpleAnimListener implements Animation.AnimationListener {

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }
}
