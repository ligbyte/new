package com.changyang.plugin.tiktok.widget;


public enum Status {
    IDLE, LOADING, ERROR, COMPLETE
}
