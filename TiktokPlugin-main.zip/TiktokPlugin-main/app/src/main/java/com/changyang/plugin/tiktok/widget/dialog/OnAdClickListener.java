package com.changyang.plugin.tiktok.widget.dialog;


public interface OnAdClickListener {
    void onAdClick();
}
