package com.changyang.plugin.tiktok.widget.dialog;


public interface PromptButtonListener {
    void onClick(PromptButton button);
}
