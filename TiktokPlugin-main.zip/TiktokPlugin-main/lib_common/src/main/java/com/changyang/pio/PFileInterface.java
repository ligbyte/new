package com.changyang.pio;


public interface PFileInterface {
    String getPath();
}
