package com.changyang.pio;

import java.io.Closeable;
import java.io.IOException;


public class PReadableBinaryFile implements Closeable {


    @Override
    public void close() throws IOException {

    }
}
