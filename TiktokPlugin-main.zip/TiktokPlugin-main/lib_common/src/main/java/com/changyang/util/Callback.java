package com.changyang.util;


public interface Callback<T> {

    void call(T t);
}
