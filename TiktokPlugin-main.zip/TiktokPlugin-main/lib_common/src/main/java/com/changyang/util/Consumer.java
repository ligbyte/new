package com.changyang.util;

import androidx.annotation.Keep;


@Keep
public interface Consumer<T> {

    void accept(T t);

}
