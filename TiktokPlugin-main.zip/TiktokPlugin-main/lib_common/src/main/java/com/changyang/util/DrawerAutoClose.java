package com.changyang.util;

import android.app.Activity;

import androidx.drawerlayout.widget.DrawerLayout;


public class DrawerAutoClose implements BackPressedHandler {

    private DrawerLayout mDrawerLayout;
    private int mGravity;

    public DrawerAutoClose(DrawerLayout drawerLayout, int gravity) {
        mDrawerLayout = drawerLayout;
        mGravity = gravity;
    }

    @Override
    public boolean onBackPressed(Activity activity) {
        if (mDrawerLayout.isDrawerOpen(mGravity)) {
            mDrawerLayout.closeDrawer(mGravity);
            return true;
        }
        return false;
    }
}