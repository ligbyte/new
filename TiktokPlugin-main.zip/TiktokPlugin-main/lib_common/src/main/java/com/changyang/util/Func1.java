package com.changyang.util;


public interface Func1<T, R> {

    R call(T t);

}
