package com.changyang.util;

import java.util.LinkedHashMap;


public class LimitedHashMap<K, V> extends LinkedHashMap<K, V> {

    private int mMaxSize;

    public LimitedHashMap(int maxSize) {
        super(4, 0.75f, true);
        mMaxSize = maxSize;
    }

    @Override
    protected boolean removeEldestEntry(Entry<K, V> eldest) {
        return size() > mMaxSize;
    }


}
