package com.changyang.util;


public class MessageEvent {

    public String message;
    public Object param;

    public MessageEvent(String message, Object param) {
        this.message = message;
        this.param = param;
    }


    public MessageEvent(String message) {
        this.message = message;
    }

}
