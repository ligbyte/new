package com.changyang.util;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import android.webkit.MimeTypeMap;

import static com.changyang.pio.PFiles.getExtension;

import com.changyang.pio.PFiles;


public class MimeTypes {

    @Nullable
    public static String fromFile(String path) {
        String ext = PFiles.getExtension(path);
        return android.text.TextUtils.isEmpty(ext) ? "*/*" : MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
    }

    @NonNull
    public static String fromFileOr(String path, String defaultType) {
        String mimeType = fromFile(path);
        return mimeType == null ? defaultType : mimeType;
    }
}
