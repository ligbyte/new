package com.changyang.util;


public interface Supplier<T> {
    T get();
}
