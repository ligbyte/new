module.exports = function(runtime, global){
    var sensors = Object.create(runtime.sensors);
    return sensors;
};