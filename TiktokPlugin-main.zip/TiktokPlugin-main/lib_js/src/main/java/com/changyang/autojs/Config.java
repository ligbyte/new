package com.changyang.autojs;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.changyang.autojs.R;


public class Config {

    private static Config sInstance;
    private SharedPreferences mSharedPreferences;
    private final Context mContext;

    public Config(Context context) {
        mContext = context;
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void setInstance(Config instance) {
        if (sInstance != null)
            throw new IllegalStateException();
        sInstance = instance;
    }

    public static Config getInstance() {
        return sInstance;
    }

    public boolean isPrintJavaStackTraceEnabled() {
        return mSharedPreferences.getBoolean(getString(R.string.key_print_java_stack_trace), false);
    }

    private String getString(int resId) {
        return mContext.getString(resId);
    }


}
