package com.changyang.autojs;

import com.changyang.autojs.engine.ScriptEngineManager;
import com.changyang.autojs.runtime.api.Console;
import com.changyang.util.UiHandler;
import com.changyang.autojs.engine.ScriptEngineManager;
import com.changyang.autojs.runtime.ScriptRuntime;
import com.changyang.autojs.runtime.api.Console;
import com.changyang.util.Supplier;
import com.changyang.util.UiHandler;


public class ScriptEngineServiceBuilder {

    ScriptEngineManager mScriptEngineManager;
    Console mGlobalConsole;
    UiHandler mUiHandler;

    public ScriptEngineServiceBuilder() {

    }

    public ScriptEngineServiceBuilder uiHandler(UiHandler uiHandler) {
        mUiHandler = uiHandler;
        return this;
    }

    public ScriptEngineServiceBuilder engineManger(ScriptEngineManager manager) {
        mScriptEngineManager = manager;
        return this;
    }

    public ScriptEngineServiceBuilder globalConsole(Console console) {
        mGlobalConsole = console;
        return this;
    }

    public ScriptEngineService build() {
        return new ScriptEngineService(this);
    }


}
