package com.changyang.autojs.core.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.view.accessibility.AccessibilityNodeInfo
import androidx.annotation.RequiresApi
import com.changyang.autojs.annotation.ScriptInterface
import com.changyang.autojs.runtime.ScriptRuntime
import com.changyang.autojs.runtime.accessibility.AccessibilityConfig
import com.changyang.automator.GlobalActionAutomator
import com.changyang.automator.UiObject
import com.changyang.automator.simple_action.ActionFactory
import com.changyang.automator.simple_action.ActionTarget
import com.changyang.automator.simple_action.SimpleAction
import com.changyang.util.DeveloperUtils
import com.changyang.util.ScreenMetrics


class SimpleActionAutomator(
    private val mAccessibilityBridge: com.changyang.autojs.core.accessibility.AccessibilityBridge,
    private val mScriptRuntime: com.changyang.autojs.runtime.ScriptRuntime
) {

    private lateinit var mGlobalActionAutomator: GlobalActionAutomator

    private var mScreenMetrics: com.changyang.util.ScreenMetrics? = null

    private val isRunningPackageSelf: Boolean
        get() = com.changyang.util.DeveloperUtils.isSelfPackage(mAccessibilityBridge.infoProvider.latestPackage)

    @com.changyang.autojs.annotation.ScriptInterface
    fun text(text: String, i: Int): ActionTarget {
        return ActionTarget.TextActionTarget(text, i)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun bounds(left: Int, top: Int, right: Int, bottom: Int): ActionTarget {
        return ActionTarget.BoundsActionTarget(Rect(left, top, right, bottom))
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @com.changyang.autojs.annotation.ScriptInterface
    fun editable(i: Int): ActionTarget {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(Build.VERSION_CODES.LOLLIPOP)
        return ActionTarget.EditableActionTarget(i)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun id(id: String): ActionTarget {
        return ActionTarget.IdActionTarget(id)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun click(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_CLICK))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun longClick(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_LONG_CLICK))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollUp(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollDown(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollBackward(i: Int): Boolean {
        return performAction(
            ActionFactory.createScrollAction(
                AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD,
                i
            )
        )
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollForward(i: Int): Boolean {
        return performAction(
            ActionFactory.createScrollAction(
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD,
                i
            )
        )
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollMaxBackward(): Boolean {
        return performAction(ActionFactory.createScrollMaxAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun scrollMaxForward(): Boolean {
        return performAction(ActionFactory.createScrollMaxAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun focus(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_FOCUS))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun select(target: ActionTarget): Boolean {
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_SELECT))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    fun setText(target: ActionTarget, text: String): Boolean {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(Build.VERSION_CODES.LOLLIPOP)
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_SET_TEXT, text))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    fun appendText(target: ActionTarget, text: String): Boolean {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(Build.VERSION_CODES.LOLLIPOP)
        return performAction(target.createAction(UiObject.ACTION_APPEND_TEXT, text))
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun back(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun home(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    fun powerDialog(): Boolean {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(Build.VERSION_CODES.LOLLIPOP)
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun notifications(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun quickSettings(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    fun recents(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun splitScreen(): Boolean {
        return performGlobalAction(AccessibilityService.GLOBAL_ACTION_TOGGLE_SPLIT_SCREEN)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun gesture(start: Long, duration: Long, vararg points: IntArray): Boolean {
        prepareForGesture()
        return mGlobalActionAutomator.gesture(start, duration, *points)
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    fun gestureAsync(start: Long, duration: Long, vararg points: IntArray) {
        prepareForGesture()
        mGlobalActionAutomator.gestureAsync(start, duration, *points)
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    fun gestures(strokes: Any): Boolean {
        prepareForGesture()
        @Suppress("UNCHECKED_CAST")
        return mGlobalActionAutomator.gestures(*strokes as Array<GestureDescription.StrokeDescription>)
    }

    //如果这里用GestureDescription.StrokeDescription[]为参数，安卓7.0以下会因为找不到这个类而报错
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun gesturesAsync(strokes: Any) {
        prepareForGesture()
        @Suppress("UNCHECKED_CAST")
        mGlobalActionAutomator.gesturesAsync(*strokes as Array<GestureDescription.StrokeDescription>)
    }

    private fun prepareForGesture() {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(24)
        if (!::mGlobalActionAutomator.isInitialized) {
            mGlobalActionAutomator =
                GlobalActionAutomator(Handler(mScriptRuntime.loopers.servantLooper)) {
                    ensureAccessibilityServiceEnabled()
                    return@GlobalActionAutomator mAccessibilityBridge.service!!
                }
        }
        mGlobalActionAutomator.setScreenMetrics(mScreenMetrics)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun click(x: Int, y: Int): Boolean {
        prepareForGesture()
        return mGlobalActionAutomator.click(x, y)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun press(x: Int, y: Int, delay: Int): Boolean {
        prepareForGesture()
        return mGlobalActionAutomator.press(x, y, delay)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun longClick(x: Int, y: Int): Boolean {
        prepareForGesture()
        return mGlobalActionAutomator.longClick(x, y)
    }

    @com.changyang.autojs.annotation.ScriptInterface
    @RequiresApi(api = Build.VERSION_CODES.N)
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, delay: Int): Boolean {
        prepareForGesture()
        return mGlobalActionAutomator.swipe(x1, y1, x2, y2, delay.toLong())
    }

    private fun performGlobalAction(action: Int): Boolean {
        ensureAccessibilityServiceEnabled()
        val service = mAccessibilityBridge.service ?: return false
        return service.performGlobalAction(action)
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @com.changyang.autojs.annotation.ScriptInterface
    fun paste(target: ActionTarget): Boolean {
        com.changyang.autojs.runtime.ScriptRuntime.requiresApi(18)
        return performAction(target.createAction(AccessibilityNodeInfo.ACTION_PASTE))
    }

    private fun ensureAccessibilityServiceEnabled() {
        mAccessibilityBridge.ensureServiceEnabled()
    }

    private fun performAction(simpleAction: SimpleAction): Boolean {
        ensureAccessibilityServiceEnabled()
        if (com.changyang.autojs.runtime.accessibility.AccessibilityConfig.isUnintendedGuardEnabled() && isRunningPackageSelf) {
            return false
        }
        val roots = mAccessibilityBridge.windowRoots().filter { it != null }
        if (roots.isEmpty())
            return false
        var succeed = true
        for (root in roots) {
            succeed = succeed and simpleAction.perform(UiObject.createRoot(root))
        }
        return succeed
    }

    fun setScreenMetrics(metrics: com.changyang.util.ScreenMetrics) {
        mScreenMetrics = metrics
    }

}
