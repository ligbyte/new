package com.changyang.autojs.core.database;

public interface DatabaseVoidCallback {
    void handleEvent();
}
