package com.changyang.autojs.core.database;

public interface TransactionCallback {
    void handleEvent(Transaction transaction);
}
