package com.changyang.autojs.core.eventloop;

public class SimpleEvent {

    public boolean consumed = false;
}
