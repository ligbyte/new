package com.changyang.autojs.core.ui.inflater;

public interface ShouldCallOnFinishInflate {

    void onFinishDynamicInflate();
}
