package com.changyang.autojs.core.ui.inflater.inflaters;

import androidx.annotation.Nullable;

import com.changyang.autojs.core.graphics.ScriptCanvasView;
import com.changyang.autojs.runtime.ScriptRuntime;
import com.changyang.autojs.core.graphics.ScriptCanvasView;
import com.changyang.autojs.core.ui.inflater.ResourceParser;
import com.changyang.autojs.core.ui.inflater.ViewCreator;
import com.changyang.autojs.runtime.ScriptRuntime;


public class CanvasViewInflater extends BaseViewInflater<ScriptCanvasView> {

    private ScriptRuntime mScriptRuntime;

    public CanvasViewInflater(ResourceParser resourceParser, ScriptRuntime runtime) {
        super(resourceParser);
        mScriptRuntime = runtime;
    }

    @Nullable
    @Override
    public ViewCreator<ScriptCanvasView> getCreator() {
        return (context, attrs) -> new ScriptCanvasView(context, mScriptRuntime);
    }
}
