package com.changyang.autojs.execution;


public class SimpleScriptExecutionListener implements ScriptExecutionListener {

    @Override
    public void onStart(ScriptExecution execution) {

    }

    @Override
    public void onSuccess(ScriptExecution execution, Object result) {

    }

    @Override
    public void onException(ScriptExecution execution, Throwable e) {

    }
}
