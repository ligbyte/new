package com.changyang.autojs.rhino;

import org.mozilla.javascript.ImporterTopLevel;

public class TopLevelScope extends ImporterTopLevel {
}
