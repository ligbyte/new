package com.changyang.autojs.runtime.exception;


public class ScriptEnvironmentException extends ScriptException {
    public ScriptEnvironmentException(String s) {
        super(s);
    }
}
