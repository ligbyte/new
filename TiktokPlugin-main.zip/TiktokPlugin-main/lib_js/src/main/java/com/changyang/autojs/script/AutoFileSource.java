package com.changyang.autojs.script;

import com.changyang.pio.PFiles;
import com.changyang.pio.PFiles;

import java.io.File;


public class AutoFileSource extends ScriptSource {

    public static final String ENGINE = AutoFileSource.class.getName() + ".Engine";
    private File mFile;

    public AutoFileSource(File file) {
        super(PFiles.getNameWithoutExtension(file.getAbsolutePath()));
        mFile = file;
    }

    public AutoFileSource(String path) {
        this(new File(path));
    }


    @Override
    public String getEngineName() {
        return ENGINE;
    }

    public File getFile() {
        return mFile;
    }

    @Override
    public String toString() {
        return mFile.toString();
    }
}
