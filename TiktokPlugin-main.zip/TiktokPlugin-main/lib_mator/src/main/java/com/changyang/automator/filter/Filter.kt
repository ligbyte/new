package com.changyang.automator.filter

import com.changyang.automator.UiObject


interface Filter {

    fun filter(node: UiObject): Boolean

}
