package com.changyang.automator.filter

import com.changyang.automator.UiObject


interface KeyGetter {

    fun getKey(nodeInfo: UiObject): String?
}
