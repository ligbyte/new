package com.changyang.automator.filter

import com.changyang.automator.UiObject


class StringEndsWithFilter(private val mSuffix: String, private val mKeyGetter: KeyGetter) :
    Filter {

    override fun filter(node: UiObject): Boolean {
        val key = mKeyGetter.getKey(node)
        return key != null && key.endsWith(mSuffix)
    }

    override fun toString(): String {
        return mKeyGetter.toString() + "EndsWith(\"" + mSuffix + "\")"
    }
}
