package com.changyang.automator.filter

import com.changyang.automator.UiObject


class StringEqualsFilter(private val mValue: String, private val mKeyGetter: KeyGetter) : Filter {

    override fun filter(node: UiObject): Boolean {
        val key = mKeyGetter.getKey(node)
        return if (key != null) {
            key == mValue
        } else false
    }

    override fun toString(): String {
        return mKeyGetter.toString() + "(\"" + mValue + "\")"
    }
}
