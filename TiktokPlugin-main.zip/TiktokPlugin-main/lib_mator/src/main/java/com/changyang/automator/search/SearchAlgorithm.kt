package com.changyang.automator.search

import com.changyang.automator.UiObject
import com.changyang.automator.filter.Filter

interface SearchAlgorithm {

    fun search(root: UiObject, filter: Filter, limit: Int = Int.MAX_VALUE): ArrayList<UiObject>
}