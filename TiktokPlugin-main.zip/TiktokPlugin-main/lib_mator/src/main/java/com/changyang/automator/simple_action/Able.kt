package com.changyang.automator.simple_action

import android.view.accessibility.AccessibilityNodeInfo
import com.changyang.automator.UiObject
import com.changyang.util.SparseArrayEntries


interface Able {

    fun isAble(node: UiObject): Boolean

    companion object {

        val ABLE_MAP = com.changyang.util.SparseArrayEntries<Able>()
            .entry(AccessibilityNodeInfo.ACTION_CLICK, object : Able {
                override fun isAble(nodeInfo: UiObject): Boolean {
                    return nodeInfo.isClickable
                }
            })
            .entry(AccessibilityNodeInfo.ACTION_LONG_CLICK, object : Able {
                override fun isAble(nodeInfo: UiObject): Boolean {
                    return nodeInfo.isLongClickable
                }
            })
            .entry(AccessibilityNodeInfo.ACTION_FOCUS, object : Able {
                override fun isAble(nodeInfo: UiObject): Boolean {
                    return nodeInfo.isFocusable
                }
            })
            .entry(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD, object : Able {
                override fun isAble(nodeInfo: UiObject): Boolean {
                    return nodeInfo.isScrollable
                }
            })
            .entry(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD, object : Able {
                override fun isAble(nodeInfo: UiObject): Boolean {
                    return nodeInfo.isScrollable
                }
            })
            .sparseArray()
    }

}
