package com.collect_beautiful_video.bean;

public class AvailableCount {
  public String activationTime;
  public int availableCount;
  public String expireTime;
  public String invitationCode;
  public int isBand;
  public int isExpired;
  public int usedCount;
  public String validDay;
}
