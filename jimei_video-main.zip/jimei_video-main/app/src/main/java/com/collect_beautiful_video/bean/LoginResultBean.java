package com.collect_beautiful_video.bean;

import org.json.JSONObject;

public class LoginResultBean {
  public String avatarUrl;
  public String nickName;
  public String openId;
  public String sessionKey;
  public String token;
  public String expireTime;
  public long surplusCount;
  public String validDay;
  public String id;

}
