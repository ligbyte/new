package com.collect_beautiful_video.bean;

import org.json.JSONObject;

public class PicBean {
  public String id;
  public long height;
  public int isChoose;
  public int isDim;
  public String localPath;
  public String url;

}
