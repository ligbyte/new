package com.collect_beautiful_video.bean;

import org.json.JSONObject;

public class SendMessageBean {
  private String msg;
  private int code;
  private JSONObject data;
}
