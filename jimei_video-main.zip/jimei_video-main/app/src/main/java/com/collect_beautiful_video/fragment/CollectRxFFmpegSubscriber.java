package com.collect_beautiful_video.fragment;

import io.microshow.rxffmpeg.RxFFmpegSubscriber;

public class CollectRxFFmpegSubscriber extends RxFFmpegSubscriber {
    @Override
    public void onFinish() {

    }

    @Override
    public void onProgress(int progress, long progressTime) {

    }

    @Override
    public void onCancel() {

    }

    @Override
    public void onError(String message) {

    }
}
