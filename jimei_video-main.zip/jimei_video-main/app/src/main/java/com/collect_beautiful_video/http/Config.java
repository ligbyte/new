package com.collect_beautiful_video.http;

public class Config {

    public  static final String baseUrl=" https://jm.changyangdt.com/";

}
