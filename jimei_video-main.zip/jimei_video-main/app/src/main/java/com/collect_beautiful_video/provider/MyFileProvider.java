package com.collect_beautiful_video.provider;

import androidx.core.content.FileProvider;

public class MyFileProvider extends FileProvider {
}
