package com.collect_beautiful_video.task;

/**
 * task priority
 *
 * @author ddnosh
 * @website http://blog.csdn.net/ddnosh
 */
public enum Priority {
    HIGH, NORMAL, LOW
}
