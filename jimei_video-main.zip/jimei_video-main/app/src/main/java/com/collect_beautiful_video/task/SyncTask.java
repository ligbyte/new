package com.collect_beautiful_video.task;

public interface SyncTask {

  void doTask();
}
