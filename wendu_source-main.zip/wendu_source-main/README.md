# kotlinMvvm

kotlin mvvm结构的框架处理