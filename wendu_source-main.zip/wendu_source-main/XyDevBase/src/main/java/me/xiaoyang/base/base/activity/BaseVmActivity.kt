package me.xiaoyang.base.base.activity

import android.content.res.Configuration
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import me.xiaoyang.base.base.viewmodel.BaseViewModel
import me.xiaoyang.base.ext.getVmClazz
import me.xiaoyang.base.network.manager.NetState
import me.xiaoyang.base.network.manager.NetworkStateManager
import com.ligbyte.lib.theme.ThemeViewEntities

import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme

import com.ligbyte.lib.theme.DarkMode







/**
 * 作者　:  xiaoyangyan
 * 时间　: 2019/12/12
 * 描述　: ViewModelActivity基类，把ViewModel注入进来了
 */
abstract class BaseVmActivity<VM : BaseViewModel> : AppCompatActivity() {

    /**
     * 是否需要使用DataBinding 供子类BaseVmDbActivity修改，用户请慎动
     */
    private var isUserDb = false

    lateinit var mViewModel: VM
    private var activityTheme: ActivityTheme = ActivityTheme(this)
    private val themeViewEntities: ThemeViewEntities = ThemeViewEntities()
    abstract fun layoutId(): Int

    abstract fun initView(savedInstanceState: Bundle?)

    abstract fun showLoading(message: String = "请求网络中...")

    abstract fun dismissLoading()

    override fun onCreate(savedInstanceState: Bundle?) {
        initTheme();
        super.onCreate(savedInstanceState)
        if (!isUserDb) {
            setContentView(layoutId())
        } else {
            initDataBind()
        }
        init(savedInstanceState)
    }

    private fun init(savedInstanceState: Bundle?) {
        mViewModel = createViewModel()
        registerUiChange()
        initView(savedInstanceState)
        createObserver()
        NetworkStateManager.instance.mNetworkStateCallback.observeInActivity(this, Observer {
            onNetworkStateChanged(it)
        })
    }

    /**
     * 网络变化监听 子类重写
     */
    open fun onNetworkStateChanged(netState: NetState) {}

    /**
     * 创建viewModel
     */
    private fun createViewModel(): VM {
        return ViewModelProvider(this).get(getVmClazz(this))
    }

    /**
     * 创建LiveData数据观察者
     */
    abstract fun createObserver()

    /**
     * 注册UI 事件
     */
    private fun registerUiChange() {
        //显示弹窗
        mViewModel.loadingChange.showDialog.observeInActivity(this, Observer {
            showLoading(it)
        })
        //关闭弹窗
        mViewModel.loadingChange.dismissDialog.observeInActivity(this, Observer {
            dismissLoading()
        })
    }

    /**
     * 将非该Activity绑定的ViewModel添加 loading回调 防止出现请求时不显示 loading 弹窗bug
     * @param viewModels Array<out BaseViewModel>
     */
    protected fun addLoadingObserve(vararg viewModels: BaseViewModel){
        viewModels.forEach {viewModel ->
            //显示弹窗
            viewModel.loadingChange.showDialog.observeInActivity(this, Observer {
                showLoading(it)
            })
            //关闭弹窗
            viewModel.loadingChange.dismissDialog.observeInActivity(this, Observer {
                dismissLoading()
            })
        }
    }

    fun userDataBinding(isUserDb: Boolean) {
        this.isUserDb = isUserDb
    }

    /**
     * 供子类BaseVmDbActivity 初始化Databinding操作
     */
    open fun initDataBind() {}


    private fun initTheme() {
        configTheme(activityTheme)
        activityTheme.assembleThemeBeforeInflate()
    }

    /**
     * 配置Activity的主题
     *
     * @param activityTheme Activity主题
     */
    open fun configTheme(activityTheme: ActivityTheme?){

    }

    fun getThemeViewEntities(): ThemeViewEntities {
        return themeViewEntities
    }

    /**
     * 设置StatusBar的背景色
     *
     * @param color Color
     */
    open fun setStatusBarColor(color: Int) {
        activityTheme.setStatusBarColor(color)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val mode = MultiTheme.getDarkMode()
        if (mode == DarkMode.followSystem) {
            val uiMode: Int = newConfig.uiMode and Configuration.UI_MODE_NIGHT_MASK
            if (uiMode == Configuration.UI_MODE_NIGHT_YES) {
                MultiTheme.d("MultiTheme", "onConfigurationChanged mode:UI_MODE_NIGHT_YES")
                MultiTheme.setAppTheme(MultiTheme.DARK_THEME)
            } else {
                MultiTheme.d("MultiTheme", "onConfigurationChanged mode:UI_MODE_NIGHT_NO")
                MultiTheme.setAppTheme(MultiTheme.sDefaultThemeIndex)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (activityTheme != null) {
            activityTheme.destroy()
        }
        themeViewEntities.clear()
    }

}