package me.xiaoyang.base.network.manager

/**
 * 作者　:  xiaoyangyan
 * 时间　: 2020/5/2
 * 描述　: 网络变化实体类
 */
class NetState(
    var isSuccess: Boolean = true
)