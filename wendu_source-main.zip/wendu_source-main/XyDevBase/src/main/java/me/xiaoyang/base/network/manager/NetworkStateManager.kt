package me.xiaoyang.base.network.manager

import me.xiaoyang.base.callback.livedata.event.EventLiveData

/**
 * 作者　:  xiaoyangyan
 * 时间　: 2020/5/2
 * 描述　: 网络变化管理者
 */
class NetworkStateManager private constructor() {

    val mNetworkStateCallback = EventLiveData<NetState>()

    companion object {
        val instance: NetworkStateManager by lazy(mode = LazyThreadSafetyMode.SYNCHRONIZED) {
            NetworkStateManager()
        }
    }

}