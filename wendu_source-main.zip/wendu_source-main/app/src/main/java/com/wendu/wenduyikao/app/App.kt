package com.wendu.wenduyikao.app

import androidx.multidex.MultiDex
import com.easefun.polyvsdk.PolyvSDKClient
import com.kingja.loadsir.callback.SuccessCallback
import com.kingja.loadsir.core.LoadSir
import com.plv.thirdpart.blankj.utilcode.util.Utils
import com.tencent.bugly.Bugly
import com.tencent.mmkv.MMKV
import com.umeng.commonsdk.UMConfigure
import com.umeng.commonsdk.utils.UMUtils
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.UmengThirdUtil
import com.wendu.wenduyikao.app.weight.loadCallBack.EmptyCallback
import com.wendu.wenduyikao.app.weight.loadCallBack.ErrorCallback
import com.wendu.wenduyikao.app.weight.loadCallBack.LoadingCallback
import com.wendu.wenduyikao.util.PolyvUtil
import me.xiaoyang.base.base.BaseApp
import me.xiaoyang.base.ext.util.jetpackMvvmLog
import me.xiaoyang.base.ext.util.logd
import org.litepal.LitePal
import com.ligbyte.lib.theme.MultiTheme
import com.umeng.analytics.MobclickAgent


/**
 * 作者　:  xiaoyangyan
 * 时间　: 2019/12/23
 * 描述　:
 */

class App : BaseApp() {

    companion object {
        lateinit var instance: App
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        MultiDex.install(this)
        Utils.init(this)
        MMKV.initialize(this.filesDir.absolutePath + "/mmkv")
        //界面加载管理 初始化
        LoadSir.beginBuilder()
            .addCallback(LoadingCallback())//加载
            .addCallback(ErrorCallback())//错误
            .addCallback(EmptyCallback())//空
            .setDefaultCallback(SuccessCallback::class.java)//设置默认加载状态页
            .commit()
        //初始化Bugly
        val context = applicationContext
        // 获取当前包名
        val packageName = context.packageName
        // 获取当前进程名
        // 设置是否为上报进程
//        val strategy = CrashReport.UserStrategy(context)
//        strategy.isUploadProcess = processName == null || processName == packageName
        // 初始化Bugly

        jetpackMvvmLog = BuildConfig.DEBUG
        LitePal.initialize(this)
        initUmengSdk()
//        PolyvUtil.initPolyvVod()
        // 设置权限申请拦截器（全局设置）
//        XXPermissions.setInterceptor(PermissionInterceptor())

//        //防止项目崩溃，崩溃后打开错误界面
//        Builder.create()
//            .backgroundMode(BACKGROUND_MODE_SILENT) //default: CaocConfig.BACKGROUND_MODE_SHOW_CUSTOM
//            .enabled(true)//是否启用CustomActivityOnCrash崩溃拦截机制 必须启用！不然集成这个库干啥？？？
//            .showErrorDetails(false) //是否必须显示包含错误详细信息的按钮 default: true
//            .showRestartButton(false) //是否必须显示“重新启动应用程序”按钮或“关闭应用程序”按钮default: true
//            .logErrorOnRestart(false) //是否必须重新堆栈堆栈跟踪 default: true
//            .trackActivities(true) //是否必须跟踪用户访问的活动及其生命周期调用 default: false
//            .minTimeBetweenCrashesMs(2000) //应用程序崩溃之间必须经过的时间 default: 3000
//            .restartActivity(WelcomeActivity::class.java) // 重启的activity
//            .errorActivity(ErrorActivity::class.java) //发生错误跳转的activity
//            .apply()
        initTheme()
    }

    private fun initTheme() {
        MultiTheme.init(this)
        MultiTheme.enableDebug()
        MultiTheme.setDefaultAppTheme(0)
    }

    /**
     * 初始化友盟组件
     */
    fun initUmengSdk() {
        if (CacheUtil.isOpenPrompt()) {
            UMConfigure.setLogEnabled(true)
//        UMConfigure.init(
//            context,
//            "613c6826520cc86a1d4803ff",
//            "Umeng",
//            UMConfigure.DEVICE_TYPE_PHONE,
//            "e6d4a90b2364efff14b4ae213c21a719"
//        );
            //预初始化

            //个人测试 62c4e65430121a652b60619c
            //正式  613c6826520cc86a1d4803ff
            UMConfigure.preInit(this, "613c6826520cc86a1d4803ff", "Umeng");
            val isMainProcess = UMUtils.isMainProgress(this);
            //MobclickAgent.setScenarioType(this, MobclickAgent.EScenarioType.E_UM_NORMAL);
            //测试 cc98545475        正式 b632124216
            Bugly.init(this, if (BuildConfig.DEBUG) "xxx" else "b632124216", BuildConfig.DEBUG)
            "".logd()
            PolyvUtil.initPolyvVod()
            if (isMainProcess) {
                //App启动速度优化：可以在子线程中调用SDK初始化接口

                //App启动速度优化：可以在子线程中调用SDK初始化接口
                Thread {
                    UmengThirdUtil.initAppPush(this)
                }.start()
            }
        }

    }
}

