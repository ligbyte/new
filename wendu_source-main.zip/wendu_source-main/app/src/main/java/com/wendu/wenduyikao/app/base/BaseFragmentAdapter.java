package com.wendu.wenduyikao.app.base;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * author : Android 轮子哥
 * github : https://github.com/getActivity/AndroidProject
 * time   : 2018/10/18
 * desc   : FragmentPagerAdapter 基类
 */
public class BaseFragmentAdapter<F extends Fragment> extends FragmentPagerAdapter {

    /**
     * Fragment集合
     */
    private final List<F> mFragmentSet = new ArrayList<>();

    /**
     * Title集合
     */
    private final List<String> mTitleSet = new ArrayList<>();

    /**
     * 当前显示的Fragment
     */
    private F mCurrentFragment;

    /**
     * 当前显示的Title
     */
    private String mCurrentTitle;
    private FragmentManager fragmentManager;

    public BaseFragmentAdapter(FragmentActivity activity) {
        this(activity.getSupportFragmentManager());
    }

    public BaseFragmentAdapter(Fragment fragment) {
        this(fragment.getChildFragmentManager());
    }

    public BaseFragmentAdapter(FragmentManager manager) {
        super(manager);
        fragmentManager = manager;
    }

    /**
     * FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT 懒加载
     *
     * @param manager
     * @param behavior BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
     */
    public BaseFragmentAdapter(FragmentManager manager, int behavior) {
        super(manager, behavior);
    }

    @NonNull
    @Override
    public F getItem(int position) {
        return mFragmentSet.get(position);
    }

    @Override
    public int getCount() {
        return mFragmentSet.size();
    }

    @SuppressWarnings("unchecked")
    @Override
    public void setPrimaryItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        if (getCurrentFragment() != object) {
            // 记录当前的Fragment对象
            mCurrentFragment = (F) object;
        }
        if (mTitleSet.size() > 0) {
            mCurrentTitle = mTitleSet.get(position);
        }

        super.setPrimaryItem(container, position, object);
    }

    public void addFragment(F fragment) {
        mFragmentSet.add(fragment);
    }

    public void addFragment(F fragment, int index) {
//        fragmentManager.beginTransaction()
//                .add(fragment,)
        mFragmentSet.add(index, fragment);
        notifyDataSetChanged();

    }

    public void setFragment(List<F> mFragments) {
        mFragmentSet.clear();
        mFragmentSet.addAll(mFragments);
    }

    public void clearFragment() {
        mFragmentSet.clear();
        notifyDataSetChanged();
    }

    public void setTitleSet(List<String> titleSet) {
        mTitleSet.clear();
        mTitleSet.addAll(titleSet);
    }

    public void setTitleSet(String[] titleSet) {
        mTitleSet.clear();
        Collections.addAll(mTitleSet, titleSet);
    }

    /**
     * 获取Fragment集合
     */
    public List<F> getAllFragment() {
        return mFragmentSet;
    }

    /**
     * 获取当前的Fragment
     */
    public F getCurrentFragment() {
        return mCurrentFragment;
    }


    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return mTitleSet != null && mTitleSet.size() > 0 ? mTitleSet.get(position) : "";
    }
    @Override
    public int getItemPosition(@NonNull Object object) {
        return POSITION_NONE;
    }
    @Override
    public long getItemId(int position) {
        //修改getItemId   不与位置对应  返回List<Fragment>中Fragment的hashCode
        return mFragmentSet.get(position).hashCode();
    }
}