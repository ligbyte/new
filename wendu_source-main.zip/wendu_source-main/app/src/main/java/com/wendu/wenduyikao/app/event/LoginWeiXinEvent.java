package com.wendu.wenduyikao.app.event;

/**
 * Package:       com.wendu.wenduyikao.app.event
 * ClassName:     LoginWeiXinEvent
 * Author:         xiaoyangyan
 * CreateDate:    8/23/21
 * Description:
 */
public class LoginWeiXinEvent {
    private String code;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
