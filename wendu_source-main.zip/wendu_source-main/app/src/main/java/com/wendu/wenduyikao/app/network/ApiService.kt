package com.wendu.wenduyikao.app.network

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.data.model.bean.*
import okhttp3.MultipartBody
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.*
import java.util.*

interface ApiService {

    companion object {

        const val SERVER_URL = BuildConfig.BASE_URL;
        const val WEB_SERVER_URL = "https://yixue.wendu.com"
//        const val SERVER_URL = "http://www.muyuan68.com"
//        const val SERVER_URL = "https://ykapp.wendu.com"

//        const val SERVER_URL = "http:192.1168.0.115:8091"

    }


    @FormUrlEncoded
    @POST("token")
    suspend fun token(
        @Header("Authorization") Authorization: String,
        @Field("username") username: String,
        @Field("password") pwd: String,
        @Field("grant_type") grant_type: String
    ): LoginInfoEntity

    /**
     * 登录
     */
    @POST("/api/sys/phoneLogin")
    suspend fun login(
        @Body json: JsonObject
    ): ApiResponse<LoginInfoEntity>


    /**
     * 密码登录
     */
    @POST("/api/sys/commonLogin")
    suspend fun loginByPwd(
        @Body json: JsonObject
    ): ApiResponse<LoginInfoEntity>

    /**
     * 微信绑定手机号
     * @param json JsonObject
     * @return ApiResponse<LoginInfoEntity>
     */
    @POST("/api/sys/wxBindPhoneLogin")
    suspend fun wxBindPhone(
        @Body json: JsonObject
    ): ApiResponse<LoginInfoEntity>

    /**
     * qq绑定手机号
     * @param json JsonObject
     * @return ApiResponse<LoginInfoEntity>
     */
    @POST("/api/sys/qqBindPhoneLogin")
    suspend fun qqBindPhone(
        @Body json: JsonObject
    ): ApiResponse<LoginInfoEntity>

    /**
     * 获取验证码
     * @param key String
     * @return ApiResponse<UserInfo>
     */
    @POST("/api/sys/sms")
    suspend fun getCode(
        @Body json: JsonObject
    ): ApiResponse<Any?>

    /**
     * 修改密码/设置密码-登录态下
     * @return ApiResponse<UserInfo>
     */
    @POST("/api/sys/updUserPassword")
    suspend fun updatePwd(
        @Body json: JsonObject
    ): ApiResponse<Any?>

    /**
     * 设置密码
     */
    @POST("/api/sys/updPassword")
    suspend fun setPwd(
        @Body json: JsonObject
    ): ApiResponse<Any?>

    /**
     * 注册
     */
    @FormUrlEncoded
    @POST("user/register")
    suspend fun register(
        @Field("username") username: String, @Field("password") pwd: String, @Field(
            "repassword"
        ) rpwd: String
    ): ApiResponse<Any>

    /**
     * 获取用户详情
     * @param token String?
     * @return ApiResponse<UserInfo>
     */
    @GET("/api/student/management/wdStudentManagement/userInfo")
    suspend fun getUserInfo(@Header("token") token: String): ApiResponse<UserInfo>

    /**
     * 退出登录
     * @param token String
     * @return ApiResponse<Any>
     */
    @GET("/api/sys/logout")
    suspend fun logout(
        @Header("token") token: String
    ): ApiResponse<Any?>

    /**
     * 退出登录
     * @param token String
     * @return ApiResponse<Any>
     */
    @POST("/api/push/wdPushVideo/exitYmCode")
    suspend fun logoutUmeng(
        @Body json: JsonObject
    ): ApiResponse<Any?>

    /**
     * 注册友盟推送
     * @param token String
     * @return ApiResponse<Any>
     */
    @POST("/api/push/wdPushVideo/upYmCode")
    suspend fun registerUmeng(
        @Body json: JsonObject
    ): ApiResponse<String>


    /**
     * 获取专业
     * @param token String
     * @return ApiResponse<List<MajorEntity>>
     */
    @GET("/api/resources/major/wdResourcesMajor/list")
    suspend fun getMajorList(
        @Header("token") token: String
    ): ApiResponse<ArrayList<MajorEntity>>

    /**
     * 获取专业---带分类层级的专业
     */
    @GET("/api/resources/major/wdResourcesMajor/newList")
    suspend fun getNewMajorList(
        @Header("token") token: String
    ): ApiResponse<ArrayList<MajorParentEntity>>

    /**
     * 绑定学员专业
     */
    @GET("/api/sys/bindinMajor")
    suspend fun bindMajor(
        @Header("token") token: String,
        @Query("majorId") majorId: String
    ): ApiResponse<Any?>


    /**
     * 获取收藏题目类型
     */
    @GET("/api/chapter/wdQuestionCollect/type")
    suspend fun getCollectTypeList(
        @Header("token") token: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ArrayList<CollectNumEntity>>


    /**
     * 错题类型
     */
    @GET("/api/questionbank/practice/findByType")
    suspend fun getErrorTypeList(
        @Header("token") token: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ErrorFilterEntity>

    /**
     * 修改用户信息
     * @param token String
     * @param body UserInfo
     * @return ApiResponse<ArrayList<MajorEntity>>
     */
    @PUT("/api/student/management/wdStudentManagement/edit")
    suspend fun updateUserInfo(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>


    /**
     * 验证旧手机号
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any>
     */
    @POST("/api/student/management/wdStudentManagement/checkPhone")
    suspend fun verifyPhone(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 修改手机号
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any>
     */
    @POST("/api/student/management/wdStudentManagement/updatePhone")
    suspend fun updatePhone(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 获取省-学校嵌套结构数据
     * @return ApiResponse<ArrayList<ProvinceInfoEntity>>
     */
    @GET("/api/school/wdSchool/list")
    suspend fun getSchoolList(
    ): ApiResponse<ArrayList<ProvinceInfoEntity>>

    @GET("/api/school/wdSchool/findSchool")
    suspend fun getSchoolByName(
        @Query("nameOrArea") nameOrArea: String
    ): ApiResponse<ArrayList<SchoolInfoEntity>>


    /**
     * 微信登录
     * @param Authorization String
     * @param code String
     * @return Call<BaseResponse<Any?>>
     */
    @POST("/api/sys/wxLogin")
    suspend fun wxLogin(
//        @Header("Authorization") Authorization: String,
        @Body body: JsonObject
    ): ApiResponse<WxLoginInfoEntity>

    @POST("/api/sys/wxLogin")
    suspend fun wxLogin2(
//        @Header("Authorization") Authorization: String,
        @Body body: JsonObject
    ): ApiResponse<WxLoginInfo2Entity>

    @POST("/api/sys/qqLogin")
    suspend fun qqLogin(
//        @Header("Authorization") Authorization: String,
        @Body body: JsonObject
    ): ApiResponse<WxLoginInfoEntity>

    /**
     * 阿里一键登录
     * @param Authorization String
     * @param code String
     * @return Call<BaseResponse<Any?>>
     */
    @GET("/api/sys/aliyunLogin/{token}")
    suspend fun aliLogin(
//        @Header("Authorization") Authorization: String,
        @Path("token") token: String,
        @Query("location") location: String
    ): ApiResponse<LoginInfoEntity>

    /**---------------------首页相关--------------------------**/
    /**
     * 查询首页直播中
     */
    @HTTP(method = "GET", path = "/api/courseapi/findByMajorLive")
    suspend fun getLiveNow(
        @Query("majorId") majorId: String
    ): ApiResponse<MutableList<LiveCourseEntity>>

    /**
     * 首页运营计划展示否
     */
    @HTTP(method = "GET", path = "/api/student/management/wdStudentManagement/findUserOperationPlan")
    suspend fun findUserOperationPlan(@Query("token") Authorization: String
    ):ApiResponse<UserPlanEntity>

    /**
     * 分页查询首页试听课程
     */
    @HTTP(method = "GET", path = "/api/courseapi/auditionCoursePageList/")
    suspend fun getAuditionCourse(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("majorId") majorId: String,
        @Query("uid") uid: String
    ): ApiResponse<ApiPageResponse<AuditionCourseEntity>>

    /**
     * 分页查询首页试听课程
     */
    @GET("/api/courseapi/auditionCoursePageList/")
    suspend fun getAuditionCourse2(
        @Query("majorId") majorId: String,
        @QueryMap params: Map<String, String>,
        @Query("uid") uid: String
    ): ApiResponse<ApiPagerResponse<ArrayList<AuditionCourseEntity>>>

    /**
     * 首页试听课程-包含试听直播和试听课程
     */
    @GET("/api/courseapi/findByDemoLesson")
    suspend fun getAuditionDemoLesson(
        @Query("majorId") majorId: String
    ): ApiResponse<AuditionDemoLessonEntity>

    /**
     * 分页查询首页试听直播
     */
    @GET("/api/courseapi/auditionLivePageList/")
    suspend fun getAuditionLive(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("majorId") majorId: String,
        @Query("uid") uid: String?
    ): ApiResponse<ApiPageResponse<LiveCourseEntity>>

    @GET("/api/courseapi/auditionLivePageList/")
    suspend fun getAuditionLive2(
        @Query("majorId") majorId: String,
        @Query("uid") uid: String?,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<LiveCourseEntity>>>

    /**
     * 分页查询首页直播预告
     */
    @GET("/api/courseapi/findByLivePreview")
    suspend fun getAuditionLivePreview(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("majorId") majorId: String,
        @Query("uid") uid: String?
    ): ApiResponse<ApiPageResponse<LiveCourseEntity>>


    /**
     * 分页查询首页热销课程
     */
    @GET("/api/courseapi/bestSellerCoursePageList")
    suspend fun getHomeHotCourse(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("majorId") majorId: String
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

    /**
     * 分页查询首页系列课程
     */
    @GET("/api/courseapi/seriesCoursePageList")
    suspend fun getHomeSeriesCourse(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("labelId") labelId: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

    /**
     * 首页热销课程
     */
    @GET("/api/courseapi/bestSellerCoursePageList")
    suspend fun getBestSellerCoursePageList(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("labelId") labelId: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

    /**
     * 分页查询首页直播预告未购买逻辑
     */
    @GET("/api/courseapi/findByNotBuyClasses")
    suspend fun getByNotBuyClasses(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("liveCourseId") liveCourseId: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

    /**
     * 分页查询首页面授课程
     */
    @GET("/api/courseapi/faceCoursePageList")
    suspend fun getFaceCourse(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
        @Query("majorId") majorId: String
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

    /**
     * 首页banner
     */
    @GET("/api/operate/banner/wdOperateBanner/list")
    suspend fun getHomeBanner(
        @Query("majorId") majorId: String
    ): ApiResponse<List<HomeBannerEntity>>


    /**
     * 首页设置考试时间
     */
    @POST("/api/student/examTime/wdStudentExam/add")
    suspend fun setExamTime(
        @Body json: JsonObject
    ): ApiResponse<String>

    /**
     * 获取首页设置考试时间
     */
    @GET("/api/student/examTime/wdStudentExam/queryById")
    suspend fun getExamTime(
        @Query("majorId") majorId: String
    ): ApiResponse<ExamTimeResponse>


    /**
     * 获取试看时常
     */
    @GET("/api/student/management/wdStudentManagement/findLiveCourseTime")
    suspend fun findLiveCourseTime(
        @Header("token") Authorization: String
    ): ApiResponse<FindCourseTimeResponse>


    /**
     * 预约直播
     */
    @POST("/api/push/wdPushVideo/add")
    suspend fun liveAgree(
        @Body json: JsonObject
    ): ApiResponse<String>


    /**---------------------课程班相关--------------------------**/


    /**
     * 提交学习次数
     */
    @GET("/api/courseapi/updateCoursePlayCount")
    suspend fun updateCoursePlayCount(
        @Query("id") resourceId: String
    ): ApiResponse<String>

    /**
     * 获取课件
     */
    @GET("/api/courseapi/queryMaterial")
    suspend fun getCoursePPt(
        @Query("id") resourceId: String
    ): ApiResponse<ArrayList<String>>


    /**
     * 提交学习记录
     */
    @POST("/api/courseapi/addLearn")
    suspend fun submitLearn(
        @Body json: JsonObject
    ): ApiResponse<String>

    /**
     * 提交学习时间
     */
    @POST("/api/course/wdCourseRecord/saveRecord")
    suspend fun submitLearnTime(
        @Body json: JsonObject
    ): ApiResponse<String>


    /**
     * 课程班的资料列表
     */
    @GET("/api/courseapi/classesBooksNew")
    suspend fun getClassBookList(@Query("id") courseClassId: String): ApiResponse<ArrayList<BooksNewEntity>>

    /**
     * 课程详情
     */
    @GET("/api/courseapi/classesDetails")
    suspend fun getClassDetail(@Query("id") courseClassId: String): ApiResponse<CourseClassEntity>

    /**
     * 班级下课程列表
     */
    @GET("/api/courseapi/classesCourse")
    suspend fun getClassCourse(@Query("id") courseClassId: String,@Query("uid") uid: String): ApiResponse<ClassCourseListEntity>

    /**
     * 班级下课程列表-新
     */
    @GET("/api/courseapi/classesCourseNew")
    suspend fun getClassCourseNew(@Query("id") courseClassId: String,@Query("uid") uid: String): ApiResponse<ClassCourseListEntity>

    /**
     * 班级下服务
     */
    @GET("/api/courseapi/classesService")
    suspend fun getClassService(@Query("id") courseClassId: String): ApiResponse<Map<String, String>>

    /**
     * 班级下服务
     */
    @GET("/api/courseapi/classesType")
    suspend fun getClassType(@Query("id") courseClassId: String): ApiResponse<ArrayList<ClassTypeEntity>>


    /**---------------------面授详情--------------------------**/

    /**
     * 分页查询首页试听课程
     */
    @HTTP(method = "GET", path = "/api/courseapi/faceClassesDetails")
    suspend fun getFaceInfo(@Query("id") faceCourseId: String): ApiResponse<FaceCourseInfoEntity>

    @GET("/api/courseapi/faceClassesDetailsNew")
    suspend fun getFaceClassesDetailsNew(@Query("id") faceCourseId: String): ApiResponse<FaceCourseInfoEntity>


    /**---------------------课程下相关接口--------------------------**/

    /**
     * 分页查询课程答疑列表
     */
    @HTTP(method = "GET", path = "/api/courseapi/queryCourseDetails")
    suspend fun getCourseCatalog(
        @Query("classid") classid: String,
        @Query("faceClassesId") faceClassesId: String?,
        @Query("courseid") courseid: String,
        @Query("uid") uid: String?
    ): ApiResponse<CourseCatalogEntity>

    /**
     * 分页查询课程答疑列表
     */
    @HTTP(method = "GET", path = "/api/courseapi/queryCourseDetails")
    suspend fun getCourseCatalog(
        @Query("classid") classid: String,
        @Query("courseid") courseid: String,
        @Query("uid") uid: String?
    ): ApiResponse<CourseCatalogEntity>

    /**---------------------学习中心--------------------------**/
    /**
     * 学习-模块课程详情
     */
    @GET("/api/api/myStudent/findByModuleOfCoursesDetail")
    suspend fun findByModuleOfCoursesDetail(
        @Query("courseId") courseid: String
    ): ApiResponse<StudyModuleCourseInfoEntity>

    /**
     * 学习-课程详情
     */
    @GET("/api/api/myStudent/findBySeriesOfCoursesDetail")
    suspend fun findBySeriesOfCoursesDetail(
        @Query("classesId") courseid: String,
        @Query("classesTypeId") classesTypeId: String
    ): ApiResponse<StudySeriesCourseInfoEntity>

    /**
     * 查询我的课程
     */
    @HTTP(method = "GET", path = "/api/courseapi/myCourse")
    suspend fun getMyClassList(): ApiResponse<MutableList<CourseClassEntity>>

    /**
     * 分页查询课程答疑列表
     */
    @HTTP(method = "GET", path = "/api/wdClass/wdClassesAnswer/wdClassesAnswer/findByClasses")
    suspend fun getCourseQuestionList(
        @Query("classesId") classesId: String,
        @Query("type") type: Int,
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
    ): ApiResponse<ApiPageResponse<CourseQuestionEntity>>

    /**
     * 提交课程答疑
     */
    @POST("/api/wdClass/wdClassesAnswer/wdClassesAnswer/saveAnswer")
    suspend fun courseQuestion(
        @Body json: JsonObject
    ): ApiResponse<String>

    /**
     * 分页查询课程笔记
     */
    @HTTP(method = "GET", path = "/api/wdClass/wdClassesNotes/wdClassesNotes/findByClasses")
    suspend fun getCourseNotesList(
        @Query("classesId") classesId: String,
        @Query("categoryId") categoryId: String,
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int,
    ): ApiResponse<ApiPageResponse<CourseNotesEntity>>


    /**
     * 获取笔记详情
     */
    @GET("/api/wdClass/wdClassesNotes/wdClassesNotes/findByNotesId")
    suspend fun getNoteInfo(
        @Query("notesId") notesId: String,
        @Query("classesId") classesId: String,
    ): ApiResponse<CourseNotesEntity>


    /**
     * 获取考试测评
     */
    @HTTP(method = "GET", path = "/api/wdClass/wdClassesAppraisal/wdClassesAppraisal/list")
    suspend fun getServiceExamList(
        @Query("classesId") classesId: String,
        @Query("type") type: Int,
    ): ApiResponse<ArrayList<ServiceExamEntity>>

    /**
     * 获取直播计划
     */
    @HTTP(method = "GET", path = "/api/courseapi/queryLivePlay")
    suspend fun getLivePlan(
        @Query("classid") classid: String,
    ): ApiResponse<List<LiveCourseEntity>>

    /**
     * 获取直播计划
     */
    @HTTP(method = "GET", path = "/api/courseapi/studyPlan")
    suspend fun getStudyPlan(
        @Query("id") classid: String,
    ): ApiResponse<String>


    /**
     * 获取上次学习
     */
    @HTTP(method = "GET", path = "/api/courseapi/queryCurrentChapter")
    suspend fun getLastStudy(
        @Query("classid") classid: String,
    ): ApiResponse<LiveCourseEntity>


    /**---------------------学习中心-----结束---------------------**/


    /**
     * 获取题库-章节练习
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiBaseResponse<ApiPagerResponse<ArrayList<QuestionCatalogEntity>>>
     */
    @GET("/api/chapter/wdQuestionChapter/list")
    suspend fun getQuestionChapterList(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionCatalogEntity>>

    @GET("/api/chapter/wdQuestionChapter/list")
    suspend fun getQuestionChapterList2(
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionCatalogEntity>>

    /**
     * 获取章列表
     */
    @GET("/api/questionbank/wdQuestionPaper/findByTemplate")
    suspend fun getTemplateList(
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionCatalogEntity>>


    /**
     * 获取题库-章节练习,节数据
     * @param Authorization String
     * @param id String
     * @return ApiResponse<ArrayList<QuestionChapterEntity>>
     */
    @GET("/api/chapter/wdQuestionChapter/listById")
    suspend fun getQuestionChapterListById(
        @Header("token") Authorization: String,
        @Query("id") id: String,
        @Query("majorId") majorId: String,
        @Query("templateId") templateId: String
    ): ApiResponse<ArrayList<QuestionChapterEntity>>

    /**
     * 精品题库-章节练习,节数据
     * @param Authorization String
     * @param id String
     * @return ApiResponse<ArrayList<QuestionChapterEntity>>
     */
    @GET("/api/questionbank/wdQuestionPaper/findByChildTemplate")
    suspend fun getChildTemplateListById(
        @Query("paperId") id: String,
        @Query("childTemplateId") templateId: String
    ): ApiResponse<ArrayList<QuestionChapterEntity>>

    /**
     * 获取真题试卷
     * @param Authorization String
     * @param majorId String
     * @param paperType String  3 历年真题；4 精品题库
     * @return ApiResponse<ArrayList<QuestionChapterEntity>>
     */
    @GET("/api/questionbank/wdQuestionPaper/list")
    suspend fun getQuestionPaperList(
        @Header("token") Authorization: String,
        @Query("majorId") majorId: String,
        @Query("paperType") paperType: String
    ): ApiResponse<ArrayList<QuestionPaperEntity>>

    /**
     * 题干列表
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ApiPagerResponse<ArrayList<QuestionCatalogEntity>>>
     */
    @GET("/api/chapter/wdQuestionChapterSubject/list")
    suspend fun getQuestionChapterSubjectList(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<QuestionChapterAllEntity>


    /**
     * 笔记原题
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ApiPagerResponse<ArrayList<QuestionCatalogEntity>>>
     */
    @GET("/api/note/querySubject")
    suspend fun getQuerySubjectByNote(
        @Header("token") Authorization: String,
        @Query("id") id: String
    ): ApiResponse<QuestionInfoEntity>

    @GET("/api/note/querySubject")
    suspend fun getQuerySubjectByNote2(
        @Header("token") Authorization: String,
        @Query("id") id: String
    ): ApiResponse<QuestionPaperInfoEntity>

    /**
     * 错题章节练习原题
     */
    @GET("/api/chapter/wdQuestionChapterSubject/queryById")
    suspend fun getQuestionChapterById(
        @Header("token") Authorization: String,
        @Query("id") id: String
    ): ApiResponse<QuestionInfoEntity>

    /**
     *答题结果集合
     * @param Authorization String
     * @param params Map<String, String>
     * @return ApiResponse<ArrayList<QuestionPracticeEntity>>
     */
    @GET("/api/questionbank/practice/list")
    suspend fun getQuestionPracticeList(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<QuestionPracticeEntity>>>

    /**
     * 提交做题结果
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/questionbank/practice/answerAll")
    suspend fun submitQuestionResult(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 提交试卷做题结果
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/questionbank/practice/answerAll")
    suspend fun submitQuestionPaperResult(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 题库收藏
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ArrayList<QuestionCollectEntity>>
     */
    @GET("/api/chapter/wdQuestionCollect/list")
    suspend fun getQuestionCollectList(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionCollectEntity>>

    /**
     * 获取收藏题型及对应数量
     */
    @GET("/api/chapter/wdQuestionCollect/type")
    suspend fun getQuestionCollectTypeNumList(
        @Header("token") Authorization: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ArrayList<CollectNumEntity>>

    /**
     * 上传图片
     * @param token String
     * @param parts List<Part>
     * @return ApiResponse<DrawImgEntity>
     */
    @Multipart
    @POST("api/student/management/wdStudentManagement/upload")
    suspend fun uploadPhotoFile(
        @Header("token") Authorization: String,
        @Part parts: List<MultipartBody.Part>
    ): ApiResponse<String>

    /**
     * 添加收藏
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/chapter/wdQuestionCollect/add")
    suspend fun addCollect(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<String?>


    /**
     *取消收藏
     * @param token String
     * @param id String
     * @return ApiResponse<Any?>
     */
    @DELETE("/api/chapter/wdQuestionCollect/delete")
    suspend fun delCollect(
        @Header("token") token: String,
        @Query("isCollectId") id: String
    ): ApiResponse<Any?>

    /**
     * 创建笔记
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/note/add")
    suspend fun createNote(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 获取笔记列表
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ApiPagerResponse<ArrayList<NoteInfoEntity>>>
     */
    @GET("/api/note/list")
    suspend fun getNoteList(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<NoteInfoEntity>>>

    /**
     * 模考数据
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<MockInfoEntity>
     */
    @GET("/api/questionbank/paperSubject/wdQPaperSubject/list")
    suspend fun getPaperSubjectList(
        @Header("token") Authorization: String,
        @Query("majorId") majorId: String
    ): ApiResponse<MockInfoEntity>

    /**
     * 获取试卷详情
     * @param Authorization String
     * @param paperId String
     * @return ApiResponse<QuestionPaperEntity>
     */
    @GET("/api/questionbank/wdQuestionPaper/queryById")
    suspend fun getQuestionPaperInfoById(
        @Header("token") Authorization: String,
        @Query("id") paperId: String
    ): ApiResponse<QuestionPaperEntity>


    @GET("/api/questionbank/wdQuestionPaper/queryByPaperId")
    suspend fun getQuestionPaperInfoByPaperId(
        @Header("token") Authorization: String,
        @Query("id") paperId: String
    ): ApiResponse<QuestionPaperEntity>

    /**
     * 获取真题下试卷问题
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ArrayList<QuestionChapterSubjectEntity>>
     */
    @GET("/api/questionbank/wdQuestionPaperSubject/listAll")
    suspend fun getQuestionPaperSubjectList(
        @Header("token") Authorization: String,
        @Query("paperId") paperId: String
    ): ApiResponse<ArrayList<QuestionPaperSubjectEntity>>


    /**
     * 获取每日一练下试卷id
     */
    @GET("/api/questionbank/wdQuestionPaper/queryDailyPractice")
    suspend fun queryDailyPractice(
        @Header("token") Authorization: String,
        @Query("token") token: String,
        @Query("majorId") majorId: String
    ): ApiResponse<QueryDailyPracticeEntity>

    /**
     * 精品题库题目-包含举一反三数据
     */
    @GET("/api/questionbank/wdQuestionPaperSubject/listByQuestionBank")
    suspend fun getQuestionBankList(
        @Header("token") Authorization: String,
        @Query("paperId") paperId: String,
        @Query("templateId") templateId: String
    ): ApiResponse<ArrayList<QuestionPaperSubjectEntity>>

    /**
     * 精品题库题目-包含举一反三数据
     */
    @GET("/api/questionbank/wdQuestionPaperSubject/listByQuestionBank")
    suspend fun getQuestionBankList2(
        @Header("token") Authorization: String,
        @Query("paperId") paperId: String,
        @Query("templateId") templateId: String
    ): ApiResponse<QuestionPaperAllEntity>

    @GET("/api/questionbank/wdQuestionPaperSubject/listByQuestionBank")
    suspend fun getQuestionBankList3(
        @Header("token") Authorization: String,
        @Query("paperId") paperId: String,
        @Query("templateId") templateId: String
    ): ApiResponse<Any>


    @GET("/api/questionbank/wdQuestionPaperSubject/listAll")
    suspend fun getQuestionPaperSubject2List(
        @Header("token") Authorization: String,
        @Query("paperId") paperId: String
    ): ApiResponse<QuestionPaperAllEntity>


    /**
     * 试卷题目详情
     */
    @GET("/api/questionbank/wdQuestionPaperSubject/queryById")
    suspend fun getQuestionPaperSubjectById(
        @Header("token") Authorization: String,
        @Query("id") id: String
    ): ApiResponse<QuestionPaperInfoEntity>

    @GET("/api/questionbank/wdQuestionPaperSubject/queryByColl")
    suspend fun getQuestionPaperSubjectByColl(
        @Header("token") Authorization: String,
        @Query("id") id: String
    ): ApiResponse<QuestionPaperInfoEntity>


    /**
     * 收藏下的智能练习
     * @param Authorization String
     * @param body JsonObject
     * @return ApiResponse<ArrayList<QuestionPaperInfoEntity>>
     */
    @POST("/api/chapter/wdQuestionCollect/practice")
    suspend fun getQuestionCollectPracticeList(
        @Header("token") Authorization: String,
        @Body body: JsonArray
    ): ApiResponse<ArrayList<QuestionChapterSubjectEntity>>

    /**
     * 删除笔记
     * @param token String
     * @param id String
     * @return ApiResponse<Any?>
     */
    @DELETE("/api/note/delete")
    suspend fun delNoteInfoById(
        @Header("token") token: String,
        @Query("id") id: String
    ): ApiResponse<Any?>

    /**
     * 支付宝支付
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/order/aliPay")
    suspend fun aliPay(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<String>

    /**
     * 图书订单支付宝支付
     */
    @POST("/api/order.wdBookOrder/wdBookOrder/aliPay")
    suspend fun bookOrderAliPay(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<String>

    /**
     * 图书订单计算生成运费
     */
    @POST("/api/order.wdBookOrder/wdBookOrder/checkFreight")
    suspend fun checkFreight(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<String>

    /**
     * 微信支付
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<String>
     */
    @POST("/api/order/wxPay")
    suspend fun wxPay(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<WxPayResultEntity>

    @POST("/api/order.wdBookOrder/wdBookOrder/wxPay")
    suspend fun bookOrderWxPay(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<WxPayResultEntity>

    /**
     * 题库订单信息
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<QuestionOrderEntity>
     */
    @POST("/api/order/add")
    suspend fun createQuestionOrder(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<QuestionOrderEntity>


    /**
     * 修改课程订单地址
     */
    @POST("/api/order.wdBookOrder/wdBookOrder/updDeliveryAddress")
    suspend fun updateOrderAddress(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 取消订单
     */
    @GET("/api/order/cancelById")
    suspend fun cancelOrderById(
        @Header("token") token: String,
        @Query("id") id: String
    ): ApiResponse<Any?>

    /**
     * 图书订单取消订单
     */
    @GET("/api/order.wdBookOrder/wdBookOrder/cancel")
    suspend fun cancelBookOrderById(
        @Query("id") id: String
    ): ApiResponse<Any?>

    /**
     * 提交试卷结果
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/questionbank/practice/check")
    suspend fun submitPaperResult(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<ExamScoreEntity>

    /**
     * 重新答题（公用）类型 1章节练习(章节练习) 2 试卷管理(历年真题,精品题库) 3评测试卷 4模拟试卷
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/questionbank/practice/again")
    suspend fun questionAgain(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 我要纠错  （意见反馈接口，新需求试题纠错也用这个接口），请求参数增加type字段，type传0为意见反馈，传1为试题纠错，如果是试题纠错则需要传subject_id（试题id）
     * @param token String
     * @param body JsonObject
     * @return ApiResponse<Any?>
     */
    @POST("/api/Feedback/wdOperateFeedback/add")
    suspend fun errorCorrection(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 获取字典数据
     *
     * dictCode 性别：sys_dict,dict_name,id,dict_code='sex'
     * 学校： wd_school,name,id
     * 专业： wd_resources_major,major_name,id
     * 学历：sys_dict,dict_name,id,dict_code='education
     * 题型：sys_dict,dict_name,id,dict_code='lifting_type'
     * @param token StringWxPayResultEntity
     * @param dictCode String
     * @return ApiResponse<ArrayList<DictCodeEntity>>
     */
    @GET("/api/sys/dict/getDict/{dictCode}")
    suspend fun getDictListByCode(
        @Path("dictCode") dictCode: String
    ): ApiResponse<ArrayList<DictCodeEntity>>

    @GET("/api/student/management/wdStudentManagement/queryStudentNews")
    suspend fun queryStudentNews(
        @Header("token") Authorization: String
    ): ApiResponse<DotEntity>


    /**
     * 获取我的错题
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ArrayList<QuestionCollectEntity>>
     */
    @GET("/api/questionbank/practice/listError")
    suspend fun getQuestionErrorList(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionCollectEntity>>

    /**
     * 错题比例
     * @param Authorization String
     * @param bodyMap Map<String, String>
     * @return ApiResponse<ArrayList<QuestionErrorProportionEntity>>
     */
    @GET("/api/questionbank/paperScore/wdQuestionSubjectScore/findByFail")
    suspend fun getQuestionErrorProportion(
        @Header("token") Authorization: String,
        @QueryMap bodyMap: Map<String, String>
    ): ApiResponse<ArrayList<QuestionErrorProportionEntity>>

    /**
     * 消灭错题
     * @param Authorization String
     * @param paperId String
     * @return ApiResponse<ArrayList<QuestionPaperSubjectEntity>>
     */
    @GET("/api/questionbank/practice/dieError")
    suspend fun getQuestionByError(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ArrayList<QuestionPaperSubjectEntity>>

    /**
     * 生成试卷
     * @param Authorization String
     * @param params Map<String, String>
     * @return ApiResponse<ArrayList<QuestionPaperSubjectEntity>>
     */
    @GET("/api/questionbank/paperSubject/wdQPaperSubject/exam")
    suspend fun getQuestionByExam(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<MockPaperSubjectEntity>

    /**
     * 课程订单
     * @param Authorization String
     * @param paperId String
     * @return ApiResponse<ApiPagerResponse<CourseOrderEntity>>
     */
    @GET("/api/order/findByClassesStudent")
    suspend fun getCourseOrderList(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<CourseOrderEntity>>>

    /**
     * 图书订单
     * @param Authorization String
     * @param paperId String
     * @return ApiResponse<ApiPagerResponse<CourseOrderEntity>>
     */
    @GET("/api/order.wdBookOrder/wdBookOrder/list")
    suspend fun getBookOrderList(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<BookOrderEntity>>>

    /**
     * 获取考试科目
     * @param Authorization String
     * @param majorId String
     * @return ApiResponse<ApiPagerResponse<ArrayList<CourseOrderEntity>>>
     */
    @GET("/api/questionbank/paperSubject/wdQPaperSubject/examList")
    suspend fun getExamList(
        @Header("token") Authorization: String,
        @Query("majorId") majorId: String
    ): ApiResponse<ExamResultInfoEntity>

    /**
     *查询试卷分数
     */
    @GET("/api/questionbank/paperScore/wdQuestionSubjectScore/findByScore")
    suspend fun getExamScore(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ExamScoreEntity>

    /**
     * 提交评测试卷
     */
    @POST("/api/wdClass/wdClassesAppraisalStudents/wdClassesAppraisalStudents/submitRoll")
    suspend fun submitRoll(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 用户注销
     */
    @POST("/api/student/management/wdStudentManagement/cancellation")
    suspend fun cancellation(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 活动列表
     */
    @GET("/api/activity/wdActivity/list")
    suspend fun getWDActivityList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<WdActivityEntity>>>

    /**
     * 获取活动详情
     */
    @GET("/api/activity/wdActivity/queryById")
    suspend fun getWDActivityById(
        @Query("id") id: String
    ): ApiResponse<WdActivityEntity>

    /**
     * 资讯列表
     */
    @GET("/api/information/wdInformation/list")
    suspend fun getWdInformationList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<WdInformationEntity>>>

    /**
     * 获取资讯详情
     */
    @GET("/api/information/wdInformation/queryById")
    suspend fun getWdInformationById(
        @Query("id") id: String
    ): ApiResponse<WdInformationEntity>

    /**
     * 获取资讯详情分享
     */
    @GET("/api/information/wdInformation/findBySharUrl")
    suspend fun getWdInformationShare(
        @Query("id") id: String
    ): ApiResponse<ActivityShareResult>

    /**
     * 资讯列表分类
     */
    @GET("/api/informationClassify/wdInformationClassify/list")
    suspend fun getWdInformationClassifyList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<WdInformationTypeEntity>>>

    /**
     * 校验checkCDK
     */
    @GET("/api/order/checkCDK")
    suspend fun checkCDK(
        @Query("cdkCode") code: String
    ): ApiResponse<CheckCDkResultEntity>

    /**
     * 兑换课程
     */
    @POST("/api/order/exchange")
    suspend fun exchangeCourse(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 确认收货
     */
    @GET("/api/order.wdBookOrder/wdBookOrder/confirm")
    suspend fun confirmOrder(
        @Query("id") id: String
    ): ApiResponse<Any?>

    /**
     * 添加地址
     */
    @POST("/api/order/wdOrderArea/add")
    suspend fun addAddress(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 编辑地址
     */
    @PUT("/api/order/wdOrderArea/edit")
    suspend fun updateAddress(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 删除地址
     */
    @DELETE("/api/order/wdOrderArea/delete")
    suspend fun delAddress(
        @Query("id") id: String
    ): ApiResponse<Any?>

    /**
     * 获取地址列表
     */
    @GET("/api/order/wdOrderArea/list")
    suspend fun getAddressList(
    ): ApiResponse<ArrayList<AddressInfoEntity>>

    /**
     * 获取省市区数据
     */
    @GET("/api/order/wdOrderArea/areaList")
    suspend fun getWdOrderAreaList(
    ): ApiResponse<ArrayList<ProvinceCityAreaEntity>>

    /**
     * 获取发现页数据
     */
    @GET("/api/informationandactivity/list")
    suspend fun getDiscoverHome(
    ): ApiResponse<DiscoverHomeEntity>


    /**
     * 兑换记录
     */
    @GET("/api/wdClass/wdCdkeyDetail/list")
    suspend fun getCdkRecordList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<ExchangeRecordEntity>>>

    /**
     * 优惠券列表
     * @param Authorization String
     * @param paperId String
     * @return ApiResponse<ApiPagerResponse<CourseOrderEntity>>
     */
    @GET("/api/coupon/wdCustomerCoupon/findByUser")
    suspend fun getCouponList(
        @Header("token") Authorization: String,
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<CouponInfoEntity>>>

    /**
     * 获取商品可用优惠券
     */
    @GET("/api/coupon/wdCoupon/findByCouponList")
    suspend fun getCouponByGoodsList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ArrayList<WdCouponEntity>>

    /**
     * 领取优惠券
     */
    @POST("/api/coupon/wdCustomerCoupon/saveCoupon")
    suspend fun saveCoupon(
        @Body body: JsonObject
    ): ApiResponse<Any?>


    /**
     * 获取图书顶级专业
     */
    @GET("/api/book/wdBook/listmagoron")
    suspend fun getListMagoron(
    ): ApiResponse<ArrayList<BookShopClassifyEntity>>

    /**
     * 获取对应分类下的图书
     */
    @GET("/api/book/wdBook/listmagorbook")
    suspend fun getListMagoronBook(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ArrayList<BookShopClassifyEntity>>

    /**
     * 获取图书详情
     */
    @GET("/api/book/wdBook/queryById")
    suspend fun getBookDetailById(
        @Query("id") bookId: String
    ): ApiResponse<BookInfoEntity>
    /**
     * 获取图书订单详情
     */
    @GET("/api/order.wdBookOrder/wdBookOrder/queryInfo")
    suspend fun getBookOrderDetailById(
        @Query("id") id: String
    ): ApiResponse<BookOrderInfoEntity>

    /**
     * 添加到购物车
     */
    @POST("/api/shopping/cart/add")
    suspend fun addBookToCard(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 获取购物车
     */
    @POST("/api/shopping/cart/list")
    suspend fun getShopCarList(
    ): ApiResponse<ArrayList<ShopCarInfoEntity>>

    /**
     * 清理购物车
     */
    @DELETE("/api/shopping/cart/deleteBatch")
    suspend fun clearShopCarAll(
        @Query("bookIds") bookIds: String
    ): ApiResponse<Any?>

    /**
     * 修改购物车商品数量
     */
    @PUT("/api/shopping/cart/edit")
    suspend fun edtCarNum(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 生成图书订单
     */
    @POST("/api/order.wdBookOrder/wdBookOrder/add")
    suspend fun addBookOrder(
        @Body body: JsonObject
    ): ApiResponse<BookOrderEntity>

    /**
     * 保存学员登录记录
     */
    @POST("/api/student/wdLoginRecord/save")
    suspend fun saveLoginRecord(
        @Body body: JsonObject
    ): ApiResponse<Any?>

    @Streaming
    @GET
    fun downloadFileWithDynamicUrlAsync(@Url fileUrl: String?): Call<ResponseBody?>?

    /**
     * 版本更新
     */
    @GET("/api/wdAppVersionControl/wdAppVersionControl/queryAppVersion")
    suspend fun updateVersion(
        @Query("type") type: String
    ): ApiResponse<VersionResultEntity>

    /**
     * 获取普为课程链接
     */
    @GET("/api/courseapi/queryCourseDetailsCourseOrSubNew")
    suspend fun getPWCourseOrSubNew(
        @Header("token") Authorization: String,
        @Query("classid") classId: String,
        @Query("courseid") courseId: String
    ): ApiResponse<PwResultEntity>

    /**
     * 获取首页banner
     */
    @GET("/api/operate/banner/wdOperateBanner/queryPopup")
    suspend fun getQueryPopup(
        @Header("token") token: String,
        @Query("majorId") majorId: String
    ): ApiResponse<BannerPopupEntity>

    /**
     * 添加微信解锁
     */
    @POST("/api/student/lock/keyUnlock")
    suspend fun keyUnlock(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 分享解锁
     */
    @POST("/api/student/lock/shareUnlock")
    suspend fun shareUnlock(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any?>

    /**
     * 判断当前用户是否为分销员
     */
    @GET("/api/sys/isHomeTop")
    suspend fun getIsHomeTop(
    ): ApiResponse<HomeTopEntity>

    /**
     * 判断用户是否是推广大使
     */
    @POST("/api/wd-distributor/judge")
    suspend fun judgeInfo(
        @Header("token") token: String
    ): ApiResponse<Any?>

    /**
     * 推送开关
     * @param token String
     * @return ApiResponse<Any>
     */
    @PUT("/api/student/management/wdStudentManagement/editPush")
    suspend fun changePush(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any>

    /**
     * 获取学习服务是否存在新内容标记
     */
    @GET("/api/wdClass/wdClassesStudents/wdClassesStudents/unreadFlag/studyServer")
    suspend fun getStudyServerMsg(
    ): ApiResponse<Boolean>

    /**
     * 获取学习服务是否存在新内容标记
     */
    @GET("/api/api/myStudent/findByPeepStreamCornerMarkMajor")
    suspend fun findByPeepStreamCornerMark(@Query("majorId") majorId: String
    ): ApiResponse<Int>

    /**
     * 获取当前班级下是否有新内容未读标记
     */
    @GET("/api/wdClass/wdClassesStudents/wdClassesStudents/unreadFlag")
    suspend fun getClassUnreadMsg(
        @Header("token") token: String,
        @Query("classId") classId: String
    ): ApiResponse<ClassUnReadFlagEntity>

    /**
     *更新当前用户的班级未读标记为已读
     */
    @PUT("/api/wdClass/wdClassesStudents/wdClassesStudents/unreadFlag")
    suspend fun updateClassUnreadMsg(
        @Header("token") token: String,
        @Body body: JsonObject
    ): ApiResponse<Any>

    /**
     * 根据用户和课程ID去查询是否存在的有班级
     */
    @GET("/api/student/management/wdStudentManagement/findByUserCourseId")
    suspend fun findByUserCourseId(
        @Header("token") token: String,
        @Query("courseId") courseId: String
    ): ApiResponse<Int>

    /**
     * 获取课程笔记分类
     */
    @GET("/api/wdClass/wdClassesNotes/wdClassesNotes/getNotesCategory")
    suspend fun getClassNoteCategoryList(
        @Query("classesId") classesId: String
    ): ApiResponse<ArrayList<ClassNotesCategoryEntity>>

    /**
     *根据majorId查询课程标签
     * classCourseLabelList 班级标签、classCourseLabelList 模块标签
     */
    @GET("/api/wdCourseLabel/wdCourseLabel/getLabelByMajorId")
    suspend fun getLabelByMajorId(
        @Query("majorId") majorId: String
    ): ApiResponse<CourseLabelEntity>

    /**
     * 获取学习阶段列表
     */
    @GET("/api/courseapi/getLearningPhaseList")
    suspend fun getLearningPhaseList(
        @Query("majorId") majorId: String
    ): ApiResponse<ArrayList<LearningPhaseEntity>>

    /**
     * 首页模块课程
     */
    @GET("/api/courseapi/queryCoursePageList")
    suspend fun getCoursePageList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<HomeModuleCourseEntity>>>
    /**
     * 首页模块课程
     */
    @GET("/api/courseapi/queryBestSellerModuleCoursePageList")
    suspend fun getBestSellerModuleCoursePageList(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<HomeModuleCourseEntity>>>

    /**
     * h获取首页推荐图书
     */
    @GET("/api/book/wdBook/list")
    suspend fun getHomeRecommendBook(
        @QueryMap params: Map<String, String>
    ): ApiResponse<ApiPagerResponse<ArrayList<BookInfoEntity>>>

    /**
     * 获取直播计划日历
     */
    @GET("/api/api/myStudent/findByPeepStreamCalendarMajor")
    suspend fun getLivePLanCalendar(
        @Query("date") date: String,@Query("majorId") majorId: String
    ): ApiResponse<ArrayList<LivePlanDateEntity>>

    /**
     * 根据日历获取直播计划

     */
    @GET("/api/api/myStudent/findByPeepStreamLiveCourseMajor")
    suspend fun findByPeepStreamLiveCourse(
        @Query("date") date: String,@Query("majorId") majorId: String
    ): ApiResponse<ArrayList<LivePlanInfoEntity>>


    /**
     * 学习模块课程
     */
    @GET("/api/api/myStudent/findByModuleOfCourses")
    suspend fun findByModuleOfCourses(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int
    ): ApiResponse<ApiPageResponse<HomeModuleCourseEntity>>

    /**
     * 分页查询学习-系列课程
     */
    @GET("/api/api/myStudent/findBySeriesOfCourses")
    suspend fun findBySeriesOfCourses(
        @Query("pageNo") pageNo: Int,
        @Query("pageSize") pageSize: Int
    ): ApiResponse<ApiPageResponse<HotCourseEntity>>

}