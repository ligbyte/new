package com.wendu.wenduyikao.app.network

import android.content.Intent
import android.util.Log
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.app.App
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.AuthTimeOutEntity
import com.wendu.wenduyikao.ui.activity.login.LoginActivity
import okhttp3.Headers
import okhttp3.Interceptor
import okhttp3.MediaType
import okhttp3.Response
import okio.Buffer
import okio.BufferedSource
import java.io.EOFException
import java.io.IOException
import java.nio.charset.Charset
import java.nio.charset.UnsupportedCharsetException


/**
 * 自定义头部参数拦截器，传入heads
 */
class MyHeadInterceptor : Interceptor {

    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val builder = chain.request().newBuilder()
        builder.addHeader("X-Access-Token", CacheUtil.getToken()).build()
//        builder.addHeader("x-www-form-urlencoded", "1").build()
//        builder.addHeader("device", "Android").build()
//        builder.addHeader("isLogin", CacheUtil.isLogin().toString()).build()

//        return chain.proceed(builder.build())
        val originalRequest = chain.request()
        if (StringUtil.isBlank(CacheUtil.getToken())) {
            return chain.proceed(originalRequest)
        }
        val authorised = originalRequest.newBuilder()
        authorised.addHeader("X-Access-Token", CacheUtil.getToken()).build()
        val response = chain.proceed(authorised.build());//执行此次请求

        val responseBody = response.body()
        try {
            val contentLength: Long = responseBody!!.contentLength()
            if (!bodyEncoded(response.headers())) {
                val source: BufferedSource = responseBody.source();
                source.request(Long.MAX_VALUE); // Buffer the entire body.
                val buffer: Buffer = source.buffer();

                var charset = UTF8
                val contentType: MediaType? = responseBody.contentType();
                if (contentType != null) {
                    try {
                        charset = contentType.charset(UTF8)!!;
                    } catch (e: UnsupportedCharsetException) {
                        return response;
                    }
                }

                if (!isPlaintext(buffer)) {
                    return response;
                }

                if (contentLength != 0L) {
                    val result: String = buffer.clone().readString(charset);
//                    Log.d("yxm", " response.url():" + response.request().url());
//                    Log.d("yxm", " response.body():" + result);
                    //得到所需的string，开始判断是否异常
                    //***********************do something*****************************
//                    val type = object : TypeToken<ApiBaseResponse<String>>() {}.type
                    val responseEntity =
                        GsonUtils.fromJson<AuthTimeOutEntity>(result, AuthTimeOutEntity::class.java)
                    if (CacheUtil.isLogin()) {
                        if (responseEntity.code == 401) {
                            CacheUtil.setUser(null)
                            CacheUtil.setToken("")
                            CacheUtil.setIsLogin(false)
                            CacheUtil.setNickName("")
                            Log.v("yxy", responseEntity.message)
                            ToastUtils.showShort(responseEntity.message)
                            App.instance.applicationContext.startActivity(
                                Intent(
                                    App.instance.applicationContext,
                                    LoginActivity::class.java
                                ).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

                            )
                            //            refreshToken()
                            return chain.proceed(builder.build())
                        }
                    }
                } else {
                    return response
                }
            } else {
                return response
            }


        } catch (e: Throwable) {

        }
//        if (response.code() == 200 && response.body().) {
//            CacheUtil.setUser(null)
//            CacheUtil.setToken("")
//            App.instance.applicationContext.startActivity(
//                    Intent(
//                            App.instance.applicationContext,
//                            LoginActivity::class.java
//                    ).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
//            )
////            refreshToken()
//            return chain.proceed(builder.build())
//        }
        return response
    }


    private val UTF8 = Charset.forName("UTF-8")
    fun bodyEncoded(headers: Headers): Boolean {
        val contentEncoding: String? = headers.get("Content-Encoding");
        return contentEncoding != null /*&& !contentEncoding.equalsIgnoreCase("identity");*/
    }

    @Throws(EOFException::class)
    fun isPlaintext(buffer: Buffer): Boolean {
        return try {
            val prefix = Buffer()
            val byteCount = if (buffer.size < 64) buffer.size else 64.toLong()
            buffer.copyTo(prefix, 0, byteCount)
            for (i in 0..15) {
                if (prefix.exhausted()) {
                    break
                }
                val codePoint = prefix.readUtf8CodePoint()
                if (Character.isISOControl(codePoint) && !Character.isWhitespace(codePoint)) {
                    return false
                }
            }
            true
        } catch (e: EOFException) {
            false // Truncated UTF-8 sequence.
        }
    }
}