package com.wendu.wenduyikao.app.util;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.webkit.JavascriptInterface;

import androidx.annotation.Nullable;

import com.blankj.utilcode.util.AppUtils;
import com.blankj.utilcode.util.GsonUtils;
import com.blankj.utilcode.util.ToastUtils;
import com.just.agentweb.AgentWeb;
import com.wendu.wenduyikao.app.App;
import com.wendu.wenduyikao.data.constans.MainTabConst;
import com.wendu.wenduyikao.data.eventbus.MainTabChooseEvent;
import com.wendu.wenduyikao.data.model.bean.OpenCourseOrderEntity;
import com.wendu.wenduyikao.data.model.bean.ShareEntity;
import com.wendu.wenduyikao.data.model.bean.SharePlanInfoEntity;
import com.wendu.wenduyikao.dialog.ShareDialog;
import com.wendu.wenduyikao.dialog.ShareImgDialog;
import com.wendu.wenduyikao.dialog.ShareMiniDialog;
import com.wendu.wenduyikao.dialog.ShareUrlDialog;
import com.wendu.wenduyikao.ui.home.CoursePayActivity;

import org.greenrobot.eventbus.EventBus;

import kotlin.reflect.KType;

/**
 * Package:       com.wendu.wenduyikao.app.util
 * ClassName:     AndroidInterface
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/13
 * Description:
 */
public class AndroidInterface {
    private AgentWeb agent;
    private Context context;
    private Activity activity;

    public AndroidInterface(AgentWeb agent, Context context, Activity activity) {
        this.agent = agent;
        this.context = context;
        this.activity = activity;
    }

    @JavascriptInterface
    public void share2WX(String str) {
        Log.v("yxy", "=share2WX===" + str);

        if (StringUtil.isNotBlank(str)) {
            SharePlanInfoEntity info = GsonUtils.fromJson(str, SharePlanInfoEntity.class);
            ShareEntity shareEntity = new ShareEntity(info.getTitle(), "文都医学", info.getImage(), info.getPath());
            if (info.getType() == 0) {
                ShareMiniDialog shareDialog = new ShareMiniDialog(context);
                shareDialog.setShareEntity(shareEntity);
                shareDialog.setResource(shareEntity);
                shareDialog.setOnSubmitClick(new ShareMiniDialog.OnSubmitClickListener() {
                    @Override
                    public void onSubmitClick(@Nullable String content) {

                    }
                });
                shareDialog.build().show();
            } else {
                ShareImgDialog shareimgDialog = new ShareImgDialog(context);
                shareimgDialog.setShareEntity(shareEntity);
                shareimgDialog.setResource(shareEntity);
                shareimgDialog.setOnSubmitClick(new ShareImgDialog.OnSubmitClickListener() {
                    @Override
                    public void onSubmitClick(@Nullable String content) {

                    }
                });
                shareimgDialog.build().show();
            }
        } else {
            ToastUtils.showShort("分享数据为空");
        }

    }

    /**
     * 打开课程订单
     */
    @JavascriptInterface
    public void jump2ClassOrderPage(String str) {
        Log.v("yxy", "=jump2ClassOrderPage===" + str);
//        ToastUtils.showShort("jump2ClassOrderPage==" + str);
        if (StringUtil.isNotBlank(str)) {
            OpenCourseOrderEntity info = GsonUtils.fromJson(str, OpenCourseOrderEntity.class);
            if (info != null) {


                Intent intent = new Intent(activity, CoursePayActivity.class);
                intent.putExtra("courseClassId", info.getId());
                intent.putExtra("courseClassName", info.getClassesName());
                intent.putExtra("courseClassBg", info.getClassesCover());
                intent.putExtra("courseClassTypeId", info.getClassesTypeId());
                intent.putExtra("courseClassTypeName", info.getClassesTypeName());
                intent.putExtra("courseClassPrice", info.getFficialPrice());
                intent.putExtra("courseClassFree", false);

                activity.startActivity(intent);
                activity.finish();
            }
        }

    }

    /**
     * 回到主页
     */
    @JavascriptInterface
    public void closeWebpage() {
        activity.finish();
        EventBus.getDefault()
                .post(new MainTabChooseEvent(MainTabConst.INSTANCE.getHOME(), true));

    }

}
