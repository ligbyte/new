package com.wendu.wenduyikao.app.util;

import android.os.CountDownTimer;
import android.widget.TextView;

import com.wendu.wenduyikao.R;

/**
 * Package:       com.lingju.youqiuser.app.util
 * ClassName:     CountDownTimerUtils
 * Author:         xiaoyangyan
 * CreateDate:    6/29/21
 * Description:
 */
public class AnswerCountDownTimerUtils extends CountDownTimer {
    private TextView mTextView;

    public AnswerCountDownTimerUtils(TextView textView, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        this.mTextView = textView;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        mTextView.setClickable(false); //设置不可点击
        long minute = millisUntilFinished / (60 * 1000);
        long second = (millisUntilFinished - minute * (1000 * 60)) / 1000;
        mTextView.setText(minute + "分" + second + "秒");  //设置倒计时时间
        mTextView.setBackgroundResource(R.drawable.shape_bg_tag_blue); //设置按钮为灰色，这时是不能点击的
    }

    @Override
    public void onFinish() {
        mTextView.setText("未开始");
        mTextView.setClickable(true);//重新获得点击
        mTextView.setBackgroundResource(R.drawable.shape_bg_tag_blue);  //还原背景色
    }
}