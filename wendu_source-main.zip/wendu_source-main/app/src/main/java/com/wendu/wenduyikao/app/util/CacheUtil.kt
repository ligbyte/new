package com.wendu.wenduyikao.app.util

import android.text.TextUtils
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.tencent.mmkv.MMKV
import com.wendu.wenduyikao.data.model.bean.*

object CacheUtil {
    /**
     * 获取保存的账户信息
     */
    fun getUser(): UserInfo? {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("user")
        return if (TextUtils.isEmpty(userStr)) {
            null
        } else {
            Gson().fromJson(userStr, UserInfo::class.java)
        }
    }

    /**
     * 设置账户信息
     */
    fun setUser(userResponse: UserInfo?) {
        val kv = MMKV.mmkvWithID("app")
        if (userResponse == null) {
            kv.encode("user", "")
            setIsLogin(false)
        } else {
            kv.encode("user", Gson().toJson(userResponse))
            setIsLogin(true)
        }

    }

    /**
     * 获取问题数据
     */
    fun getQuestionSubject(): ArrayList<QuestionChapterSubjectEntity> {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("question")
        return if (TextUtils.isEmpty(userStr)) {
            arrayListOf()
        } else {
//            Gson().fromJson(userStr, TypeToken<ArrayList<QuestionChapterSubjectEntity>>().type)
            val turnsType = genericType<ArrayList<QuestionChapterSubjectEntity>>()
            return Gson().fromJson(userStr, turnsType)
        }
    }

    inline fun <reified T> genericType() = object : TypeToken<T>() {}.type

    /**
     * 保存问题数据
     */
    fun setQuestionList(questionList: ArrayList<QuestionInfoEntity>) {
        val kv = MMKV.mmkvWithID("app")
        if (questionList == null) {
            kv.encode("questionList", "")
        } else {
            kv.encode("questionList", Gson().toJson(questionList))
        }

    }


    /**
     * 获取已答问题集合
     */
    fun getQuestionResultList(): ArrayList<QuestionPracticeEntity> {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("questionResult")
        return if (TextUtils.isEmpty(userStr)) {
            arrayListOf()
        } else {
            val turnsType = genericType<ArrayList<QuestionPracticeEntity>>()
            return Gson().fromJson(userStr, turnsType)
        }
    }

    /**
     * 保存已答问题集合
     */
    fun setQuestionResultList(questionList: ArrayList<QuestionPracticeEntity>) {
        val kv = MMKV.mmkvWithID("app")
        if (questionList == null) {
            kv.encode("questionResult", "")
        } else {
            kv.encode("questionResult", Gson().toJson(questionList))
        }
    }


    /**
     * 获取试卷问题数据
     */
    fun getQuestionPaperList(): ArrayList<QuestionPaperInfoEntity> {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("questionPaperList")
        return if (TextUtils.isEmpty(userStr)) {
            arrayListOf()
        } else {
            val turnsType = genericType<ArrayList<QuestionPaperInfoEntity>>()
            return Gson().fromJson(userStr, turnsType)
        }
    }

    /**
     * 保存试卷问题数据
     */
    fun setQuestionPaperList(questionList: ArrayList<QuestionPaperInfoEntity>) {
        val kv = MMKV.mmkvWithID("app")
        if (questionList == null) {
            kv.encode("questionPaperList", "")
        } else {
            kv.encode("questionPaperList", Gson().toJson(questionList))
        }

    }

    /**
     * 获取题型数据
     */
    fun getDictCodeList(): ArrayList<DictCodeEntity> {
        val kv = MMKV.mmkvWithID("app")
        val dictStr = kv.decodeString("dictList")
        return if (TextUtils.isEmpty(dictStr)) {
            arrayListOf()
        } else {
            val turnsType = genericType<ArrayList<DictCodeEntity>>()
            return Gson().fromJson(dictStr, turnsType)
        }
    }

    /**
     * 保存题型数据
     */
    fun setDictCodeList(dictList: ArrayList<DictCodeEntity>) {
        val kv = MMKV.mmkvWithID("app")
        if (dictList == null) {
            kv.encode("dictList", "")
        } else {
            kv.encode("dictList", Gson().toJson(dictList))
        }

    }


    /**
     * 保存问题数据
     */
    fun setQuestionSubject(questionList: ArrayList<QuestionChapterSubjectEntity>?) {
        val kv = MMKV.mmkvWithID("app")
        if (questionList == null) {
            kv.encode("question", "")
        } else {
            val questions = arrayListOf<QuestionInfoEntity>()
            for (info in questionList) {
                questions.addAll(info.list)
            }
            setQuestionList(questions)
            kv.encode("question", Gson().toJson(questionList))
        }

    }


    /**
     * 获取问题数据
     */
    fun getQuestionList(): ArrayList<QuestionInfoEntity> {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("questionList")
        return if (TextUtils.isEmpty(userStr)) {
            arrayListOf()
        } else {
            val turnsType = genericType<ArrayList<QuestionInfoEntity>>()
            return Gson().fromJson(userStr, turnsType)
        }
    }

    /**
     * 保存试卷问题数据
     */
    fun setQuestionPaperSubject(questionList: ArrayList<QuestionPaperSubjectEntity>?) {
        val kv = MMKV.mmkvWithID("app")
        if (questionList == null) {
            kv.encode("question", "")
        } else {
            val questions = arrayListOf<QuestionPaperInfoEntity>()
            for (info in questionList) {
                questions.addAll(info.list)
            }
            setQuestionPaperList(questions)
            kv.encode("questionPaper", Gson().toJson(questionList))
        }

    }

    /**
     * 获取试卷问题数据
     */
    fun getQuestionPaperSubject(): ArrayList<QuestionPaperSubjectEntity> {
        val kv = MMKV.mmkvWithID("app")
        val userStr = kv.decodeString("questionPaper")
        return if (TextUtils.isEmpty(userStr)) {
            arrayListOf()
        } else {
//            Gson().fromJson(userStr, TypeToken<ArrayList<QuestionChapterSubjectEntity>>().type)
            val turnsType = genericType<ArrayList<QuestionPaperSubjectEntity>>()
            return Gson().fromJson(userStr, turnsType)
        }
    }

    /**
     * 获取保存的昵称
     */
    fun getNickName(): String? {
        val kv = MMKV.mmkvWithID("app")
        val nickname = kv.decodeString("nickname")
        return if (TextUtils.isEmpty(nickname)) {
            null
        } else {
            nickname
        }
    }

    /**
     * 设置昵称
     */
    fun setNickName(nickname: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (nickname == null) {
            kv.encode("nickname", "")
        } else {
            kv.encode("nickname", nickname)
        }

    }


    /**
     * 获取保存的头像
     */
    fun getHeadImgUrl(): String? {
        val kv = MMKV.mmkvWithID("app")
        val headImgUrl = kv.decodeString("headImgUrl")
        return if (TextUtils.isEmpty(headImgUrl)) {
            null
        } else {
            headImgUrl
        }
    }

    /**
     * 设置头像
     */
    fun setHeadImaUrl(headImgUrl: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (headImgUrl == null) {
            kv.encode("headImgUrl", "")
        } else {
            kv.encode("headImgUrl", headImgUrl)
        }

    }

    /**
     * 设置token
     * @param token String
     */
    fun setToken(token: String) {
        val kv = MMKV.mmkvWithID("app")
//        kv.encode("token", "Bearer " + token)
        kv.encode("token", token)
    }

    /**
     * 获取token
     * @return String
     */
    fun getToken(): String {
        val kv = MMKV.mmkvWithID("app")
        val token = kv.decodeString("token")
        return if (TextUtils.isEmpty(token)) {
            ""
        } else {
            token
        }
    }

    /**
     * 是否已经登录
     */
    @JvmStatic
    fun isLogin(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("login", false)
    }

    /**
     * 设置是否已经登录
     */
    fun setIsLogin(isLogin: Boolean) {
        if(!isLogin){
            setClassId("")
        }
        val kv = MMKV.mmkvWithID("app")
        kv.encode("login", isLogin)
    }



    fun isRefresh(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("isRefresh", false)
    }

    fun setRefresh(isRefresh: Boolean) {
        if(!isRefresh){
            setClassId("")
        }
        val kv = MMKV.mmkvWithID("app")
        kv.encode("isRefresh", isRefresh)
    }

    /**
     * 是否是第一次登陆
     */
    fun isFirst(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("first", true)
    }

    /**
     * 是否是第一次登陆
     */
    fun setFirst(first: Boolean): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.encode("first", first)
    }

    /**
     * 是否是第一次登陆
     */
    fun isTryBuy(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("try_buy", false)
    }

    /**
     * 是否是第一次登陆
     */
    @JvmStatic
    fun setTryBuy(try_buy: Boolean): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.encode("try_buy", try_buy)
    }


    /**
     * 是否打开隐私弹窗
     */
    fun isOpenPrompt(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("isOpenPrompt", false)
    }

    /**
     * 是否打开隐私弹窗
     */
    fun setOpenPrompt(isOpenPrompt: Boolean): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.encode("isOpenPrompt", isOpenPrompt)
    }

    /**
     * 首页是否开启获取指定文章
     */
    fun isNeedTop(): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.decodeBool("top", true)
    }

    /**
     * 设置首页是否开启获取指定文章
     */
    fun setIsNeedTop(isNeedTop: Boolean): Boolean {
        val kv = MMKV.mmkvWithID("app")
        return kv.encode("top", isNeedTop)
    }

    /**
     * 获取搜索历史缓存数据
     */
    fun getSearchHistoryData(): ArrayList<String> {
        val kv = MMKV.mmkvWithID("cache")
        val searchCacheStr = kv.decodeString("history")
        if (!TextUtils.isEmpty(searchCacheStr)) {
            return Gson().fromJson(searchCacheStr, object : TypeToken<ArrayList<String>>() {}.type)
        }
        return arrayListOf()
    }

    fun setSearchHistoryData(searchResponseStr: String) {
        val kv = MMKV.mmkvWithID("cache")
        kv.encode("history", searchResponseStr)
    }

    /**
     * 获取保存的专业id
     */
    fun getQuestionMajorId(): String {
        val kv = MMKV.mmkvWithID("app")
        val majorId = kv.decodeString("questionMajorId")
        return if (TextUtils.isEmpty(majorId)) {
            ""
        } else {
            majorId
        }
    }

    /**
     * 设置全局专业
     */
    fun setQuestionMajorId(majorId: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorId == null) {
            kv.encode("questionMajorId", "")
        } else {
            kv.encode("questionMajorId", majorId)
        }
    }

    /**
     * 获取保存的专业名称
     */
    fun getQuestionMajorName(): String? {
        val kv = MMKV.mmkvWithID("app")
        val majorName = kv.decodeString("questionMajorName")
        return if (TextUtils.isEmpty(majorName)) {
            ""
        } else {
            majorName
        }
    }

    /**
     * 设置专业名称
     */
    fun setQuestionMajorName(majorName: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorName == null) {
            kv.encode("questionMajorName", "")
        } else {
            kv.encode("questionMajorName", majorName)
        }
    }

    /**
     * 获取保存的专业名称
     */
    fun getQuestionGroupMajorId(): String? {
        val kv = MMKV.mmkvWithID("app")
        val majorName = kv.decodeString("questionGroupMajorId")
        return if (TextUtils.isEmpty(majorName)) {
            ""
        } else {
            majorName
        }
    }

    /**
     * 设置专业名称
     */
    fun setQuestionGroupMajorId(majorGroupId: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorGroupId == null) {
            kv.encode("questionGroupMajorId", "")
        } else {
            kv.encode("questionGroupMajorId", majorGroupId)
        }
    }
    /**
     * 获取保存的专业id
     */
    fun getMajorId(): String {
        val kv = MMKV.mmkvWithID("app")
        val majorId = kv.decodeString("majorId")
        return if (TextUtils.isEmpty(majorId)) {
            ""
        } else {
            majorId
        }
    }

    /**
     * 设置全局专业
     */
    fun setMajorId(majorId: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorId == null) {
            kv.encode("majorId", "")
        } else {
            kv.encode("majorId", majorId)
        }
    }

    /**
     * 设置全局试看时间
     */
    fun setCourseTime(courseTime: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (courseTime == null) {
            kv.encode("courseTime", "")
        } else {
            kv.encode("courseTime", courseTime)
        }
    }

    /**
     * 获取全局试看时间
     */
    @JvmStatic
    fun getCourseTime(): String? {
        val kv = MMKV.mmkvWithID("app")
        val courseTime = kv.decodeString("courseTime")
        return if (TextUtils.isEmpty(courseTime)) {
            "0"
        } else {
            courseTime
        }
    }


    /**
     * 获取保存的专业名称
     */
    fun getMajorName(): String? {
        val kv = MMKV.mmkvWithID("app")
        val majorName = kv.decodeString("majorName")
        return if (TextUtils.isEmpty(majorName)) {
            ""
        } else {
            majorName
        }
    }

    /**
     * 设置专业名称
     */
    fun setMajorName(majorName: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorName == null) {
            kv.encode("majorName", "")
        } else {
            kv.encode("majorName", majorName)
        }
    }

    /**
     * 是否显示首页模块课程
     */
    fun isModuleCourseSale(): Int {
        val kv = MMKV.mmkvWithID("app")
        val isModuleCourseSale = kv.decodeInt("isModuleCourseSale",0)
        return isModuleCourseSale
    }

    /**
     * 设置-是否显示首页模块
     */
    fun setIsModuleCourseSale(isModuleCourseSale: Int) {
        val kv = MMKV.mmkvWithID("app")
        kv.encode("isModuleCourseSale", isModuleCourseSale)
    }
    /**
     * 获取保存的专业分组id
     */
    fun getMajorGroupId(): String? {
        val kv = MMKV.mmkvWithID("app")
        val majorName = kv.decodeString("majorGroupId")
        return if (TextUtils.isEmpty(majorName)) {
            ""
        } else {
            majorName
        }
    }

    /**
     * 设置专业分组id
     */
    fun setMajorGroupId(majorGroupId: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (majorGroupId == null) {
            kv.encode("majorGroupId", "")
        } else {
            kv.encode("majorGroupId", majorGroupId)
        }
    }
    /**
     * 获取保存的课程id
     */
    fun getClassId(): String {
        val kv = MMKV.mmkvWithID("app")
        val classIdList = kv.decodeString("classIdList")
        return if (TextUtils.isEmpty(classIdList)) {
            ""
        } else {
            classIdList
        }
    }

    @JvmStatic
    fun setUnitId(unitId: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (unitId == null) {
            kv.encode("unitId", "")
        } else {
            kv.encode("unitId", unitId)
        }
    }

    @JvmStatic
    fun getUnitId(): String {
        val kv = MMKV.mmkvWithID("app")
        val unitId = kv.decodeString("unitId")
        return if (TextUtils.isEmpty(unitId)) {
            ""
        } else {
            unitId
        }
    }
    @JvmStatic
    fun setUnlockType(unlocktype: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (unlocktype == null) {
            kv.encode("unlocktype", "")
        } else {
            kv.encode("unlocktype", unlocktype)
        }
    }

    @JvmStatic
    fun getUnlockType(): String {
        val kv = MMKV.mmkvWithID("app")
        val unlocktype = kv.decodeString("unlocktype")
        return if (TextUtils.isEmpty(unlocktype)) {
            ""
        } else {
            unlocktype
        }
    }

    @JvmStatic
    fun setUnlockContent(unlockcontent: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (unlockcontent == null) {
            kv.encode("unlockcontent", "")
        } else {
            kv.encode("unlockcontent", unlockcontent)
        }
    }

    @JvmStatic
    fun getUnlockContent(): String {
        val kv = MMKV.mmkvWithID("app")
        val unlockcontent = kv.decodeString("unlockcontent")
        return if (TextUtils.isEmpty(unlockcontent)) {
            ""
        } else {
            unlockcontent
        }
    }


    /**
     * 设置我的课程id
     */
    fun setClassId(classIdList: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (classIdList == null) {
            kv.encode("classIdList", "")
        } else {
            kv.encode("classIdList", classIdList)
        }
    }

    @JvmStatic
    fun setAudition(audition: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (audition == null) {
            kv.encode("audition", "0")
        } else {
            kv.encode("audition", audition)
        }
    }

    @JvmStatic
    fun getAudition(): String {
        val kv = MMKV.mmkvWithID("app")
        val deviceToken = kv.decodeString("audition")
        return if (TextUtils.isEmpty(deviceToken)) {
            "0"
        } else {
            deviceToken
        }
    }

    @JvmStatic
    fun setBuy(buy: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (buy == null) {
            kv.encode("buy", "0")
        } else {
            kv.encode("buy", buy)
        }
    }

    @JvmStatic
    fun getBuy(): String {
        val kv = MMKV.mmkvWithID("app")
        val deviceToken = kv.decodeString("buy")
        return if (TextUtils.isEmpty(deviceToken)) {
            "0"
        } else {
            deviceToken
        }
    }





    /**
     * 获取保存的课程id
     */
    fun getDeviceToken(): String {
        val kv = MMKV.mmkvWithID("app")
        val deviceToken = kv.decodeString("deviceToken")
        return if (TextUtils.isEmpty(deviceToken)) {
            ""
        } else {
            deviceToken
        }
    }

    /**
     * 设置我的课程id
     */
    fun setDeviceToken(deviceToken: String?) {
        val kv = MMKV.mmkvWithID("app")
        if (deviceToken == null) {
            kv.encode("deviceToken", "")
        } else {
            kv.encode("deviceToken", deviceToken)
        }
    }


    /**
     * 获取搜索历史缓存数据
     */
    fun getVideoViewData(): HashMap<String,Int> {
        val kv = MMKV.mmkvWithID("cache")
        val searchCacheStr = kv.decodeString("VideoView")
        if (!TextUtils.isEmpty(searchCacheStr)) {
            return Gson().fromJson(searchCacheStr, object : TypeToken<HashMap<String,Int>>() {}.type)
        }
        return hashMapOf()
    }

    fun setVideoViewData(searchResponseStr: HashMap<String,Int>) {
        val kv = MMKV.mmkvWithID("cache")
        kv.encode("VideoView", Gson().toJson(searchResponseStr))
    }

}