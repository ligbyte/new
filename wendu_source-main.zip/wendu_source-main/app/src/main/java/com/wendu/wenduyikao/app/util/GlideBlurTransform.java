package com.wendu.wenduyikao.app.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import androidx.annotation.NonNull;

import com.blankj.utilcode.util.ConvertUtils;
import com.bumptech.glide.load.engine.bitmap_recycle.BitmapPool;
import com.bumptech.glide.load.resource.bitmap.CenterCrop;

import java.security.MessageDigest;

/**
 * Package:       com.wendu.wenduyikao.app.util
 * ClassName:     GlideRoundTransform
 * Author:         xiaoyangyan
 * CreateDate:    2022/8/2
 * Description:
 */
public class GlideBlurTransform extends CenterCrop {
    private Context context;

    public GlideBlurTransform(Context context) {
        this.context = context;
    }

    @Override
    protected Bitmap transform(@NonNull BitmapPool pool, @NonNull Bitmap toTransform, int outWidth, int outHeight) {
        Bitmap bitmap = super.transform(pool, toTransform, outWidth, outHeight);
        return MobileUtil.blurBitmap(context, bitmap, 25, (int) (outWidth * 0.5), (int) (outHeight * 0.5));
    }

    @Override
    public void updateDiskCacheKey(@NonNull MessageDigest messageDigest) {
    }
}