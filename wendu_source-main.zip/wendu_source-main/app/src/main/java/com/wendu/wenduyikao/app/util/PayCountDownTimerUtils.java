package com.wendu.wenduyikao.app.util;

import android.os.CountDownTimer;
import android.widget.TextView;

import com.wendu.wenduyikao.R;

/**
 * Package:       com.lingju.youqiuser.app.util
 * ClassName:     CountDownTimerUtils
 * Author:         xiaoyangyan
 * CreateDate:    6/29/21
 * Description:
 */
public class PayCountDownTimerUtils extends CountDownTimer {
    private TextView mTextView;

    public PayCountDownTimerUtils(TextView textView, long millisInFuture, long countDownInterval) {
        super(millisInFuture, countDownInterval);
        this.mTextView = textView;
    }

    @Override
    public void onTick(long millisUntilFinished) {
        mTextView.setClickable(false); //设置不可点击
        long minute = millisUntilFinished / (60 * 1000);
        long second = (millisUntilFinished - minute * (1000 * 60)) / 1000;
        mTextView.setText("剩余时间" +minute + ":" + second +"到期将自动取消订单");  //设置倒计时时间
    }

    @Override
    public void onFinish() {
        mTextView.setText("00:00");
        mTextView.setClickable(true);//重新获得点击
    }
}