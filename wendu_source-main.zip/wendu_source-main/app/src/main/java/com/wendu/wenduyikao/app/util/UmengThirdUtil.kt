package com.wendu.wenduyikao.app.util

import android.app.Application
import android.content.Context
import android.util.Log
import com.umeng.commonsdk.UMConfigure
import com.umeng.message.IUmengRegisterCallback
import com.umeng.message.PushAgent
import com.umeng.message.UmengNotificationClickHandler
import com.umeng.message.entity.UMessage
import com.wendu.wenduyikao.app.App
import com.wendu.wenduyikao.data.Constants.*
import com.wendu.wenduyikao.util.PolyvUtil
import org.android.agoo.huawei.HuaWeiRegister
import org.android.agoo.mezu.MeizuRegister
import org.android.agoo.oppo.OppoRegister
import org.android.agoo.vivo.VivoRegister
import org.android.agoo.xiaomi.MiPushRegistar

/**
 * author:yxm on 2021/12/6 20:07
 * email:943789510@qq.com
 * describe:
 */
object UmengThirdUtil {
    fun initAppPush(context:Application){

        /**
         * 初始化common库
         * 参数1:上下文，不能为空
         * 参数2:【友盟+】 AppKey
         * 参数3:【友盟+】 Channel
         * 参数4:设备类型，UMConfigure.DEVICE_TYPE_PHONE为手机、UMConfigure.DEVICE_TYPE_BOX为盒子，默认为手机
         * 参数5:Push推送业务的secret
         */
        //测试 62c4e65430121a652b60619c          b70ff108e9dad0966ea774a8eebdc102
        //正式 613c6826520cc86a1d4803ff          e6d4a90b2364efff14b4ae213c21a719


        UMConfigure.init(
            context,
            "613c6826520cc86a1d4803ff",
            "Umeng",
            UMConfigure.DEVICE_TYPE_PHONE,
            "e6d4a90b2364efff14b4ae213c21a719"
        );


        val pushAgent: PushAgent = PushAgent.getInstance(context)
        //注册推送服务，每次调用register方法都会回调该接口
        //注册推送服务，每次调用register方法都会回调该接口
        pushAgent.register(object : IUmengRegisterCallback {
            override fun onSuccess(deviceToken: String) {
                CacheUtil.setDeviceToken(deviceToken)
                //注册成功会返回deviceToken
                Log.d("yxm", "onSuccess: deviceToken==" + deviceToken)
//                PolyvUtil.init(instance, "2574188","1439118470813831169")
            }

            override fun onFailure(s: String, s1: String) {}
        })


        val notificationClickHandler: UmengNotificationClickHandler =
            object : UmengNotificationClickHandler() {

                override fun handleMessage(p0: Context?, msg: UMessage?) {
                    super.handleMessage(p0, msg)
                    Log.d("yxm==", "handleMessage: ==" + msg!!.extra.toString())
                    val map = msg.extra as Map<String, String?>
                    PolyvUtil.init(
                        App.instance,
                        map["liveClassroomCode"],
                        map["unitId"],
                        map["liveClassroomName"],
                        map["teacherImagePhoto"]
                    )
                }

            }
        pushAgent.notificationClickHandler = notificationClickHandler

        MiPushRegistar.register(context, XIAOMI_ID, XIAOMI_KEY, false)
        HuaWeiRegister.register(context)
        MeizuRegister.register(context, meizuAppId, meizuAppKey)
        OppoRegister.register(context, oppoappkey, appserversecret)
        VivoRegister.register(context)
    }
}