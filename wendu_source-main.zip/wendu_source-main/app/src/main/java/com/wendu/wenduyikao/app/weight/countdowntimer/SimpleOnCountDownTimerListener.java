package com.wendu.wenduyikao.app.weight.countdowntimer;

/**
 * @author xiandanin
 * created 2020-06-08 17:57
 */
public abstract class SimpleOnCountDownTimerListener implements OnCountDownTimerListener {
    @Override
    public void onTick(long millisUntilFinished) {

    }

    @Override
    public void onFinish() {

    }

    @Override
    public void onCancel() {

    }
}
