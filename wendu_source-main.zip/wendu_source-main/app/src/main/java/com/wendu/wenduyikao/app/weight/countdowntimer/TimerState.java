package com.wendu.wenduyikao.app.weight.countdowntimer;

/**
 * author  xiandanin
 * created 2017/5/16 13:28
 */
public enum TimerState {
    START,PAUSE,FINISH
}
