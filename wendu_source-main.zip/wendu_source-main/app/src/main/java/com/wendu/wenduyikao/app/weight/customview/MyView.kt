package com.wendu.wenduyikao.app.weight.customview

import android.content.Context
import android.util.AttributeSet
import android.view.View


/**
 * 作者　:  xiaoyangyan
 * 时间　: 2020/4/24
 * 描述　:
 */
class MyView(context: Context) : View(context) {

    constructor(context: Context, attr: AttributeSet) : this(context) {

    }
}