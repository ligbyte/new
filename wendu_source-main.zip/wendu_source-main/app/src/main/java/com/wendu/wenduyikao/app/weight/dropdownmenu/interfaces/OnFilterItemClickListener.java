package com.wendu.wenduyikao.app.weight.dropdownmenu.interfaces;

/**
 * author: baiiu
 * date: on 16/2/16 15:49
 * description:
 */
public interface OnFilterItemClickListener<DATA> {
    void onItemClick(DATA item);
}
