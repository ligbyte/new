package com.wendu.wenduyikao.app.weight.loadCallBack


import com.kingja.loadsir.callback.Callback
import com.wendu.wenduyikao.R


class EmptyCallback : Callback() {

    override fun onCreateView(): Int {
        return R.layout.layout_empty
    }

}