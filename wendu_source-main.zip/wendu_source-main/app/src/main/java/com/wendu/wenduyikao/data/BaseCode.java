package com.wendu.wenduyikao.data;


import android.util.Log;

import com.blankj.utilcode.util.GsonUtils;
import com.wendu.wenduyikao.app.util.CacheUtil;
import com.wendu.wenduyikao.app.util.StringUtil;
import com.wendu.wenduyikao.data.model.bean.CodeEntity;
import com.wendu.wenduyikao.data.model.bean.DictCodeEntity;
import com.wendu.wenduyikao.data.model.bean.MajorInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionChapterSubjectEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionPaperEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionPaperSubjectEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity;
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity;
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity;

import org.litepal.LitePal;

import java.util.ArrayList;
import java.util.List;

/**
 * Package:       com.lingju.wangli.result
 * ClassName:     BaseCode
 * Author:         xiaoyangyan
 * CreateDate:    5/10/21
 * Description:
 */
public class BaseCode {

    public static ArrayList<CodeEntity> getQuestionType() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("practice");
        work.setLabel("章节练习");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("real");
        work.setLabel("历年考题");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("boutique");
        work.setLabel("精品题库");
        mDataList.add(work);
        return mDataList;
    }

    /**
     * 获取首页课程类型
     *
     * @return
     */
    public static ArrayList<CodeEntity> getHomeCourseType(boolean isModuleCourseSale) {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        work = new CodeEntity();
        work.setType("hot");
        work.setLabel("热销课程");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("series");
        work.setLabel("系列课程");
        mDataList.add(work);
        if (isModuleCourseSale) {
            work = new CodeEntity();
            work.setType("module");
            work.setLabel("模块课程");
            mDataList.add(work);
        }
        work = new CodeEntity();
        work.setType("face");
        work.setLabel("面授课程");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getHomeCourseType2() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        work = new CodeEntity();
        work.setType("hot");
        work.setLabel("热销课程");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("series");
        work.setLabel("系列课程");
        mDataList.add(work);

        work = new CodeEntity();
        work.setType("face");
        work.setLabel("面授课程");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getQuestionFilter() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        work = new CodeEntity();
        work.setType("1");
        work.setLabel("章节练习");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("历年考题");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("精品题库");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("4");
        work.setLabel("模考");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getQuestionNumFilter() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("1");
        work.setLabel("章节练习");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("试卷管理");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getLifeTypeFilter() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        ArrayList<DictCodeEntity> list = CacheUtil.INSTANCE.getDictCodeList();
        for (DictCodeEntity code : list) {
            work = new CodeEntity();
            work.setType(code.getValue());
            work.setLabel(code.getTitle());
            mDataList.add(work);
        }
        return mDataList;
    }

    public static ArrayList<CodeEntity> getNumFilter() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        work = new CodeEntity();
        work.setType("0");
        work.setLabel("全部");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("1");
        work.setLabel("1");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("2");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("3");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("4");
        work.setLabel("3次以上");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getCollectQuestionType() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("1");
        work.setLabel("选择题");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("多选题");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("共用题干");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("4");
        work.setLabel("公用选项");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getCourseOrderType() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("");
        work.setLabel("全部");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("1");
        work.setLabel("待支付");
        mDataList.add(work);
//        work = new CodeEntity();
//        work.setType("unsend");
//        work.setLabel("待发货");
//        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("已完成");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getBookOrderType() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;
        work = new CodeEntity();
        work.setType("");
        work.setLabel("全部");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("0");
        work.setLabel("待支付");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("待发货");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("6");
        work.setLabel("部分发货");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("待收货");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("4");
        work.setLabel("已完成");
        mDataList.add(work);
        return mDataList;
    }

    public static ArrayList<CodeEntity> getCouponType() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("1");
        work.setLabel("可使用");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("已使用");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("已过期");
        mDataList.add(work);
        return mDataList;
    }

    /**
     * 获取对应题干的序号
     *
     * @param subList
     * @return
     */
    public static ArrayList<QuestionResultEntity> getQuestionCardData(ArrayList<QuestionChapterSubjectEntity> subList) {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        int subNum = 1;
        int subSize = subList.size();
        for (int i = 0; i < subSize; i++) {
            list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(subList.get(i).getType())));
            if (subList.get(i).getType() == 3 || subList.get(i).getType() == 4 || subList.get(i).getType() == 7 || subList.get(i).getType() == 8) {
                QuestionChapterSubjectEntity chapterSub = subList.get(i);
                for (int k = 0; k < chapterSub.getList().size(); k++) {
                    ArrayList<QuestionInfoEntity> subs = chapterSub.getList().get(k).getQuestionList();
                    for (int m = 0; m < subs.size(); m++) {
                        String index = (subNum) + "-" + (m + 1);
                        QuestionInfoEntity info = CacheUtil.INSTANCE.getQuestionList().get(subNum - 1).getQuestionList().get(m);
                        info.setIndex(index);
                        list.add(new QuestionResultEntity(false, info));
                    }
                    subNum += 1;
                }
            } else {
                int size = subList.get(i).getList().size();
                for (int j = 0; j < size; j++) {
                    QuestionInfoEntity info = CacheUtil.INSTANCE.getQuestionList().get(subNum - 1);
                    List<QuestionDbEntity> list2 = LitePal.findAll(QuestionDbEntity.class);
                    info.setIndex(String.valueOf(subNum));
                    list.add(new QuestionResultEntity(false, info));
                    subNum += 1;
                }
            }


        }
        return list;
    }

    public static ArrayList<QuestionResultEntity> getQuestionCardData2() {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        for (int i = 1; i < 9; i++) {
            if (i == 5) {
                Log.v("yxy", "==start=>" + StringUtil.getSubjectTypeByType(i) + "===" + i);
                for (int j = 1; j < 4; j++) {
                    List<QuestionDbEntity> questions = LitePal.where("topicCategory =?", String.valueOf(j)).find(QuestionDbEntity.class);
                    if (questions.size() > 0) {
                        list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeBy5(j)));
                        for (QuestionDbEntity info : questions) {
                            list.add(new QuestionResultEntity(false, info));
                        }
                    }
                }
            } else {
                List<QuestionDbEntity> questions = LitePal.where("liftingType =?", String.valueOf(i)).find(QuestionDbEntity.class);

                if (questions.size() > 0) {
                    list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(i)));
                    for (QuestionDbEntity info : questions) {
                        list.add(new QuestionResultEntity(false, info));
                    }
                }
            }
        }
        return list;
    }

    public static ArrayList<QuestionResultEntity> getQuestionErrorCardData2() {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        for (int i = 1; i < 9; i++) {
            if (i != 5) {
                List<QuestionDbEntity> questions = LitePal.where("liftingType =?", String.valueOf(i)).find(QuestionDbEntity.class);

                if (questions.size() > 0) {
                    ArrayList<QuestionDbEntity> errorList = new ArrayList<QuestionDbEntity>();
//                    Log.v("yxy", "==getQuestionPaperCardData2=>" + GsonUtils.toJson(questions.get(0).getWdQuestionChapterPractice()));
                    for (QuestionDbEntity info : questions) {
                        if (StringUtil.isNotBlank(info.getWdQuestionChapterPractice())) {
                            WdQuestionChapterPracticeEntity practice = GsonUtils.fromJson(info.getWdQuestionChapterPractice(), WdQuestionChapterPracticeEntity.class);
                            if (practice != null) {
                                if (practice.getIsRight().equals("1")) {
                                    errorList.add(info);
                                }
                            }
                        } else {
                            errorList.add(info);
                        }

                    }
                    if (errorList.size() > 0) {
                        list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(i)));
                    }

                    for (QuestionDbEntity info : questions) {
                        if (StringUtil.isNotBlank(info.getWdQuestionChapterPractice())) {
                            WdQuestionChapterPracticeEntity practice = GsonUtils.fromJson(info.getWdQuestionChapterPractice(), WdQuestionChapterPracticeEntity.class);
                            if (practice != null) {
                                if (practice.getIsRight().equals("1")) {
                                    list.add(new QuestionResultEntity(false, info));
                                }
                            }
                        } else {
                            list.add(new QuestionResultEntity(false, info));
                        }


                    }
                }
            }
        }
        return list;
    }

    public static ArrayList<QuestionResultEntity> getQuestionPaperCardData2() {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        for (int i = 1; i < 9; i++) {
            if (i == 5) {
                for (int j = 1; j < 4; j++) {
                    List<QuestionPaperDbEntity> questions = LitePal.where("topicCategory =?", String.valueOf(j)).find(QuestionPaperDbEntity.class);
                    if (questions.size() > 0) {
                        list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeBy5(j)));
                        for (QuestionPaperDbEntity info : questions) {
                            list.add(new QuestionResultEntity(false, info));
                        }
                    }
                }
            } else {
                List<QuestionPaperDbEntity> questions = LitePal.where("liftingType =?", String.valueOf(i)).find(QuestionPaperDbEntity.class);
                if (questions.size() > 0) {
                    list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(i)));
                    Log.v("yxy", "==getQuestionPaperCardData2=>" + GsonUtils.toJson(questions.get(0).getWdQuestionChapterPractice()));
                    for (QuestionPaperDbEntity info : questions) {
                        list.add(new QuestionResultEntity(false, info));
                    }
                }


            }
        }
        return list;
    }

    public static ArrayList<QuestionResultEntity> getQuestionPaperErrorCardData2() {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        for (int i = 1; i < 9; i++) {
            if (i != 5) {
                List<QuestionPaperDbEntity> questions = LitePal.where("liftingType =?", String.valueOf(i)).find(QuestionPaperDbEntity.class);
                if (questions.size() > 0) {
                    ArrayList<QuestionPaperDbEntity> errorList = new ArrayList<QuestionPaperDbEntity>();
//                    Log.v("yxy", "==getQuestionPaperCardData2=>" + GsonUtils.toJson(questions.get(0).getWdQuestionChapterPractice()));
                    for (QuestionPaperDbEntity info : questions) {
                        if (StringUtil.isNotBlank(info.getWdQuestionChapterPractice())) {
                            WdQuestionChapterPracticeEntity practice = GsonUtils.fromJson(info.getWdQuestionChapterPractice(), WdQuestionChapterPracticeEntity.class);
                            if (practice != null) {
                                if (practice.getIsRight().equals("1")) {
                                    errorList.add(info);
                                }
                            }
                        } else {
                            errorList.add(info);
                        }

                    }
                    if (errorList.size() > 0) {
                        list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(i)));
                    }
                    for (QuestionPaperDbEntity info : questions) {
                        if (StringUtil.isNotBlank(info.getWdQuestionChapterPractice())) {
                            WdQuestionChapterPracticeEntity practice = GsonUtils.fromJson(info.getWdQuestionChapterPractice(), WdQuestionChapterPracticeEntity.class);
                            if (practice != null) {
                                if (practice.getIsRight().equals("1")) {
                                    list.add(new QuestionResultEntity(false, info));
                                }
                            }
                        } else {
                            list.add(new QuestionResultEntity(false, info));
                        }

                    }


                }
            }
        }
        return list;
    }

    /**
     * 获取对应题干的序号
     *
     * @param subList
     * @return
     */
    public static ArrayList<QuestionResultEntity> getQuestionPaperCardData(ArrayList<QuestionPaperSubjectEntity> subList) {
        ArrayList<QuestionResultEntity> list = new ArrayList<QuestionResultEntity>();
        int subNum = 1;
        for (int i = 0; i < subList.size(); i++) {
            list.add(new QuestionResultEntity(true, StringUtil.getSubjectTypeByType(subList.get(i).getType())));
            if (subList.get(i).getType() == 3 || subList.get(i).getType() == 4) {
                QuestionPaperSubjectEntity chapterSub = subList.get(i);
                for (int k = 0; k < chapterSub.getList().size(); k++) {
                    ArrayList<QuestionPaperInfoEntity> subs = chapterSub.getList().get(k).getWdQuestionPaperSubjectSubordinatesList();
                    for (int m = 0; m < subs.size(); m++) {
//                        Log.v("yxy","=subNum="+subNum+"==="+m+"===="+CacheUtil.INSTANCE.getQuestionPaperList().size());
                        QuestionPaperInfoEntity quesiton = CacheUtil.INSTANCE.getQuestionPaperList().get(subNum - 1).getWdQuestionPaperSubjectSubordinatesList().get(m);
                        String index = (subNum) + "-" + (m + 1);
                        quesiton.setIndex(index);
                        list.add(new QuestionResultEntity(false, quesiton));
                    }
                    subNum += 1;
                }

            } else {
                for (int j = 0; j < subList.get(i).getList().size(); j++) {
                    Log.v("yxy", "sub===" + subList.get(i).getType() + "======" + subNum + "============" + subList.get(i).getList().size());
                    subList.get(i).getList().get(j).setIndex(String.valueOf(subNum));
                    list.add(new QuestionResultEntity(false, subList.get(i).getList().get(j)));
                    subNum += 1;
                }
            }


        }

        return list;
    }


    public static ArrayList<CodeEntity> getEducationData() {
        ArrayList<CodeEntity> mDataList = new ArrayList<>();
        CodeEntity work = null;

        work = new CodeEntity();
        work.setType("1");
        work.setLabel("中专");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("2");
        work.setLabel("大专");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("3");
        work.setLabel("本科");
        mDataList.add(work);
        work = new CodeEntity();
        work.setType("4");
        work.setLabel("硕士");
        mDataList.add(work);
        work = new CodeEntity();

        work.setType("5");
        work.setLabel("博士");
        mDataList.add(work);
        return mDataList;
    }
}
