package com.wendu.wenduyikao.data;

public class Constants {
    //weixin
//    APPID: wx3da7ce1f96ea431a
//    APPSECRET: 5a53e96a2ff43a015db24b81aab35f6b
    public static final String WX_APP_ID = "wx3da7ce1f96ea431a";
    public static final String WX_APP_MOCK_ID = "wxcfa6aad936fccedd";

    // qq
//    appKey: 1105657829
//    appSecret: UKm2rcvVhRjWkZsd

    public static final String QQ_APP_ID = "1105657829";
    public static final String APP_AUTHORITIES = "com.wendu.wenduyikao.fileprovider";

    //阿里一键登录
//    Z2sXGuoc0eLo60486Md5lfEMoOyc9SIwUduIO1Y8vyUZeky2GsrXIEPrSOmvtpIFUVl/ZWG1LKw8bPMoj4ePEHNaF3RaYL5TVZWFiAxkXT46qFIrstFZd/zg0DQENEE5OlfSTLAS5e/HmBB5hOMlvjF+veXXnjeeih+3dGCv45wA1wFvOl2Lm2x01pP3Fuo7StU2hiFUPyz50zeA7vvClHOnJDgO2VbN786pkeSE/cfIWfzAmORpOeUmySl6umN5Ul3WswDx41FhqDC4OGBKU+44qFeAFvpfTA+90+jeEihhDf3zoW313A==
    public static final String AUTH_SECRET = " Z2sXGuoc0eLo60486Md5lfEMoOyc9SIwUduIO1Y8vyUZeky2GsrXIEPrSOmvtpIFUVl/ZWG1LKw8bPMoj4ePEHNaF3RaYL5TVZWFiAxkXT46qFIrstFZd/zg0DQENEE5OlfSTLAS5e/HmBB5hOMlvjF+veXXnjeeih+3dGCv45wA1wFvOl2Lm2x01pP3Fuo7StU2hiFUPyz50zeA7vvClHOnJDgO2VbN786pkeSE/cfIWfzAmORpOeUmySl6umN5Ul3WswDx41FhqDC4OGBKU+44qFeAFvpfTA+90+jeEihhDf3zoW313A==";
    public static final int PERMISSIONS_REQUEST_STORAGE = 1;


    //    全局 静态参数
    //章节练习
    public static final String PARAMS_QUESTION_SOURCE_CHAPTER = "chapter";
    public static final String PARAMS_QUESTION_CHAPTER_ID = "chapterId";
    public static final String PARAMS_QUESTION_TEMPLATE_ID = "templateId";
    public static final String PARAMS_QUESTION_CLASS_ID = "classId";
    //试卷
    public static final String PARAMS_QUESTION_SOURCE_PAPER = "paper";
    //真题
    public static final String PARAMS_QUESTION_SOURCE_REAL = "pets";
    //错题练习
    public static final String PARAMS_QUESTION_SOURCE_ERROR = "error";

    //试卷练习
    public static final String PARAMS_QUESTION_SOURCE_PAPER_ERROR = "paper_error";
    //解析
    public static final String PARAMS_QUESTION_SOURCE_RESOLVE = "resolve";
    //答题报告
    public static final String PARAMS_QUESTION_RESULT = "result";
    //笔记
    public static final String PARAMS_QUESTION_SOURCE_NOTE = "note";
    //笔记
    public static final String PARAMS_QUESTION_SOURCE_CHAPTER_INFO = "chapter_info";
    //答题卡
    public static final String PARAMS_QUESTION_SOURCE_CARD = "card";
    //精品试题--试卷格式的答题模式
    public static final String PARAMS_QUESTION_SOURCE_BOUTIQUE = "boutique";

    //消灭错题
    public static final String PARAMS_QUESTION_ERROR = "question_error";

    //学习-服务-考试测评
    public static final String PARAMS_QUESTION_SOURCE_STUDY_PAPER = "study_paper";
    //模拟试卷
    public static final String PARAMS_QUESTION_SOURCE_MOCK = "mock";


    //数据加载类型
    //1 章节练习
    public static final int PARAMS_QUESTION_LOAD_TYPE_CHAPTER = 1;
    //2 试卷管理（历年真题和精品题库）
    public static final int PARAMS_QUESTION_LOAD_TYPE_PAPER = 2;

    //3 评测试卷
    public static final int PARAMS_QUESTION_LOAD_TYPE_TEST = 3;
    //4 模拟考试
    public static final int PARAMS_QUESTION_LOAD_TYPE_MOCK = 4;
    //5 模拟考试
    public static final int PARAMS_QUESTION_LOAD_TYPE_JINGDIAN = 5;



    public static final String XIAOMI_ID = "2882303761517518910";
    public static final String XIAOMI_KEY = "5601751843910";


    public static final String meizuAppId = "131871";
    public static final String meizuAppKey = "2a22636c4d2245de9835a8ee69f7a696";

    public static final String oppoappkey = "BCabpfgSWgg8G4WC0W04ocO8g";
    public static final String appserversecret = "9135bBf647F6149e53777dC46b4Fe314";
    public static  float questionTextSize = 15f;
    public static  int currentMode = 0;

//
//    华为Appid：10691022
//    华为Secret：3e0bf184ea856b59511bd7492d248669





//    魅族Appid  3141425
//    魅族Key: d7e2e3787512447db1d09a69ea9e48ed
//    魅族Secret  nxroKj8wwt2orxIhCr8ucuJOaSOJzQEm
//    推送：
//    appId：131871
//    key：2a22636c4d2245de9835a8ee69f7a696
//    secret：c013a00754fb44b68014b774006e73ce

//
//    Vivo Appid：100063086
//    Vivo Appkey：fc270d6e2840f945055e84527a25a224
//    Vivo AppSecret：26bec3ba-3b5e-424e-b718-4eeaac7b9738



//
//            Oppo
//    appid: 3558232
//    appkey:BCabpfgSWgg8G4WC0W04ocO8g(勿外泄)
//    appsecret:9135bBf647F6149e53777dC46b4Fe314(勿外泄)
//    appserversecret:B718c17587fB92EaDC26C177dc904706(勿外泄)
//    推送：
//    AppID: 3558232
//    Appkey: BCabpfgSWgg8G4WC0W04ocO8g
//    appSecret: 9135bBf647F6149e53777dC46b4Fe314
}
