package com.wendu.wenduyikao.data.constans

import androidx.core.content.res.ResourcesCompat
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R

/**
 * author:yxm on 2021/8/11 19:33
 * email:943789510@qq.com
 * describe: 课程资源类型
 */
class CourseAttributeTypeConst {
   companion object{
       val GUIDANCE_STAGE = 1 //导学阶段
       val BASIC_STAGE = 2 //基础阶段
       val SKILL_STAGE = 3 //技能阶段
       val SPRINT_STAGE = 4 //冲刺阶段
       val PRE_EXAM_STAGE = 5 //考前阶段
       val SECOND_EXAM_STAGE = 6 //二试阶段
   }


}


fun RTextView.setCourseAttributeTypeUI(type:Int,label:String){
    when (type) {
        CourseAttributeTypeConst.GUIDANCE_STAGE ->{
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_daoxue_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_daoxue,null)
//            text = "导学阶段"
            text =label
        }
        CourseAttributeTypeConst.BASIC_STAGE -> {
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jichu_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jichu,null)
//            text = "基础阶段"
            text =label
        }
        CourseAttributeTypeConst.SKILL_STAGE->{
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jineng_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jineng,null)
//            text = "技能阶段"
            text =label
        }
        CourseAttributeTypeConst.SPRINT_STAGE->{
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_chongci_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_chongci,null)
//            text = "冲刺阶段"
            text =label
        }
        CourseAttributeTypeConst.PRE_EXAM_STAGE->{
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_kaoqian_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_kaoqian,null)
//            text = "考前阶段"
            text =label
        }
        CourseAttributeTypeConst.SECOND_EXAM_STAGE->{
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_ershi_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_ershi,null)
//            text = "二试阶段"
            text =label
        }
        else -> {
            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jichu_bg,null)
            textColorNormal = ResourcesCompat.getColor(resources,R.color.course_type_jichu,null)
            text = label
        }
    }
}