package com.wendu.wenduyikao.data.constans;

/**
 * Created by yxm on 2020/7/3.
 * 下载状态 1.未下载, 2.下载中, 3.下载完成, 4.下载暂停, 5.下载错误
 */
public class DownLoadStatusConst {

    /**
     * 未下载
     */
    public static final int NO_DOWN = 1;
    /**
     * 下载中
     */
    public static final int CURRENT_DOWN = 2;
    /**
     * 下载完成
     */
    public static final int SUCCESS_DOWN = 3;
    /**
     * 下载暂停
     */
    public static final int PAUSE_DOWNLOAD = 4;
    /**
     * 下载错误
     */
    public static final int ERROR = 5;




    /**
     * course状态
     */
    public static final int NED_CLASS = 1; //已结课
    public static final int NO_NED_CLASS = 0; //未结课
}
