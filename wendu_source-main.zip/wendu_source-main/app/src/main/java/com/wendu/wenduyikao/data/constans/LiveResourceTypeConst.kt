package com.wendu.wenduyikao.data.constans

import android.annotation.SuppressLint
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.content.res.ResourcesCompat
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.App
import kotlinx.android.synthetic.main.activity_paper_resolve.*
import java.math.BigDecimal

/**
 * author:yxm on 2021/8/11 19:33
 * email:943789510@qq.com
 * describe: 直播资源的状态
 */
class LiveResourceTypeConst {
    companion object {
        val NOSTART = 1 //直播未开始
        val LIVEING = 2 //直播中
        val LIVECOMPLITE = 3 //直播完成--回放生成中
        val PLAYBACK = 4 //回放

        val VIDEO_WAIT_UPDATE = 10 //视频--待更新
        val VIDEO_UPDATE = 11 //视频--已更新

        val AUDITION = 5 //试听
        val LEARNED = 6 //已学
        val NOTBOUGHT = 7 //未购买

        val LIVE_AGREE = 8 //直播预约--提醒我
        val LIVE_AGREED = 9 //直播已预约成功--已预约

        val COURSE_LOCK = 12 //课程学习
        val COURSE_UNLOCK = 13 //课程学习
        fun getLiveType(status: Int): String {
            when (status) {
                LIVEING -> {
                    return "直播中"
                }
                PLAYBACK -> {
                    return "回放"
                }
                LIVECOMPLITE -> {
                    return "已结束"
                }
                NOSTART -> {
                    return "未开始"
                }
                VIDEO_UPDATE -> {
                    return "已更新"
                }
                VIDEO_WAIT_UPDATE -> {
                    return "待更新"
                }
                AUDITION -> {
                    return "试听"
                }
                LEARNED -> {
                    return "已学"
                }
                NOTBOUGHT -> {
                    return "未购买"
                }
                LIVE_AGREE -> {
                    return "提醒我"
                }
                LIVE_AGREED -> {
                    return "已预约"
                }
            }
            return "未购买"
        }
    }


}
//@SuppressLint("SetTextI18n")
//fun RTextView.setCustomerUI(type:Int, learnProcess:BigDecimal) : RTextView{
//    when (type) {
//        LiveResourceTypeConst.LIVEING ->{
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.font_orange,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "直播中"
//        }
//        LiveResourceTypeConst.LIVECOMPLITE -> {
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.font_yellow,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "回放"
//        }
//        LiveResourceTypeConst.PLAYBACK -> {
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.font_yellow,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "已结束"
//        }
//        LiveResourceTypeConst.NOSTART->{
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.main_color,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "未开始"
//        }
//        LiveResourceTypeConst.LIVE_AGREE->{
//            iconNormal = null
//            background = ResourcesCompat.getDrawable(resources,R.drawable.bg_rectangle_radius15_main_gradient,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "提醒我"
//        }
//        LiveResourceTypeConst.LIVE_AGREED->{
//            iconNormal = null
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.main_color,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.white,null)
//            text = "已预约"
//        }
//        LiveResourceTypeConst.AUDITION->{
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.view_green,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.font_green_fresh,null)
//            text = "试听"
//        }
//        LiveResourceTypeConst.LEARNED->{
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.view_blue,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.font_blue,null)
////            text = "已学${learnProcess}%"
//            text = "学习中"
//        }
//        LiveResourceTypeConst.NOTBOUGHT->{
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.text_color_ccc,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.text_color_666,null)
//            text = "未订购"
//        }
//        else -> {
//            iconNormal = ResourcesCompat.getDrawable(resources,R.mipmap.ic_course_live,null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources,R.color.text_color_ccc,null)
//            textColorNormal = ResourcesCompat.getColor(resources,R.color.text_color_666,null)
//            text = "未订购"
//        }
//    }
//    return this
//}

@SuppressLint("SetTextI18n")
fun RTextView.setCustomerUIForAudition(type: Int, learnProcess: BigDecimal): RTextView {
    iconNormal = null
    when (type) {
        LiveResourceTypeConst.VIDEO_WAIT_UPDATE -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_refresh, null)
            backgroundColorNormal =
                ResourcesCompat.getColor(resources, R.color.wait_update_video, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "待更新"
        }
        LiveResourceTypeConst.VIDEO_UPDATE -> {
            Log.v("yxy", "===播放按钮==")
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_video, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.main_color, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "播放"
        }
        LiveResourceTypeConst.LIVEING -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_live, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.font_orange, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "直播中"
        }
        LiveResourceTypeConst.LIVECOMPLITE -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_live, null)
            backgroundColorNormal =
                ResourcesCompat.getColor(resources, R.color.text_color_999, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "已结束"
        }
        LiveResourceTypeConst.PLAYBACK -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_live, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.font_yellow, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "回放"
        }
        LiveResourceTypeConst.NOSTART -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_course_live, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.main_color, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "待直播"
        }

        LiveResourceTypeConst.LIVE_AGREE -> {
            iconNormal = null
            background = ResourcesCompat.getDrawable(  resources,   R.drawable.bg_rectangle_radius15_main_gradient,null )
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "提醒我"
        }
        LiveResourceTypeConst.LIVE_AGREED -> {
            iconNormal = null
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.main_color, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "已预约"
        }
        LiveResourceTypeConst.AUDITION -> {
            iconNormal = null
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.view_green, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.font_green_fresh, null)
            text = "试听"
        }
        LiveResourceTypeConst.LEARNED -> {
            Log.v("yxy", "===学习==")
            iconNormal = null
//            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.ic_account_qq, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.view_blue, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.font_blue, null)
            if (learnProcess == BigDecimal(100)) {
                text = "已学完"
            } else {
                text = "已学${learnProcess}%"
            }
        }
        LiveResourceTypeConst.NOTBOUGHT -> {
            iconNormal = null
            backgroundColorNormal =
                ResourcesCompat.getColor(resources, R.color.text_color_ccc, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.text_color_666, null)
            text = "未订购"
        }
        LiveResourceTypeConst.COURSE_UNLOCK -> {
            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.icon_lock_white, null)
            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.main_color, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
            text = "解锁"
        }
        else -> {
            iconNormal = null
            backgroundColorNormal =
                ResourcesCompat.getColor(resources, R.color.text_color_ccc, null)
            textColorNormal = ResourcesCompat.getColor(resources, R.color.text_color_666, null)
            text = "未订购"
        }
    }
    return this
}

fun setCustomerUIForAudition2(type: Int, learnProcess: BigDecimal, rText: RTextView) {

    when (type) {
        LiveResourceTypeConst.VIDEO_WAIT_UPDATE -> {
            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_refresh)
            rText.backgroundColorNormal = App.instance.getColor(R.color.wait_update_video)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.text = "待更新"

        }
        LiveResourceTypeConst.VIDEO_UPDATE -> {
            Log.v("yxy", "===播放按钮==")


            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_video)
            rText.backgroundColorNormal = App.instance.getColor(R.color.main_color)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "播放"
        }
        LiveResourceTypeConst.LIVEING -> {


            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_live)
            rText.backgroundColorNormal = App.instance.getColor(R.color.font_orange)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.text = "直播中"
        }
        LiveResourceTypeConst.LIVECOMPLITE -> {

            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_live)
            rText.backgroundColorNormal = App.instance.getColor(R.color.text_color_999)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "已结束"
        }
        LiveResourceTypeConst.PLAYBACK -> {

            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_live)
            rText.backgroundColorNormal = App.instance.getColor(R.color.font_yellow)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.text = "回放"
        }
        LiveResourceTypeConst.NOSTART -> {

            rText.iconNormal = App.instance.getDrawable(R.mipmap.ic_course_live)
            rText.backgroundColorNormal = App.instance.getColor(R.color.main_color)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "待直播"
        }

        LiveResourceTypeConst.LIVE_AGREE -> {
            rText.iconNormal = null
            rText.background = App.instance.getDrawable(R.drawable.bg_rectangle_radius15_main_gradient)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "提醒我"
        }

        LiveResourceTypeConst.COURSE_UNLOCK -> {
            rText.iconNormal = null
            rText.background = App.instance.getDrawable(R.drawable.bg_rectangle_radius15_main_gradient)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(R.mipmap.ic_unlock,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "未解锁"
        }

        LiveResourceTypeConst.LIVE_AGREED -> {

            rText.iconNormal = null
            rText.background = App.instance.getDrawable(R.color.main_color)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.white))
            rText.text = "已预约"
        }
        LiveResourceTypeConst.AUDITION -> {
            rText.iconNormal = null
            rText.background = App.instance.getDrawable(R.color.view_green)
            rText.setTextColor(App.instance.getColor(R.color.font_green_fresh))
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.text = "试听"
        }
        LiveResourceTypeConst.LEARNED -> {
            Log.v("yxy", "===学习==")

            rText.iconNormal = null
            rText.backgroundColorNormal = App.instance.getColor(R.color.view_blue)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.font_blue))
            if (learnProcess == BigDecimal(100)) {
                rText.text = "已学完"
            } else {
                rText.text = "已学${learnProcess}%"
            }
        }
        LiveResourceTypeConst.NOTBOUGHT -> {

            rText.iconNormal = null
            rText.backgroundColorNormal = App.instance.getColor(R.color.text_color_ccc)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.text_color_666))
            rText.text = "未订购"
        }
        LiveResourceTypeConst.COURSE_UNLOCK -> {
//            iconNormal = ResourcesCompat.getDrawable(resources, R.mipmap.icon_lock_white, null)
//            backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.main_color, null)
//            textColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
//            text = "解锁"

            rText.iconNormal = App.instance.getDrawable(R.mipmap.icon_lock_white)
            rText.backgroundColorNormal = App.instance.getColor(R.color.white)
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.setTextColor(App.instance.getColor(R.color.main_color))
            rText.text = "解锁"
        }
        else -> {
            rText.iconNormal = null
            rText.backgroundColorNormal = App.instance.getColor(R.color.white)
            rText.setTextColor(App.instance.getColor(R.color.text_color_ccc))
            rText.setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
            rText.text = "未订购"


        }
    }

}