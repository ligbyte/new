package com.wendu.wenduyikao.data.constans

object MainTabConst {
    val HOME = 0 //首页
    val QUESTION = 1 //题库
    val STUDY = 2 //课程
    val DISCOVERY = 3 //发现
    val MINE = 4 //我的
}