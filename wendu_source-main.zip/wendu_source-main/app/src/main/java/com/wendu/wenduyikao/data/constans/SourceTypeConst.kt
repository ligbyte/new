package com.wendu.wenduyikao.data.constans

/**
 * Created by yxm on 2020/4/13.
 *
 * 资源类型
 *
 */
object SourceTypeConst {
    const val ALL = 0 //全部
    const val LIVE = 1 //直播资源
    const val VIDEO = 2 //视频资源
    const val CLAZZ = 3 //课程班
    const val FACE = 4 //面授班
}