package com.wendu.wenduyikao.data.eventbus;

/**
 * Created by yxm on 2020/1/8.
 *
 * 该事件用于监听页面滑动状态，，以改变主页浮动布局状态
 */
public class MainScrollViewEvent {


    public int SCROLL_UP = 1;
    public int SCROLL_DOWN = 2;

    //滑动方向 1--向上  2--向下
    public int scrollDirection;

    //纵向滑动距离
    public int scrollYDistance = 0;
}
