package com.wendu.wenduyikao.data.eventbus

/**
 * Created：yxm on 2021/9/3 0003.
 * Email：943789510@qq.com
 * Description:课程选择
 */
class MainTabChooseEvent {

    var position = 0
    var isLibrary = false

    constructor(position:Int) {
        this.position = position
    }
    constructor(position:Int,isLibrary:Boolean) {
        this.position = position
        this.isLibrary = isLibrary
    }


}