package com.wendu.wenduyikao.data.eventbus

/**
 * author:yxm on 2021/9/14 01:58
 * email:943789510@qq.com
 * describe:
 */
class PPtEvent(materials:MutableList<String>) {
    val materials:MutableList<String> = materials
}