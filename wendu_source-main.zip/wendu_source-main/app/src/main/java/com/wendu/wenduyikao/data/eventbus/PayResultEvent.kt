package com.wendu.wenduyikao.data.eventbus

/**
 * 微信支付, 支付宝支付, 余额支付结果回调事件分发
 */
class PayResultEvent(
    /**
     * 是否支付成功
     */
    var isSuccess: Boolean
)