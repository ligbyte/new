package com.wendu.wenduyikao.data.eventbus

/**
 * Created：yxm on 2021/9/3 0003.
 * Email：943789510@qq.com
 * Description:课程选择
 */
class RefreshChooseCourseClassEvent(chooseCourseClassId:String) {
    var chooseCourseClassId = chooseCourseClassId
}