package com.wendu.wenduyikao.data.eventbus


class RefreshStudyCourseEvent {
}