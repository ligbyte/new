package com.wendu.wenduyikao.data.eventbus;

public class StudentNewsEvent {
}
