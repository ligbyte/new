package com.wendu.wenduyikao.data.eventbus

/**
 * author:yxm on 2021/9/14 00:34
 * email:943789510@qq.com
 * describe:
 */
class SubmitLearnEvent(progress:Int) {
    var progress = progress
}