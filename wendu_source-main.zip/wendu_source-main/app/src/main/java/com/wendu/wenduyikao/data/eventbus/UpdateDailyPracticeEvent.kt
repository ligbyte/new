package com.wendu.wenduyikao.data.eventbus

class UpdateDailyPracticeEvent {
}