package com.wendu.wenduyikao.data.eventbus

/**
 * Created：yxm on 2021/9/3 0003.
 * Email：943789510@qq.com
 * Description:
 */
class VisableEvent {
    var visable:Int = 0
    constructor(visable:Int){
        this.visable = visable
    }
}