package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ActivityShareResult
 * Author:         xiaoyangyan
 * CreateDate:    2022/2/24
 * Description:
 */
public class ActivityShareResult implements Serializable {
    private String informationUrl;
    private String informationUrlTest;

    public String getInformationUrlTest() {
        return informationUrlTest;
    }

    public void setInformationUrlTest(String informationUrlTest) {
        this.informationUrlTest = informationUrlTest;
    }

    public String getInformationUrl() {
        return informationUrl;
    }

    public void setInformationUrl(String informationUrl) {
        this.informationUrl = informationUrl;
    }
}
