package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     AddressInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/10
 * Description:
 */
@Parcelize
class AddressInfoEntity(
    val address: String,
    val area: String,
    val code: String,
    val createBy: String,
    val createTime: String,
    val id: String,
    val isdefault: String,
    val name: String,
    val areaName: String,
    val areaText: String,
    val areaNo: String,
    val phone: String,
    val studentId: String,
    val sysOrgCode: String,
    val tenantId: String,
    val updateBy: String,
    val updateTime: String
) : Parcelable