package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/8/16 21:59
 * email:943789510@qq.com
 * describe:
 */
data class ApiPageResponse<T>(
    val total: Int = 0,
    val size: Int = 0,
    val current: Int = 0,
    val pages: Int = 0,
    val records: MutableList<T>
)

