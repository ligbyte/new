package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/20 21:19
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class AuditionCourseEntity(
    val id: String = "",
    val playCount: Int = 0,
    val courseName: String = "",
    val courseId: String = "",
    val courseImgPath: String = "",
    val teacherimagePhoto: String = "",
    val vid: String = "",
    val isNoBuy:Int = 0, //0未购买 1已购买
    val isAudition:Int = 0,   //1 - 试听  0 -不试听
    val unlock:UnlockEntity,
    val materials: ArrayList<String> = arrayListOf()
) : Parcelable