package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     AuditionDemoLessonEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/7/22
 * Description:
 */
@Parcelize
class AuditionDemoLessonEntity(
    val wdCourseLiveList: ArrayList<LiveCourseEntity>,
    val wdCourseList: ArrayList<AuditionCourseEntity>,
) : Parcelable