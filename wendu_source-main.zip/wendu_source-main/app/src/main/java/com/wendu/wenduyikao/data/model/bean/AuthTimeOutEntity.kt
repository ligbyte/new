package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     AuthTimeOutEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/12/27
 * Description:
 */
@Parcelize
class AuthTimeOutEntity(
    val code: Int,
    val message: String,
    val success: Boolean,
    val timestamp: Long
) : Parcelable