package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BannerPopupEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/5
 * Description:
 */
@Parcelize
class BannerPopupEntity(
    val bannerName: String,
    val bannerType: String,
    val clickEvent: String, //0 无；1网址 2课程班级 3 面授班级   4图书详情   题库详情  6 优惠券
    val createBy: String,
    val createTime: String,
    val endTime: String,
    val id: String,
    val pcImage: String,
    val phoneImage: String,
    val releaseStatus: String,
    val skipUrl: String,  //链接地址或者课程面授地址，题库详情id
    val startTime: String,
    val sysOrgCode: String,
    val tenantId: String,
    val updateBy: String,
    val updateTime: String,
    val wdCoupon: WdCoupon?
) : Parcelable

@Parcelize
class WdCoupon(
    val category: Int,
    val classesIds: String,
    val content: String,
    val couponAmount: Int,
    val couponName: String,
    val couponStatus: String,
    val createTime: String,
    val creator: String,
    val discountAmount: Double,
    val effectiveTimeEnd: String,
    val effectiveTimeStart: String,
    val fixDays: Int,
    val flg: String,
    val hasThreshold: Int,
    val id: String,
    val isDeleted: Int,
    val isPublish: Int,
    val receiveAmount: Int,
    val timeLimit: Int,
    val type: Int,
    val updateTime: String,
    val updater: String,
    val useLimit: Double
) : Parcelable