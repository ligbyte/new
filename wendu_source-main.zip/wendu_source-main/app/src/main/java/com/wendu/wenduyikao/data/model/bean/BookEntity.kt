package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

/**
 * author:yxm on 2021/8/22 17:04
 * email:943789510@qq.com
 * describe: 图书
 */
@Parcelize
data class BookEntity(
    val id: String = "",
    val booksName: String = "",
    val booksImgPath: String = "",
    val bookEntity: BookInfoEntity
) : Parcelable{

    val price:Double  = 0.0
//        val price:BigDecimal? = null
//        get() = field ?: BigDecimal(0)

    }
