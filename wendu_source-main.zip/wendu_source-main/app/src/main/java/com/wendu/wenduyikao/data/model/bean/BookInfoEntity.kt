package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BookInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/22
 * Description:
 */
@Parcelize
class BookInfoEntity(
    val bookCode: String,
    val bookName: String,
    val content: String,
    val createTime: String,
    val creator: String,
    val dealerPrice: Double,
    val id: String,
    val image: String,
    val images: String,
    val isDeleted: Int,
    val isOversold: Int,
    val isPutway: Int,
    val majorId: String,
    val officalPrice: Double,
    val sales: String,
    val sellingPoints: String,
    val stock: Int,
    val subMajorId: String,
    val updateTime: String,
    val updater: String
) : Parcelable