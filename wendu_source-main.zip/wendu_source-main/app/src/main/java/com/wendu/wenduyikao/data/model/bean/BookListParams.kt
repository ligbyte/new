package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class BookListParams(
    val bookAmount: Double,
    val bookId: String,
    val id: String,
) : Parcelable