package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     bookOrderEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/26
 * Description:
 */
@Parcelize
class BookOrderEntity(
    val actualPrice: Double,
    val bookAmount: Int,
    val couponId: String,
    val courseId: String,
    val createTime: String,
    val customId: String,
    val discountAmount: Double,
    val generationType:Int,
    val expressCompany: String,
    val expressNumber: String,
    val id: String,
    val orderArea: String,
    val orderAreaAddress: String,
    val orderAreaCode: String,
    val orderAreaName: String,
    val orderAreaPhone: String,
    val orderId: String,
    val orderSource: Int,
    val orderType: Int,
    val paymentId: String,
    val paymentTime: String,
    val paymentWay: Int,
    val sendTime: String,
    val shippingAddress: String,
    val status: Int, //0待付款，1已取消，2待发货，3已发货，4已完成
    val bookOrderItemList: ArrayList<ShopCarInfoEntity>,
    val jsonObjectList: ArrayList<BookOrderItemEntity>,
    val totalPrice: Double
) : Parcelable