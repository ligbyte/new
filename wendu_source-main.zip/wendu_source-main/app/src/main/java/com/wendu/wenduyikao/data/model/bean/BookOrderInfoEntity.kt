package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BookInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/22
 * Description: 图书订单详情
 */
@Parcelize
class BookOrderInfoEntity(
    val wdOrder: BookOrderEntity,
    val wdBookOrder: BookOrderEntity

) : Parcelable



@Parcelize
class WdBookOrder(
//    val actualPrice: Int,
//    val bookAmount: Int,
//    val bookOrderItemList: Any,
//    val confirmTime: Any,
//    val couponId: Any,
//    val courseId: String,
//    val createTime: String,
//    val customId: String,
//    val dicId: Any,
//    val discountAmount: Int,
//    val expressCompany: Any,
//    val expressNumber: Any,
//    val id: String,
//    val jsonObjectList: Any,
//    val orderArea: Any,
//    val orderAreaAddress: Any,
//    val orderAreaCode: Any,
//    val orderAreaName: Any,
//    val orderAreaPhone: Any,
//    val orderId: String,
//    val orderSource: Int,
//    val orderType: Int,
//    val orderWay: String,
//    val paymentId: Any,
//    val paymentTime: Any,
//    val paymentWay: Any,
//    val returnTime: Any,
//    val sendTime: Any,
//    val shippingAddress: Any,
    val status: Int,
    val totalPrice: Int
) : Parcelable
