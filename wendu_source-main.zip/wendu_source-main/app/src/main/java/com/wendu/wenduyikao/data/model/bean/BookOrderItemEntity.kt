package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BookOrderItemEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/3
 * Description:
 */
@Parcelize
class BookOrderItemEntity(
    val bookAmount: Int,
    val bookId: String,
    val bookPrice: Double,
    val confirmTime: Long,
    val expressCompany: String,
    val expressNumber: String,
    val id: String,
    val orderId: String,
    val subTotal: Double,
    val wdBook: BookInfoEntity,
    val itemList:ArrayList<BookOrderItemEntity>
) : Parcelable
