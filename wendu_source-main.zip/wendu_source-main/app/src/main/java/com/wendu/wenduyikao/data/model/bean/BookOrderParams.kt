package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BookOrderItemEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/3
 * Description:
 */
@Parcelize
class BookOrderParams(
    val channel: String,
    val couponId: String,
    val courseId: String,
    val flag: Int,
    val orderArea: String,
    val orderAreaAddress: String,
    val orderAreaCode: String,
    val orderAreaId: String,
    val orderAreaName: String,
    val orderAreaPhone: String,
    val orderId: String,
    val orderWay: String,
    val bookList:ArrayList<BookListParams>
) : Parcelable
