package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BookShopClassifyEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/22
 * Description:
 */
@Parcelize
class BookShopClassifyEntity(
    val bookList: ArrayList<BookInfoEntity>,
    val createBy: String,
    val createTime: String,
    val hideStatus: String,
    val id: String,
    val isLeaf: Int,
    val majorName: String,
    val menuType: String,
    val sort: Int,
    val sysOrgCode: String
) : Parcelable