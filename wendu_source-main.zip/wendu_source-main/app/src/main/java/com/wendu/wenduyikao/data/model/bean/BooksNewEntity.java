package com.wendu.wenduyikao.data.model.bean;

import com.chad.library.adapter.base.entity.MultiItemEntity;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     BooksNewEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/4/14
 * Description:
 */
public class BooksNewEntity  implements Serializable, MultiItemEntity {
    private int itemType=0;
    private String id;
    private String classesId;
    private String classesTypeName;
    private ArrayList<BookEntity> mapList;
    private ArrayList<BookEntity> booksListNew;

    public ArrayList<BookEntity> getBooksListNew() {
        return booksListNew;
    }

    public void setBooksListNew(ArrayList<BookEntity> booksListNew) {
        this.booksListNew = booksListNew;
    }

    public void setItemType(int itemType) {
        this.itemType = itemType;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassesId() {
        return classesId;
    }

    public void setClassesId(String classesId) {
        this.classesId = classesId;
    }

    public String getClassesTypeName() {
        return classesTypeName;
    }

    public void setClassesTypeName(String classesTypeName) {
        this.classesTypeName = classesTypeName;
    }

    public ArrayList<BookEntity> getMapList() {
        return mapList;
    }

    public void setMapList(ArrayList<BookEntity> mapList) {
        this.mapList = mapList;
    }

    @Override
    public int getItemType() {
        return 0;
    }
}
