package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/9/12 18:32
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class ChapterEntity(
    val chapterid: String = "",
    val chapterName: String = "",
    val classHour: String = "",
    val type: Int = 0,//1- 直播 ；2 -视频
    var sort: Int = 0,
//    val type: String = "",//1- 直播 ；2 -视频
    val list: MutableList<ResourceEntity> = mutableListOf(),
) : Parcelable