package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     CheckCDkResultEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/10
 * Description:
 */
@Parcelize
class CheckCDkResultEntity(
    val flg: Int,
    val wdClasses: WdClassesInfo,
    val wdClassesBooksList: ArrayList<WdClassesBooks>,
    val wdClassesSales: WdClassesSalesInfo,
    val wdClassesType: WdClassesType
) : Parcelable

@Parcelize
class WdClassesInfo(
    val academicYear: Int,
    val classesCover: String,
    val classesDescribe: String,
    val classesDetails: String,
    val classesName: String,
    val createBy: String,
    val createTime: String,
    val del: Int,
    val faceClass: Int,
    val id: String,
    val issue: Int,
    val majorId: String,
    val openTime: String,
    val operationRecommend: Int,
    val shelves: Int,
    val sort: Int,
    val studyPlan: String,
    val sysOrgCode: String,
    val updateBy: String,
    val updateTime: String
) : Parcelable

@Parcelize
class WdClassesBooks(
    val booksId: String,
    val classesId: String,
    val id: String,
    val wdBook: WdBook
) : Parcelable

@Parcelize
class WdClassesSalesInfo(
    val applyReread: Int,
    val classesTypeId: String,
    val createBy: String,
    val createTime: String,
    val distributionPrice: Double,
    val fficialPrice: Double,
    val id: String,
    val refund: Int,
    val registrationWay: Int,
    val sysOrgCode: String,
    val useCoupons: Int
) : Parcelable

@Parcelize
class WdClassesType(
    val classesId: String,
    val classesTypeName: String,
    val createBy: String,
    val createTime: String,
    val del: Int,
    val id: String,
    val sysOrgCode: String
) : Parcelable

@Parcelize
class WdBook(
    val bookCode: String,
    val bookName: String,
    val content: String,
    val createTime: String,
    val creator: String,
    val dealerPrice: Double,
    val id: String,
    val images: String,
    val isDeleted: Int,
    val isOversold: Int,
    val isPutway: Int,
    val majorId: String,
    val officalPrice: Double,
    val sales: Int,
    val sellingPoints: String,
    val stock: Int,
) : Parcelable