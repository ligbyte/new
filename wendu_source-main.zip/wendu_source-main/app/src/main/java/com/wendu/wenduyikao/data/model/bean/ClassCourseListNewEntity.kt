package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/8/22 18:34
 * email:943789510@qq.com
 * describe:
 */
data class ClassCourseListNewEntity(

 val courseType:Int = 0,
 val auditionCourseList:MutableList<AuditionCourseEntity> = mutableListOf(),
 val courseList:MutableList<CourseEntity> = mutableListOf(),
 val classesCourseList:MutableList<ClassCourseListRootEntity> = mutableListOf(),
)