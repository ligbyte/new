package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/8/22 18:34
 * email:943789510@qq.com
 * describe:
 */
data class ClassCourseListRootEntity(

 val sectionName:String,
 val allClassesHour:Int = 1,
 val courseList:MutableList<CourseEntity> = mutableListOf(),
 val classesCourseList:MutableList<CourseEntity> = mutableListOf()
)