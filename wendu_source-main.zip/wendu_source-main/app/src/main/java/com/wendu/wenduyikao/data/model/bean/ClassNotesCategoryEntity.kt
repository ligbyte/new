package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ClasstNotesCategoryEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/10/23
 * Description:课程笔记分类
 */
@Parcelize
class ClassNotesCategoryEntity(
    val createBy: String,
    val createTime: String,
    val id: String,
    val majorId: String,
    val noteCategoryName: String,
    val sort: String,
    val sysOrgCode: String
) : Parcelable