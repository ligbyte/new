package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/24 22:22
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class ClassServiceEntity (
    val id:String = "",
    val studyPlan:Boolean = false,
    val examNotice:Boolean = false,
    val classMeeting:Boolean = false,
    val moveClass:Boolean = false,
    val liveNotes:Boolean = false,
    val questionPractice:Boolean = false,
    val entranceTest:Boolean = false,
    val hdCourseware:Boolean = false,
    val teachingQuestions:Boolean = false,
    val monthlyAppraisal:Boolean = false,
    val vipTutoring:Boolean = false,
    val livePlayback:Boolean = false,
    val monthlyEvaluation:Boolean = false,
    val informationSharing:Boolean = false,
    val superintendentService:Boolean = false,
    val learningAnalysis:Boolean = false,
):Parcelable