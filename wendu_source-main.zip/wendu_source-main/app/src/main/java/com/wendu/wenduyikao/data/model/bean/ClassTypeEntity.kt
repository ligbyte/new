package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/25 20:37
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class ClassTypeEntity(

    val flg:Int = 0, //flg=0 说明没有优惠券   flg=1 说明有优惠券
    val id:String = "",
    val classesTypeDescribe:String = "",
    val classesTypeName:String = "",
    val instructions:String = "",
    val registrationWay:Int = 0,  //1免费2收费
    val discountList:MutableList<DiscountInfoEntity> = mutableListOf(),
    val userCouponEntity:UserCouponEntity,
    val booksListNew:MutableList<BookEntity> = mutableListOf(),

):Parcelable{
//    val fficialPrice:BigDecimal? = null
//    get() = field ?: BigDecimal(0)
//
//    val rereadRepairFee:BigDecimal? = null
//    get() = field ?: BigDecimal(0)
//
//    val bookFee:BigDecimal? = null
//    get() = field ?: BigDecimal(0)

    val fficialPrice:Double  = 0.0
    val lineFficialPrice:Double  = 0.0
    val rereadRepairFee:Double  = 0.0

    val bookFee:Double  = 0.0

    val couponMoney:Double  = 0.0
//        get() = field ?: BigDecimal(0)

}