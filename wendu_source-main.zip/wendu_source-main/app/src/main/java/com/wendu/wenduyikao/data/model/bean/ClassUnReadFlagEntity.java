package com.wendu.wenduyikao.data.model.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ClassUnReadFlagEmtity
 * Author:         xiaoyangyan
 * CreateDate:    2022/7/20
 * Description:
 */
public class ClassUnReadFlagEntity implements Serializable {


    private int curriculumFlag;//课程是否有更新内容
    private int noteFlag;//笔记是否有更新内容
    private int evaluateFlag;//考试评测是否有更新内容
    private int studyFlag;//学习计划是否有更新内容


    public int getCurriculumFlag() {
        return curriculumFlag;
    }

    public void setCurriculumFlag(int curriculumFlag) {
        this.curriculumFlag = curriculumFlag;
    }

    public int getNoteFlag() {
        return noteFlag;
    }

    public void setNoteFlag(int noteFlag) {
        this.noteFlag = noteFlag;
    }

    public int getEvaluateFlag() {
        return evaluateFlag;
    }

    public void setEvaluateFlag(int evaluateFlag) {
        this.evaluateFlag = evaluateFlag;
    }

    public int getStudyFlag() {
        return studyFlag;
    }

    public void setStudyFlag(int studyFlag) {
        this.studyFlag = studyFlag;
    }
}
