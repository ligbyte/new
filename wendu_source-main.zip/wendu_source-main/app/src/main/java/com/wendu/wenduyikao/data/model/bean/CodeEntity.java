package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;

/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     CodeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description:
 */
public class CodeEntity implements Serializable {
    private String type;
    private String label;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
