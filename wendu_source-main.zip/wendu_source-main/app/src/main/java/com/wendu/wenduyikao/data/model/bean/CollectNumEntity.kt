package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     CollectNumEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/9/20
 * Description:
 */
@Parcelize
class CollectNumEntity(
    val liftingType: Int,
    val topicCategory: Int,
    var number: Int
) : Parcelable