package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     CouponInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/21
 * Description: 优惠券
 */
@Parcelize
class CouponInfoEntity(
    val category: Int,
    val classesIds: String,
    val content: String,
    val couponAmount: Int,
    val couponName: String,
    val couponStatus: String,
    val createTime: String,
    val discountAmount: Double,
    val effectiveTimeEnd: String,
    val effectiveTimeStart: String,
    val fixDays: Int,
    val flg: Int,
    val hasThreshold: Int,
    val id: String,
    val isDeleted: Int,
    val isPublish: Int,
    val receiveAmount: Int,
    val timeLimit: Int,
    val type: Int,
    val updateTime: String,
    val useLimit: Double,
    val isUsed: Int,
    val wdCoupon: WdCouponEntity
) : Parcelable