package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/11 21:37
 * email:943789510@qq.com
 * describe:
 */
data class CourseCatalogEntity(
    val id: String = "",
    val courseName: String = "",
    val courseDescription: String = "",

    val courseImgPath: String = "",
    val learningPhase: String = "",
    val learningPhaseText: String = "",
    val unitId: String = "",
    val type: String = "",
    val isNoBuy: Int = 0, //0未购买 1已购买
    val wdCourseSale:WdClassesSales,

    val list: MutableList<ChapterEntity> = mutableListOf(),
)
