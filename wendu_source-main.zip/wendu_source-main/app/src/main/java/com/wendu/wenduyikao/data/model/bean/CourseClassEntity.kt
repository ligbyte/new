package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/8/22 18:51
 * email:943789510@qq.com
 * describe:
 */
data class CourseClassEntity(
    val id:String = "",
    val faceClassesId:String? = "",
    val classHour:Int = 0,
    val isShowIcon:Int = 0,//0否1是
    val shelves:Int = 0,  //0没上架  1上架
    val classesName:String = "",
    val classesDetails:String = "",
    val classesDescribe:String = "",
    val classesCover:String = "",
    val studyPlan:String = "",
    val isNoBuy:Int = 0, //0未购买 1已购买
    val registrationWay:Int = 2, //1-免费 2-收费
    val teacherList:MutableList<TeacherEntity> = mutableListOf(),
    val classesTypeList:MutableList<ClassTypeEntity> = mutableListOf(),
    val booksList:MutableList<BookEntity> = mutableListOf(),
    val booksListNew:MutableList<BooksNewEntity> = mutableListOf(),
    val discountList:MutableList<DiscountInfoEntity> = mutableListOf(),
    val classesCourseList:MutableList<ClassCourseListRootEntity> = mutableListOf(),
    val lineFficialPrice:Double  = 0.0,
    val courseList:MutableList<CourseEntity> = mutableListOf(),
    val courseType:Int = 0,
){
    val price:Double  = 0.0
//    val price:BigDecimal? = null
//    get() = field ?: BigDecimal(0)
}