package com.wendu.wenduyikao.data.model.bean


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ClasstNotesCategoryEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/10/23
 * Description:班级课程分类
 */
data class CourseClassTypeEntity(

    val classesTypeName:String,
    val courseType:Int = 0,
    val courseGroupingList:MutableList<ClassCourseListRootEntity> = mutableListOf(),
    val classesCourseList:ClassCourseListRootEntity
)