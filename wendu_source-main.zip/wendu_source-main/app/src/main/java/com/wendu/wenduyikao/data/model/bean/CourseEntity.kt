package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/19 18:58
 * email:943789510@qq.com
 * describe: 直播课程相关字段
 */
@Parcelize
data class CourseEntity(
    val id: String = "",
    val type: Int = 0,//1- 直播 ；2 -视频
    val courseType: Int = 0,//1- 直播 ；2 -视频
    val learningPhase: Int = 0,
    val learningPhaseText: String = "",
    val classHour: String = "",
    val courseName: String = "",
    val courseImgPath: String = "",
    val startTime: String = "",
    val pwCourseType: Int = 0,

    val courseDescription: String = "",
    val courseLiveDescription: String = "",
) : Parcelable