package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     CourseLabelEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/1
 * Description:classCourseLabelList 班级标签、classCourseLabelList 模块标签
 */
@Parcelize
class CourseLabelEntity(
    val classCourseLabelList: ArrayList<CourseLabel>,//班级标签
    val courseLabelList: ArrayList<CourseLabel>//模块标签
) : Parcelable

@Parcelize
class ClassCourseLabel(
    val id: String,
    val labelName: String,
    val majorId: String,
) : Parcelable

@Parcelize
class CourseLabel(
    val id: String,
    val labelName: String,
    val majorId: String,
) : Parcelable