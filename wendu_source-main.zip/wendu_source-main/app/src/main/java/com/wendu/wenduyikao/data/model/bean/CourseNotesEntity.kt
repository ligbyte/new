package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/7 21:38
 * email:943789510@qq.com
 * describe:
 */
data class CourseNotesEntity(
    val id:String = "",
    val classesId:String = "",
    val majorId:String = "",
    val createTime:String = "",
    val title:String = "",
    val materialId:String = "",
    val content:String = "",
    val isView:Int = 0,//是否查看过 0没有查看过 1查看过
    val wdResourcesMaterial:CourseNoteMaterialEntity
)
