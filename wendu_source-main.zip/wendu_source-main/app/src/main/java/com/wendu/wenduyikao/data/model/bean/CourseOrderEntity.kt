package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 课程订单
 */
@SuppressLint("ParcelCreator")
@Parcelize
class CourseOrderEntity(
    val classesId: String,
    val classesTypeId: String,
    val courseId: String,
    val createBy: String,
    val createTime: String,
    val ddje: Double,
    val finishTime: String,
    val gmqd: String,
    val id: String,
    val moduleCourseId: String,

    val lsh: String,
    val paperId: String,
    val payTime: String,
    val sfje: Double,
    val status: String,
    val status_dictText: String,
    val sysOrgCode: String,
    val tenantId: String,
    val type: String,
    val type_dictText: String,
    val updateBy: String,
    val updateTime: String,
    val wdQuestionPaper: WdQuestionPaper,
    val wdClassesSales: WdClassesSales,
    val courseVo: CourseVo,
    val wdClasses: WdClasses,
    val xygs: String,
    val yhid: String,
    val zyxk: String
) : Parcelable

@Parcelize
class WdQuestionPaper(
    val buyersNumber: Int,
    val createTime: String,
    val dealerPrice: Double,
    val id: String,
    val isCoupon: Int,
    val isRefund: Int,
    val isRelease: Int,
    val isShelf: Int,
    val majorId: String,
    val officialPrice: Double,
    val openingMode: Int,
    val orderNum: String,
    val paperDescribe: String,
    val paperName: String,
    val paperType: String,
    val payFlg: Int,
    val rate: Int,
    val refundPeriod: Int,
    val remark: String,
    val total: Int,
    val updateTime: String,
    val url: String,
    val useTime: Int,
    val vipDay: String,
) : Parcelable

@Parcelize
class WdClasses(
    val id: String,
    val classesCover: String,
    val classesName: String,
    val faceClass: Int,
    val wdBookOrder:BookOrderEntity
) : Parcelable

@Parcelize
class WdClassesSales(
    val bookFee: Double,
    val distributionPrice: Double,
    val fficialPrice: Double,
    val lineFficialPrice: Double,
    val id: String,
    val courseId: String = "",
    val classesTypeId: String = "",
    val registrationWay: Int,
    val classesDescribe: String,
    val classesName: String,
) : Parcelable

@Parcelize
class CourseVo(
    val id: String,
    val courseImg: String,
    val courseName: String,
    val wdCourseSale:WdClassesSales
) : Parcelable