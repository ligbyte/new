package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/5 13:09
 * email:943789510@qq.com
 * describe:
 */
data class CourseQuestionEntity(
    val id:String,
    val problemContent:String,
    val answerCountent:String,
    val problemImg:String,
    val wdClassesAnswer:CourseQuestionEntity,
    val teacherAvatar:String = "",
    val wdStudentManagement:UserInfo?,
)
