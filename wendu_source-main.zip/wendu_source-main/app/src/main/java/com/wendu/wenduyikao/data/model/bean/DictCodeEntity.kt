package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/7/21 3:44 PM
 * @Description: 字典数据
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class DictCodeEntity(
    var value: String,
    var text: String,
    var title: String,
    var num:Int,
) : Parcelable
