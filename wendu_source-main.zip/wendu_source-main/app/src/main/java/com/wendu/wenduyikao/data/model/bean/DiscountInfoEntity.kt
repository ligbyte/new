package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@Parcelize
data class DiscountInfoEntity(

    val discountAmount:Double = 0.0,  //1免费2收费
    val discountType:String = "",
):Parcelable{


}