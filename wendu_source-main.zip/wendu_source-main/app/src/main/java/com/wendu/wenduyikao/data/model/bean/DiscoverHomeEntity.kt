package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     DiscoverHomeEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/11
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class DiscoverHomeEntity(
    val activity: ArrayList<WdActivityEntity>,
    val book: ArrayList<BookInfoEntity>,
    val information: ArrayList<WdInformationEntity>,
) : Parcelable