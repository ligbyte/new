package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Author:         jeek
 * CreateDate:    8/3/21
 * Description: 未读消息
 */
@SuppressLint("ParcelCreator")
@Parcelize
class DotEntity(
    val feedback: Boolean,
    val my: Boolean,
    val order: Boolean,
    val orderNumber: Int,
) : Parcelable


