package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       me.xiaoyang.bearingproduction.result.model.bean
 * ClassName:     DrawImgEntity
 * Author:         xiaoyangyan
 * CreateDate:    4/8/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class DrawImgEntity(
    val sn: Int,
    val url: String

) : Parcelable