package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;
import java.util.Map;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ErrorFiltterEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/10/9
 * Description:
 */
public class ErrorFilterEntity implements Serializable {
    private Map<String, String> pageType;
    private Map<String, String> liftingType;

    public Map<String, String> getPageType() {
        return pageType;
    }

    public void setPageType(Map<String, String> pageType) {
        this.pageType = pageType;
    }

    public Map<String, String> getLiftingType() {
        return liftingType;
    }

    public void setLiftingType(Map<String, String> liftingType) {
        this.liftingType = liftingType;
    }
}
