package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ExamInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    9/14/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class ExamInfoEntity(
    val id: String,
    val majorId: String,
    val papersId: String,
    val score: Int,
    val stateCode: Int,
    val subjectName: String,
    val timeExamination: Int,
    val totalScore: Int,
    val wdQuestionExaminationTypeList: List<WdQuestionExaminationType>
) : Parcelable

@Parcelize
class WdQuestionExaminationType(
    val examinationId: String,
    val id: String,
    val numberSubject: Int,
    val type: String
) : Parcelable