package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ExamInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    9/14/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class ExamResultInfoEntity(
    val examList: ArrayList<ExamInfoEntity>,
    val major: MajorEntity,
) : Parcelable
