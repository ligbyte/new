package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ExamScoreEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/10/13
 * Description:  试卷评分
 */
@Parcelize
class ExamScoreEntity(
    val appraisalClassesId: String,
    val chapterId: String,
    val countAll: Int,
    val createTime: String,
    val doCount: Int,
    val id: String,
    val majorId: String,
    val paperId: String,
    val proportion: String,
    val scoreAll: Double,
    val studentId: String,
    val successCount: Int,
    val successScore: Double,
    val type: Int
) : Parcelable