package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ExchangeRecordEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/13
 * Description:
 */
@Parcelize
class ExchangeRecordEntity(
    val cdkeyCode: String,
    val cdkeyId: String,
    val createTime: String,
    val customerId: String,
    val id: String,
    val usedTime: String,
    val wdClassesDescribe: String,
    val wdClassesDistributionPrice: Double,
    val wdClassesFficialPrice: Double,
    val wdClassesName: String,
    val wdClassesTypeName: String,
    val wdResourcesTeacherList: List<WdResourcesTeacher>
) : Parcelable

@Parcelize
class WdResourcesTeacher(
    val createBy: String,
    val createTime: String,
    val disableStatus: String,
    val id: String,
    val idPhoto: String,
    val imagePhoto: String,
    val introduce: String,
    val loginStatus: String,
    val name: String,
    val password: String,
    val phone: String,
    val sort: Int,
    val sysOrgCode: String,
    val title: String,
    val updateBy: String,
    val updateTime: String,
    val userName: String
) : Parcelable