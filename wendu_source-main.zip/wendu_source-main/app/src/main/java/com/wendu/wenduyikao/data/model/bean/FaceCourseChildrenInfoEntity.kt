package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Created：yxm on 2021/8/23 0023.
 * Email：943789510@qq.com
 * Description: 面授详情
 */
@Parcelize
data class FaceCourseChildrenInfoEntity(
    val classesName:String = "",
    val classesList:MutableList<HotCourseEntity> = mutableListOf(),
):Parcelable{
}