package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Created：yxm on 2021/8/23 0023.
 * Email：943789510@qq.com
 * Description: 面授详情
 */
@Parcelize
data class FaceCourseInfoEntity(
    val id: String = "",
    val classHour: Int = 0,
    val classesName: String = "",
    val classesDetails: String = "",
    val classesDescribe: String = "",
    val classesCover: String = "",
    val teacherList: MutableList<TeacherEntity> = mutableListOf(),
    val courseListnew: MutableList<FaceCourseChildrenInfoEntity> = mutableListOf(),
    val courseList: MutableList<HotCourseEntity> = mutableListOf(),
    val booksList: MutableList<BookEntity> = mutableListOf(),
    val classesTypeList: MutableList<ClassTypeEntity> = mutableListOf()
) : Parcelable {
    val price: Double = 0.0
//    val price:BigDecimal? = null
//    get() = field ?: BigDecimal(0)
}