package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/9/4 16:49
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class FindCourseTimeResponse(
    val time:Double
):Parcelable