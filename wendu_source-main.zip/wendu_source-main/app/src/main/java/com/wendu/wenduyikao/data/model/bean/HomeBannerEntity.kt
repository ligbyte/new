package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/29 10:30
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class HomeBannerEntity(
    val id:String = "",
    val bannerName:String = "",
    val phoneImage:String = "",
    val pcImage:String = "",
    val skipUrl:String = "",
    val tenantId:String = "",
    val clickEvent:Int = 0,//0.无 1.网址 2.课程班级 3.面授班级 4.图书详情 5.题库详情这些
//    "id": "1425735064323051521",
//"bannerName": "测试路径",
//"phoneImage": "https://zhongtao0710.oss-cn-beijing.aliyuncs.com/upload/test/2052675_1629713085508.jpg",
//"pcImage": "https://zhongtao0710.oss-cn-beijing.aliyuncs.com/upload/test/2052675_1629713085508.jpg",
//"clickStatus": null,
//"skipType": null,
//"skipUrl": "www.baidu.com",
//"startTime": "2021-08-12",
//"endTime": "2021-08-31",
//"releaseStatus": "0",
//"createTime": "2021-08-12",
//"createBy": "admin",
//"updateTime": null,
//"updateBy": null,
//"tenantId": null,
//"sysOrgCode": "A01"
):Parcelable