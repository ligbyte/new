package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     HomeModuleCourseEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/2
 * Description:
 */
@Parcelize
class HomeModuleCourseEntity(
    val classHour: String,
    val courseDescription: String,
    val courseImgPath: String,
    val courseLiveDescription: String,
    val description: String,
    val courseName: String,
    val courseType: Int,
    val fficialPrice: Double,
    val id: String,
    val isNoBuy: Int,//0未购买 1已购买
    val isSale: Int,
    val learningPhase: String,
    val learningPhaseText: String,
    val lineFficialPrice: Double,
    val pwCourseType: Int,
    val registrationWay: Int,
    val sort: Int,
    val startTime: String
) : Parcelable