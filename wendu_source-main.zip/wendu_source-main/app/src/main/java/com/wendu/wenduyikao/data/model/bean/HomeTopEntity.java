package com.wendu.wenduyikao.data.model.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     HomeTopEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/13
 * Description:
 */
public class HomeTopEntity implements Serializable {

    private String ambassadorFlg;//0是关 1是开
    private String helpStuUrl;//助学计划
    private String helpStuFlg;//0是关 1是开
    private String ambassadorUrl;//推广

    public String getAmbassadorFlg() {
        return ambassadorFlg;
    }

    public void setAmbassadorFlg(String ambassadorFlg) {
        this.ambassadorFlg = ambassadorFlg;
    }

    public String getHelpStuUrl() {
        return helpStuUrl;
    }

    public void setHelpStuUrl(String helpStuUrl) {
        this.helpStuUrl = helpStuUrl;
    }

    public String getHelpStuFlg() {
        return helpStuFlg;
    }

    public void setHelpStuFlg(String helpStuFlg) {
        this.helpStuFlg = helpStuFlg;
    }

    public String getAmbassadorUrl() {
        return ambassadorUrl;
    }

    public void setAmbassadorUrl(String ambassadorUrl) {
        this.ambassadorUrl = ambassadorUrl;
    }
}
