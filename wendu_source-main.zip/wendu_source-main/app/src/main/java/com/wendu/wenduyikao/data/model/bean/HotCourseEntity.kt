package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/19 18:58
 * email:943789510@qq.com
 * describe: 直播课程相关字段
 */
@Parcelize
data class HotCourseEntity(
    val id: String = "",
    val courseType: Int = 0,
    val classesTypeId:String="",
    val learningPhase: Int = 0,
    val learningPhaseText: String = "",
    val isShowIcon: Int = 0,
    val students: Int = 0,
    val classHour: Int = 0,
    val faceDays: Int = 0,
    val courseCombination: String = "",
    val classesId: String = "",
    val classesName: String = "",
    val courseImgPath: String = "",
    val startTime: String = "",
    val classesDescribe: String = "",
    val teacherList: MutableList<TeacherEntity> = mutableListOf(),
    val faceLocation: String = "",
    val registrationWay: Int = 2, //1-免费 2-收费
    val faceClass: Int = 1, //1-非面授 2-面授
    val academicYear: Int = 0, //1-非面授 2-面授
    val couponFlg: Int = 0,
    val coverImage:String = ""
) : Parcelable {
    val price: Double = 0.0
    val lineFficialPrice: Double = 0.0
//    val price:BigDecimal? = null
//    get() = field ?: BigDecimal(0)
}