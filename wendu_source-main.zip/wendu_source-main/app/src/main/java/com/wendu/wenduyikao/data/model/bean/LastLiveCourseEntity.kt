package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/19 18:58
 * email:943789510@qq.com
 * describe: 直播课程相关字段
 *
 * @see LiveResourceTypeConst
 */
@Parcelize
data class LastLiveCourseEntity(
    val id: String = "",
    val courseid: String = "",
    val liveClassroomStatus: Int = 0,
    val type: Int = 1,//1直播 2视频
    val isAgree: Int = 0,//0 无预约  1 有预约
    val courseName: String = "",
    val teacherName: String = "",
    val teacherImagePhoto: String = "",
    val liveClassroomName: String = "",
    val liveStartTime: String = "",
    val channel: String = "",
    val vid: String = "",
    val materials: ArrayList<String> = arrayListOf()
) : Parcelable

/**
 *          val NOSTART = 1 //直播未开始
            val LIVEING = 2 //直播中
            val PLAYBACK = 3 //回放
            val LIVECOMPLITE = 4 //直播完成
 * **/