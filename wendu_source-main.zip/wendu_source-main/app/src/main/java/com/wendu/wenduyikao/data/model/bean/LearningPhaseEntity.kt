package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     LearningPhaseEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/1
 * Description:
 */
@Parcelize
class LearningPhaseEntity(
    val learning_phase: String,
    val learning_phase_name: String
) : Parcelable