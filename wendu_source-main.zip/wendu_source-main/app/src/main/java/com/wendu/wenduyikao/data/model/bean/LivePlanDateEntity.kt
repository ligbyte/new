package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     LivePlanDateEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/2
 * Description:
 */
@Parcelize
class LivePlanDateEntity(
    val id: String = "",
    val count: Int,
    val date: String,
    val day: Int,
    val liveCount: Int,
    val userCount: Int,
    val courseCount: Int,
    val week: String
) : Parcelable