package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize





/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     LivePlanDateEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/2
 * Description:
 */
@Parcelize
class LivePlanInfoEntity(
    val channel: String,
    val classHour: Int,
    val courseDescription: String,
    val courseImgPath: String,
    val courseName: String,
    val courseType: Int,
    val liveCourseId:String="",
    val courseId:String="",
    val id: String,
    val isAgree: Int,
    val isBuy: Int,
    val isNoBuy: Int,
    val isAudition: Int,
    val learningPhase: String,
    val liveClassroomName: String,
    val liveClassroomStatus: Int,
    val liveTime: String,
    val startTime: String,
    val teacherName: String,
    val teacherPhoto: String,
    val vid:String,
    val type: Int,
    val unlock: UnlockEntity,
    val unitId: String
) : Parcelable