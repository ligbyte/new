package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       me.xiaoyang.bearingproduction.result.model.bean
 * ClassName:     LoginInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    3/1/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class LoginInfoEntity(
    var token: String = "",
    var userInfo: UserInfo?,
) : Parcelable