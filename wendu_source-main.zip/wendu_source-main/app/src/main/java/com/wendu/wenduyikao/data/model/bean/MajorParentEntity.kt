package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.changyang.wendu.data.model.bean
 * ClassName:     MajorEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/18/21
 * Description: 专业
 */
@Parcelize
class MajorParentEntity(
    val groupName: String,
    val id: String,
    val sort: Int,
    val parentMajors:ArrayList<MajorEntity>
) : Parcelable