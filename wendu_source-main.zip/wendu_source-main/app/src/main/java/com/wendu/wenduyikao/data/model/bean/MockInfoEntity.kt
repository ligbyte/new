package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/30/21 10:17 AM
 * @Description: 模拟考
 */
@SuppressLint("ParcelCreator")
@Parcelize
class MockInfoEntity(
    val alreadyList: ArrayList<PaperRecordEntity>,
    val classicList: ArrayList<PaperInfoEntity>
) : Parcelable