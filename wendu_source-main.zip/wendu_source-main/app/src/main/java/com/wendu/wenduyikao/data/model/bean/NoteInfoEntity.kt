package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 笔记详情
 */
@SuppressLint("ParcelCreator")
@Parcelize
class NoteInfoEntity(
    val createTime: String,
    val id: String,
    val imageUrl: String,
    val note: String,
    val studentId: String,
    val subjectId: String,
    val type: String
) : Parcelable