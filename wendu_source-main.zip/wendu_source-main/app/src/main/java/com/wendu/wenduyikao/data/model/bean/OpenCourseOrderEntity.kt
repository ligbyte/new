package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     OpenCourseOrderEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/10/27
 * Description:
 */
@Parcelize
class OpenCourseOrderEntity(
    val classesCover: String,
    val classesName: String,
    val classesTypeId: String,
    val classesTypeName: String,
    val fficialPrice: Double,
    val id: String
) : Parcelable