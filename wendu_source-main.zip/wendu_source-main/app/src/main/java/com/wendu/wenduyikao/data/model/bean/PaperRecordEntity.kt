package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 试卷详情
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class PaperRecordEntity(
    val createTime: String,
    val id: String,
    val majorId: String,
    val paperName: String,
    val paper_type:String,
    val successScore: String
) : Parcelable
