package com.wendu.wenduyikao.data.model.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     CodeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description:
 */
public class PayWayEntity implements Serializable {
    private String type;
    private String label;
    private boolean isCheck;
    private int img;

    public boolean isCheck() {
        return isCheck;
    }

    public void setCheck(boolean check) {
        isCheck = check;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }
}
