package com.wendu.wenduyikao.data.model.bean

import com.contrarywind.interfaces.IPickerViewData


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ProvinceCityAreaEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/12
 * Description:
 */
data class ProvinceCityAreaEntity(
    val cityList: MutableList<City>,
    val id: String,
    val pid: String,
    val text: String
)

data class City(
    val id: String,
    val list: MutableList<Area>,
    val pid: String,
    val text: String
)

data class Area (
    val id: String,
    val pid: String,
    val text: String
) : IPickerViewData {
    override fun getPickerViewText(): String = text
}