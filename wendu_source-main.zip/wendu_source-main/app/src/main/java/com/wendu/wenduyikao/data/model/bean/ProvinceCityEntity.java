package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ProvinceCityEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/12
 * Description:
 */
public class ProvinceCityEntity implements Serializable {

    private String id;
    private String text;
    private String pid;
    private ArrayList<CityInfoEntity> cityList;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public ArrayList<CityInfoEntity> getCityList() {
        return cityList;
    }

    public void setCityList(ArrayList<CityInfoEntity> cityList) {
        this.cityList = cityList;
    }

    public class CityInfoEntity{
        private String id;
        private String text;
        private String pid;
        private ArrayList<AreaInfoEntity> list;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }

        public ArrayList<AreaInfoEntity> getList() {
            return list;
        }

        public void setList(ArrayList<AreaInfoEntity> list) {
            this.list = list;
        }
    }

    public class AreaInfoEntity{
        private String id;
        private String text;
        private String pid;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
        }

        public String getPid() {
            return pid;
        }

        public void setPid(String pid) {
            this.pid = pid;
        }
    }
}
