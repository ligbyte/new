package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     PwResultEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/4/15
 * Description:
 */
@Parcelize
data class PwResultEntity(
    val obj: Obj
) : Parcelable

@Parcelize
class Obj(
    val expireTimeStamp: Int,
    val playPcUrl: String,
    val playUrl: String
) : Parcelable