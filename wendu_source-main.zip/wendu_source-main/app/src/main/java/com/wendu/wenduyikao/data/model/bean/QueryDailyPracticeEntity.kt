package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 试卷
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QueryDailyPracticeEntity(
    val transcendNumber: Float,
    val accuracy: Float,
    val useTime: Int,
    val id: String,
    val examTime: String,
    val examNumber: Int,
    val questionNumber:Int,
    val isAnswer:Boolean
) : Parcelable


