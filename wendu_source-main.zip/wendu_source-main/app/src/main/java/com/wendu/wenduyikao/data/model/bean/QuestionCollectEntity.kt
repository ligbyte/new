package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 题库收藏
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionCollectEntity(
    val id: String,
    val liftingType: Int,
    val stem: String,
    val studentId: String,
    val subjectId: String,
    val number: Int,
    val type: String,
    val isCollectId:String,
    var isCollect: Int
) : Parcelable