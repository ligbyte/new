package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 错题比例
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionErrorProportionEntity(
    val appraisalClassesId: String,
    val chapterId: String,
    val countAll: String,
    val createTime: String,
    val doCount: String,
    val id: String,
    val majorId: String,
    val paperId: String,
    val proportion: Float,
    val scoreAll: String,
    val studentId: String,
    val successCount: String,
    val successScore: String,
    val type: Int
) : Parcelable