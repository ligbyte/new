package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 题目详情
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionInfoEntity(
    var index: String,
    var name: String,
    val answer: String,
    val answerTxt: String,
    val answerText: String,
    val chapterId: String?="",
    val paperId: String?="",
    val createBy: String,
    val createTime: String,
    val dataList: ArrayList<SubjectFileEntity>?,
    val id: String,
    val liftingType: Int,
    var optionList: ArrayList<QuestionOptionEntity>,
    val questionList: ArrayList<QuestionInfoEntity>,
    val parentId: String,
    val score: Double,
    val section: Int,
    val isCollect: Int,
    val isCollectId: String? = "",
    val selectList: ArrayList<SubjectFileEntity>?,
    var wdQuestionChapterPractice: WdQuestionChapterPracticeEntity,
    val stem: String,
    val subjectNumber: Int,
    val sysOrgCode: String,
    val templateId: String,
    val templateName: String,
    val tenantId: String,
    val totalSubjectNumber: Int,
    val topicCategory: Int,
    val updateBy: String,
    val updateTime: String,
    var solution: String,
    val facilityValue:Int,
    var isDo: Boolean,//是否已做 本地校验字段
    var isRight: Int //是否正确 本地检验字段
) : Parcelable



