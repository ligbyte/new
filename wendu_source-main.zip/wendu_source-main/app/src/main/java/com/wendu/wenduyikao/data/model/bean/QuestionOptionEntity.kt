package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     QuestionOptionEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/26/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionOptionEntity(
    val content: String,
    val id: String,
    val rightFlag: Int,
    val subType: Int,//1 文字  2 图片
    val selectValue: String,
    val subjectId: String,
    var isSelect: Boolean
) : Parcelable