package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/2/21 4:34 PM
 * @Description: 题库订单
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionOrderEntity(
    val courseId: String,
    val createBy: String,
    val createTime: String,
    val finishTime: String,
    val gmqd: String,
    val id: String,
    val lsh: String,
    val paperId: String,
    val payTime: String,
    val status: String,
    val status_dictText: String,
    val sysOrgCode: String,
    val tenantId: String,
    val type: String,
    val type_dictText: String,
    val updateBy: String,
    val updateTime: String,
    val xygs: String,
    val yhid: String,
    val zffs: String,
    val zyxk: String
) : Parcelable{

    val ddje:Double  = 0.0
    val sfje:Double  = 0.0
//    val ddje:BigDecimal? = null
//        get() = field ?: BigDecimal(0)
//    val sfje:BigDecimal? = null
//        get() = field ?: BigDecimal(0)

}