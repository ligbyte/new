package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 题目试卷
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionPaperEntity(
    val allNumber: Int,
    val buyersNumber: Int,
    val createBy: String,
    val createTime: String,
    val dealerPrice: Double,
    val orderNum:Int,
    val doNumber: Int,
    val id: String,
    val isCoupon: String,
    val isRefund: String,
    val isRelease: String,
    val isShelf: String,
    val majorId: String,
    val officialPrice: Double,
    val openingMode: Int,
    val paperDescribe: String,
    val paperName: String,
    val paperType: String,
    val payFlg: Int,  //0未购买； 1已购买
    val rate: Int,
    val refundPeriod: Int,
    val sysOrgCode: String,
    val map:Map<String,String>,
    val tenantId: String,
    val total: Int,
    val userCount: Int,//做题人数
    val updateBy: String,
    val updateTime: String,
    val url: String,
    val remark:String,
    val templateId:String,
    val isGenre:Int=0, //0 试卷  1 章节
    val useTime: Long,
    val facilityValue:Int,
    val wdQuestionPaperData: String,
    val unlock: UnlockEntity,
    val wdQuestionPaperTitleList: ArrayList<QuestionPaperTitleEntity>?
) : Parcelable