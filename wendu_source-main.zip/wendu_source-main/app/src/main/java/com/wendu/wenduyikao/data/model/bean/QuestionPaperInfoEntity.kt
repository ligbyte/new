package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.result.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 试卷题目详情
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionPaperInfoEntity(
    var index: String,
    var name: String,
    val answer: String,
    val answerTxt: String,
    val answerText: String,
    val paperId: String,
    val createBy: String,
    val createTime: String,
    var wdQuestionPaperDataVideo: ArrayList<SubjectFileEntity>,
    var wdQuestionPaperData: ArrayList<SubjectFileEntity>,
    val id: String,
    val liftingType: Int,
    var wdQuestionChapterPractice:WdQuestionChapterPracticeEntity,
    var wdQuestionPaperOption: ArrayList<QuestionOptionEntity>,
    val wdQuestionPaperSubjectSubordinatesList: ArrayList<QuestionPaperInfoEntity>,
    val wdQuestionBankList: ArrayList<QuestionPaperInfoEntity>,
    val parentId: String,
    val paperType: String,
    val score: Double,
    val section: Int,
    val selectList: ArrayList<SubjectFileEntity>?,
    val stem: String,
    var title:String,
    var solution: String,
    val subjectNumber: Int,
    val isCollect: Int,
    val isCollectId: String,
    val sysOrgCode: String,
    val templateId: String,
    val templateName: String,
    val tenantId: String,
    val totalSubjectNumber: Int,
    val topicCategory:Int,
    val updateBy: String,
    val updateTime: String,
    val facilityValue:Int,
    var isDo: Boolean,//是否已做 本地校验字段
    var total:Int,//该试卷总体数
    var questionIndex:Int,//当前题目所在试卷中的题号（主要处理共用题干类题目）
    var isRight: Int //是否正确 本地检验字段
) : Parcelable



