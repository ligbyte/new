package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/31/21 5:07 PM
 * @Description: 答题结果
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionPracticeEntity(
    val chapterId: String,
    val createBy: String,
    val createTime: String,
    val id: String,
    val type: String,
    val isFocus: String,
    val isRight: String,
    val number: String,
    val optionId: String,
    val solution: String,
    val studentId: String,
    val subjectId: String,
    val sysOrgCode: String,
    val tenantId: String,
    val updateBy: String
) : Parcelable