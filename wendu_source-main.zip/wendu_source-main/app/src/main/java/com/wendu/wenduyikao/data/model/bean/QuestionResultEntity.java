package com.wendu.wenduyikao.data.model.bean;

import com.chad.library.adapter.base.entity.JSectionEntity;

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 11:00 AM
 * @Description: 
 */
public class QuestionResultEntity extends JSectionEntity {
    private boolean isHeader;
    private Object object;

    public QuestionResultEntity(boolean isHeader, Object object) {
        this.isHeader = isHeader;
        this.object = object;
    }

    public Object getObject() {
        return object;
    }

    @Override
    public boolean isHeader() {
        return isHeader;
    }

}
