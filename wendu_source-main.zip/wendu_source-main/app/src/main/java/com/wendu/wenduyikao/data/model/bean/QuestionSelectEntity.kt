package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     QuestionOptionEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/26/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class QuestionSelectEntity(
    val id: String,
    val imageUrl: String,
    val materialType: String,
    val subjectId: String,
    val videoUrl: String
) : Parcelable