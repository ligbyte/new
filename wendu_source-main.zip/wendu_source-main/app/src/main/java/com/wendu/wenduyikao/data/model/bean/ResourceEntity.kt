package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/9/11 21:38
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class ResourceEntity(
    val id: String = "",
    val liveClassroomName: String = "",
    val liveClassroomStatus: Int = 0,
    val courseId: String = "",
    val isAudition: Int = 0,   //1 - 试听  0 -不试听
    val liveStartTime: String = "",
    val duration: String = "",
    val courseName: String = "",
    val teacherName: String = "",
    val teacherImagePhoto: String = "",
    val channel: String = "",
    val isLook: Int = 0,
    val type: Int = 0,
    val isNoBuy:Int = 0, //0未购买 1已购买
    val lookPercentage: Int = 0,
    val associatedCoursewareCode: String = "",
    var vid: String = "",
    val relatedLiveNewCode: String = "",
    val unlock:UnlockEntity,
    val materials: ArrayList<String> = arrayListOf(),
    var sort: Int,
) : Parcelable
