package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.changyang.wendu.data.model.bean
 * ClassName:     QuestionTypeEntity
 * Author:         xiaoyangyan
 * CreateDate:    8/3/21
 * Description: 题目类型
 */
@SuppressLint("ParcelCreator")
@Parcelize
class SchoolInfoEntity(
    val bm: String,
    val bs: String,
    val bz: String,
    val cc: String,
    val dz: String,
    val id: Int,
    val name: String
) : Parcelable