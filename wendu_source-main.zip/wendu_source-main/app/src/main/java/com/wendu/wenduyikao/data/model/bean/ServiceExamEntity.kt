package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/8 20:27
 * email:943789510@qq.com
 * describe:
 */
data class ServiceExamEntity(
    val id: String = "",
    val majorId: String = "",
    val paperId: String = "",
    val appraisalName: String = "",
    val startTime: String = "",
    val endTime: String = "",
    val createTime: String = "",
    val score: Double = 0.0,
    val isAppraisal: Int = 0,//状态 0未评测1合格2不合格3待打分999过期
    val wdQuestionPaper: WdExamPaper,
    val wdPaperSubjectTypeVoList: WdPaperSubjectTypeVoList,//状态 0未评测1合格2不合格3待打分999过期
    val wdClassesAppraisalStudents: WdClassesAppraisalStudents,//用户测试情况
)

data class WdPaperSubjectTypeVoList(
    val type: String = "",//题库类型
//    val wdQuestionPaper:WdExamPaper,
    val paperId: String = "",
)

data class WdClassesAppraisalStudents(
    val score: Double = 0.0,
    val isAppraisal: Int = 0,//状态 0未评测1合格2不合格3待打分999过期
)

data class WdExamPaper(
    val doNumber: Int = 0,//做了多少道题
    val useTime: Long = 0L,//用时多长时间
    val paperType: String
)
