package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/25 19:40
 * email:943789510@qq.com
 * describe:
 */
data class ShareEntity(
    val title: String?,
    val decs: String?,
    val imageUrl: String?,
    val path: String?,
)
