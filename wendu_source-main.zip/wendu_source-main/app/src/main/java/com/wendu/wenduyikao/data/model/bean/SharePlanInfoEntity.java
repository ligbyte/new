package com.wendu.wenduyikao.data.model.bean;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     SharePlanInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/14
 * Description:
 */
public class SharePlanInfoEntity  implements Serializable {

    private String title;
    private String path;
    private String image;
    private  int type;
    private  int way;

    public int getWay() {
        return way;
    }

    public void setWay(int way) {
        this.way = way;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
