package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     ShopCarInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/22
 * Description:
 */
@Parcelize
class ShopCarInfoEntity(
    var bookAmount: Int,
    val bookId: String,
    val bookName: String,
    val bookPrice: Double,
    val images: String,
    val wdBook: BookInfoEntity?,
    var isSelect: Boolean
) : Parcelable