package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     HomeModuleCourseEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/2
 * Description:
 */
@Parcelize
class StudyModuleCourseInfoEntity(
    val newCourseClassesFlg: Int,
    val courseType: Int,
    val isNoBuy:Int,
    val courseList: CourseList
) : Parcelable

@Parcelize
class CourseList(
    val classesName: String,
    val courseDescription: String,
    val courseImgPath: String,
    val courseName: String,
    val id: String,
    val isNoBuy: Int,
    val learningPhase: String,
    val learningPhaseText: String,
    val list: ArrayList<ChapterEntity>,
    val type: String,
    val unitId: String,
    val wdCourseSale: WdClassesSales,
    val wdStudentLastTimeLearn: String
) : Parcelable



