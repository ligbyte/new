package com.wendu.wenduyikao.data.model.bean
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize




/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     HomeModuleCourseEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/12/2
 * Description:
 */
@Parcelize
class StudySeriesCourseInfoEntity(
    val classesMap: ClassesMap,
    val isNoBuy:Int,
    val courseUnitDetailsVo: CourseUnitDetailsVo,
    val curriculumFlag: Int,
    val evaluateFlag: Int,
    val newCourseClassesFlg: Int,
    val noteFlag: Int,
    val studyFlag: Int
) : Parcelable

@Parcelize
class ClassesMap(
    val courseType: Int,
    val learningPhaseMap: ArrayList<LearningPhaseMap>,
    val wdClassesGrouping: ArrayList<WdClassesGroupingEntity>
) : Parcelable

@Parcelize
class CourseUnitDetailsVo(
    val id: String = "",
    val liveClassroomName: String = "",
    val liveClassroomStatus: Int = 0,
    val isAudition: Int = 0,   //1 - 试听  0 -不试听
    val liveStartTime: String = "",
    val duration: String = "",
    val courseName: String = "",
    val teacherName: String = "",
    val teacherImagePhoto: String = "",
    val channel: String = "",
    val isLook: Int = 0,
    val type: Int = 0,
    val lookPercentage: Int = 0,
    val associatedCoursewareCode: String = "",
    var vid: String = "",
    val relatedLiveNewCode: String = "",
    val unlock:UnlockEntity,
    val materials: ArrayList<String> = arrayListOf(),
    var sort: Int,
) : Parcelable

@Parcelize
class WdClassesGroupingEntity(
    val sectionName: String = "",
    val classesId: String = "",
    val classesTypeId: String = "",
    val id: String = "",
    val learningPhaseMap: ArrayList<LearningPhaseMap>,
) : Parcelable
@Parcelize
class LearningPhaseMap(
    val learningPhase: String,
    val learningPhaseCourseMap: ArrayList<HomeModuleCourseEntity>,
    val learningPhaseText: String
) : Parcelable

