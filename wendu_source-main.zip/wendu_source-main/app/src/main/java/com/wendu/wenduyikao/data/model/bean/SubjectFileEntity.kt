package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


@SuppressLint("ParcelCreator")
@Parcelize
class SubjectFileEntity(
    val id: String,
    val imageUrl: String?="",
    val materialType: String,
    val subjectId: String,
    val type:Int,
    val videoUrl: String
) : Parcelable