package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/21 09:48
 * email:943789510@qq.com
 * describe:
 */
@Parcelize
data class TeacherEntity(
    val id: String = "",
    val teacherName: String = "",
    val teacherImagePhoto: String = "",
    val teacherIntroduce: String = "",
    val teacherTitle: String = "",
):Parcelable