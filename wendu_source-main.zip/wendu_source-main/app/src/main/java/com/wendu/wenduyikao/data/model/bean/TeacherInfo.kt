package com.wendu.wenduyikao.data.model.bean

/**
 * author:yxm on 2021/9/5 13:30
 * email:943789510@qq.com
 * describe:
 */
data class TeacherInfo(
    val idPhoto:String = "",
    val imagePhoto:String = "",
    val introduce:String = "",
    val teacherAvatar:String = "",
)
