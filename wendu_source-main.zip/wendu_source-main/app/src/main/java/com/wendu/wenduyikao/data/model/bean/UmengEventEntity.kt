package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
import java.math.BigDecimal

/**
 * author:yxm on 2021/8/22 17:04
 * email:943789510@qq.com
 * describe: UMeng事件统计
 */
@Parcelize
data class UmengEventEntity(
    val page_id: String = "",
    val function_name: String = "",
    val function_id: String = "",
) : Parcelable{

    }
