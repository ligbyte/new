package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     UnlockEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/12
 * Description:
 */
public class UnlockEntity  implements Serializable {
    private int isUnLock;//用户解锁状态 0未解锁，1已解锁
    private int unlockType;//（解锁类型 null未上锁，0添加老师微信解锁，1分享解锁，2闯关）
    private String teacherWx;//老师微信
    private String teacherProfilePhoto;///老师头像

    public int getIsUnLock() {
        return isUnLock;
    }

    public void setIsUnLock(int isUnLock) {
        this.isUnLock = isUnLock;
    }

    public int getUnlockType() {
        return unlockType;
    }

    public void setUnlockType(int unlockType) {
        this.unlockType = unlockType;
    }

    public String getTeacherWx() {
        return teacherWx;
    }

    public void setTeacherWx(String teacherWx) {
        this.teacherWx = teacherWx;
    }

    public String getTeacherProfilePhoto() {
        return teacherProfilePhoto;
    }

    public void setTeacherProfilePhoto(String teacherProfilePhoto) {
        this.teacherProfilePhoto = teacherProfilePhoto;
    }
}
