package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * @auther yxm
 * @date 2021/12/4
 * @desc
 */
@Parcelize
data class UserCouponEntity(

    var category: Int,

    var classesIds: Int,

    var content: String,

    var couponAmount: Int,

    var couponName: String,

    var couponStatus: Int,

    var createTime: String,

    var discountAmount: Double,

    var effectiveTimeEnd: String,

    var effectiveTimeStart: String,

    var fixDays: Int,

    var flg: Int, //0没领取 1已领取

    var hasThreshold: Int,

    var id: String,

    var isDeleted: Int,

    var isPublish: Int,

    var receiveAmount: Int,

    var timeLimit: Int,

    var type: Int,

    var updateTime: String,

    var useLimit: Double
): Parcelable