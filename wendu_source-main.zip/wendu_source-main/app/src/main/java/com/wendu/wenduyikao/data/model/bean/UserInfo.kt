package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * 作者　:  xiaoyangyan
 * 时间　: 2019/12/23
 * 描述　: 账户信息
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class UserInfo(
    var id: String = "",
    var userID: Int,
    var type: Int = 0,
    var name: String = "",
    var stuPhone: String = "",
    var stuSex: String = "",
    var wxname: String = "",
    var qq: String = "",
    var openid: String = "",
    var feedBackUrl: String = "",
    var address: String = "",
    var education: String = "",//学历
    var graduationMajor: String = "",//专业
    var school: String = "",//学校
    var headimgurl: String = "",
    val unionid: String = "",
    val userPassword: String = "",
    val isPush: Int = 0,
    val school_dictText: String = "",
    val distributionId_dictText: String = "",
    val majorId: String = "",

    var stuName: String = ""
) : Parcelable
