package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * author:yxm on 2021/8/19 18:58
 * email:943789510@qq.com
 * describe: 首页是否展示运营计划
 *
 */
@Parcelize
data class UserPlanEntity(
    val planProdUrl: String = "",
    val view: Int = 0,
    val planImg: String = "",
    val planUrl: String = "",
    val planId: String = "",
    ) : Parcelable