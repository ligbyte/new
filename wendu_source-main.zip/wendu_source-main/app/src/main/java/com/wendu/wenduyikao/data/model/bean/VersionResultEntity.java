package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;

/**
 * Package:       com.xiaoyang.kankanTraffic.data.model.bean
 * ClassName:     VersionResultEntity
 * Author:         xiaoyangyan
 * CreateDate:    2022/1/16
 * Description:
 */
public class VersionResultEntity implements Serializable {
    private String downloadLink;
    private String versionName;
    private int versionCode;
    private String description;
    private String appVersion;
private int appVersionInt;

    public int getAppVersionInt() {
        return appVersionInt;
    }

    public void setAppVersionInt(int appVersionInt) {
        this.appVersionInt = appVersionInt;
    }

    public String getVersionName() {
        return versionName;
    }

    public void setVersionName(String versionName) {
        this.versionName = versionName;
    }

    public int getVersionCode() {
        return versionCode;
    }

    public void setVersionCode(int versionCode) {
        this.versionCode = versionCode;
    }

    public String getDownloadLink() {
        return downloadLink;
    }

    public void setDownloadLink(String downloadLink) {
        this.downloadLink = downloadLink;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }
}
