package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     WdActivityEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/9
 * Description:
 */

@SuppressLint("ParcelCreator")
@Parcelize
class WdActivityEntity(
    val activityEndTime: String,
    val activityStratTime: String,
    val classifyId: String,
    val content: String,
    val createTime: String,
    val headline: String,
    val id: String,
    val imgUrl: String,
    val link: String,
    val preview: Int,
    val proceedType:Int,
    val state: Int,
    val stratTime: String
) : Parcelable