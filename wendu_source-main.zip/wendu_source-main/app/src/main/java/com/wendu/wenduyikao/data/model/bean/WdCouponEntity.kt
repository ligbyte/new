package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     WdCouponEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/25
 * Description:
 */
@Parcelize
class WdCouponEntity(
    val flg:Int,
    val category: Int,
    val content: String,
    val couponAmount: Int,
    val couponName: String,
    val couponStatus: String,
    val createTime: String,
    val discountAmount: Double,
    val effectiveTimeEnd: String,
    val effectiveTimeStart: String,
    val fixDays: Int,
    val hasThreshold: Int,
    val id: String,
    val isDeleted: Int,
    val isPublish: Int,
    val receiveAmount: Int,
    val timeLimit: Int,
    val type: Int,
    val updateTime: String,
    val useLimit: Double
) : Parcelable