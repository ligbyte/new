package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     WdInformationEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/10
 * Description:
 */
@Parcelize
class WdInformationEntity(
    val author: String,
    val classId: String,
    val createTime: String,
    val guidance: String,
    val id: String,
    val img: String,
    val name: String,
    val particulars: String,
    val type: Int,
    val preview: Int,

    val userId: String,
    val userId_dictText: String
) : Parcelable