package com.wendu.wenduyikao.data.model.bean

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     WdInformationEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/11/10
 * Description:
 */
@Parcelize
class WdInformationTypeEntity(
    val createTime: String,
    val id: String,
    val img: String,
    val name: String,
    val sort: String,
    val type: Int
) : Parcelable