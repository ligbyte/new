package com.wendu.wenduyikao.data.model.bean;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Package:       com.wendu.wenduyikao.data.model.bean
 * ClassName:     wd
 * Author:         xiaoyangyan
 * CreateDate:    2021/9/22
 * Description:
 */
public class WdQuestionChapterPracticeEntity implements Serializable {
    private ArrayList<QuestionOptionEntity> chapterContentList;
    private ArrayList<QuestionOptionEntity> wdQuestionPaperOption;
    private String isRight;
    private String optionId;
    private String subjectId;
    private String type;
    private String solution;

    public ArrayList<QuestionOptionEntity> getWdQuestionPaperOption() {
        return wdQuestionPaperOption;
    }

    public void setWdQuestionPaperOption(ArrayList<QuestionOptionEntity> wdQuestionPaperOption) {
        this.wdQuestionPaperOption = wdQuestionPaperOption;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public ArrayList<QuestionOptionEntity> getChapterContentList() {
        return chapterContentList;
    }

    public void setChapterContentList(ArrayList<QuestionOptionEntity> chapterContentList) {
        this.chapterContentList = chapterContentList;
    }

    public String getIsRight() {
        return isRight;
    }

    public void setIsRight(String isRight) {
        this.isRight = isRight;
    }

    public String getOptionId() {
        return optionId;
    }

    public void setOptionId(String optionId) {
        this.optionId = optionId;
    }

    public String getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(String subjectId) {
        this.subjectId = subjectId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
