package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize


/**
 * Package:       me.xiaoyang.bearingproduction.data.model.bean
 * ClassName:     LoginInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    3/1/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class WxLoginInfo2Entity(
    val city: String,
    val country: String,
    val headimgurl: String,
    val language: String,
    val nickname: String,
    val openid: String,
    val province: String,
    val sex: Int,
    val token:String,
    val userInfo: UserInfo,
    val unionid: String
) : Parcelable