package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * Package:       me.xiaoyang.bearingproduction.data.model.bean
 * ClassName:     LoginInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    3/1/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
data class WxLoginInfoEntity(
    var userInfo: UserInfo,
    var token: String
) : Parcelable