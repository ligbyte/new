package com.wendu.wenduyikao.data.model.bean

import android.annotation.SuppressLint
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize



/**
 * Package:       me.xiaoyang.bearingproduction.data.model.bean
 * ClassName:     LoginInfoEntity
 * Author:         xiaoyangyan
 * CreateDate:    3/1/21
 * Description:
 */
@SuppressLint("ParcelCreator")
@Parcelize
class WxPayResultEntity(
    val appid: String,
    val noncestr: String,
    val `package`: String,
    val partnerid: String,
    val prepayid: String,
    val sign: String,
    val timestamp: String,
    val trade_type: String
) : Parcelable