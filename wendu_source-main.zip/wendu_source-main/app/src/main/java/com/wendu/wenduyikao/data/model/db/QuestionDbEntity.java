package com.wendu.wenduyikao.data.model.db;

import com.google.gson.annotations.SerializedName;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.db
 * ClassName:     QuestionDbEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/9/22
 * Description:
 */
public class QuestionDbEntity extends LitePalSupport implements Serializable {
    private String index;
    private int position;
    private int questionIndex;
    private int total;
    private String name;
    private String answer;
    private String answerTxt;//解析富文本内容
    private String answerText; //答题统计
    private String chapterId;
    private String dataList;
    @SerializedName(value = "id")
    private String questionId; //题干id,单选为主题干id,共用题干，存储子题干id
    private String parentId; //主题干id
    private int liftingType;
    private String optionList;
    private String questionList;
    private double score;
    private int isCollect;
    private String isCollectId="";
    private int topicCategory;
    private String typeLabel;
    private String selectList;
    private String wdQuestionChapterPractice;
    private String stem;
    private String templateId;
    private String templateName;
    private String tenantId;
    private String solution;
    private String childStem;
    private String childIndex;
    private int facilityValue; //难易程度

    public String getAnswerTxt() {
        return answerTxt;
    }

    public void setAnswerTxt(String answerTxt) {
        this.answerTxt = answerTxt;
    }

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public int getFacilityValue() {
        return facilityValue;
    }

    public void setFacilityValue(int facilityValue) {
        this.facilityValue = facilityValue;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getIsCollectId() {
        return isCollectId;
    }

    public void setIsCollectId(String isCollectId) {
        this.isCollectId = isCollectId;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public int getTopicCategory() {
        return topicCategory;
    }

    public void setTopicCategory(int topicCategory) {
        this.topicCategory = topicCategory;
    }

    public String getTypeLabel() {
        return typeLabel;
    }

    public void setTypeLabel(String typeLabel) {
        this.typeLabel = typeLabel;
    }

    public String getChildIndex() {
        return childIndex;
    }

    public void setChildIndex(String childIndex) {
        this.childIndex = childIndex;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public String getChildStem() {
        return childStem;
    }

    public void setChildStem(String childStem) {
        this.childStem = childStem;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getChapterId() {
        return chapterId;
    }

    public void setChapterId(String chapterId) {
        this.chapterId = chapterId;
    }

    public String getDataList() {
        return dataList;
    }

    public void setDataList(String dataList) {
        this.dataList = dataList;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public int getLiftingType() {
        return liftingType;
    }

    public void setLiftingType(int liftingType) {
        this.liftingType = liftingType;
    }

    public String getOptionList() {
        return optionList;
    }

    public void setOptionList(String optionList) {
        this.optionList = optionList;
    }

    public String getQuestionList() {
        return questionList;
    }

    public void setQuestionList(String questionList) {
        this.questionList = questionList;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public int getIsCollect() {
        return isCollect;
    }

    public void setIsCollect(int isCollect) {
        this.isCollect = isCollect;
    }

    public String getSelectList() {
        return selectList;
    }

    public void setSelectList(String selectList) {
        this.selectList = selectList;
    }

    public String getWdQuestionChapterPractice() {
        return wdQuestionChapterPractice;
    }

    public void setWdQuestionChapterPractice(String wdQuestionChapterPractice) {
        this.wdQuestionChapterPractice = wdQuestionChapterPractice;
    }

    public String getStem() {
        return stem;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }
}
