package com.wendu.wenduyikao.data.model.db;

import com.google.gson.annotations.SerializedName;

import org.litepal.crud.LitePalSupport;

import java.io.Serializable;

/**
 * Package:       com.wendu.wenduyikao.data.model.db
 * ClassName:     QuestionDbEntity
 * Author:         xiaoyangyan
 * CreateDate:    2021/9/22
 * Description:
 */
public class QuestionPaperDbEntity extends LitePalSupport implements Serializable {
    private String index;
    private int position;
    private int questionIndex;
    private int total;
    private String answer;
    private String answerText;//答题统计
    private String answerTxt; //答题富文本
    private String wdQuestionPaperData;
    @SerializedName(value = "id")
    private String questionId;
    private String parentId;
    private int liftingType;
    private String wdQuestionPaperOption;
    private String wdQuestionPaperSubjectSubordinatesList;
    private double score;
    private int isCollect;
    private String isCollectId;
    private int topicCategory;
    private String paperId;
    private String paperType;

    private String typeLabel;
    private String wdQuestionPaperDataVideo;
    private String wdQuestionChapterPractice;
    private String stem;
    private String templateId;
    private String templateName;
    private String tenantId;
    private String solution;
    private String childStem;
    private String childIndex;
    private String wdQuestionBankList; //是否有举一反三
    private int facilityValue; //难易程度

    public String getAnswerText() {
        return answerText;
    }

    public void setAnswerText(String answerText) {
        this.answerText = answerText;
    }

    public String getAnswerTxt() {
        return answerTxt;
    }

    public void setAnswerTxt(String answerTxt) {
        this.answerTxt = answerTxt;
    }

    public String getWdQuestionBankList() {
        return wdQuestionBankList;
    }

    public void setWdQuestionBankList(String wdQuestionBankList) {
        this.wdQuestionBankList = wdQuestionBankList;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public int getFacilityValue() {
        return facilityValue;
    }

    public void setFacilityValue(int facilityValue) {
        this.facilityValue = facilityValue;
    }

    public String getPaperType() {
        return paperType;
    }

    public void setPaperType(String paperType) {
        this.paperType = paperType;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getQuestionIndex() {
        return questionIndex;
    }

    public void setQuestionIndex(int questionIndex) {
        this.questionIndex = questionIndex;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public String getWdQuestionPaperData() {
        return wdQuestionPaperData;
    }

    public void setWdQuestionPaperData(String wdQuestionPaperData) {
        this.wdQuestionPaperData = wdQuestionPaperData;
    }

    public String getQuestionId() {
        return questionId;
    }

    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }

    public int getLiftingType() {
        return liftingType;
    }

    public void setLiftingType(int liftingType) {
        this.liftingType = liftingType;
    }

    public String getWdQuestionPaperOption() {
        return wdQuestionPaperOption;
    }

    public void setWdQuestionPaperOption(String wdQuestionPaperOption) {
        this.wdQuestionPaperOption = wdQuestionPaperOption;
    }

    public String getWdQuestionPaperSubjectSubordinatesList() {
        return wdQuestionPaperSubjectSubordinatesList;
    }

    public void setWdQuestionPaperSubjectSubordinatesList(String wdQuestionPaperSubjectSubordinatesList) {
        this.wdQuestionPaperSubjectSubordinatesList = wdQuestionPaperSubjectSubordinatesList;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public int getIsCollect() {
        return isCollect;
    }

    public void setIsCollect(int isCollect) {
        this.isCollect = isCollect;
    }

    public String getIsCollectId() {
        return isCollectId;
    }

    public void setIsCollectId(String isCollectId) {
        this.isCollectId = isCollectId;
    }

    public int getTopicCategory() {
        return topicCategory;
    }

    public void setTopicCategory(int topicCategory) {
        this.topicCategory = topicCategory;
    }

    public String getPaperId() {
        return paperId;
    }

    public void setPaperId(String paperId) {
        this.paperId = paperId;
    }

    public String getTypeLabel() {
        return typeLabel;
    }

    public void setTypeLabel(String typeLabel) {
        this.typeLabel = typeLabel;
    }

    public String getWdQuestionPaperDataVideo() {
        return wdQuestionPaperDataVideo;
    }

    public void setWdQuestionPaperDataVideo(String wdQuestionPaperDataVideo) {
        this.wdQuestionPaperDataVideo = wdQuestionPaperDataVideo;
    }

    public String getWdQuestionChapterPractice() {
        return wdQuestionChapterPractice;
    }

    public void setWdQuestionChapterPractice(String wdQuestionChapterPractice) {
        this.wdQuestionChapterPractice = wdQuestionChapterPractice;
    }

    public String getStem() {
        return stem;
    }

    public void setStem(String stem) {
        this.stem = stem;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public String getSolution() {
        return solution;
    }

    public void setSolution(String solution) {
        this.solution = solution;
    }

    public String getChildStem() {
        return childStem;
    }

    public void setChildStem(String childStem) {
        this.childStem = childStem;
    }

    public String getChildIndex() {
        return childIndex;
    }

    public void setChildIndex(String childIndex) {
        this.childIndex = childIndex;
    }
}
