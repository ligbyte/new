package com.wendu.wenduyikao.data.repository.request

import com.wendu.wenduyikao.app.network.apiService
import me.xiaoyang.base.network.AppException
import com.wendu.wenduyikao.data.model.bean.*
import com.google.gson.JsonObject

/**
 * 作者　:  xiaoyangyan
 * 时间　: 2020/5/4
 * 描述　: 处理协程的请求类
 */

val HttpRequestCoroutine: HttpRequestManger by lazy(mode = LazyThreadSafetyMode.SYNCHRONIZED) {
    HttpRequestManger()
}

class HttpRequestManger {
    suspend fun register(username: String, code: String): ApiResponse<LoginInfoEntity> {
        val registerData = apiService.register(username, code, code)
        //判断注册结果 注册成功，调用登录接口
        if (registerData.isSucces()) {
            val json = JsonObject()
            json.addProperty("mobile", username)
            json.addProperty("code", code)
            return apiService.login(json)
        } else {
            //抛出错误异常
            throw AppException(registerData.code, registerData.message)
        }
    }





}