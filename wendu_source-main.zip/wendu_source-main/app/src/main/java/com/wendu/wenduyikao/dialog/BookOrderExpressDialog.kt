package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.content.Context
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import com.lxj.xpopup.core.CenterPopupView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.data.model.bean.BookOrderItemEntity
import com.wendu.wenduyikao.mine.adapter.BookOrderExpressAdapter
import kotlinx.android.synthetic.main.book_order_express_popup.view.*

/**
 * Package:       com.wendu.wenduyikao.dialog
 * ClassName:     BookOrderExpressDialog
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/3
 * Description:
 */

@SuppressLint("ViewConstructor")
class BookOrderExpressDialog(context: Context, bookList: ArrayList<BookOrderItemEntity>) :
    CenterPopupView(context) {
    private var list = bookList

    override fun getImplLayoutId(): Int {
        return R.layout.book_order_express_popup
    }

    override fun onCreate() {
        super.onCreate()
        findViewById<View>(R.id.tv_close).setOnClickListener {
            dismiss()
        }
        setData()
    }
//        @Override
    //        protected int getMaxHeight() {
    //            return 200;
    //        }
    //
    //        @Override
    //        protected int getMaxWidth() {
    //            return 1000;
    //        }

    fun setData() {
        Log.v("yxy", "=====" + list.size)
        initBokRecycleView(list)
    }


    private fun initBokRecycleView(list: ArrayList<BookOrderItemEntity>) {
        val shopCarAdapter = BookOrderExpressAdapter(list)
        //初始化recyclerView
        rlv_book.init(
            LinearLayoutManager(context),
            shopCarAdapter
        )

        shopCarAdapter.run {
            setOnItemClickListener { adapter, view, position ->

            }


        }
    }
}