package com.wendu.wenduyikao.dialog;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.umeng.commonsdk.UMConfigure;
import com.umeng.message.PushAgent;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.app.App;
import com.wendu.wenduyikao.app.util.CacheUtil;
import com.wendu.wenduyikao.app.util.UmengThirdUtil;
import com.wendu.wenduyikao.ui.activity.MainActivity;
import com.wendu.wenduyikao.ui.activity.WebActivity;
import com.wendu.wenduyikao.ui.home.SelectMajorActivity;
import com.wendu.wenduyikao.util.PolyvUtil;

import java.util.Map;
import java.util.Objects;
import java.util.Set;

import retrofit2.Response;

/**
 * 中间dialog的弹出
 */
public class CenterDialog {
    private Activity activity;
    private AlertDialog.Builder builder;
    private View v;

    public CenterDialog(int layoutId, Activity activity) {
        this.activity = activity;
        this.builder = new AlertDialog.Builder(activity);
        this.v = (LayoutInflater.from(activity)).inflate(layoutId, null);
    }


    private static int dip2px(Context mContext, float dpValue) {
        final float scale = mContext.getResources()
                .getDisplayMetrics().density;
        return (int) (dpValue * scale + 0.5f);
    }


    public void showUserPrompt() {
//        SPUtils.put(App.getContext(), "isAppOpened", "true");
        TextView btn_sure = v.findViewById(R.id.userConfirm);
        TextView btn_cancel = v.findViewById(R.id.userCancel);

        TextView tv_userAgreement = v.findViewById(R.id.tv_userAgreement);//用户协议
        TextView tv_privacy = v.findViewById(R.id.tv_privacy);//隐私政策
        final Dialog dialog = builder.create();
        Objects.requireNonNull(dialog.getWindow()).setBackgroundDrawableResource(R.color.transparent);
        dialog.show();
        //此处设置位置窗体大小
        dialog.getWindow().setLayout(dip2px(activity, 280), LinearLayout.LayoutParams.WRAP_CONTENT);
        Objects.requireNonNull(dialog.getWindow()).setContentView(v);//自定义布局应该在这里添加，要在dialog.show()的后面
        dialog.getWindow().setGravity(Gravity.CENTER);//可以设置显示的位置
        dialog.setCancelable(false);
        tv_userAgreement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //用户协议
                activity.startActivity(new Intent(activity, WebActivity.class)
                        .putExtra("type", 3));

            }
        });
        tv_privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //隐私政策
                activity.startActivity(new Intent(activity, WebActivity.class)
                        .putExtra("type", 2));

            }
        });
        btn_sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CacheUtil.INSTANCE.setOpenPrompt(true);
                dialog.dismiss();
                if (TextUtils.isEmpty(CacheUtil.INSTANCE.getMajorId())) {
                    activity.startActivity(new Intent(activity, SelectMajorActivity.class).putExtra(SelectMajorActivity.FROM_WHERE, 3));
                } else {
                    activity.startActivity(new Intent(activity, MainActivity.class));
                }
                UMConfigure.setLogEnabled(true);
//        UMConfigure.init(
//            context,
//            "613c6826520cc86a1d4803ff",
//            "Umeng",
//            UMConfigure.DEVICE_TYPE_PHONE,
//            "e6d4a90b2364efff14b4ae213c21a719"
//        );
                //预初始化
                //个人测试 62c4e65430121a652b60619c
                //正式  613c6826520cc86a1d4803ff
                UMConfigure.preInit(App.instance, "613c6826520cc86a1d4803ff", "Umeng");
                UmengThirdUtil.INSTANCE.initAppPush(App.instance);
                PolyvUtil.INSTANCE.initPolyvVod();
                activity.finish();
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                CacheUtil.INSTANCE.setOpenPrompt(false);
                dialog.dismiss();
                activity.finish();
            }
        });
    }

}
