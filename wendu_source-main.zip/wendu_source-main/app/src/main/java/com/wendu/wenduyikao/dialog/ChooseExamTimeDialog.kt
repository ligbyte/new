package com.wendu.wenduyikao.dialog

import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.res.ResourcesCompat
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.weight.datepick.DatePicker
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.ruffian.library.RTextView
import kotlinx.android.synthetic.main.date_picker_customer.view.*
import java.util.*


/**
 * author:yxm on 2021/8/11 21:36
 * email:943789510@qq.com
 * describe:
 */
class ChooseExamTimeDialog (context: Context?) : BaseBottomSheetBuilder(context) {

    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.layout_choose_exam_time, null)
        val height = mContext.resources.getDimension(R.dimen.dp_340).toInt()
        setHeight(height) //设置Dialog的高度
        val ivClose:ImageView = rootView.findViewById(R.id.iv_close)
        val tvConfirm: RTextView = rootView.findViewById(R.id.tv_confirm)


        val datePickerShowText: TextView = rootView.findViewById(R.id.date_picker_show_text)
        val datePicker: DatePicker = rootView.findViewById(R.id.datePicker)


        ivClose.setOnClickListener { mDialog.dismiss() }
        tvConfirm.setOnClickListener {
            datePicker.year
            datePicker.month + 1
            datePicker.dayOfMonth
            onSubmitClick!!.onSubmitClick("${datePicker.year}-${datePicker.month + 1}-${datePicker.dayOfMonth}")
            ToastUtils.showShort("${datePicker.year}年${datePicker.month + 1}月${datePicker.dayOfMonth}日")
            mDialog.dismiss()
        }


//        val datePicker: DatePicker = rootView.findViewById(R.id.datePicker)
//
//            datePicker.addOnDateChanged { previousDate, newDate->
//                ToastUtils.showShort("${newDate}111")
//                // this library provides convenience extensions to Calendar like month, year, and dayOfMonth too.
//            }
//
//        // Removes all callbacks you've added previously with addOnDateChanged(...)
//        datePicker.clearOnDateChanged()

        val calendar = Calendar.getInstance()
        calendar[2000, 1] = 1
        datePicker.setMinDate(calendar.timeInMillis)
        calendar[2100, 1] = 1


        datePicker.setDividerThickness(1)
        datePicker.setDividerColor(ResourcesCompat.getColor(mContext.resources,R.color.divider,null))
        datePicker.setTextColor(ResourcesCompat.getColor(mContext.resources,R.color.text_color_999,null))
        datePicker.setSelectedTextColor(ResourcesCompat.getColor(mContext.resources,R.color.main_color,null))
        datePicker.setMaxDate(calendar.timeInMillis)
        datePicker.setFormatter("%02d年", "%02d月", "%02d日")
        datePicker.setOnChangedListener { view, year, monthOfYear, dayOfMonth ->
            datePickerShowText.text = "你将在什么时间参加考试？"

                StringBuilder()
                .append("DatePicker:")
                .append(year).append("年")
                .append(monthOfYear + 1).append("月")
                .append(dayOfMonth).append("日")
        }

        return rootView
    }

    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener): ChooseExamTimeDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String)
    }

    companion object {
        fun newBuilder(
            context: Activity?,
            listener: OnSubmitClickListener
        ): BaseBottomSheetDialog {
            return ChooseExamTimeDialog(context)
                .setOnSubmitClick(listener).build()
        }
    }
}
