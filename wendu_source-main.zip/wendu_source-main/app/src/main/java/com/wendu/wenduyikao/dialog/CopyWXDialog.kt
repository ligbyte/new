package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.UnlockEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/12/11 12:50 下午
 * @Description: 添加微信号
 */
class CopyWXDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    //    private var shareImg: ImageView? = null
    private var unlockInfo: UnlockEntity = UnlockEntity()

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_add_wx_layout, null)
//        val height = MobileUtil.getScreenHeight(mContext) * 6 / 7
//        setHeight(height) //设置Dialog的高度

        val ivClose: TextView = rootView.findViewById(R.id.tv_share_cancel)
        val tvActivation: RTextView = rootView.findViewById(R.id.tv_share_activation)
        val tvShareCopy: RTextView = rootView.findViewById(R.id.tv_share_copy)
        val wxPhoto: ImageView = rootView.findViewById(R.id.share_wx_pic)
        val tvName: TextView = rootView.findViewById(R.id.share_wx_tv_name)
        val edtKey: EditText = rootView.findViewById(R.id.edt_add_wx_key)

        ivClose.setOnClickListener { mDialog.dismiss() }
        tvActivation.setOnClickListener {
            if (StringUtil.isBlank(edtKey.text.toString())) {
               ToastUtils.showShort("请输入解锁码")
            }else{
                onSubmitClick!!.onSubmitClick(edtKey.text.toString())
                mDialog.dismiss()
            }


        }
        tvShareCopy.setOnClickListener {
            try {
                val cm = mContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                // 创建普通字符型ClipData
                val mClipData = ClipData.newPlainText("Label", unlockInfo.teacherWx)
                // 将ClipData内容放到系统剪贴板里。
                cm.setPrimaryClip(mClipData)
                ToastUtils.showShort("复制成功")
            } catch (e: Exception) {

            }
        }
        tvName.text = unlockInfo.teacherWx
        val options = RequestOptions()
        options.skipMemoryCache(true) //跳过内存缓存
        options.diskCacheStrategy(DiskCacheStrategy.NONE) //不缓冲disk硬盘中
        Glide.with(mContext).load(unlockInfo.teacherProfilePhoto).apply(options)
            .placeholder(R.drawable.ic_default_pic2).into(wxPhoto)
        return rootView
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): CopyWXDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    fun setUnLock(unlock: UnlockEntity): CopyWXDialog {
        this.unlockInfo = unlock
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String)
    }

    companion object {

        @JvmStatic
        fun newBuilder(
            context: Activity?,
            unlock: UnlockEntity,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {
            return CopyWXDialog(context)
                .setUnLock(unlock)
                .setOnSubmitClick(listener).build()
        }

    }

}