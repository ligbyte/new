package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Paint
import android.text.TextUtils
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.res.ResourcesCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.eventbus.ChooseClassTypeEvent
import com.wendu.wenduyikao.data.model.bean.ClassTypeEntity
import com.wendu.wenduyikao.data.model.bean.CourseClassEntity
import com.wendu.wenduyikao.data.model.bean.FaceCourseInfoEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.ui.home.CoursePayActivity
import com.wendu.wenduyikao.ui.home.adapter.CourseTypeListAdapter
import com.wendu.wenduyikao.util.GlideHelper
import com.wendu.wenduyikao.util.UserUtil
import com.wendu.wenduyikao.util.WeixinHelper
import com.wendu.wenduyikao.viewmodel.request.CouponCenterViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus

/**
 * Created by yxm on 2021/8/9.
 * 选择购课类型
 */
class CourseChooseDialog1(context: Context?) : BaseBottomSheetBuilder(context) {
    var resourceId = 0
    var classEntity: CourseClassEntity? = null
    var classType: MutableList<ClassTypeEntity>? = null
    var faceInfo: FaceCourseInfoEntity? = null
    var rvRefund: RTextView? = null

    var rvReStudy: RTextView? = null
    var rvRefundHint: RTextView? = null
    var rvBuy: RTextView? = null
    var tvContact: RTextView? = null
    var tvPrice: TextView? = null
    var tv_line_fficial_price: TextView? = null
    var tvPriceCoupon: TextView? = null
    var clPriceCoupon: ConstraintLayout? = null

    var choosePosition = 0
    var chooseType: ClassTypeEntity? = null

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.layout_course_class_choose_course1, null)
        val height = mContext.resources.getDimension(R.dimen.dp_330).toInt()
        setHeight(height) //设置Dialog的高度
        createObserver()
        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        val ivCourseBg: ImageView = rootView.findViewById(R.id.iv_course_bg)
        tv_line_fficial_price = rootView.findViewById<TextView>(R.id.tv_line_fficial_price)
        tvPrice = rootView.findViewById(R.id.tv_price)
        tvPriceCoupon = rootView.findViewById(R.id.tv_price_coupon)
        clPriceCoupon = rootView.findViewById(R.id.cl_price_coupon)

        ivClose.setOnClickListener { mDialog.dismiss() }


        rvBuy = rootView.findViewById(R.id.rv_buy)
        tvContact = rootView.findViewById(R.id.tv_contact)
        if (classTypeConst == classCourse) {
            rvBuy!!.visibility = View.VISIBLE
            tvContact!!.visibility = View.GONE
            GlideHelper.loadRoundRectImage(ivCourseBg, classEntity!!.classesCover, 10)
        } else {
            rvBuy!!.visibility = View.GONE
            tvContact!!.visibility = View.VISIBLE
            GlideHelper.loadRoundRectImage(ivCourseBg, faceInfo!!.classesCover, 10)
        }

        rvBuy!!.setOnClickListener {
            if (chooseType!!.registrationWay == 1) {
                if (!UserUtil.isLogin(mContext)) {
                    return@setOnClickListener
                }
                EventBus.getDefault().post(ChooseClassTypeEvent(chooseType!!.id))
                mDialog.dismiss()
                return@setOnClickListener
//                CoursePayActivity.toThis(mContext,classEntity!!.id,classEntity!!.classesName,
//                    classEntity!!.classesCover,
//                    chooseType!!.id,"免费领取","0",true)
            } else {
                if (chooseType!!.flg == 1 && chooseType!!.userCouponEntity.flg != 1) {

                    requestViewModel.saveCoupon(chooseType!!.userCouponEntity.id)
                }
                CoroutineScope(Dispatchers.Main).launch {
                    Log.e("TAG", "1.执行CoroutineScope.... [当前线程为：${Thread.currentThread().name}]")
                    delay(500)     //延时500ms
                    CoursePayActivity.toThis(
                        mContext, classEntity!!.id, classEntity!!.classesName,
                        classEntity!!.classesCover, chooseType!!.id, chooseType!!.classesTypeName,
                        chooseType!!.fficialPrice!!.toDouble(), false
                    )
                }

            }

            mDialog.dismiss()

        }
        tvContact!!.setOnClickListener {
//            ToastUtils.showShort("咨询")
            WeixinHelper.goToWeixinChat(mContext)
        }

        rvRefundHint = rootView.findViewById(R.id.rv_refund_hint)

        val typeAdapter = CourseTypeListAdapter()

        val recyclerView: RecyclerView = rootView.findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(mContext, LinearLayoutManager.HORIZONTAL,false)
        recyclerView.adapter = typeAdapter
        typeAdapter.data.addAll(classType!!)


        typeAdapter.choosePosition = choosePosition
        chooseType = classType!![choosePosition]
        refreshUi()

        typeAdapter.setOnItemClickListener { adapter, view, position ->
            choosePosition = position
            chooseType = classType!![choosePosition]
            typeAdapter.choosePosition = position
            typeAdapter.notifyDataSetChanged()
            refreshUi()
        }

        return rootView
    }


    private fun refreshUi() {
        if (chooseType == null || tvPrice == null) return
        if (chooseType!!.registrationWay == 1) {//1免费
            tvPrice!!.text = "免费"
            rvBuy!!.text = "免费领取"
        } else {
            rvBuy!!.text = "立即购买"
            tvPrice!!.text = StringUtil.formatDoublePrice(chooseType!!.fficialPrice)

            if (chooseType!!.lineFficialPrice > 0) {
                tv_line_fficial_price!!.visibility = View.VISIBLE
                tv_line_fficial_price!!.paintFlags =
                    tv_line_fficial_price!!.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                tv_line_fficial_price!!.text =
                    StringUtil.formatDoublePrice(chooseType!!.lineFficialPrice)
            } else {
                tv_line_fficial_price!!.visibility = View.GONE
            }

        }

        if (classTypeConst == classCourse) {
            if (chooseType!!.flg == 1) { //有优惠券
                Log.v("yxy", "有权费" + chooseType?.couponMoney)
                tvPriceCoupon!!.text = StringUtil.formatDoublePrice(chooseType!!.couponMoney)
                clPriceCoupon!!.visibility = View.VISIBLE
                rvBuy!!.text = "领券购买"
            } else {
                Log.v("yxy", "免费" + chooseType?.couponMoney)
                clPriceCoupon!!.visibility = View.GONE
                tvPriceCoupon!!.text = StringUtil.formatDoublePrice(chooseType!!.couponMoney)
            }
        }

        rvRefundHint!!.text = chooseType!!.instructions

        if (TextUtils.isEmpty(chooseType!!.instructions) || chooseType!!.registrationWay == 1) {
            rvRefundHint!!.visibility = View.GONE
        } else {
            rvRefundHint!!.visibility = View.VISIBLE
        }
    }

    private fun refreshUiForFace() {
        if (chooseType == null || tvPrice == null) return
        if (chooseType!!.registrationWay == 1) {//1免费
            tvPrice!!.text = "免费"
//            rvBuy!!.text = "免费领取"
        } else {
//            rvBuy!!.text = "立即购买"
            tvPrice!!.text = StringUtil.formatDoublePrice(chooseType!!.fficialPrice)
            if (chooseType!!.lineFficialPrice > 0) {
                tv_line_fficial_price!!.visibility = View.VISIBLE
                tv_line_fficial_price!!.paintFlags =
                    tv_line_fficial_price!!.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                tv_line_fficial_price!!.text =
                    StringUtil.formatDoublePrice(chooseType!!.lineFficialPrice)
            } else {
                tv_line_fficial_price!!.visibility = View.GONE
            }
        }

        rvRefundHint!!.text = chooseType!!.instructions

        if (TextUtils.isEmpty(chooseType!!.instructions) || chooseType!!.registrationWay == 1) {
            rvRefundHint!!.visibility = View.GONE
        } else {
            rvRefundHint!!.visibility = View.VISIBLE
        }
    }

    @SuppressLint("SetTextI18n")
    fun RTextView.setCustomerUI(type: Int) {
        when (type) {
            choose -> {
                backgroundColorNormal =
                    ResourcesCompat.getColor(resources, R.color.font_orange_lighter, null)
                textColorNormal = ResourcesCompat.getColor(resources, R.color.font_orange, null)
                borderColorNormal = ResourcesCompat.getColor(resources, R.color.font_orange, null)
            }
            unchoose -> {
                backgroundColorNormal = ResourcesCompat.getColor(resources, R.color.white, null)
                textColorNormal = ResourcesCompat.getColor(resources, R.color.text_color, null)
                borderColorNormal =
                    ResourcesCompat.getColor(resources, R.color.text_color_ccc, null)
            }
        }
    }

    fun createObserver() {

    }

    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): CourseChooseDialog1 {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null
    fun setResource(classEntity: CourseClassEntity?): CourseChooseDialog1 {
        this.classEntity = classEntity
        classTypeConst = classCourse
        return this
    }

    fun setClassType(classType: MutableList<ClassTypeEntity>?): CourseChooseDialog1 {
        this.classType = classType
        return this
    }

    fun setFaceResource(faceInfo: FaceCourseInfoEntity?): CourseChooseDialog1 {
        this.faceInfo = faceInfo
        classTypeConst = faceCourse
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String?)
    }

    companion object {
        val requestViewModel = CouponCenterViewModel()
        const val classCourse = 1
        const val faceCourse = 2
        var classTypeConst = classCourse

        const val choose = 1
        const val unchoose = 2

        var mActivity: Activity? = null
        fun newBuilder(
            context: Activity?,
            classEntity: CourseClassEntity?,
            classType: MutableList<ClassTypeEntity>?,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {
            mActivity = context
            return CourseChooseDialog1(context).setResource(classEntity).setClassType(classType)
                .setOnSubmitClick(listener).build()
        }

        fun newBuilder(
            context: Activity?,
            faceInfo: FaceCourseInfoEntity?,
            classType: MutableList<ClassTypeEntity>?,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {
            mActivity = context
            return CourseChooseDialog1(context).setClassType(classType).setFaceResource(faceInfo)
                .setOnSubmitClick(listener).build()
        }
    }

}