package com.wendu.wenduyikao.dialog;

import android.content.Context;
import android.graphics.Color;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;

import com.flyco.dialog.utils.CornerUtils;
import com.flyco.dialog.widget.base.BaseDialog;
import com.ligbyte.lib.theme.MultiTheme;
import com.wendu.wenduyikao.util.ViewFindUtils;
import com.wendu.wenduyikao.R;
/**
 * Author: Jeek
 * Date: 2019/5/16 14:31
 * Description: ${DESCRIPTION}
 */
public class CustomAlertDialog extends BaseDialog<CustomAlertDialog> {

    private Context context;
    private TextView tv_title;
    private TextView tv_cancel;
    private TextView tv_ok;
    private TextView tv_content;
    private EditTextDialogListener editTextDialogListener;
    private String content;
    private String title;
    private String cancel;
    private String ok;

    public CustomAlertDialog(Context context, String title, String content) {
        super(context);
        this.context = context;
        this.content = content;
        this.title = title;
    }

    public CustomAlertDialog(Context context, String title, String content, String cancel, String ok) {
        super(context);
        this.context = context;
        this.content = content;
        this.title = title;
        this.cancel = cancel;
        this.ok = ok;
    }

    @Override
    public View onCreateView() {
        widthScale(0.75f);
        heightScale(0.28f);
        showAnim(new com.flyco.animation.ZoomEnter.ZoomInEnter());
        View inflate = View.inflate(context, R.layout.dialog_custom_alert, null);
        tv_cancel = ViewFindUtils.find(inflate, R.id.tv_cancel);
        tv_ok = ViewFindUtils.find(inflate, R.id.tv_ok);
        tv_title = ViewFindUtils.find(inflate, R.id.tv_title);
        tv_content = ViewFindUtils.find(inflate, R.id.tv_content);
        tv_content.setText(content);
        tv_title.setText(title);
        if (!TextUtils.isEmpty(cancel)){
            tv_cancel.setText(cancel);
        }
        if (!TextUtils.isEmpty(ok)){
            tv_ok.setText(ok);
        }
        setCanceledOnTouchOutside(false);
        inflate.setBackgroundDrawable(
                CornerUtils.cornerDrawable(MultiTheme.getAppTheme() == 1 ? Color.parseColor("#1A191E") : Color.parseColor("#FFFFFF"), dp2px(5)));

        return inflate;
    }

    @Override
    public void setUiBeforShow() {
        tv_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editTextDialogListener != null) {
                    editTextDialogListener.onCancle();
                }
                dismiss();
            }
        });

        tv_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });

        return;
    }

    public void setEditTextDialogListener(EditTextDialogListener editTextDialogListener) {
        this.editTextDialogListener = editTextDialogListener;
    }


    public interface EditTextDialogListener {

        void onCancle();

        void onOk(String content);
    }




}
