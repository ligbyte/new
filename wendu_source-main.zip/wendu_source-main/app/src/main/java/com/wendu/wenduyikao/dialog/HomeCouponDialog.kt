package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.content.Context
import android.view.View
import com.bumptech.glide.Glide
import com.lxj.xpopup.core.CenterPopupView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.BannerPopupEntity
import kotlinx.android.synthetic.main.home_coupon_popup.view.*

/**
 * Package:       com.wendu.wenduyikao.dialog
 * ClassName:     BookOrderExpressDialog
 * Author:         xiaoyangyan
 * CreateDate:    2022/5/3
 * Description:
 */

@SuppressLint("ViewConstructor")
class HomeCouponDialog(context: Context, bannerInfo: BannerPopupEntity) :
    CenterPopupView(context) {
    private var info = bannerInfo

    override fun getImplLayoutId(): Int {
        return R.layout.home_coupon_popup
    }

    override fun onCreate() {
        super.onCreate()
        findViewById<View>(R.id.home_coupon_close).setOnClickListener {
            dismiss()
        }
        findViewById<View>(R.id.tv_get_coupon).setOnClickListener {
            val content = ""
            info.wdCoupon?.id?.let { it1 ->
                onSubmitClick!!.onSubmitClick(it1)
                dismiss()
            }
        }
        findViewById<View>(R.id.home_dialog_img_content).setOnClickListener {
            if (info.clickEvent != "6") {
                if (StringUtil.isNotBlank(info.skipUrl)) {
                    info.skipUrl.let { it1 -> onSubmitClick!!.onSubmitClick(it1) }

                }
            }
            dismiss()
        }
        setData()
    }
//        @Override
    //        protected int getMaxHeight() {
    //            return 200;
    //        }
    //
    //        @Override
    //        protected int getMaxWidth() {
    //            return 1000;
    //        }

    @SuppressLint("SetTextI18n")
    fun setData() {
        if (info.clickEvent != "6") {
            Glide.with(context).load(info.phoneImage).into(home_dialog_img_content)
            home_dialog_rl_coupon.visibility = View.GONE
            tv_get_coupon.visibility = View.GONE
        } else {
            home_dialog_rl_coupon.visibility = View.VISIBLE
            tv_title.text = info.bannerName
            tv_popu_name.text = info.wdCoupon?.couponName
            tv_get_coupon.text = "立即领取"
            tv_get_coupon.visibility = View.VISIBLE
            home_coupon_tv_money.text =
                StringUtil.formatDouble(info.wdCoupon!!.discountAmount)
            //优惠券类型（1满减，2折扣）
            when (info.wdCoupon?.type) {
                1 -> {
                    val useLimit =
                        "满" + info.wdCoupon?.useLimit + "减" + StringUtil.formatDouble(info.wdCoupon!!.discountAmount)
                    (  info.wdCoupon?.discountAmount?.let { StringUtil.formatDouble(it) }).also {
                        tv_popu_money.text = it
                    }

                }
                2 -> {
                    tv_popu_money.text = (info.wdCoupon?.discountAmount).toString() + "折"
                }
            }
        }

    }

    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener): HomeCouponDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String)
    }
}