package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.GsonUtils
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.QuestionPaperCardAdapter

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 答题卡
 */
class PaperScantronCardDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var rlvScantron: RecyclerView? = null
    private var isSeeAll=true
    private var loadFrom=0 //0 默认正常渠道进入   1，为精品题库=章节类型-举一反三数据

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_scantron_layout, null)
        val height = MobileUtil.getScreenHeight(mContext) * 4 / 5
        setHeight(height) //设置Dialog的高度
        val rtv_children_no_answer = rootView.findViewById<RTextView>(R.id.rtv_children_no_answer)
        if(loadFrom==1){
            rtv_children_no_answer.visibility = View.VISIBLE
        }else{
            rtv_children_no_answer.visibility = View.GONE
        }

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        rlvScantron = rootView.findViewById(R.id.rlv_dialog_scantron)

        ivClose.setOnClickListener { mDialog.dismiss() }

        initRecycleView()

        return rootView
    }

    private fun initRecycleView() {
        rlvScantron?.setLayoutManager(GridLayoutManager(mContext, 6))
        var mData = arrayListOf<QuestionResultEntity>()
        if(isSeeAll){
            mData = BaseCode.getQuestionPaperCardData2()
        }else{
            mData = BaseCode.getQuestionPaperErrorCardData2()
        }
        val mySection: QuestionResultEntity = mData.get(1)
        if (!mySection.isHeader) {
            val question: QuestionPaperDbEntity =
                mySection.getObject() as QuestionPaperDbEntity
            Log.v("yxy", "==card 11111adapter==" + question.wdQuestionChapterPractice)
        }
        val adapter =
            QuestionPaperCardAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val question: QuestionPaperDbEntity =
                    mySection.getObject() as QuestionPaperDbEntity
                Log.v("yxy", "==card adapter==" + GsonUtils.toJson(question.wdQuestionChapterPractice))
                onSubmitClick!!.onSubmitClick(question.position)
                mDialog.dismiss()
            }
        })

        rlvScantron?.adapter = adapter
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): PaperScantronCardDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null

    fun setResource(isseeAll:Boolean,loadFrom:Int): PaperScantronCardDialog {
        this.isSeeAll=isseeAll
        this.loadFrom=loadFrom
        return this
    }
    interface OnSubmitClickListener {
        fun onSubmitClick(content: Int)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            isSeeAll:Boolean,
            loadFrom:Int,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return PaperScantronCardDialog(context)
                .setResource(isSeeAll,loadFrom)
                .setOnSubmitClick(listener).build()
        }

    }

}