package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.QuestionPaperResultAdapter

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 答题卡
 */
class PaperScantronDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var rlvScantron: RecyclerView? = null

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_scantron_layout, null)
        val height = MobileUtil.getScreenHeight(mContext) * 4 / 5
        setHeight(height) //设置Dialog的高度

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        rlvScantron = rootView.findViewById(R.id.rlv_dialog_scantron)

        ivClose.setOnClickListener { mDialog.dismiss() }

        initRecycleView()

        return rootView
    }

    private fun initRecycleView() {
        rlvScantron?.setLayoutManager(GridLayoutManager(mContext, 6))
        val mData = BaseCode.getQuestionPaperCardData2()
        val adapter =
            QuestionPaperResultAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val question: QuestionPaperDbEntity =
                    mySection.getObject() as QuestionPaperDbEntity

                onSubmitClick!!.onSubmitClick(question.position)
                mDialog.dismiss()
            }
        })

        rlvScantron?.adapter = adapter
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): PaperScantronDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    interface OnSubmitClickListener {
        fun onSubmitClick(content: Int)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return PaperScantronDialog(context)
                .setOnSubmitClick(listener).build()
        }

    }

}