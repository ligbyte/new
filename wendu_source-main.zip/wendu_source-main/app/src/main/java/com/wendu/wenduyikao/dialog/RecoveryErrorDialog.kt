package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import com.blankj.utilcode.util.ToastUtils
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.TagAdapter
import com.wendu.wenduyikao.widget.flowlayout.FlowTagLayout

import com.wendu.wenduyikao.widget.flowlayout.OnTagSelectListener
import java.lang.StringBuilder


/**
 * @Author     : jeek
 * @Time       : 18/04/2023 14:29
 * @Description: 我要纠错
 */
class RecoveryErrorDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var flow_layout_choose: FlowTagLayout? = null
    private var isSeeAll = true
    private var tags = ""
    private var loadFrom = 0 //0 默认正常渠道进入   1，为精品题库=章节类型-举一反三数据

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_recovery_error, null)

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        flow_layout_choose = rootView.findViewById(R.id.flow_layout_choose)

        ivClose.setOnClickListener { mDialog.dismiss() }
        val et_content:EditText  =  rootView.findViewById(R.id.et_content)
        val tv_submit:RTextView  =  rootView.findViewById(R.id.tv_submit)
        val tv_count:RTextView  =  rootView.findViewById(R.id.tv_count)

        et_content.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {

            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                tv_count.setText(s.toString().length.toString() + "/200")
            }
        })
        tv_submit.setOnClickListener {
            onSubmitClick?.onSubmitClick(tags,et_content.text.toString().trim())
        }
        initFlowLayout()

        return rootView
    }

    private fun initFlowLayout() {
        var mData = arrayListOf<String>()

        val adapter = TagAdapter<String>(mContext)
        mData.add("题干有误")
        mData.add("选项有误")
        mData.add("考题陈旧")
        mData.add("答案与解析不符")
        flow_layout_choose?.setTagCheckedMode(FlowTagLayout.FLOW_TAG_CHECKED_SINGLE)
        flow_layout_choose?.setAdapter(adapter)
        adapter.setSelected(-1)
        adapter.addData(mData)
        flow_layout_choose?.setOnTagSelectListener(OnTagSelectListener { parent, positon, selectedList ->
            var tag = (positon + 11);
            if (tag == 13){
                tags = 14.toString()
            }else if(tag == 14){
                tags = 13.toString()
            }else{
                tags = tag.toString()
            }


        })


    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): RecoveryErrorDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null

    fun setResource(isseeAll: Boolean, loadFrom: Int): RecoveryErrorDialog {
        this.isSeeAll = isseeAll
        this.loadFrom = loadFrom
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(tags:String,content: String)

    }

    companion object {

        fun newBuilder(
            context: Activity?,
            isSeeAll: Boolean,
            loadFrom: Int,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return RecoveryErrorDialog(context)
                .setResource(isSeeAll, loadFrom)
                .setOnSubmitClick(listener).build()
        }

    }

}