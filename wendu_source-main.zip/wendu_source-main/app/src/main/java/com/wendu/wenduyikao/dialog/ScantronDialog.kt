package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.QuestionCardAnswerDbAdapter

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 答题卡
 */
class ScantronDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    private var rlvScantron: RecyclerView? = null
    private var answerType = "chapter"
    private var isSeeAll = true

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_scantron_layout, null)
        val height = MobileUtil.getScreenHeight(mContext) * 6 / 7
        setHeight(height) //设置Dialog的高度
        val rtv_children_no_answer = rootView.findViewById<RTextView>(R.id.rtv_children_no_answer)
        rtv_children_no_answer.visibility = View.GONE
        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        rlvScantron = rootView.findViewById(R.id.rlv_dialog_scantron)

        ivClose.setOnClickListener { mDialog.dismiss() }
        initRecycleView()

        return rootView
    }

    private fun initRecycleView() {
        rlvScantron?.layoutManager = GridLayoutManager(mContext, 6)
        var mData = arrayListOf<QuestionResultEntity>()

        if (isSeeAll) {
            mData = BaseCode.getQuestionCardData2()
        } else {
            mData = BaseCode.getQuestionErrorCardData2()
        }

        val adapter =
            QuestionCardAnswerDbAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val question: QuestionDbEntity = mySection.getObject() as QuestionDbEntity
                onSubmitClick!!.onSubmitClick(question.position)
                mDialog.dismiss()
            }
        })

        rlvScantron?.adapter = adapter
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): ScantronDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    fun setResource(type: String, isseeAll: Boolean): ScantronDialog {
        this.answerType = type
        this.isSeeAll = isseeAll
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: Int)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            answerType: String,
            isSeeAll: Boolean,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return ScantronDialog(context)
                .setResource(answerType, isSeeAll)
                .setOnSubmitClick(listener).build()
        }

    }

}