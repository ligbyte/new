package com.wendu.wenduyikao.dialog


import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.BookInfoEntity
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 选择图书数量
 */
class SelectBookCountDialog(context: Context?) :
    BaseBottomSheetBuilder(context) {

    private var bookResult: BookInfoEntity? = null
    private var book_dialog_title: TextView? = null
    private var book_dialog_price: TextView? = null
    private var book_dialog_num: TextView? = null
    private var book_dialog_minus: TextView? = null

    private var book_dialog_add: TextView? = null
    private var book_dialog_img: ImageView? = null

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_select_book_layout, null)
//        val height = MobileUtil.getScreenHeight(mContext)*2/ 3
//        setHeight(height) //设置Dialog的高度

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        book_dialog_title = rootView.findViewById(R.id.book_detail_item_name)
        book_dialog_price = rootView.findViewById(R.id.book_detail_item_price)
        book_dialog_num = rootView.findViewById(R.id.goods_num_tv_num)
        book_dialog_minus = rootView.findViewById(R.id.goods_num_minus)
        book_dialog_add = rootView.findViewById(R.id.goods_num_add)
        book_dialog_img = rootView.findViewById(R.id.information_item_pic)
        val tvConfirm: RTextView = rootView.findViewById(R.id.tv_confirm)

        ivClose.setOnClickListener { mDialog.dismiss() }
        book_dialog_title?.setText(bookResult?.bookName)
        book_dialog_price?.setText(bookResult?.officalPrice?.let { StringUtil.formatDoublePrice(it) })
        val pathList = StringUtil.convertStrToList(bookResult?.images)
        Glide.with(mContext).load(pathList[0])
            .placeholder(R.drawable.ic_default_pic1).into(book_dialog_img!!)
        tvConfirm.setOnClickListener {
            val name = bookResult?.bookName.toString()
            val imgs = bookResult?.images.toString()
            val price = bookResult?.officalPrice
            val id = bookResult?.id.toString()
            val num = book_dialog_num!!.text.toString().toInt()
            val info = ShopCarInfoEntity(num, id, name, price!!, imgs, null, false)

            onSubmitClick!!.onSubmitClick(info)
            mDialog.dismiss()
        }

        book_dialog_minus!!.setOnClickListener {
            var num = book_dialog_num!!.text.toString().toInt()
            if (num > 1) {
                num--
            }
            book_dialog_num!!.text = num.toString()
        }
        book_dialog_add!!.setOnClickListener {
            var num = book_dialog_num!!.text.toString().toInt()
            num++
            book_dialog_num!!.text = num.toString()
        }
        return rootView
    }

    fun setResource(bookInfo: BookInfoEntity): SelectBookCountDialog {
        this.bookResult = bookInfo
        return this
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): SelectBookCountDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    interface OnSubmitClickListener {
        fun onSubmitClick(shopCarInfo: ShopCarInfoEntity)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            bookInfo: BookInfoEntity,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return SelectBookCountDialog(context).setResource(bookInfo)
                .setOnSubmitClick(listener).build()
        }

    }

}