package com.wendu.wenduyikao.dialog


import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.ExamInfoEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.SelectExamAdapter

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 选择科目
 */
class SelectExamDialog(context: Context?) :
    BaseBottomSheetBuilder(context) {

    private var rlv_dialog_exam: RecyclerView? = null
    private var examResult: ArrayList<ExamInfoEntity> = arrayListOf()
    private var exam_dialog_time: TextView? = null
    private var exam_dialog_standard: TextView? = null
    private var exam_dialog_type: TextView? = null
    private var examId = ""
    private var userTime=0

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_select_exam_layout, null)
//        val height = MobileUtil.getScreenHeight(mContext)*2/ 3
//        setHeight(height) //设置Dialog的高度

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        rlv_dialog_exam = rootView.findViewById(R.id.rlv_dialog_exam)
        exam_dialog_standard = rootView.findViewById(R.id.exam_dialog_standard)
        exam_dialog_time = rootView.findViewById(R.id.exam_dialog_time)
        exam_dialog_type = rootView.findViewById(R.id.exam_dialog_type)
        val tvConfirm: RTextView = rootView.findViewById(R.id.tv_confirm)

        ivClose.setOnClickListener { mDialog.dismiss() }
        val info = examResult[0]
        examId = info.id
        exam_dialog_time?.text = info.timeExamination.toString() + "分钟"
        var questionType = ""
        for (exam in info.wdQuestionExaminationTypeList) {
            questionType += StringUtil.getSubjectTypeByType(exam.type.toInt()) + "   ${exam.numberSubject}" + "  "
        }
        userTime=info.timeExamination
        exam_dialog_type?.text = questionType
        exam_dialog_standard?.text = "满分${info.totalScore}    ${info.score} 及格"

        initRecycleView()

        tvConfirm.setOnClickListener {
            Log.v("yxy","=====timeExamination===="+userTime)
            onSubmitClick!!.onSubmitClick(examId, userTime)
            mDialog.dismiss()
        }
        return rootView
    }

    fun setResource(examList: ArrayList<ExamInfoEntity>): SelectExamDialog {
        this.examResult = examList
        return this
    }

    private fun initRecycleView() {
        rlv_dialog_exam?.layoutManager = GridLayoutManager(mContext, 3)

        val examAdapter = SelectExamAdapter(examResult)
        examAdapter.setPosition(0)
        examAdapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val info: ExamInfoEntity = adapter.getItem(position) as ExamInfoEntity
            examAdapter.setPosition(position)
            examAdapter.notifyDataSetChanged()
            (info.timeExamination.toString() + "分钟").also { exam_dialog_time?.text = it }
            var questionType = ""
            for (exam in info.wdQuestionExaminationTypeList) {
                questionType += StringUtil.getSubjectTypeByType(exam.type.toInt()) + " ${exam.numberSubject}  "
            }
            userTime=info.timeExamination
            exam_dialog_type?.text = questionType
            exam_dialog_standard?.text = "满分${info.totalScore}    ${info.score} 及格"
            examId = info.id
        })

        rlv_dialog_exam?.adapter = examAdapter
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): SelectExamDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    interface OnSubmitClickListener {
        fun onSubmitClick(content: String, userTime: Int)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            examList: ArrayList<ExamInfoEntity>,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return SelectExamDialog(context).setResource(examList)
                .setOnSubmitClick(listener).build()
        }

    }

}