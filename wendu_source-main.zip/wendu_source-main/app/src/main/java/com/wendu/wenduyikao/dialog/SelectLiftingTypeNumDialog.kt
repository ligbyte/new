package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.ConvertUtils
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.CollectNumEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.SelectLiftingTypeNumAdapter

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/1/21 5:29 PM
 * @Description: 选择不同题型的题目数量
 */
class SelectLiftingTypeNumDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var rlvLiftingType: RecyclerView? = null
    private var collectTypeList: ArrayList<CollectNumEntity> = arrayListOf()
    private val numAdapter: SelectLiftingTypeNumAdapter by lazy {
        SelectLiftingTypeNumAdapter(
            arrayListOf()
        )
    }

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext)
                .inflate(R.layout.dialog_select_liftingtype_num_layout, null)
        val height = MobileUtil.getScreenHeight(mContext) * 2 / 3
        setHeight(height) //设置Dialog的高度

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        rlvLiftingType = rootView.findViewById(R.id.rlv_dialog_lifting_type)
        val tvConfirm: RTextView = rootView.findViewById(R.id.tv_confirm)
        initRecycleView()
        ivClose.setOnClickListener { mDialog.dismiss() }
        tvConfirm.setOnClickListener {
            val jsonArray = JsonArray()
            for (info in numAdapter.data) {
                val json = JsonObject()
                json.addProperty("dictId", info.liftingType)
                json.addProperty("num", info.number)
                json.addProperty("majorId", CacheUtil.getQuestionMajorId())
                if(info.topicCategory>0){
                    json.addProperty("topicCategory", info.topicCategory)
                }
                jsonArray.add(json)
            }
            onSubmitClick?.onSubmitClick(jsonArray)
            mDialog.dismiss()
        }
        return rootView
    }

    private fun initRecycleView() {
        rlvLiftingType?.init(LinearLayoutManager(mContext), numAdapter).let {
            it?.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        numAdapter.data = collectTypeList
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener): SelectLiftingTypeNumDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null
    fun setResource(collectTypeList: ArrayList<CollectNumEntity>): SelectLiftingTypeNumDialog {
        this.collectTypeList = collectTypeList
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: JsonArray)
    }

    companion object {
        fun newBuilder(
            context: Activity?,
            collectTypeList: ArrayList<CollectNumEntity>,
            listener: OnSubmitClickListener
        ): BaseBottomSheetDialog {
            return SelectLiftingTypeNumDialog(context)
                .setResource(collectTypeList)
                .setOnSubmitClick(listener).build()
        }

    }

}