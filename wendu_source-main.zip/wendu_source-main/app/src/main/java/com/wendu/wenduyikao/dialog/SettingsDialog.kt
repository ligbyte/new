package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.blankj.utilcode.util.SPUtils
import com.blankj.utilcode.util.ToastUtils
import com.jaygoo.widget.OnRangeChangedListener
import com.jaygoo.widget.RangeSeekBar
import com.kyle.radiogrouplib.NestedRadioGroup
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.TagAdapter
import com.wendu.wenduyikao.widget.flowlayout.FlowTagLayout

import com.wendu.wenduyikao.widget.flowlayout.OnTagSelectListener
import com.wendu.wenduyikao.widget.rangebar.RangeBar
import java.lang.StringBuilder
import com.wendu.wenduyikao.ui.activity.MainActivity

import com.wendu.wenduyikao.widget.rangebar.RangeBarListener

import com.wendu.wenduyikao.question.adapter.RangeAdapter
import com.kyle.radiogrouplib.BaseRadioLayout

import com.kyle.radiogrouplib.NestedRadioLayout
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.data.Constants


/**
 * @Author     : jeek
 * @Time       : 18/04/2023 14:29
 * @Description: 我要纠错
 */
class SettingsDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var radioGroup: NestedRadioGroup? = null
    var radio_day: NestedRadioLayout? = null
    var radio_moon: NestedRadioLayout? = null
    var seekbar_font:RangeSeekBar? = null

    var main_bg: LinearLayout? = null
    var tv_title:TextView? = null
    var iv_close:ImageView? = null
    var line:View? = null
    var tv_theme:TextView? = null
    var tv_theme_summary:TextView? = null
    var tv_theme_day:TextView? = null
    var tv_theme_night:TextView? = null
    var tv_font_size:TextView? = null
    var tv_font_size_summary:TextView? = null

    var tv_aa_left:TextView? = null
    var tv_aa_right:TextView? = null
    var tv_size_small:TextView? = null
    var tv_size_default:TextView? = null
    var tv_size_big:TextView? = null

    private var isSeeAll = true
    private var tags = ""
    private var loadFrom = 0 //0 默认正常渠道进入   1，为精品题库=章节类型-举一反三数据
    private var onSubmitClick: OnSubmitClickListener? = null
    var questionTextSize = 15f
    var currentMode = 0
    var progress = 0f

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_settings, null)

        val ivClose: ImageView = rootView.findViewById(R.id.iv_close)
        radioGroup = rootView.findViewById(R.id.radioGroup)
        radio_day = rootView.findViewById(R.id.radio_day)
        radio_moon = rootView.findViewById(R.id.radio_moon)

        main_bg = rootView.findViewById(R.id.main_bg)
        tv_title = rootView.findViewById(R.id.tv_title)
        iv_close = rootView.findViewById(R.id.iv_close)
        line = rootView.findViewById(R.id.line)
        tv_theme = rootView.findViewById(R.id.tv_theme)
        tv_theme_summary = rootView.findViewById(R.id.tv_theme_summary)
        tv_theme_day = rootView.findViewById(R.id.tv_theme_day)
        tv_theme_night = rootView.findViewById(R.id.tv_theme_night)
        tv_font_size = rootView.findViewById(R.id.tv_font_size)
        tv_font_size_summary = rootView.findViewById(R.id.tv_font_size_summary)
        tv_aa_left = rootView.findViewById(R.id.tv_aa_left)
        tv_aa_right = rootView.findViewById(R.id.tv_aa_right)
        tv_size_small = rootView.findViewById(R.id.tv_size_small)
        tv_size_default = rootView.findViewById(R.id.tv_size_default)
        tv_size_big = rootView.findViewById(R.id.tv_size_big)

        ivClose.setOnClickListener { mDialog.dismiss() }
        val tv_submit:RTextView  =  rootView.findViewById(R.id.tv_submit)

        tv_submit.setOnClickListener {
            onSubmitClick?.onSubmitClick(currentMode,seekbar_font?.leftSeekBar?.progress)
            mDialog.dismiss()
        }

        seekbar_font = rootView.findViewById(R.id.seekbar_font)
        seekbar_font?.setProgress(SPUtils.getInstance().getFloat("fontSize",50f))
        seekbar_font?.setOnRangeChangedListener(object : OnRangeChangedListener {
            override fun onRangeChanged(rangeSeekBar: RangeSeekBar, leftValue: Float, rightValue: Float, isFromUser: Boolean) {
                onSubmitClick?.onRangeChanged(leftValue)
            }

            override fun onStartTrackingTouch(view: RangeSeekBar?, isLeft: Boolean) {

            }

            override fun onStopTrackingTouch(view: RangeSeekBar?, isLeft: Boolean) {

            }

        })
        initRadioGroup()

        return rootView
    }

    private fun initRadioGroup() {
        if (MultiTheme.getAppTheme() == 1) {
            radio_moon?.isChecked = true
            radio_moon?.background = mContext.resources.getDrawable(R.drawable.shape_theme_selecter)
        }else{
            radio_day?.isChecked = true
        }
        radioGroup?.setOnCheckedChangeListener(NestedRadioGroup.OnCheckedChangeListener { baseRadioLayout, checked ->
            progress = seekbar_font?.leftSeekBar?.progress!!
            if (checked === R.id.radio_day) {
                    radio_moon?.background = mContext.resources.getDrawable(R.drawable.shape_theme_unselect)
                    currentMode = 0
                    onSubmitClick?.onModeSelect(currentMode,progress)
                    setDarkTheme(false)
                    seekbar_font?.setProgress(progress)
                } else if (checked === R.id.radio_moon) {
                    radio_moon?.background = mContext.resources.getDrawable(R.drawable.shape_theme_selecter)
                    currentMode = 1
                    onSubmitClick?.onModeSelect(currentMode,progress)
                    setDarkTheme(true)
                    seekbar_font?.setProgress(progress)
                }
        })




    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): SettingsDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }


    fun setResource(isseeAll: Boolean, loadFrom: Int): SettingsDialog {
        this.isSeeAll = isseeAll
        this.loadFrom = loadFrom
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(mode:Int,fontSize: Float?)
        fun onModeSelect(mode: Int,value: Float?)
        fun onRangeChanged(value: Float);
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            isSeeAll: Boolean,
            loadFrom: Int,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return SettingsDialog(context)
                .setResource(isSeeAll, loadFrom)
                .setOnSubmitClick(listener).build()
        }

    }

    fun setDarkTheme(isDark:Boolean){

        if (isDark){
            radioGroup?.setBackgroundColor(mContext.resources.getColor(R.color.white_dark))
            radio_day?.background = mContext.resources.getDrawable(R.drawable.selector_theme_bg_dark)
            main_bg?.background = mContext.resources.getDrawable(R.drawable.bg_rectangle_radius_20_20_0_0_white_dark)
            tv_title?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            iv_close?.setColorFilter(mContext.resources.getColor(R.color.iv_close_color_dark))
            line?.background = mContext.resources.getDrawable(R.color.divider_dark)
            tv_theme?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            tv_theme_summary?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            tv_theme_day?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            tv_theme_night?.setTextColor(mContext.resources.getColor(R.color.white))
            tv_font_size?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            tv_font_size_summary?.setTextColor(mContext.resources.getColor(R.color.text_color_dark))
            tv_aa_left?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color_dark))
            tv_aa_right?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color_dark))
            tv_size_small?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color_dark))
            tv_size_default?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color_dark))
            tv_size_big?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color_dark))
            mDialog.onRestoreInstanceState(mDialog.onSaveInstanceState())
            seekbar_font?.progressDrawableId = R.drawable.progress_dark
            seekbar_font?.progressDefaultDrawableId  = R.drawable.progress_dark

        }else{
            radioGroup?.setBackgroundColor(mContext.resources.getColor(R.color.white))
            radio_moon?.background = mContext.resources.getDrawable(R.drawable.selector_theme_bg)
            main_bg?.background = mContext.resources.getDrawable(R.drawable.bg_rectangle_radius_20_20_0_0_white)
            tv_title?.setTextColor(mContext.resources.getColor(R.color.text_color))
            iv_close?.setColorFilter(mContext.resources.getColor(R.color.iv_close_color))
            line?.background = mContext.resources.getDrawable(R.color.divider)
            tv_theme?.setTextColor(mContext.resources.getColor(R.color.text_color))
            tv_theme_summary?.setTextColor(mContext.resources.getColor(R.color.textHint))
            tv_theme_day?.setTextColor(mContext.resources.getColor(R.color.white))
            tv_theme_night?.setTextColor(mContext.resources.getColor(R.color.text_color))
            tv_font_size?.setTextColor(mContext.resources.getColor(R.color.text_color))
            tv_font_size_summary?.setTextColor(mContext.resources.getColor(R.color.textHint))
            tv_aa_left?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color))
            tv_aa_right?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color))
            tv_size_small?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color))
            tv_size_default?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color))
            tv_size_big?.setTextColor(mContext.resources.getColor(R.color.dialog_text_color))
            mDialog.onRestoreInstanceState(mDialog.onSaveInstanceState())
            seekbar_font?.progressDrawableId = R.drawable.progress
            seekbar_font?.progressDefaultDrawableId  = R.drawable.progress
        }
    }

}