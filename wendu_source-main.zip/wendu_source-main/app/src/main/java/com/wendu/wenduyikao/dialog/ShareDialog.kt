package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.view.LayoutInflater
import android.view.View
import com.blankj.utilcode.util.ToastUtils
import com.ruffian.library.RTextView
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage
import com.tencent.mm.opensdk.modelmsg.WXMiniProgramObject
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.ShareEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLConnection


/**
 * Created by yxm on 2021/8/9.
 * 分享
 */
class ShareDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var shareEntity:ShareEntity? = null
    var img:String? = null

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.layout_share_img_dialog, null)
        val height = mContext.resources.getDimension(R.dimen.dp_340).toInt()
        setHeight(height) //设置Dialog的高度

        val rvCancel: RTextView = rootView.findViewById(R.id.rv_cancel)
        val rvWeixin: RTextView = rootView.findViewById(R.id.rv_weixin)
        val rvMoments: RTextView = rootView.findViewById(R.id.rv_moments)

        rvWeixin.setOnClickListener {
            val api = WXAPIFactory.createWXAPI(mContext, Constants.WX_APP_ID)
//            val req = WXLaunchMiniProgram.Req()
//            req.userName = "gh_8b27cea17f73" // 填小程序原始id
//            req.path = path //拉起小程序页面的可带参路径，不填默认拉起小程序首页
//            req.miniprogramType = WXLaunchMiniProgram.Req.MINIPTOGRAM_TYPE_RELEASE // 可选打开 开发版，体验版和正式版
//            api.sendReq(req)


            val miniProgramObj = WXMiniProgramObject()
            miniProgramObj.webpageUrl = "http://www.qq.com" // 兼容低版本的网页链接

            if (BuildConfig.FLAVOR.contains("product")) {
                miniProgramObj.miniprogramType =
                    WXMiniProgramObject.MINIPTOGRAM_TYPE_RELEASE // 正式版:0，测试版:1，体验版:2

            }else{
                miniProgramObj.miniprogramType =
                    WXMiniProgramObject.MINIPROGRAM_TYPE_PREVIEW // 正式版:0，测试版:1，体验版:2

            }

//            miniProgramObj.miniprogramType =
//                WXMiniProgramObject.MINIPROGRAM_TYPE_PREVIEW // 正式版:0，测试版:1，体验版修改:2

            miniProgramObj.userName = "gh_8b27cea17f73" // 小程序原始 id
            miniProgramObj.path = shareEntity!!.path //小程序页面路径；对于小游戏，可以只传入 query 部分，来实现传参效果，如：传入 "?foo=bar"

            val msg = WXMediaMessage(miniProgramObj)
            msg.title = shareEntity!!.title // 小程序消息title
            msg.description = shareEntity!!.decs // 小程序消息desc
//            msg.thumbData = shareEntity!!.imageUrl // 小程序消息封面图片，小于128k
//            val bitmap = BitmapFactory.decodeResource(mContext.resources,R.mipmap.ic_login_logo)
            Thread {
                var bitmap = getBitmap(shareEntity!!.imageUrl)
                if(bitmap == null){
                    bitmap = BitmapFactory.decodeResource(mContext.resources,R.mipmap.ic_login_logo)
                }
                if (isOverSize(bitmap!!, 128)) {
                    val ysBitmap = imageZoom(bitmap)
                    msg.setThumbImage(ysBitmap)// 小程序消息封面图片，小于128k
                } else {
                    msg.setThumbImage(bitmap) // 小程序消息封面图片，小于128k
                }
                val req = SendMessageToWX.Req()
                req.transaction = "miniProgram"
                req.message = msg
                req.scene = SendMessageToWX.Req.WXSceneSession // 目前只支持会话

                api.sendReq(req)
                mDialog.dismiss()
            }.start()

        }

        rvMoments.setOnClickListener {
            ShareCourseImgDialog.newBuilder(mActivity,img!!,null).show()
            mDialog.dismiss()
        }

        rvCancel.setOnClickListener {
            mDialog.dismiss()
        }

        return rootView
    }



    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): ShareDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null
    fun setResource(shareEntity: ShareEntity?): ShareDialog {
        this.shareEntity = shareEntity
        return this
    }
    fun setImg(img: String?): ShareDialog {
        this.img = img
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String?)
    }

    companion object {

        var mActivity:Activity? = null
        fun newBuilder(
            context: Activity?,
            path: ShareEntity?,
            img:String,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {
            mActivity = context
            return ShareDialog(context).setResource(path).setImg(img)
                .setOnSubmitClick(listener).build()
        }

    }

    /**
     * 分享一个网页
     *
     * @param httpUrl     连接
     * @param type        分享类型，朋友圈、收藏、好友
     * @param icon        连接前显示的图标
     * @param title       别人看到的标题
     * @param description 别人看到的描述
     */
//    public void shareWebPage(String httpUrl, ShareType type, Bitmap icon, String title, String description) {
//        WXWebpageObject webpage = new WXWebpageObject();
//        webpage.webpageUrl = httpUrl;
//        WXMediaMessage msg = new WXMediaMessage(webpage);
//        msg.title = title;
//        msg.description = description;
//        msg.thumbData = bmpToByteArray(icon);
//
//        SendMessageToWX.Req req = new SendMessageToWX.Req();
//        req.transaction = buildTransaction("webpage");
//        req.message = msg;
//        req.scene = ShareType.getWechatType(type);
//        sendReq(req);
//    }

    //url转bitmap
    open fun getBitmap(urlpath: String?): Bitmap? {
        var bm: Bitmap? = null
        try {
            val iconUrl = URL(urlpath)
            val conn: URLConnection = iconUrl.openConnection()
            val http: HttpURLConnection = conn as HttpURLConnection
            val length: Int = http.contentLength
            conn.connect()
            // 获得图像的字符流
            val `is`: InputStream = conn.getInputStream()
            val bis = BufferedInputStream(`is`, length)
            bm = BitmapFactory.decodeStream(bis)
            bis.close()
            `is`.close() // 关闭流
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return bm
    }

    fun isOverSize(bitmap: Bitmap, maxSize: Int): Boolean {
        // 将bitmap放至数组中，意在bitmap的大小（与实际读取的原文件要大）
        val baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos)
        val b: ByteArray = baos.toByteArray()
        // 将字节换成KB
        val mid = (b.size / 1024).toDouble()
        // 判断bitmap占用空间是否大于允许最大空间 如果大于则压缩 小于则不压缩
        return mid > maxSize
    }

    /**
     * Bitmap转换成byte[]并且进行压缩,压缩到不大于 128 maxkb
     *
     * @param bitmap
     * @param maxKb
     * @return
     */
    fun imageZoom(bitMap: Bitmap): Bitmap? {
        //图片允许最大空间 单位：KB
        val maxSize = 128.00
        //将bitmap放至数组中，意在bitmap的大小（与实际读取的原文件要大）
        val baos = ByteArrayOutputStream()
        bitMap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val b = baos.toByteArray()
        //将字节换成KB
        val mid = (b.size / 1024).toDouble()
        //获取bitmap大小 是允许最大大小的多少倍
        val i = mid / maxSize
        //开始压缩 此处用到平方根 将宽带和高度压缩掉对应的平方根倍 （1.保持刻度和高度和原bitmap比率一致，压缩后也达到了最大大小占用空间的大小）
        return zoomImage(bitMap, bitMap.width / Math.sqrt(i), bitMap.height / Math.sqrt(i) * 0.8)
    }

    fun zoomImage(
        bgimage: Bitmap, newWidth: Double,
        newHeight: Double
    ): Bitmap? {
        // 获取这个图片的宽和高
        val width = bgimage.width.toFloat()
        val height = bgimage.height.toFloat()
        // 创建操作图片用的matrix对象
        val matrix = Matrix()
        // 计算宽高缩放率
        val scaleWidth = newWidth.toFloat() / width
        val scaleHeight = newHeight.toFloat() / height
        // 缩放图片动作
        matrix.postScale(scaleWidth, scaleHeight)
        return Bitmap.createBitmap(
            bgimage, 0, 0,
            width.toInt(),
            height.toInt(), matrix, true
        )
    }


}