package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/12/11 12:50 下午
 * @Description: 分享预览
 */
class ShareImgPreviewDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    //    private var shareImg: ImageView? = null
    private var url = ""

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.dialog_share_preview_layout, null)
//        val height = MobileUtil.getScreenHeight(mContext) * 6 / 7
//        setHeight(height) //设置Dialog的高度

        val ivClose: TextView = rootView.findViewById(R.id.tv_share_cancel)
        val tvShare: RTextView = rootView.findViewById(R.id.tv_share_preview)
        val shareImg: ImageView = rootView.findViewById(R.id.share_dialog_pic)

        ivClose.setOnClickListener { mDialog.dismiss() }
        tvShare.setOnClickListener {
            onSubmitClick!!.onSubmitClick()
            mDialog.dismiss()
        }
//        url="https://wenzdu.changyangdt.com/api/share/wdWeixinShare/getShareImg?id=1466283301757751297&pageSource=classesDetail"
        Log.v("yxy","url==="+url)
        val options = RequestOptions()
        options.skipMemoryCache(true) //跳过内存缓存
        options.diskCacheStrategy(DiskCacheStrategy.NONE) //不缓冲disk硬盘中

        Glide.with(mContext).load(url).apply(options).placeholder(R.drawable.ic_default_pic2).into(shareImg)
        return rootView
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): ShareImgPreviewDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null


    fun setUrl(url: String): ShareImgPreviewDialog {
        this.url = url
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick()
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            url: String,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return ShareImgPreviewDialog(context)
                .setUrl(url)
                .setOnSubmitClick(listener).build()
        }

    }

}