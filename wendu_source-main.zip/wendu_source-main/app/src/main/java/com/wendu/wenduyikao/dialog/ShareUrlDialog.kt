package com.wendu.wenduyikao.dialog

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import com.ruffian.library.RTextView
import com.tencent.mm.opensdk.modelmsg.SendMessageToWX
import com.tencent.mm.opensdk.modelmsg.WXMediaMessage
import com.tencent.mm.opensdk.modelmsg.WXWebpageObject
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.ShareEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetBuilder
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import java.net.URL


/**
 * Created by yxm on 2021/8/9.
 * 分享
 */
class ShareUrlDialog(context: Context?) : BaseBottomSheetBuilder(context) {

    var shareEntity: ShareEntity? = null

    @SuppressLint("SetTextI18n")
    override fun buildView(): View {
        val rootView: View =
            LayoutInflater.from(mContext).inflate(R.layout.layout_share_img_dialog, null)
        val height = mContext.resources.getDimension(R.dimen.dp_340).toInt()
        setHeight(height) //设置Dialog的高度

        val rvCancel: RTextView = rootView.findViewById(R.id.rv_cancel)
        val rvWeixin: RTextView = rootView.findViewById(R.id.rv_weixin)
        val rvMoments: RTextView = rootView.findViewById(R.id.rv_moments)
        rvWeixin.setOnClickListener {
            val api = WXAPIFactory.createWXAPI(mContext, Constants.WX_APP_ID)

            val webpage = WXWebpageObject()
            val url = shareEntity!!.path
            webpage.webpageUrl = url;
            val msg = WXMediaMessage(webpage)
            msg.title = shareEntity?.title
            msg.description=shareEntity?.decs
            val imgUrl = shareEntity?.imageUrl ?: ""

            Log.v("yxy", "url==" + shareEntity!!.imageUrl+"==="+shareEntity?.path)
            Thread {
                if (StringUtil.isNotBlank(imgUrl)) {
                    Log.v("yxy","imgurl---"+imgUrl)
                    var bitmap = BitmapFactory.decodeStream(URL(imgUrl).openStream())
                    if (bitmap == null) {
                        bitmap =
                            BitmapFactory.decodeResource(mContext.resources, R.mipmap.ic_login_logo)
                    }
                    msg.setThumbImage(bitmap)
                } else {
                    val bitmap =
                        BitmapFactory.decodeResource(mContext.resources, R.mipmap.ic_login_logo)
                    msg.setThumbImage(bitmap)
                }
                val req = SendMessageToWX.Req()
                req.transaction = "webpage"
                req.message = msg
                req.scene = SendMessageToWX.Req.WXSceneSession // 目前只支持会话

                api.sendReq(req)

            }.start()
            onSubmitClick?.onSubmitClick("")
            mDialog.dismiss()
        }
        rvMoments.setOnClickListener {
            val api = WXAPIFactory.createWXAPI(mContext, Constants.WX_APP_ID)

            val webpage = WXWebpageObject()
            val url = shareEntity!!.path
            webpage.webpageUrl = url;
            val msg = WXMediaMessage(webpage)
            msg.title = shareEntity?.title
            msg.description=shareEntity?.decs
            val imgUrl = shareEntity?.imageUrl ?: ""
            Thread {
                if (StringUtil.isNotBlank(imgUrl)) {
                    var bitmap = BitmapFactory.decodeStream(URL(imgUrl).openStream())
                    if (bitmap == null) {
                        bitmap =
                            BitmapFactory.decodeResource(mContext.resources, R.mipmap.ic_login_logo)
                    }
                    msg.setThumbImage(bitmap)
                } else {
                    val bitmap =
                        BitmapFactory.decodeResource(mContext.resources, R.mipmap.ic_login_logo)
                    msg.setThumbImage(bitmap)
                }
                Log.v("yxy", "url==" + shareEntity!!.path)
                val req = SendMessageToWX.Req()
                req.transaction = "webpage"
                req.message = msg
                req.scene = SendMessageToWX.Req.WXSceneTimeline // 目前只支持会话

                api.sendReq(req)

            }.start()
            onSubmitClick?.onSubmitClick("")
            mDialog.dismiss()
        }
        rvCancel.setOnClickListener {
            mDialog.dismiss()
        }

        return rootView
    }


    fun setOnSubmitClick(onSubmitClick: OnSubmitClickListener?): ShareUrlDialog {
        this.onSubmitClick = onSubmitClick
        return this
    }

    private var onSubmitClick: OnSubmitClickListener? = null
    fun setResource(shareEntity: ShareEntity?): ShareUrlDialog {
        this.shareEntity = shareEntity
        return this
    }

    interface OnSubmitClickListener {
        fun onSubmitClick(content: String?)
    }

    companion object {

        fun newBuilder(
            context: Activity?,
            path: ShareEntity?,
            listener: OnSubmitClickListener?
        ): BaseBottomSheetDialog {

            return ShareUrlDialog(context).setResource(path)
                .setOnSubmitClick(listener).build()
        }

    }
}