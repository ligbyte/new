package com.wendu.wenduyikao.dialog.bottom_sheet;

import android.content.Context;
import android.content.DialogInterface;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by changer on 2019/4/9.
 * desc:
 * modify:
 */
public abstract class BaseBottomSheetBuilder {

    protected Context mContext;
    protected BaseBottomSheetDialog mDialog;

    protected boolean mIsCanceledOnTouchOutside;
    protected boolean mIsCancelable;

    protected DialogInterface.OnDismissListener mOnBottomDialogDismissListener;

    protected int mHeight;



    public BaseBottomSheetBuilder(Context context) {
        this.mContext = context;
    }

    /**
     * 设置是否可以外部点击隐藏
     * @return
     */
    public BaseBottomSheetBuilder setCanceledOnTouchOutside(boolean isCanceledOnTouchOutside){
        this.mIsCanceledOnTouchOutside = isCanceledOnTouchOutside;
        return this;
    }

    /**
     * 设置是否可以取消
     * @return
     */
    public BaseBottomSheetBuilder setCancelable(boolean isCancelable){
        this.mIsCancelable = isCancelable;
        return this;
    }

    /**
     * 设置dialog高度  px
     * @return
     */
    public BaseBottomSheetBuilder setHeight(int height){
        this.mHeight = height;
        return this;
    }

    /**
     * dialog消失的监听
     * @return
     */
    public BaseBottomSheetBuilder setOnBottomDialogDismissListener(DialogInterface.OnDismissListener listener) {
        mOnBottomDialogDismissListener = listener;
        return this;
    }

    public BaseBottomSheetDialog build(){
        mDialog = new BaseBottomSheetDialog(mContext);
        View rootView = buildView();
        ViewGroup.LayoutParams layoutParams = null;
        if (mHeight <= 0){
            layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }else{
            layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mHeight);
        }
        mDialog.setContentView(rootView,  layoutParams);
        if (mOnBottomDialogDismissListener != null) {
            mDialog.setOnDismissListener(mOnBottomDialogDismissListener);
        }
        return mDialog;
    }

    public BaseBottomSheetDialog build(int style){
        mDialog = new BaseBottomSheetDialog(mContext, style);
        View rootView = buildView();
        ViewGroup.LayoutParams layoutParams = null;
        if (mHeight <= 0){
            layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }else{
            layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, mHeight);
        }
        mDialog.setContentView(rootView,  layoutParams);
        if (mOnBottomDialogDismissListener != null) {
            mDialog.setOnDismissListener(mOnBottomDialogDismissListener);
        }
        return mDialog;
    }

    protected abstract View buildView();


}
