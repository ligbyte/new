package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import androidx.activity.viewModels
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.eventbus.RefreshShopCarEvent
import com.wendu.wenduyikao.data.model.bean.BookInfoEntity
import com.wendu.wenduyikao.data.model.bean.HomeBannerEntity
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.databinding.ActivityBookDetailBinding
import com.wendu.wenduyikao.dialog.SelectBookCountDialog
import com.wendu.wenduyikao.ui.fragment.HomeBannerAdapter
import com.wendu.wenduyikao.util.GlideHelper
import com.wendu.wenduyikao.util.UserUtil
import com.wendu.wenduyikao.viewmodel.request.RequestBookViewModel
import com.zhpan.bannerview.BannerViewPager
import com.zhpan.bannerview.utils.BannerUtils
import com.zhpan.indicator.enums.IndicatorSlideMode
import com.zzhoujay.richtext.RichText
import kotlinx.android.synthetic.main.activity_book_detail.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:54 下午
 * @Description: 图书详情
 */
class BookDetailActivity : BaseActivity<RequestBookViewModel, ActivityBookDetailBinding>() {
    private val requestBookViewModel: RequestBookViewModel by viewModels()
    private var bookId = ""
    private var bookJson = ""
    lateinit var bannerViewPager: BannerViewPager<HomeBannerEntity>
    override fun layoutId() = R.layout.activity_book_detail
    private var  js = "<script type=\"text/javascript\">"+
            "var imgs = document.getElementsByTagName('img');" +  // 找到img标签
            "for(var i = 0; i<imgs.length; i++){" +  // 逐个改变
            "imgs[i].style.width = '100%';" +  // 宽度改为100%
            "imgs[i].style.height = 'auto';" +
            "}" +
            "</script>"
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, book_detail_ll_content)
        tv_toolbar_title.text = "图书详情"
        img_back.setOnClickListener { finish() }
        img_right.visibility = View.VISIBLE
        img_right.setImageResource(R.drawable.icon_shop_car)
        img_right.setOnClickListener {
            if (CacheUtil.isLogin()) {
            startActivity(Intent(this, ShopCarActivity::class.java))
        } else {
            UserUtil.goLogin(this)
        }

        }
        RichText.initCacheDir(this)
        RichText.debugMode = false
        mDatabind.click = ProxyClick()
        bookId = intent.getStringExtra("bookId").toString()
        initBanner()
//        setData()
        if (StringUtil.isNotBlank(bookId)) {
            requestBookViewModel.getBookDetailById(bookId)
        }
        initWebView()
    }

    private fun initWebView(){
        val webSettings: WebSettings = book_detail_wb_content.getSettings()
        webSettings.javaScriptEnabled = true //允许使用js
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false

    }
    private fun setData() {
        val json = intent.getStringExtra("data")
        if (StringUtil.isBlank(json)) {
            return
        }
        val info = GsonUtils.fromJson<BookInfoEntity>(json, BookInfoEntity::class.java)
        if (info == null) {
            return
        }
        mDatabind.info = info
        bookId = info.id
        if (StringUtil.isNotBlank(bookId)) {
            requestBookViewModel.getBookDetailById(bookId)
        }

        GlideHelper.loadInsideImage(book_detail_pic, info.images)
//        initContent(info.content)

        if (StringUtil.isNotBlank(info.content)) {
//                RichText.fromHtml(content).into(tv_content);
            book_detail_wb_content.loadDataWithBaseURL(null,info.content+js, "text/html" , "utf-8", null);

        }
        val list = StringUtil.convertStrToList(info.images)
        val imgList = mutableListOf<HomeBannerEntity>()
        for (str in list) {
            imgList.add(HomeBannerEntity("", "", str, "", "", "", 0))
        }

        bannerViewPager.refreshData(imgList)
    }

    private fun initContent(content: String) {
        try {
            if (StringUtil.isNotBlank(content)) {
                RichText.fromHtml(content).into(book_detail_tv_content);
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun createObserver() {

        requestBookViewModel.addCardResult.observe(this, Observer {
            if (it.success) {
                EventBus.getDefault().post(RefreshShopCarEvent())
                ToastUtils.showShort("加入购物车成功")
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestBookViewModel.bookInfoResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    mDatabind.info = it
                    bookJson=GsonUtils.toJson(it)
                    (StringUtil.formatDoublePrice(it.officalPrice) + "立即抢购").also {
                        book_detail_add_book_order.text = it
                    }
                    GlideHelper.loadInsideImage(book_detail_pic, it.images)
                    initContent(it.content)
                    if (StringUtil.isNotBlank(it.content)) {
                        book_detail_wb_content.loadDataWithBaseURL(null,it.content+js, "text/html" , "utf-8", null);

                    }
                    val list = StringUtil.convertStrToList(it.images)
                    val imgList = mutableListOf<HomeBannerEntity>()
                    for (str in list) {
                        imgList.add(HomeBannerEntity("", "", str, "", "", "", 0))
                    }

                    bannerViewPager.refreshData(imgList)
                }
            })
        })
    }

    private fun initBanner() {
        val bannerAdapter = HomeBannerAdapter(this)
        bannerViewPager = findViewById(R.id.book_detail_banner)
        bannerViewPager
            .setIndicatorVisibility(View.VISIBLE)
            .setAdapter(bannerAdapter)
            .setLifecycleRegistry(lifecycle)
            .setIndicatorSliderGap(BannerUtils.dp2px(6f))
            .setIndicatorSliderColor(
                ResourcesCompat.getColor(resources, R.color.text_color_ccc, null),
                ResourcesCompat.getColor(resources, R.color.white, null)
            )
            .setIndicatorSlideMode(IndicatorSlideMode.WORM)
            .create()
    }

    inner class ProxyClick() {
        /**
         * 添加购物车
         */
        fun addShopCar() {
            if (CacheUtil.isLogin()) {
                val json = JsonObject()
                json.addProperty("bookAmount", 1)
                json.addProperty("bookId", bookId)
                requestBookViewModel.addBookToCard(json)
            } else {
                UserUtil.goLogin(this@BookDetailActivity)
            }


        }

        /**
         * 添加图书订单
         */
        fun addBookOrder() {

            if (StringUtil.isBlank(bookJson)) {
                return
            }
            val info = GsonUtils.fromJson<BookInfoEntity>(bookJson, BookInfoEntity::class.java)
            if (info == null) {
                return
            }
            val chooseDialog = SelectBookCountDialog.newBuilder(this@BookDetailActivity, info,
                object : SelectBookCountDialog.OnSubmitClickListener {
                    override fun onSubmitClick(shopCarInfo: ShopCarInfoEntity) {
                        Log.v(
                            "yxy",
                            "==GsonUtils.toJson(shopCarInfo)=" + GsonUtils.toJson(shopCarInfo)
                        )
                        val carList = arrayListOf<ShopCarInfoEntity>()
                        carList.add(shopCarInfo)
                        if (CacheUtil.isLogin()) {
                            startActivity(
                                Intent(
                                    this@BookDetailActivity,
                                    CreateBookOrderActivity::class.java
                                ).putExtra("data", GsonUtils.toJson(carList))
                                    .putExtra("channel", 1)
                            )
                        } else {
                            UserUtil.goLogin(this@BookDetailActivity)
                        }

                    }

                })
            chooseDialog.show()
        }
    }
}