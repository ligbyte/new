package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager1
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.eventbus.RefreshShopCarEvent
import com.wendu.wenduyikao.data.model.bean.BookShopClassifyEntity
import com.wendu.wenduyikao.databinding.ActivityBookListBinding
import com.wendu.wenduyikao.discovery.fragment.BookListFragment
import com.wendu.wenduyikao.util.UserUtil
import com.wendu.wenduyikao.viewmodel.request.RequestBookViewModel
import kotlinx.android.synthetic.main.activity_book_list.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.fragment_home.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/22 11:06 上午
 * @Description: 医学书店
 */
class BookListActivity : BaseActivity<RequestBookViewModel, ActivityBookListBinding>() {

    private val requestViewModel: RequestBookViewModel by viewModels()
    override fun layoutId() = R.layout.activity_book_list
    private var bookJson = ""

    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()


    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, book_list_ll_content)
        tv_toolbar_title.text = "医学书店"
        img_back.setOnClickListener { finish() }
        book_view_pager.initActivity(this, fragments)
        EventBus.getDefault().register(this)
        //初始化 magic_indicator
        book_magic_indicator.bindViewPager1(book_view_pager, mDataList)
        mDatabind.click = ProxyClick()
        requestViewModel.getListMagoron()
        requestViewModel.getShopCarList()
    }

    override fun createObserver() {
        requestViewModel.classifyResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {
                    initMagicIndicator(it.listData)
                }
            }
        })

        requestViewModel.carBooksResult.observe(this, Observer {
            if (it.isSuccess) {

                var total = 0.0
                var count = 0
                if (it.listData.size > 0) {
                    bookJson = GsonUtils.toJson(it.listData)
                    book_list_tv_num.visibility = View.VISIBLE
                    for (info in it.listData) {
                        total += (info.bookPrice * info.bookAmount)
                        count += info.bookAmount
                    }
                } else {
                    bookJson = ""
                    book_list_tv_num.visibility = View.GONE
                }
                book_list_tv_num_label.text = count.toString() + "件商品"
                book_list_tv_price.text = StringUtil.formatDoublePrice(total)
            }
        })
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun refreshShopCar(shopCar: RefreshShopCarEvent) {
        Log.v("yxy", "刷新 购物车数据")
        requestViewModel.getShopCarList()
    }

    inner class ProxyClick() {
        /**
         * 添加购物车
         */
        fun gotoShopCar() {
            if (CacheUtil.isLogin()) {
                startActivity(Intent(this@BookListActivity, ShopCarActivity::class.java))
            } else {
                UserUtil.goLogin(this@BookListActivity)
            }
        }

        /**
         * 添加图书订单
         */
        fun createOrder() {
            if (CacheUtil.isLogin()) {
                if (StringUtil.isNotBlank(bookJson)) {
                    startActivity(
                        Intent(
                            this@BookListActivity,
                            CreateBookOrderActivity::class.java
                        ).putExtra("data", bookJson)
                            .putExtra("channel", 2)
                    )
                } else {
                    ToastUtils.showShort("购物车暂无商品")
                }
            } else {
                UserUtil.goLogin(this@BookListActivity)
            }
            Log.v("yxy", "===bookJson==" + bookJson)


        }
    }

    private fun initMagicIndicator(typeList: ArrayList<BookShopClassifyEntity>) {
//        val typeList = BaseCode.getCouponType()
        mDataList.addAll(typeList.map { it.majorName })
        Log.v("yxy", "mDataList" + mDataList.size.toString())
        typeList.forEach {
            fragments.add(BookListFragment.newInstance(it.id))


        }
        book_magic_indicator.navigator.notifyDataSetChanged()
        book_view_pager.adapter?.notifyDataSetChanged()
        book_view_pager.offscreenPageLimit = fragments.size
    }
}