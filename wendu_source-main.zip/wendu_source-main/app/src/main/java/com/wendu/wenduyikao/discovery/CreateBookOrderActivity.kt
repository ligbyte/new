package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import android.os.Message
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.alipay.sdk.app.PayTask
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.Gson
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.eventbus.RefreshShopCarEvent
import com.wendu.wenduyikao.data.model.bean.AddressInfoEntity
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.databinding.ActivityCreateBookOrderBinding
import com.wendu.wenduyikao.discovery.adapter.BookOrderGoodsAdapter
import com.wendu.wenduyikao.listener.CheckFreightListener
import com.wendu.wenduyikao.question.PayWayActivity
import com.wendu.wenduyikao.viewmodel.request.RequestShopCarViewModel
import kotlinx.android.synthetic.main.activity_create_book_order.*
import kotlinx.android.synthetic.main.activity_exchange_course_detail.*
import kotlinx.android.synthetic.main.activity_pay_way.*
import kotlinx.android.synthetic.main.activity_shop_car.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import java.util.*
import kotlin.math.log

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:56 下午
 * @Description: 创建课程订单
 */
class CreateBookOrderActivity :
    BaseActivity<RequestShopCarViewModel, ActivityCreateBookOrderBinding>() {
    private val PARAMS_SELECT_ADDRESS = 2080
    private val PARAMS_SELECT_COUPON = 2081
    private val requestViewModel: RequestShopCarViewModel by viewModels()
    private var areaId = ""
    private var goodsId = ""
    private var couponId = ""
    private var couponType: Int = 0
    private var discountAmount: Double = 0.0
    private var total = 0.0
    private var yunFei = 0.0
    private var orderId = ""
    private var price = 0
    private var addressIndex = 0
    private var channel = 1
    override fun layoutId() = R.layout.activity_create_book_order
    private var addressJson = ""
    private var bookList: List<ShopCarInfoEntity> = arrayListOf()

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, book_order_ll_content)
        img_back.setOnClickListener { finish() }
        tv_toolbar_title.text = "图书订单"
        mDatabind.click = ProxyClick()
        channel = intent.getIntExtra("channel", 1)
        setData()
        requestViewModel.getAddressList()
    }

    private fun setData() {
        val json = intent.getStringExtra("data")
        if (StringUtil.isBlank(json)) {
            return
        }
        val turnsType = CacheUtil.genericType<ArrayList<ShopCarInfoEntity>>()
        val list =
            Gson().fromJson<ArrayList<ShopCarInfoEntity>>(
                json,
                turnsType
            )
        bookList = list
        total = 0.0
        for (info in list) {
            total += (info.bookPrice * info.bookAmount)
            goodsId += info.bookId + ","
        }
        book_order_tv_price.text = StringUtil.formatDoublePrice(total + yunFei)
        initCarRecycleView(list);
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == PARAMS_SELECT_ADDRESS) {
                addressJson = data?.getStringExtra("data").toString()
                areaId = data?.getStringExtra("areaId").toString()
                val address = data?.getStringExtra("address")
                val user = data?.getStringExtra("user")
                val index = data?.getIntExtra("index", 0)
                if (StringUtil.isNotBlank(address)) {
                    book_order_address.text = address
                    checkFreight();
                }
                if (StringUtil.isNotBlank(user)) {
                    book_order_user.text = user
                }
                if (index != null) {
                    addressIndex = index
                }
            } else if (requestCode == PARAMS_SELECT_COUPON) {
                couponId = data?.getStringExtra("id").toString()
                couponType = data!!.getIntExtra("couponType", 1)
                discountAmount = data.getDoubleExtra("discountAmount", 0.0)
                val couponName = data?.getStringExtra("couponName").toString()
                setPriceText()
                book_order_coupon.text = couponName
            }
        }
    }

    fun setPriceText(){
        var price = 0.0
        if (couponType == 1) {
            price = total - discountAmount
            book_order_tv_price.text = "¥" + StringUtil.formatDouble(price + yunFei)
        } else if (couponType == 2) {
            price = total * (discountAmount / 10)
            price = Math.round(price * 100) / 100.0
            book_order_tv_price.text = "¥" + StringUtil.formatDouble(price + yunFei)
        }
    }

    override fun createObserver() {

        requestViewModel.checkFreightResult.observe(this, Observer {
            Log.d("TAG", "checkFreightResult: " + it)
             if (it.toDouble() > 0){
                 tv_yun_fei.text = "运费 ￥" + it
                 yunFei = it.toDouble()
                 book_order_tv_price.text = StringUtil.formatDoublePrice(total + yunFei)
             }else{
                 tv_yun_fei.text = "快递免运费"
                 yunFei = 0.0
                 book_order_tv_price.text = StringUtil.formatDoublePrice(total + yunFei)
             }
        })

        requestViewModel.createBookOrderResult.observe(this) { it ->
            parseState(it, {
                ToastUtils.showShort("订单创建成功")
                EventBus.getDefault().post(RefreshShopCarEvent())
                orderId = it.orderId
                startActivity(
                    Intent(this, PayWayActivity::class.java)
                        .putExtra("isFromOrder", true)
                        .putExtra("isBookOrder", true)
                        .putExtra("price", StringUtil.formatDouble(it.actualPrice))
                        .putExtra("courseClassId", it.id)
                        .putExtra("isNeedUpdateAddress", false)
                        .putExtra("orderId", it.id)
                )
                finish()
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        }
        requestViewModel.addressResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {
                    var address = ""
                    var user = ""
                    for (info in it.listData) {
                        if (info.isdefault == "0") {
                            address = info.areaName + " " + info.address
                            user = info.name + " " + info.phone
                            addressIndex = it.listData.indexOf(info)
                            addressJson = GsonUtils.toJson(info)
                        } else {
                            address = it.listData[0].areaName + " " + it.listData[0].address
                            user = it.listData[0].name + " " + it.listData[0].phone
                            addressIndex = it.listData.indexOf(it.listData[0])
                            addressJson = GsonUtils.toJson(it.listData[0])
                        }
                    }
                    if (StringUtil.isNotBlank(address)) {
                        book_order_address.text = address
                        checkFreight();
                        book_order_user.text = user
                        addressIndex = 0
                    } else {
                        book_order_address.text = "请选择收货地址"
                    }

                } else {
                    book_order_address.text = "请选择收货地址"
                }
            }
        })
    }

    private fun initCarRecycleView(list: ArrayList<ShopCarInfoEntity>) {
        val shopCarAdapter = BookOrderGoodsAdapter(list)
        //初始化recyclerView
        book_order_rlv_book.init(
            LinearLayoutManager(this),
            shopCarAdapter
        )

        shopCarAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity =
                    adapter.getItem(position) as ShopCarInfoEntity

//                startActivity(
//                    Intent(this@CreateBookOrderActivity, BookDetailActivity::class.java)
//                        .putExtra(
//                            "data", GsonUtils.toJson(info)
//                        )
//                )
            }


        }
    }


    inner class ProxyClick() {
        fun gotoPayClick() {
            val addressInfo =
                GsonUtils.fromJson<AddressInfoEntity>(addressJson, AddressInfoEntity::class.java)

            if (addressInfo == null) {
                ToastUtils.showShort("请选择收货地址")
                return
            }

            if (tv_yun_fei.text.equals("超出配送范围")){
                ToastUtils.showLong("超出配送范围")
                return
            }

            val json = JsonObject()
            val jsonArray = JsonArray()
            for (book in bookList) {
                val bookJson = JsonObject()
                bookJson.addProperty("bookAmount", book.bookAmount)
                bookJson.addProperty("bookId", book.bookId)
                jsonArray.add(bookJson)
            }
            json.add("bookList", jsonArray)
            if (StringUtil.isNotBlank(couponId)) {
                json.addProperty("couponId", couponId)
            }
            json.addProperty("orderArea", addressInfo.area)
            json.addProperty("orderAreaAddress", addressInfo.address)
            json.addProperty("orderAreaCode", addressInfo.areaNo)
            json.addProperty("orderAreaName", addressInfo.areaName)
            json.addProperty("orderAreaPhone", addressInfo.phone)
            json.addProperty("orderAreaId", addressInfo.id)
            json.addProperty("orderWay", "5")
            json.addProperty("channel", channel.toString())
            Log.v("yxy", "==json=>" + GsonUtils.toJson(json))
            requestViewModel.addBookOrder(json)
        }

        fun selectAddress() {
            startActivityForResult(
                Intent(
                    this@CreateBookOrderActivity,
                    SelectAddressActivity::class.java
                ).putExtra("index", addressIndex), PARAMS_SELECT_ADDRESS
            )
        }

        fun selectCoupon() {
            startActivityForResult(
                Intent(
                    this@CreateBookOrderActivity,
                    SelectCouponActivity::class.java
                ).putExtra("goodsId", goodsId.subSequence(0, goodsId.length - 1))
                    .putExtra("type", "3"), PARAMS_SELECT_COUPON
            )
        }
    }

    fun checkFreight() {
        val addressInfo =
            GsonUtils.fromJson<AddressInfoEntity>(addressJson, AddressInfoEntity::class.java)
        if (addressInfo == null) {
            return
        }
        val json = JsonObject()
        val jsonArray = JsonArray()
        for (book in bookList) {
            val bookJson = JsonObject()
            bookJson.addProperty("bookAmount", book.bookAmount)
            bookJson.addProperty("bookId", book.bookId)
            jsonArray.add(bookJson)
        }
        json.add("bookList", jsonArray)
        if (StringUtil.isNotBlank(couponId)) {
            json.addProperty("couponId", couponId)
        }
        json.addProperty("orderArea", addressInfo.area)
        json.addProperty("orderAreaAddress", addressInfo.address)
        json.addProperty("orderAreaCode", addressInfo.areaNo)
        json.addProperty("orderAreaName", addressInfo.areaName)
        json.addProperty("orderAreaPhone", addressInfo.phone)
        json.addProperty("orderAreaId", addressInfo.id)
        json.addProperty("orderWay", "5")
        json.addProperty("channel", channel.toString())
        Log.v("yxy", "==json=>" + GsonUtils.toJson(json))
        requestViewModel.checkFreight(json, CheckFreightListener {
            tv_yun_fei.text = "超出配送范围"
            yunFei = 0.0
            setPriceText()
        })
    }

}