package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.constans.MainTabConst
import com.wendu.wenduyikao.data.eventbus.MainTabChooseEvent
import com.wendu.wenduyikao.data.model.bean.ShareEntity
import com.wendu.wenduyikao.databinding.ActivityInformationDetailBinding
import com.wendu.wenduyikao.dialog.ShareUrlDialog
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.viewmodel.request.WdActivityViewModel
import com.zzhoujay.richtext.RichText
import kotlinx.android.synthetic.main.activity_information_detail.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import java.util.regex.Pattern


/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/11 5:09 下午
 * @Description: 活动资讯详情
 */
class InformationDetailActivity :
    BaseActivity<WdActivityViewModel, ActivityInformationDetailBinding>() {
    private val requestViewModel: WdActivityViewModel by viewModels()
    override fun layoutId() = R.layout.activity_information_detail
    private var type = 1 //1 活动 2 资讯
    private var id = ""
    var shareDialog: BaseBottomSheetDialog? = null
    private var title = ""
    private var guidance = ""
    private var imgUrl = ""
    private var js = "<script type=\"text/javascript\">" +
            "var imgs = document.getElementsByTagName('img');" +  // 找到img标签
            "for(var i = 0; i<imgs.length; i++){" +  // 逐个改变
            "imgs[i].style.width = '100%';" +  // 宽度改为100%
            "imgs[i].style.height = 'auto';" +
            "}" +
            "</script>"

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, information_detail_ll_content)
        type = intent.getIntExtra("type", 1)
        iv_back.setOnClickListener { finish() }
        id = intent.getStringExtra("id").toString()
        if (type == 1) {
            information_tv_title.text = "活动详情"
            information_num.visibility = View.GONE
            information_status.visibility = View.VISIBLE
            requestViewModel.getWDActivityById(id)
        } else {
            information_tv_title.text = "资讯详情"
            information_num.visibility = View.VISIBLE
            information_status.visibility = View.GONE
            information_tv_guidance.visibility = View.VISIBLE
            requestViewModel.getWdInformationById(id)
        }
        initWebView()
        RichText.initCacheDir(this)
        RichText.debugMode = true
        iv_share.setOnClickListener {
            requestViewModel.getWdInformationShare(id)
        }

    }

    override fun onResume() {
        super.onResume()
        if (type == 1) {
            information_tv_title.text = "活动详情"
            information_num.visibility = View.GONE
            information_status.visibility = View.VISIBLE
            requestViewModel.getWDActivityById(id)
        } else {
            information_tv_title.text = "资讯详情"
            information_num.visibility = View.VISIBLE
            information_status.visibility = View.GONE
            information_tv_guidance.visibility = View.VISIBLE
            requestViewModel.getWdInformationById(id)
        }
    }

    override fun createObserver() {
        requestViewModel.wdActivityResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    information_time.text = it.activityStratTime + "-" + it.activityEndTime
                    StringUtil.getProceedType(it.proceedType, information_status)
                    wd_information_title.text = it.headline
                    initContent(it.content)
                }
            })
        })
        requestViewModel.wdInformationResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    information_num.text = it.preview.toString()
                    information_tv_guidance.text = it.guidance
                    information_time.text = it.createTime
                    wd_information_title.text = it.name
                    title = it.name
                    guidance = it.guidance
                    imgUrl = StringUtil.getNonNullString(it.img, "")
                    initContent(it.particulars)
                }
            })
        })
        requestViewModel.informationShareResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    if (shareDialog != null) {
                        shareDialog!!.dismiss()
                        shareDialog = null
                    }
                    val shareEntity = ShareEntity(title, guidance, imgUrl, it.informationUrl)
                    val url = it.informationUrlTest
                    shareDialog = ShareUrlDialog.newBuilder(this, shareEntity, null)
                    shareDialog!!.show()
                }
            })
        })
    }

    private fun initContent(content: String) {
        try {
            if (StringUtil.isNotBlank(content)) {
//                RichText.fromHtml(content).into(tv_content);
                web_content.loadDataWithBaseURL(null, content + js, "text/html", "utf-8", null);

                web_content.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                    }

                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
//                        首页：https://wendu.changyangdt.com/pc/
//                        列表：https://wendu.changyangdt.com/pc/testPreparationInformation
//                        咨询分类：https://wendu.changyangdt.com/pc/testPreparationInformation?tabId=1479332966044520450
//                        详情：https://wendu.changyangdt.com/zixun/1480812827690803202.html

//
//                        首页：https://yixue.wendu.com/
//                        列表：https://yixue.wendu.com/testPreparationInformation
//                        详情：https://yixue.wendu.com/zixun/1514175352803713026.html
//                        分类：https://yixue.wendu.com/testPreparationInformation?tabId=1460790726081404929
                        Log.v("yxy", "==点击href=" + url)
//                        if (url != null) {
//                            view?.loadUrl(url)
//                        }
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                            if (url.toString()
                                    .contains("https://yixue.wendu.com/testPreparationInformation")
                            ) {

                                val newString = StringBuffer()
                                val matcher = Pattern.compile("\\d").matcher(url)
                                while (matcher.find()) {
                                    newString.append(matcher.group())
                                }
                                Log.v("yxy", "=newString==>" + newString.toString())
                                startActivity(
                                    Intent(
                                        this@InformationDetailActivity,
                                        WdInformationActivity::class.java
                                    ).putExtra("tabId", newString.toString())
                                )
                                return false
                            } else if (url.toString().equals("https://yixue.wendu.com/")) {
                                EventBus.getDefault()
                                    .post(MainTabChooseEvent(MainTabConst.HOME, true))
                                finish()
                                return false
                            } else if (url.toString()
                                    .contains("https://yixue.wendu.com/zixun/")
                            ) {

                                val newString = StringBuffer()
                                val matcher = Pattern.compile("\\d").matcher(url)
                                while (matcher.find()) {
                                    newString.append(matcher.group())
                                }
                                Log.v("yxy", "=newString==>" + newString.toString())

                                startActivity(
                                    Intent(
                                        this@InformationDetailActivity,
                                        InformationDetailActivity::class.java
                                    )
                                        .putExtra("type", 2)
                                        .putExtra("id", newString.toString())
                                )
                                return true
                            } else {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                startActivity(intent)
                                return true;
                            }

                        }
                        return false;
                    }


                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun initWebView() {
        val webSettings: WebSettings = web_content.getSettings()
        webSettings.javaScriptEnabled = true //允许使用js
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false
    }

    override fun onDestroy() {
        super.onDestroy()
        RichText.recycle()
    }
}