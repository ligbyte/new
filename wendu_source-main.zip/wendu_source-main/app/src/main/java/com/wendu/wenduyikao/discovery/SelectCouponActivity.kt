package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.model.bean.WdCouponEntity
import com.wendu.wenduyikao.databinding.ActivitySelectCouponBinding
import com.wendu.wenduyikao.mine.adapter.CouponAdapter
import com.wendu.wenduyikao.viewmodel.request.CouponCenterViewModel
import kotlinx.android.synthetic.main.activity_select_coupon.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/23 5:42 下午
 * @Description: 选择优惠券
 */
class SelectCouponActivity : BaseActivity<CouponCenterViewModel, ActivitySelectCouponBinding>() {
    private val requestViewModel: CouponCenterViewModel by viewModels()
    private var goodsId = ""
    private var goodsTypeId = ""
    private var type = ""
    override fun layoutId() = R.layout.activity_select_coupon
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, select_coupon_content)
        tv_toolbar_title.text = "优惠券"
        img_back.setOnClickListener { finish() }
        goodsId = intent.getStringExtra("goodsId").toString()
        type = intent.getStringExtra("type").toString()
        if (intent.getStringExtra("goodsTypeId") != null) {
            goodsTypeId = intent.getStringExtra("goodsTypeId").toString()
        }
        getCouponGoodsByList()
    }

    private fun getCouponGoodsByList() {
        if (goodsTypeId.isNullOrEmpty()) {
            requestViewModel.getCouponByGoodsList(goodsId, type)
        } else {
            requestViewModel.getCouponByGoodsList(goodsId, type, goodsTypeId)
        }
    }

    private fun initCarRecycleView(list: ArrayList<WdCouponEntity>) {
        val couponAdapter = CouponAdapter(list)
        //初始化recyclerView
        rlv_select_coupon.init(
            LinearLayoutManager(this),
            couponAdapter
        )
        couponAdapter.addChildClickViewIds(R.id.coupon_item_status)
        couponAdapter.run {
//            setOnItemClickListener { adapter, view, position ->
//                val info: WdCouponEntity =
//                    adapter.getItem(position) as WdCouponEntity
//                val intent = Intent()
//                intent.putExtra("id", info.id)
//                intent.putExtra("couponName", info.couponName)
//                intent.putExtra("couponType", info.type)
//                intent.putExtra("discountAmount", info.discountAmount)
//                setResult(RESULT_OK, intent)
//                finish()
//            }

            setOnItemChildClickListener { adapter, view, position ->
                val info: WdCouponEntity =
                    adapter.getItem(position) as WdCouponEntity
                when (view.id) {
                    R.id.coupon_item_status -> {
                        val intent = Intent()
                        intent.putExtra("id", info.id)
                        intent.putExtra("couponName", info.couponName)
                        intent.putExtra("couponType", info.type)
                        intent.putExtra("discountAmount", info.discountAmount)
                        setResult(RESULT_OK, intent)
                        if (info.flg == 0) {
                            requestViewModel.saveCoupon(info.id)
                        } else {

                            finish()
                        }
                    }
                }
            }
        }
    }

    override fun createObserver() {
        requestViewModel.goodsCouponListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {
                    initCarRecycleView(it.listData)
                }
            }
        })

        requestViewModel.saveCouponResult.observe(this, Observer {
            if (it.success) {
              ToastUtils.showShort("领取优惠券成功")
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }
}