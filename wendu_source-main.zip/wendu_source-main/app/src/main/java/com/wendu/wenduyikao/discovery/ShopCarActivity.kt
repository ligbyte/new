package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.eventbus.RefreshShopCarEvent
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.databinding.ActivityShopCarBinding
import com.wendu.wenduyikao.discovery.adapter.ShopCarAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestShopCarViewModel
import kotlinx.android.synthetic.main.activity_shop_car.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import org.greenrobot.eventbus.EventBus
import java.util.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:53 下午
 * @Description: 购物车
 */
class ShopCarActivity : BaseActivity<RequestShopCarViewModel, ActivityShopCarBinding>() {
    private val requestViewModel: RequestShopCarViewModel by viewModels()
    private var isManage = false
    private var isHaveGoods = false
    private var isSelectAll = false
    override fun layoutId() = R.layout.activity_shop_car
    private var shopCarAdapter: ShopCarAdapter = ShopCarAdapter(
        arrayListOf()
    )

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, shop_car_ll_content)
        tv_toolbar_title.text = "购物车"
        img_back.setOnClickListener { finish() }
        requestViewModel.getShopCarList()
        mDatabind.click = ProxyClick()
        initEvent()
    }

    private fun initCarRecycleView(list: ArrayList<ShopCarInfoEntity>) {
        shopCarAdapter = ShopCarAdapter(list)
        //初始化recyclerView
        shop_car_rlv_goods.init(
            LinearLayoutManager(this),
            shopCarAdapter
        ).addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(10f)))
        shopCarAdapter.addChildClickViewIds(
            R.id.goods_num_minus,
            R.id.goods_num_add,
            R.id.shop_car_img_check
        )
        shopCarAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity =
                    adapter.getItem(position) as ShopCarInfoEntity

                startActivity(
                    Intent(this@ShopCarActivity, BookDetailActivity::class.java)
                        .putExtra(
                            "data", GsonUtils.toJson(info)
                        ) .putExtra(
                            "bookId", info.bookId
                        )
                )
            }

            setOnItemChildClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity =
                    adapter.getItem(position) as ShopCarInfoEntity

                when (view.id) {
                    R.id.shop_car_img_check -> {
                        shopCarAdapter.setPosition(position)
                        shopCarAdapter.notifyDataSetChanged()
                        setPrice()
                    }
                    R.id.goods_num_minus -> {
                        val linearLayout: LinearLayout = view.parent as LinearLayout
                        val tvNum: TextView = linearLayout.findViewById(R.id.goods_num_tv_num)
                        if (info.bookAmount > 1) {
                            info.bookAmount--
                        }
                        tvNum.text = info.bookAmount.toString()
                        requestViewModel.edtCarNum(info.bookId, info.bookAmount)
                        setPrice()
                    }
                    R.id.goods_num_add -> {
                        val linearLayout: LinearLayout = view.parent as LinearLayout
                        val tvNum: TextView = linearLayout.findViewById(R.id.goods_num_tv_num)
                        info.bookAmount++
                        tvNum.text = info.bookAmount.toString()
                        requestViewModel.edtCarNum(info.bookId, info.bookAmount)
                        setPrice()
                    }
                }

            }

        }
    }

    private fun setPrice() {
        val list = shopCarAdapter.data
        var total = 0.0
        for (info in list) {
            if (info.isSelect) {
                total += (info.bookPrice * info.bookAmount)
            }

        }
        shop_car_tv_price.text = StringUtil.formatDoublePrice(total)
    }

    fun initEvent() {
        shop_car_check_box.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                shopCarAdapter.setSelectAll()
                shopCarAdapter.notifyDataSetChanged()
                setPrice()
            } else {
                shopCarAdapter.clearSelectAll()
                shopCarAdapter.notifyDataSetChanged()
                shop_car_tv_price.text = "¥0.0"
            }

        }
    }

    override fun createObserver() {
        requestViewModel.carBooksResult.observe(this, Observer {
            if (it.isSuccess) {
                isHaveGoods = it.listData.size > 0
                initCarRecycleView(it.listData)
                setPrice()
            }
        })
        requestViewModel.delBookResult.observe(this, Observer {
            if (it.success) {
                EventBus.getDefault().post(RefreshShopCarEvent())
                requestViewModel.getShopCarList()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun manageClick() {
            isManage = !isManage
            if (isManage && isHaveGoods) {
                shop_car_label.text = "完成"
                shop_car_tv_price_label.visibility = View.GONE
                shop_car_rv_delete.visibility = View.VISIBLE
                shop_car_tv_price.visibility = View.GONE
                shop_car_rv_buy.visibility = View.GONE
            } else {
                shop_car_label.text = "管理"
                shop_car_tv_price_label.visibility = View.VISIBLE
                shop_car_rv_delete.visibility = View.GONE
                shop_car_tv_price.visibility = View.VISIBLE
                shop_car_rv_buy.visibility = View.VISIBLE
            }
        }

        fun deleteSelect() {
            var bookIds = ""
            val list = shopCarAdapter.data
            for (info in list) {
                if (info.isSelect) {
                    bookIds += info.bookId + ","
                }

            }
            if (StringUtil.isNotBlank(bookIds)) {
                requestViewModel.clearShopCarAll(bookIds)
            } else {
                ToastUtils.showShort("请选择商品")
            }

        }

        fun createBookOrder() {
            val list = shopCarAdapter.data
            val selectList = arrayListOf<ShopCarInfoEntity>()
            for (info in list) {
                if (info.isSelect) {
                    selectList.add(info)
                }
            }

            val bookJson = GsonUtils.toJson(selectList)
            if (selectList.size > 0) {
                startActivity(
                    Intent(
                        this@ShopCarActivity,
                        CreateBookOrderActivity::class.java
                    ).putExtra("data", bookJson)
                        .putExtra("channel", 2)
                )
                finish()
            } else {
                ToastUtils.showShort("请选择商品")
            }
        }
    }
}