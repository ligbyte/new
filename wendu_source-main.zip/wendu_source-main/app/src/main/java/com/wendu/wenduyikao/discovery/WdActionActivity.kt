package com.wendu.wenduyikao.discovery

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.WdActivityEntity
import com.wendu.wenduyikao.databinding.ActivityWdActionBinding
import com.wendu.wenduyikao.discovery.adapter.WdActivityAdapter
import com.wendu.wenduyikao.viewmodel.request.WdActivityViewModel
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.activity_wd_action.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.include_recyclerview.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/9 4:54 下午
 * @Description: 活动列表
 */
class WdActionActivity : BaseActivity<WdActivityViewModel, ActivityWdActionBinding>() {

    //请求的ViewModel
    private val requestViewModel: WdActivityViewModel by viewModels()

    //适配器
    private val wdActivityAdapter: WdActivityAdapter by lazy {
        WdActivityAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    private lateinit var footView: DefineLoadMoreView
    override fun layoutId() = R.layout.activity_wd_action

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, ll_wd_action_content)
        tv_toolbar_title.text = "活动"
        img_back.setOnClickListener { finish() }
        initRecycleView();
        lazyLoadData()
    }

    private fun initRecycleView() {
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getWDActivityList(true)
        }
        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(this), wdActivityAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getWDActivityList(false)
            })
        }
        val list = arrayListOf<WdActivityEntity>()
        wdActivityAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getWDActivityList(true)
        }
        wdActivityAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: WdActivityEntity =
                    adapter.getItem(position) as WdActivityEntity
                startActivity(
                    Intent(this@WdActionActivity, InformationDetailActivity::class.java)
                        .putExtra("type", 1)
                        .putExtra("id", info.id)
                )

            }

        }
    }


    fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getWDActivityList(true)
    }

    override fun createObserver() {
        requestViewModel.activityListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, wdActivityAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                showMessage(it.errMessage)
            }
        })

    }
}