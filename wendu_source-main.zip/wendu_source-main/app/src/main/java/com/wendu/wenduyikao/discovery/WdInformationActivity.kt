package com.wendu.wenduyikao.discovery

import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager1
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.WdInformationTypeEntity
import com.wendu.wenduyikao.databinding.ActivityWdInformationBinding
import com.wendu.wenduyikao.discovery.fragment.WdInformationFragment
import com.wendu.wenduyikao.viewmodel.request.WdActivityViewModel
import kotlinx.android.synthetic.main.activity_my_fav.magic_indicator
import kotlinx.android.synthetic.main.activity_my_fav.view_pager
import kotlinx.android.synthetic.main.activity_wd_information.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

class WdInformationActivity : BaseActivity<WdActivityViewModel, ActivityWdInformationBinding>() {
    private val requestViewModel: WdActivityViewModel by viewModels()

    override fun layoutId() = R.layout.activity_wd_information

    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()

    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()
    private var selectId = ""

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, information_ll_content)
        tv_toolbar_title.text = "x资讯"
        img_back.setOnClickListener { finish() }
        view_pager.initActivity(this, fragments)
        selectId = intent.getStringExtra("tabId") ?: ""
        magic_indicator.bindViewPager1(view_pager, mDataList)

        requestViewModel.getWdInformationClassifyList()
    }

    private fun initMagicIndicator(list: ArrayList<WdInformationTypeEntity>) {
        var  positon=0
        mDataList.addAll(list.map { it.name })


        list.forEach {
            fragments.add(WdInformationFragment.newInstance(it.id))
        }


        magic_indicator.navigator.notifyDataSetChanged()
        view_pager.adapter?.notifyDataSetChanged()
        view_pager.offscreenPageLimit = fragments.size
        if(StringUtil.isNotBlank(selectId)){
            for((index, info) in list.withIndex()){
                if (info.id==selectId) {
                    positon=index
                }
            }
            Log.v("yxy","tabId==="+positon)
            magic_indicator.onPageSelected(positon)
            magic_indicator.onPageScrollStateChanged(positon)
            magic_indicator.navigator.notifyDataSetChanged()
            view_pager.setCurrentItem(positon)
            view_pager.adapter?.notifyDataSetChanged()
        }

    }

    override fun createObserver() {
        requestViewModel.informationTypeListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (!it.isEmpty) {
                    initMagicIndicator(it.listData)
                } else {
                    ToastUtils.showShort("暂无资讯类别数据")
                }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
    }
}