package com.wendu.wenduyikao.discovery.adapter;

import android.graphics.Color;
import android.util.Log;
import android.widget.ImageView;

import com.blankj.utilcode.util.GsonUtils;
import com.chad.library.adapter.base.BaseSectionQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.app.util.StringUtil;
import com.wendu.wenduyikao.data.model.bean.BookInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity;
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity;
import com.wendu.wenduyikao.util.GlideHelper;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

/**
 * https://github.com/CymChad/BaseRecyclerViewAdapterHelper
 */
public class BookClassifyDbAdapter extends BaseSectionQuickAdapter<QuestionResultEntity, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization result.
     *
     * @param sectionHeadResId The section head layout id for each item
     * @param layoutResId      The layout resource id of each item.
     * @param data             A new list is created out of this one to avoid mutable list
     */
    public BookClassifyDbAdapter(int layoutResId, int sectionHeadResId, List<QuestionResultEntity> data) {
        super(sectionHeadResId, data);
        setNormalLayout(layoutResId);

    }

    @Override
    protected void convertHeader(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        if (item.getObject() instanceof String) {
            helper.setText(R.id.header, (String) item.getObject());
        }
    }


    @Override
    protected void convert(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        BookInfoEntity info = (BookInfoEntity) item.getObject();
        helper.setText(R.id.book_item_name, info.getBookName());
        ImageView pic = helper.getView(R.id.book_item_pic);
        List<String> imgs = StringUtil.convertStrToList(info.getImages());
        if (imgs != null) {
            GlideHelper.INSTANCE.loadInsideImage(pic, imgs.get(0));
        }

        helper.setText(R.id.book_item_price, StringUtil.formatDoublePrice(info.getOfficalPrice()));


    }
}
