package com.wendu.wenduyikao.discovery.adapter

import android.util.Log
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.BookInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 图书
 */
class BookGridAdapter(data: ArrayList<BookInfoEntity>) :
    BaseQuickAdapter<BookInfoEntity, BaseViewHolder>(
        R.layout.book_item_layout_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: BookInfoEntity) {
        item.run {
            holder.setText(R.id.book_item_name, bookName)
            val pic = holder.getView<ImageView>(R.id.book_item_pic)
            val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))

            if (StringUtil.isNotBlank(images)) {
                if (images.split(",").size > 0) {
                    val imgUrl = images.split(",")[0]
                    if (StringUtil.isNotBlank(imgUrl)) {
                        Glide.with(context).load(imgUrl).apply(operation)
                            .placeholder(R.drawable.ic_default_pic1).into(pic)
                    }
                }

            }

            holder.setText(R.id.book_item_price, StringUtil.formatDoublePrice(officalPrice))
        }
    }

}