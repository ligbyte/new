package com.wendu.wenduyikao.discovery.adapter

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 图书
 */
class BookOrderInfoAdapter(data: ArrayList<ShopCarInfoEntity>) :
    BaseQuickAdapter<ShopCarInfoEntity, BaseViewHolder>(
        R.layout.book_order_books_item_view,
        data
    ) {
    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: ShopCarInfoEntity) {
        item.run {
            holder.setText(R.id.wd_book_item_name, wdBook?.bookName)
            val pic = holder.getView<ImageView>(R.id.wd_book_item_pic)
            val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
            val pathList = StringUtil.convertStrToList(wdBook?.images)
            if (pathList.size > 0) {
                Glide.with(context).load(pathList[0]).apply(operation)
                    .placeholder(R.drawable.ic_default_pic1).into(pic)
            }
            holder.setText(R.id.wd_book_item_price,
                wdBook?.let { StringUtil.formatDoublePrice(it.officalPrice) })
            holder.setText(R.id.wd_book_item_num, "x$bookAmount")

//            if (data.size > 1) {
//                holder.getView<View>(R.id.wd_book_item_line).visibility = View.VISIBLE
//            } else {
//                holder.getView<View>(R.id.wd_book_item_line).visibility = View.GONE
//            }
        }
    }

}