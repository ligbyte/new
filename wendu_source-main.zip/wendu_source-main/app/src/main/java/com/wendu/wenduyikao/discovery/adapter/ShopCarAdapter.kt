package com.wendu.wenduyikao.discovery.adapter

import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 图书
 */
class ShopCarAdapter(data: ArrayList<ShopCarInfoEntity>) :
    BaseQuickAdapter<ShopCarInfoEntity, BaseViewHolder>(
        R.layout.shop_car_item_view,
        data
    ) {
    private val choiceNum = 0
    private val selectList = arrayListOf<ShopCarInfoEntity>()
    var mutilSelectedList = mutableSetOf<Int>()

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    fun getSelectList(): ArrayList<ShopCarInfoEntity> {
        return selectList
    }

    fun setPosition(position: Int) {
        val info = data[position]
        info.isSelect = !info.isSelect
        if (info.isSelect) {
            mutilSelectedList.add(position)
        } else {
            mutilSelectedList.remove(position)
        }
        selectList.add(info)
    }

    fun setSelectAll() {
        for (info in data) {
            info.isSelect = true
        }
    }

    fun clearSelectAll() {
        for (info in data) {
            info.isSelect = false
        }
    }


    override fun convert(holder: BaseViewHolder, item: ShopCarInfoEntity) {
        item.run {
            holder.setText(R.id.shop_car_item_name, bookName)
            val pic = holder.getView<ImageView>(R.id.information_item_pic)
            val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
            val pathList = StringUtil.convertStrToList(images)
            Glide.with(context).load(pathList[0]).apply(operation)
                .placeholder(R.drawable.ic_default_pic1).into(pic)
            holder.setText(R.id.shop_car_item_price, StringUtil.formatDoublePrice(bookPrice))
            holder.setText(R.id.goods_num_tv_num, bookAmount.toString())

            if (isSelect) {
                holder.setImageResource(
                    R.id.shop_car_img_check,
                    R.mipmap.ic_check_box
                )

            } else {
                holder.setImageResource(
                    R.id.shop_car_img_check,
                    R.mipmap.ic_check_box_un
                )

            }
            if (data.size > 1) {
                holder.getView<View>(R.id.shop_car_item_line).visibility = View.VISIBLE
            } else {
                holder.getView<View>(R.id.shop_car_item_line).visibility = View.GONE
            }
//            holder.getView<RelativeLayout>(R.id.goods_num_minus).setOnClickListener {
//                if (bookAmount > 0) {
//                    bookAmount--
//                }
//                holder.setText(R.id.goods_num_tv_num, bookAmount.toString())
//            }
//            holder.getView<RelativeLayout>(R.id.goods_num_add).setOnClickListener {
//                bookAmount++
//                holder.setText(R.id.goods_num_tv_num, bookAmount.toString())
//            }
            addChildClickViewIds(R.id.goods_num_minus, R.id.goods_num_add)
        }
    }

}