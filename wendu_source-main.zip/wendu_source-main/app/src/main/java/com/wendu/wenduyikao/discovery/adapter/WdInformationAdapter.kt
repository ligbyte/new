package com.wendu.wenduyikao.discovery.adapter

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.WdInformationEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 课程订单
 */
class WdInformationAdapter(data: ArrayList<WdInformationEntity>) :
    BaseQuickAdapter<WdInformationEntity, BaseViewHolder>(
        R.layout.wd_information_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: WdInformationEntity) {
        item.run {
            holder.setText(R.id.wd_information_item_name, name)
            holder.setText(R.id.information_item_num, preview.toString())
            val pic = holder.getView<ImageView>(R.id.information_item_pic)
            val operation = RequestOptions().centerCrop().transform(RoundedCorners(20))
            Glide.with(context).load(img).apply(operation)
                .placeholder(R.drawable.ic_default_pic1).into(pic)
            holder.setText(R.id.information_item_time, createTime)

        }
    }

}