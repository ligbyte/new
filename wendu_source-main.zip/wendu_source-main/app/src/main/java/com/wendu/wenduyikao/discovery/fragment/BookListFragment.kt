package com.wendu.wenduyikao.discovery.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.scwang.smartrefresh.layout.listener.OnRefreshListener
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseFragment
import com.wendu.wenduyikao.data.model.bean.BookInfoEntity
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.databinding.FragmentBookListBinding
import com.wendu.wenduyikao.discovery.BookDetailActivity
import com.wendu.wenduyikao.discovery.adapter.BookClassifyDbAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestBookViewModel
import kotlinx.android.synthetic.main.fragment_book_list.*
import java.util.*

class BookListFragment : BaseFragment<RequestBookViewModel, FragmentBookListBinding>() {

    private var id = ""
    private val requestBookViewModel: RequestBookViewModel by viewModels()
    override fun layoutId(): Int {
        return R.layout.fragment_book_list
    }

    override fun initView(savedInstanceState: Bundle?) {
        arguments?.let {
            id = it.getString("id", "")

        }
        getBooksByClassify()
        initSmartRefreshLayout()
    }
    private fun initSmartRefreshLayout() {
        mDatabind.bookSmartRefresh.setEnableLoadMore(false)
        mDatabind.bookSmartRefresh.setOnRefreshListener(OnRefreshListener {
            getBooksByClassify()
        })
    }

    /**
     * 停止下拉刷新
     */
    private fun finishRefresh() {
        if (mDatabind.bookSmartRefresh == null) {
            return
        }
        mDatabind.bookSmartRefresh.finishRefresh()
    }

    private fun initRecycleView(list: ArrayList<QuestionResultEntity>) {
        rlv_book_list.layoutManager = GridLayoutManager(mActivity, 2)
//        rlv_book_list.let {
//            it.addItemDecoration(
//                SpaceItemDecoration(
//                    ConvertUtils.dp2px(10f),
//                    ConvertUtils.dp2px(11f)
//                )
//            )
//        }
        val adapter =
            BookClassifyDbAdapter(
                R.layout.book_item_layout_view,
                R.layout.book_list_result_head,
                list
            )
        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = list.get(position)
            if (!mySection.isHeader) {
                val info: BookInfoEntity =
                    mySection.getObject() as BookInfoEntity
//                dataId = question.questionId
                startActivity(
                    Intent(mActivity, BookDetailActivity::class.java).putExtra(
                        "data",
                        GsonUtils.toJson(info)
                    ).putExtra(
                        "bookId", info.id
                    )

                )
            }
        })

        rlv_book_list.adapter = adapter
    }


    private fun getBooksByClassify() {
        val map = mutableMapOf<String, String>()
        map["majorId"] = id
        requestBookViewModel.getListMagoronBook(map)
    }


    override fun createObserver() {
        requestBookViewModel.classifyBookResult.observe(this, Observer {
            if (it.isSuccess) {
                finishRefresh()
                val list = ArrayList<QuestionResultEntity>()
                if (it.listData.size > 0) {
                    for (info in it.listData) {
                        if(info.bookList.size>0){
                            list.add(QuestionResultEntity(true, info.majorName))
                            for (book in info.bookList) {
                                list.add(QuestionResultEntity(false, book))
                            }
                        }

                    }

                    Log.v("yxy", "=books==" + list.size)
                }
                initRecycleView(list)
            }
        })
    }

    companion object {
        fun newInstance(id: String): BookListFragment {
            val args = Bundle()
            args.putString("id", id)
            val fragment = BookListFragment()
            fragment.arguments = args
            return fragment
        }
    }
}