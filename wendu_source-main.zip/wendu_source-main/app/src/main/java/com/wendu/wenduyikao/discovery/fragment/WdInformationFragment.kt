package com.wendu.wenduyikao.discovery.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseFragment
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.WdInformationEntity
import com.wendu.wenduyikao.databinding.WdInformationFragmentBinding
import com.wendu.wenduyikao.discovery.InformationDetailActivity
import com.wendu.wenduyikao.discovery.adapter.WdInformationAdapter
import com.wendu.wenduyikao.viewmodel.request.WdActivityViewModel
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.include_recyclerview.*

class WdInformationFragment : BaseFragment<WdActivityViewModel, WdInformationFragmentBinding>() {

    private val requestViewModel: WdActivityViewModel by viewModels()
    override fun layoutId() = R.layout.wd_information_fragment
    private var id = ""
    private lateinit var loadsir: LoadService<Any>

    //适配器
    private val wdInformationAdapter: WdInformationAdapter by lazy {
        WdInformationAdapter(
            arrayListOf()
        )
    }

    private lateinit var footView: DefineLoadMoreView
    override fun initView(savedInstanceState: Bundle?) {
        arguments?.let {
            id = it.getString("id", "")
        }
        initRecycleView()

    }

    private fun initRecycleView() {
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getWDActivityList(true)
        }
        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(mActivity), wdInformationAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getWdInformationList(false, id)
            })
        }
        val list = arrayListOf<WdInformationEntity>()
        wdInformationAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getWdInformationList(true, id)
        }
        wdInformationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: WdInformationEntity =
                    adapter.getItem(position) as WdInformationEntity
                startActivity(
                    Intent(mActivity, InformationDetailActivity::class.java)
                        .putExtra("type", 2)
                        .putExtra("id", info.id)
                )

            }

        }
    }


    override fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getWdInformationList(true, id)
    }

    override fun createObserver() {
        requestViewModel.informationListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, wdInformationAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                showMessage(it.errMessage)
            }
        })

    }


    companion object {
        fun newInstance(id: String): WdInformationFragment {
            val args = Bundle()
            args.putString("id", id)
            val fragment = WdInformationFragment()
            fragment.arguments = args
            return fragment
        }
    }
}