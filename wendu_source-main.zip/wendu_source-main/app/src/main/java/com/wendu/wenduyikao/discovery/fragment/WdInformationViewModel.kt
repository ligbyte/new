package com.wendu.wenduyikao.discovery.fragment

import me.xiaoyang.base.base.viewmodel.BaseViewModel

class WdInformationViewModel : BaseViewModel() {
    // TODO: Implement the ViewModel
}