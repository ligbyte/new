package com.wendu.wenduyikao.listener;

public interface CheckFreightListener {
    public void onError();
}
