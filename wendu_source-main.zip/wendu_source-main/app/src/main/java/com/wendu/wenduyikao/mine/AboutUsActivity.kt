package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.databinding.ActivityAboutUsBinding
import com.wendu.wenduyikao.ui.activity.WebActivity
import kotlinx.android.synthetic.main.activity_about_us.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.base.viewmodel.BaseViewModel

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/12/21 1:36 PM
 * @Description: 关于我们
 */
class AboutUsActivity : BaseActivity<BaseViewModel, ActivityAboutUsBinding>() {

    override fun layoutId() = R.layout.activity_about_us


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, about_us_ll_content)
        tv_toolbar_title.text = "关于我们"
        mDatabind.click=ProxyClick()
        img_back.setOnClickListener { finish() }
        about_us_version.text=MobileUtil.getVersionName(this)
    }

    inner class ProxyClick() {
        fun gotoHomeIndex() {
            startActivity(Intent(this@AboutUsActivity, WebActivity::class.java).putExtra("type", 1))
        }

        fun gotoPrivacyPolicy() {
            startActivity(Intent(this@AboutUsActivity, WebActivity::class.java).putExtra("type", 2))
        }

        fun gotoServiceAgreement() {
            startActivity(Intent(this@AboutUsActivity, WebActivity::class.java).putExtra("type", 3))
        }
    }
}