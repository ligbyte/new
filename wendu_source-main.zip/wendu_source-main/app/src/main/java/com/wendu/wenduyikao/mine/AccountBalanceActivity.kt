package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.BalanceInfoEntity
import com.wendu.wenduyikao.databinding.ActivityAccountBalanceBinding
import com.wendu.wenduyikao.mine.adapter.BalanceListAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestBalanceViewModel
import kotlinx.android.synthetic.main.activity_about_us.*
import kotlinx.android.synthetic.main.activity_account_balance.*
import kotlinx.android.synthetic.main.activity_chapter.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/12/21 2:18 PM
 * @Description: 账户余额
 *
 */
class AccountBalanceActivity :
    BaseActivity<RequestBalanceViewModel, ActivityAccountBalanceBinding>() {

    override fun layoutId() = R.layout.activity_account_balance
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, balance_ll_content)
        balance_tv_title.text = "账户余额"
        balance_img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        initRecycleView()
    }



    private fun initRecycleView() {
        val list = arrayListOf<BalanceInfoEntity>()
        for (i in 0 until 10) {
            list.add(BalanceInfoEntity(" $i 学习币"))
        }
        val balanceAdapter = BalanceListAdapter(list)
        //初始化recyclerView
        balance_rlv_level.init(
            GridLayoutManager(this, 3),
            balanceAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(8f)))
        }
        balanceAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: BalanceInfoEntity =
                    adapter.getItem(position) as BalanceInfoEntity
                balanceAdapter.setPosition(position)
                balanceAdapter.notifyDataSetChanged()
                submit_balance_count.text = info.name
            }
        }
    }

    inner class ProxyClick() {
        /**
         * 充值记录
         */
        fun gotoBalanceRecord() {
            startActivity(Intent(this@AccountBalanceActivity, BalanceRecordActivity::class.java))
        }
    }
}