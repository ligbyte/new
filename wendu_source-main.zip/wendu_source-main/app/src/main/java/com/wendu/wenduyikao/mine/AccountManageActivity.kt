package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.text.TextUtils
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.tencent.mm.opensdk.modelmsg.SendAuth
import com.tencent.mm.opensdk.openapi.IWXAPI
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import com.tencent.open.log.SLog
import com.tencent.tauth.DefaultUiListener
import com.tencent.tauth.IUiListener
import com.tencent.tauth.Tencent
import com.tencent.tauth.UiError
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.App
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.event.LoginWeiXinEvent
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.UserInfo
import com.wendu.wenduyikao.databinding.ActivityAccountManageBinding
import com.wendu.wenduyikao.viewmodel.request.RequestUserViewModel
import kotlinx.android.synthetic.main.activity_account_manage.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.json.JSONObject

class AccountManageActivity :
    BaseActivity<RequestUserViewModel, ActivityAccountManageBinding>() {

    override fun layoutId() = R.layout.activity_account_manage
    private val requestViewModel: RequestUserViewModel by viewModels()

    private var wxApi: IWXAPI? = null
    val mTencent: Tencent =
        Tencent.createInstance(Constants.QQ_APP_ID, App.instance.applicationContext)

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, account_manage_ll_content)
        tv_toolbar_title.text = "账号管理"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
        if (mTencent == null) {
            SLog.e("yxy", "Tencent instance create fail!")
        }
        val user = CacheUtil.getUser()
        if (user != null) {
            setStatusView(user)
        }
        regToWx()
    }


    override fun onDestroy() {
        super.onDestroy()
        if (EventBus.getDefault().isRegistered(this))//加上判断
            EventBus.getDefault().unregister(this);
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.d("yxy", "-->onActivityResult $requestCode resultCode=$resultCode")
        if (requestCode == com.tencent.connect.common.Constants.REQUEST_LOGIN ||
            requestCode == com.tencent.connect.common.Constants.REQUEST_APPBAR
        ) {
            Tencent.onActivityResultData(requestCode, resultCode, data, loginListener)
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun regToWx() {
        val appId: String = Constants.WX_APP_ID
        wxApi = WXAPIFactory.createWXAPI(this, appId, false)
        wxApi?.registerApp(appId)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public fun OnLoginWeiXinEvent(event: LoginWeiXinEvent) {
        //获取Token信息
        Log.v("yxy", "login code==" + event.code)
        var user = CacheUtil.getUser()
        requestViewModel.wxLogin(event.code, user?.stuPhone.toString())
    }

    override fun createObserver() {
        requestViewModel.wxLoginResult.observe(this, Observer { resultState ->
            parseState(resultState, { data ->
                if (data.userInfo != null) {
                    CacheUtil.setUser(data.userInfo)
                    appViewModel.userinfo.value = data.userInfo
                    appViewModel.isLogin.value = true
                    CacheUtil.setToken(data.token)
                    setStatusView(data.userInfo)
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
        requestViewModel.qqLoginResult.observe(this, Observer { resultState ->
            parseState(resultState, { data ->
                if (data.userInfo != null) {
                    CacheUtil.setUser(data.userInfo)
                    appViewModel.userinfo.value = data.userInfo
                    appViewModel.isLogin.value = true
                    CacheUtil.setToken(data.token)
                    setStatusView(data.userInfo)
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
    }


    private fun setStatusView(user: UserInfo) {
        Log.v("yxy", "====" + GsonUtils.toJson(user))
        //根据openid来判定是否已绑定微信
        if (StringUtil.isNotBlank(user.openid)) {
            account_wx_status.text = "已绑定"
        } else {
            account_wx_status.text = "未绑定"
        }
        if (StringUtil.isNotBlank(user.qq)) {
            account_qq_status.text = "已绑定"
        } else {
            account_qq_status.text = "未绑定"
        }
    }

    inner class ProxyClick() {
        /**
         * 更换手机号
         */
        fun gotoUpdatePhoneClick() {

            startActivity(
                Intent(this@AccountManageActivity, UpdatePhoneActivity::class.java)
                    .putExtra("from", 2)
            )
        }

        fun bindWxClick() {
            if (account_wx_status.text.equals("未绑定")) {
                if (wxApi?.isWXAppInstalled == false) {
                    ToastUtils.showShort("您的设备未安装微信客户端")
                } else {
                    val req = SendAuth.Req()
                    req.scope = "snsapi_userinfo"
                    req.state = "wechat_sdk_demo_test"
                    wxApi?.sendReq(req)
                }
            }
        }

        fun bindQQClick() {
            if (account_qq_status.text.equals("未绑定")) {
//                if (!mTencent.isSessionValid) {
//                    mTencent.login(this@AccountManageActivity, "all", loginListener);
//                }
                mTencent.login(this@AccountManageActivity, "all", loginListener);
            }

        }
    }


    var loginListener: IUiListener = object : BaseUiListener() {
        override fun doComplete(values: JSONObject?) {
            Log.d("SDKQQAgentPref", "AuthorSwitch_SDK:" + SystemClock.elapsedRealtime())
            if (values != null) {
                initOpenidAndToken(values)
            }


        }
    }

    fun initOpenidAndToken(jsonObject: JSONObject) {
        try {
            val token =
                jsonObject.getString(com.tencent.connect.common.Constants.PARAM_ACCESS_TOKEN)
            val expires =
                jsonObject.getString(com.tencent.connect.common.Constants.PARAM_EXPIRES_IN)
            val openId = jsonObject.getString(com.tencent.connect.common.Constants.PARAM_OPEN_ID)

            Log.v("yxy", "==qq openId====" + openId)
            if (!TextUtils.isEmpty(token) && !TextUtils.isEmpty(expires)
                && !TextUtils.isEmpty(openId)
            ) {
                mTencent.setAccessToken(token, expires)
                mTencent.setOpenId(openId)
                val user = CacheUtil.getUser()
                if (user != null) {
                    requestViewModel.qqLogin(openId, user.stuPhone)
                }
//                startActivity(
//                    Intent(this, BindingPhoneActivity::class.java).putExtra(
//                        "openId", openId
//                    ).putExtra("loginType", "qq")
//                )
//                finish()
            }
        } catch (e: Exception) {
        }
    }

    private open class BaseUiListener : DefaultUiListener() {
        override fun onComplete(response: Any) {
            if (null == response) {
                Log.v("yxy", "返回为空" + "登录失败")
                return
            }
            val jsonResponse = response as JSONObject
            if (jsonResponse.length() == 0) {
                Log.v("yxy", "返回为空" + "登录失败")
                return
            }
            Log.v("yxy", response.toString() + "登录成功")

            doComplete(response)
        }

        protected open fun doComplete(values: JSONObject?) {

        }

        override fun onError(e: UiError) {


        }

        override fun onCancel() {

        }
    }

}
