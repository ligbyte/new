package com.wendu.wenduyikao.mine

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.model.bean.AddressInfoEntity
import com.wendu.wenduyikao.databinding.ActivityAddressBinding
import com.wendu.wenduyikao.mine.adapter.AddressAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestAddressViewModel
import com.yanzhenjie.recyclerview.SwipeMenuItem
import kotlinx.android.synthetic.main.activity_address.*
import kotlinx.android.synthetic.main.activity_select_education.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.util.dp2px

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/10 8:53 上午
 * @Description:
 */
class AddressActivity : BaseActivity<RequestAddressViewModel, ActivityAddressBinding>() {

    private val PARAMS_CREATE_ADDRESS = 2060
    private val requestViewModel: RequestAddressViewModel by viewModels()
    override fun layoutId() = R.layout.activity_address
    private var areaId = ""
    private var address = ""
    private var user = ""
    private var addressJson = ""
    private var index=0
    private var addressList = arrayListOf<AddressInfoEntity>()
    //适配器
    private val addressAdapter: AddressAdapter by lazy {
        AddressAdapter(
            arrayListOf()
        )
    }
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, ll_address_content)
        tv_toolbar_title.text = "收货地址"
        img_back.setOnClickListener {
            val intent = Intent()
            intent.putExtra("areaId", areaId)
            intent.putExtra("address", address)
            intent.putExtra("user", user)
            intent.putExtra("data", addressJson)
            setResult(RESULT_OK, intent)
            finish()
        }
        index=intent.getIntExtra("index",0)
        mDatabind.click = ProxyClick()
        requestViewModel.getAddressList()
        initRecycleView()
    }

    override fun createObserver() {
        requestViewModel.addressResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {
                    user = it.listData[0].name + "  " + it.listData[0].phone
                    areaId = it.listData[0].id
                    address = it.listData[0].areaText+it.listData[0].address
                    addressJson = GsonUtils.toJson(it.listData[0])
                    addressList = it.listData
//                    initRecycleView(it.listData)

                }
                addressAdapter.data=it.listData
                addressAdapter.notifyDataSetChanged()
            }
        })

        requestViewModel.delAddressResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("删除地址成功")

            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    private fun initRecycleView() {
//         addressAdapter = SelectAddressAdapter(list)

        rlv_address.setSwipeMenuCreator { leftMenu, rightMenu, position ->
            val deleteItem = SwipeMenuItem(this);
            deleteItem.setBackground(R.drawable.shape_menu_bg_red)
                .setText("删除")
                .setTextColor(Color.WHITE)
                .setHeight(dp2px(90))
                .setWidth(170);

            rightMenu.addMenuItem(deleteItem);
        }

        rlv_address.setOnItemMenuClickListener { menuBridge, adapterPosition ->
            menuBridge.closeMenu();
            val info = addressAdapter.data[adapterPosition]
            requestViewModel.delAddress(info.id)
            addressAdapter.data.removeAt(adapterPosition);
            addressAdapter.notifyDataSetChanged()
        }

        //初始化recyclerView
        rlv_address.init(
            LinearLayoutManager(this),
            addressAdapter
        )
        addressAdapter.setPosition(index)
        addressAdapter.notifyDataSetChanged()
        addressAdapter.addChildClickViewIds(R.id.address_item_img_edt)

        addressAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: AddressInfoEntity =
                    adapter.getItem(position) as AddressInfoEntity
                user = info.name + "  " + info.phone
                areaId = info.id
                address = info.areaText+info.address
                addressJson = GsonUtils.toJson(info)
                addressAdapter.setPosition(position)
                addressAdapter.notifyDataSetChanged()
                val intent = Intent()
                intent.putExtra("areaId", areaId)
                intent.putExtra("address", address)
                intent.putExtra("user", user)
                intent.putExtra("data", addressJson)
                intent.putExtra("index", position)
                setResult(RESULT_OK, intent)
                finish()
            }
            setOnItemChildClickListener { adapter, view, position ->
                val info: AddressInfoEntity =
                    adapter.getItem(position) as AddressInfoEntity

                if (view.id == R.id.address_item_img_edt) {
                    startActivityForResult(
                        Intent(this@AddressActivity, CreateAddressActivity::class.java)
                            .putExtra("type", 2)
                            .putExtra("data", GsonUtils.toJson(info)),
                        PARAMS_CREATE_ADDRESS
                    )
                }

            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.v("yxy", "编辑地址信息回调")
        if (resultCode == RESULT_OK) {
            Log.v("yxy", "地址列表刷新")
            requestViewModel.getAddressList()
        }
    }

    inner class ProxyClick() {
        /**
         * 创建地址
         */
        fun gotoCreateAddressClick() {
            startActivityForResult(
                Intent(this@AddressActivity, CreateAddressActivity::class.java)
                    .putExtra("type", 1),
                PARAMS_CREATE_ADDRESS
            )
        }
    }
}