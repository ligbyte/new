package com.wendu.wenduyikao.mine

import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.BalanceRecordInfoEntity
import com.wendu.wenduyikao.databinding.ActivityAccountBalanceBinding
import com.wendu.wenduyikao.mine.adapter.BalanceRecordAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestBalanceViewModel
import kotlinx.android.synthetic.main.activity_account_balance.*
import kotlinx.android.synthetic.main.activity_balance_record.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/12/21 3:59 PM
 * @Description: 充值记录
 */
class BalanceRecordActivity :
    BaseActivity<RequestBalanceViewModel, ActivityAccountBalanceBinding>() {

    override fun layoutId() = R.layout.activity_balance_record


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, balance_record_ll_content)
        tv_toolbar_title.text = "充值记录"
        img_back.setOnClickListener { finish() }
        initRecycleView()
    }

    private fun initRecycleView() {
        val list = arrayListOf<BalanceRecordInfoEntity>()
        for (i in 0 until 5) {
            list.add(BalanceRecordInfoEntity(""))
        }
        val balanceAdapter = BalanceRecordAdapter(list)
        //初始化recyclerView
        balance_record_rlv_info.init(
            LinearLayoutManager(this),
            balanceAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(8f)))
        }
    }
}