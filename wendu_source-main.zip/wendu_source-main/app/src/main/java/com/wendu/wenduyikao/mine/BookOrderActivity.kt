package com.wendu.wenduyikao.mine

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager1
import com.wendu.wenduyikao.app.ext.bindViewPager3
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.databinding.ActivityBookOrderBinding
import com.wendu.wenduyikao.mine.fragment.BookOrderFragment
import com.wendu.wenduyikao.mine.fragment.BookOrderViewModel
import kotlinx.android.synthetic.main.activity_book_order.*
import kotlinx.android.synthetic.main.activity_create_book_order.book_order_ll_content
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/26 9:55 下午
 * @Description: kecheng课程订单
 */
class BookOrderActivity : BaseActivity<BookOrderViewModel, ActivityBookOrderBinding>() {

    override fun layoutId() = R.layout.activity_book_order

    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()

    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, book_order_ll_content)
        tv_toolbar_title.text = "图书订单"
        img_back.setOnClickListener { finish() }
        book_order_view_pager.initActivity(this, fragments)

        //初始化 magic_indicator
        book_order_magic_indicator.bindViewPager1(book_order_view_pager, mDataList)
        initMagicIndicator()
    }


    private fun initMagicIndicator() {
        val typeList = BaseCode.getBookOrderType()
        Log.v("yxy", "typelist" + typeList.size.toString())
        mDataList.addAll(typeList.map { it.label })
        Log.v("yxy", "mDataList" + mDataList.size.toString())
        typeList.forEach {
            fragments.add(BookOrderFragment.newInstance(it.type))


        }
        book_order_magic_indicator.navigator.notifyDataSetChanged()
        book_order_view_pager.adapter?.notifyDataSetChanged()
        book_order_view_pager.offscreenPageLimit = fragments.size
    }
}
