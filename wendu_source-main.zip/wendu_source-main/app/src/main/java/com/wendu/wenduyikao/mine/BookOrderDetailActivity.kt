package com.wendu.wenduyikao.mine

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.lxj.xpopup.XPopup
import com.lxj.xpopup.enums.PopupAnimation
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.stepview.bean.StepBean
import com.wendu.wenduyikao.data.eventbus.RefreshBookOrderEvent
import com.wendu.wenduyikao.data.model.bean.BookOrderEntity
import com.wendu.wenduyikao.data.model.bean.BookOrderItemEntity
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.databinding.ActivityBookOrderDetailBinding
import com.wendu.wenduyikao.dialog.BookOrderExpressDialog
import com.wendu.wenduyikao.discovery.BookDetailActivity
import com.wendu.wenduyikao.discovery.adapter.BookOrderInfoAdapter
import com.wendu.wenduyikao.mine.fragment.BookOrderViewModel
import com.wendu.wenduyikao.question.PayWayActivity
import com.wendu.wenduyikao.ui.home.CoursePayActivity
import com.wendu.wenduyikao.util.GlideHelper
import kotlinx.android.synthetic.main.activity_book_order_detail.*
import kotlinx.android.synthetic.main.activity_course_pay.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/29 5:02 下午
 * @Description: 图书d订单详情
 */
class BookOrderDetailActivity : BaseActivity<BookOrderViewModel, ActivityBookOrderDetailBinding>() {
    private val PARAMS_SELECT_ADDRESS = 2090
    private val requestViewModel: BookOrderViewModel by viewModels()
    override fun layoutId() = R.layout.activity_book_order_detail
    private var expressInfo = ""
    private var expressNo = ""
    private var orderId = ""
    private var price = ""
    private var status = 0
    private var bookList = arrayListOf<BookOrderItemEntity>()
    private var areaId = ""
    private var addressJson = ""
    private var courseOrderId = ""
    private var isNeedUpdateAddress=false
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, book_order_detail_ll_content)
        tv_toolbar_title.text = "订单详情"
        img_back.setOnClickListener { finish() }
        courseOrderId=intent.getStringExtra("orderId")?:""
        if(StringUtil.isNotBlank(courseOrderId)){
            requestViewModel.getBookOrderDetailById(courseOrderId)
        }else{
            setBookOrderData()
        }
        isNeedUpdateAddress=intent.getBooleanExtra("isNeedUpdateAddress",false)
        mDatabind.click = ProxyClick()
    }

    private fun setBookOrderData() {
        expressInfo = ""
        val json = intent.getStringExtra("data")
        if (StringUtil.isBlank(json)) {
            return
        }
        val info = GsonUtils.fromJson<BookOrderEntity>(json, BookOrderEntity::class.java)
        mDatabind.info = info

        if (StringUtil.isNotBlank(info.orderAreaAddress)) {
            book_order_detail_address.text = info.orderArea + info.orderAreaAddress
        } else {
            book_order_detail_address.text = ""
        }
        if (StringUtil.isNotBlank(info.orderAreaName)) {
            ("收件人:" + info.orderAreaName + "  联系电话:" + info.orderAreaPhone).also {
                book_order_detail_user.text = it
            }
        } else {
            book_order_detail_user.text = ""
        }
        ("-" + StringUtil.formatDoublePrice(info.discountAmount)).also {
            book_order_detail_tv_discountamount.text = it
        }
        expressInfo += "订单号：" + info.id + "\n"
        expressInfo += "物流公司：" + info.expressCompany + "\n"
        expressInfo += "物流单号：" + info.expressNumber + "\n"
        expressNo = info.expressNumber
        price = StringUtil.formatDouble(info.actualPrice)
        orderId = info.id
        bookList = info.jsonObjectList
        status = info.status
        order_detail_tv_step.text = StringUtil.getBookOrderByType(info.status)
        initCarRecycleView(info.bookOrderItemList)
        initOrderStatusView(info.status, info.orderSource)
        initOrderStepView(info.status)
    }

    private fun initOrderStepView(status: Int) {

        when (status) {
            0, 1 -> {
                order_step_tv_label2.text = "等待发货"
                order_step_tv_1.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_2.setBackgroundResource(R.drawable.shape_bg_tran_oval_line)
                order_step_tv_3.setBackgroundResource(R.drawable.shape_bg_tran_oval_line)
                order_step_line2.setBackgroundColor(Color.parseColor("#ABC6FF"))
                order_step_line1.setBackgroundColor(Color.parseColor("#ABC6FF"))
                order_step_tv_label1.setTextColor(Color.parseColor("#ffffff"))
                order_step_tv_1.setTextColor(Color.parseColor("#3D7DFF"))
            }
            2 -> {
                order_step_tv_label2.text = "等待发货"
                order_step_tv_1.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_2.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_3.setBackgroundResource(R.drawable.shape_bg_tran_oval_line)
                order_step_line2.setBackgroundColor(Color.parseColor("#ABC6FF"))
                order_step_line1.setBackgroundColor(Color.parseColor("#ffffff"))
                order_step_tv_label2.setTextColor(Color.parseColor("#ffffff"))
                order_step_tv_1.setTextColor(Color.parseColor("#3D7DFF"))
                order_step_tv_2.setTextColor(Color.parseColor("#3D7DFF"))
            }
            3, 6 -> {
                if (status == 3) {
                    order_step_tv_label2.text = "等待收货"
                } else {
                    order_step_tv_label2.text = "部分发货"
                }
                order_step_tv_1.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_2.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_3.setBackgroundResource(R.drawable.shape_bg_tran_oval_line)
                order_step_line2.setBackgroundColor(Color.parseColor("#ABC6FF"))
                order_step_line1.setBackgroundColor(Color.parseColor("#ffffff"))
                order_step_tv_label2.setTextColor(Color.parseColor("#ffffff"))
                order_step_tv_1.setTextColor(Color.parseColor("#3D7DFF"))
                order_step_tv_2.setTextColor(Color.parseColor("#3D7DFF"))
            }
            4 -> {
                order_step_tv_label2.text = "等待收货"
                order_step_tv_1.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_2.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_tv_3.setBackgroundResource(R.drawable.shape_bg_white_oval)
                order_step_line2.setBackgroundColor(Color.parseColor("#ffffff"))
                order_step_line1.setBackgroundColor(Color.parseColor("#ffffff"))
                order_step_tv_label3.setTextColor(Color.parseColor("#ffffff"))
                order_step_tv_1.setTextColor(Color.parseColor("#3D7DFF"))
                order_step_tv_2.setTextColor(Color.parseColor("#3D7DFF"))
                order_step_tv_3.setTextColor(Color.parseColor("#3D7DFF"))
            }
        }
    }

    private fun initOrderStatusView(status: Int, orderSource: Int) {
        //已完成：查看物流
        if (status == 2) {
            rl_book_order_save_address.visibility = View.VISIBLE
            book_order_detail_ll_menu.visibility = View.GONE
        } else {
            rl_book_order_save_address.visibility = View.GONE
            book_order_detail_ll_menu.visibility = View.VISIBLE
        }
        //去支付
        if (status == 0 && orderSource == 1) {
            book_order_detail_pay.visibility = View.VISIBLE
        } else {
            book_order_detail_pay.visibility = View.GONE
        }
        //关闭交易
        if (status == 0 && orderSource == 1) {
            book_order_detail_close.visibility = View.VISIBLE
        } else {
            book_order_detail_close.visibility = View.GONE
        }

        //查看物流
        if (status == 3 || status == 4 || status == 6) {
            book_order_detail_check.visibility = View.VISIBLE
        } else {
            book_order_detail_check.visibility = View.GONE
        }
        //确认收货
        if (status == 3) {
            book_order_detail_receive.visibility = View.VISIBLE
        } else {
            book_order_detail_receive.visibility = View.GONE
        }


//        initStepView(status)
    }

    fun initStepView(status: Int) {
        val stepsBeanList: MutableList<StepBean> = ArrayList()
        var state0: Int = 1
        var state1: Int = 1
        var state2: Int = 1
        when (status) {
            0 -> {
                state0 = 1
                state1 = -1
                state2 = -1
            }
            1 -> {
                state0 = -1
                state1 = -1
                state2 = -1
            }
            2 -> {
                state0 = 1
                state1 = 1
                state2 = -1
            }
            3, 6 -> {
                state0 = 1
                state1 = 1
                state2 = -1
            }
            4 -> {
                state0 = 1
                state1 = 1
                state2 = 1
            }
        }
        val stepBean0 = StepBean("买家付款", "", state0)
        var stepBean1: StepBean? = null

        stepBean1 = when (status) {
            6 -> StepBean("部分发货", "", state1)
            4 -> StepBean("等待收货", "", state1)
            3 -> StepBean("等待收货", "", state1)
            else -> {
                StepBean("等待发货", "", state1)
            }
        }


        val stepBean2 = StepBean("交易完成", "", state2)
        stepsBeanList.add(stepBean0)
        stepsBeanList.add(stepBean1)
        stepsBeanList.add(stepBean2)

        hs_view.setStepViewTexts(stepsBeanList).setTextSize(12)//set textSize
            .setStepsViewIndicatorCompletedLineColor(
                ContextCompat.getColor(
                    getBaseContext(), R.color.white
                )
            )//设置StepsViewIndicator完成线的颜色
            .setStepsViewIndicatorUnCompletedLineColor(
                ContextCompat.getColor(
                    getBaseContext(), R.color.font_light_blue
                )
            )//设置StepsViewIndicator未完成线的颜色
            .setStepViewComplectedTextColor(
                ContextCompat.getColor(
                    getBaseContext(), R.color.white
                )
            )//设置StepsView text完成线的颜色
            .setStepViewUnComplectedTextColor(
                ContextCompat.getColor(
                    getBaseContext(), R.color.font_light_blue
                )
            )//设置StepsView text未完成线的颜色
            .setStepsViewIndicatorCompleteIcon(
                ContextCompat.getDrawable(
                    getBaseContext(), R.drawable.shape_bg_white_oval
                )
            )//设置StepsViewIndicator CompleteIcon
            .setStepsViewIndicatorDefaultIcon(
                ContextCompat.getDrawable(
                    getBaseContext(), R.drawable.shape_bg_tran_oval_line
                )
            )//设置StepsViewIndicator DefaultIcon
            .setStepsViewIndicatorAttentionIcon(
                ContextCompat.getDrawable(
                    getBaseContext(), R.drawable.attention
                )
            );//设置StepsViewIndicator AttentionIcon

    }

    private fun initCarRecycleView(list: ArrayList<ShopCarInfoEntity>) {
        val shopCarAdapter = BookOrderInfoAdapter(list)
        //初始化recyclerView
        book_order_detail_rlv_book.init(
            LinearLayoutManager(this), shopCarAdapter
        )

        shopCarAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity = adapter.getItem(position) as ShopCarInfoEntity
                startActivity(
                    Intent(this@BookOrderDetailActivity, BookDetailActivity::class.java).putExtra(
                        "data", GsonUtils.toJson(info.wdBook)
                    ).putExtra(
                        "bookId", info.bookId
                    )
                )
            }


        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == PARAMS_SELECT_ADDRESS) {
                addressJson = data?.getStringExtra("data").toString()
                areaId = data?.getStringExtra("areaId").toString()
                val address = data?.getStringExtra("address")
                val user = data?.getStringExtra("user")
                val phone = data?.getStringExtra("phone")
                Log.v("yxy","=addressJson="+addressJson)
                if (StringUtil.isNotBlank(address)) {
                    book_order_detail_address.text = address
                }
                if (StringUtil.isNotBlank(user)) {
                    book_order_detail_user.text = user
                }
            }
        }
    }

    override fun createObserver() {
        requestViewModel.confirmOrderResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("确认收货成功")
                EventBus.getDefault().post(RefreshBookOrderEvent())
                requestViewModel.getBookOrderListById(orderId)
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.cancelOrderResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("取消交易成功")
                EventBus.getDefault().post(RefreshBookOrderEvent())
                requestViewModel.getBookOrderListById(orderId)
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.bookOrderListResult.observe(this, Observer {
            if (it.isSuccess) {
                val info = it.listData[0]
                mDatabind.info = info
                expressInfo += "订单号：" + info.id + "\n"
                expressInfo += "物流公司：" + info.expressCompany + "\n"
                expressInfo += "物流单号：" + info.expressNumber + "\n"
                expressNo = info.expressNumber
                price = info.actualPrice.toString()
                orderId = info.id
                initCarRecycleView(info.bookOrderItemList)
                initOrderStatusView(info.status, info.orderSource)
            } else {
                showMessage(it.errMessage)
            }
        })

        requestViewModel.updateAddressResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("修改成功")
                EventBus.getDefault().post(RefreshBookOrderEvent())
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })


        requestViewModel.bookOrderDetail.observe(this) { it ->
            parseState(it, {
                if (it.wdBookOrder != null) {
                    val info = it.wdBookOrder
                    mDatabind.info = info

                    if (StringUtil.isNotBlank(info.orderAreaAddress)) {
                        book_order_detail_address.text = info.orderArea + info.orderAreaAddress
                    } else {
                        book_order_detail_address.text = ""
                    }
                    if (StringUtil.isNotBlank(info.orderAreaName)) {
                        ("收件人:" + info.orderAreaName + "  联系电话:" + info.orderAreaPhone).also {
                            book_order_detail_user.text = it
                        }
                    } else {
                        book_order_detail_user.text = ""
                    }
                    ("-" + StringUtil.formatDoublePrice(info.discountAmount)).also {
                        book_order_detail_tv_discountamount.text = it
                    }
                    expressInfo += "订单号：" + info.id + "\n"
                    expressInfo += "物流公司：" + info.expressCompany + "\n"
                    expressInfo += "物流单号：" + info.expressNumber + "\n"
                    expressNo = info.expressNumber
                    price = StringUtil.formatDouble(info.actualPrice)
                    orderId = info.id
                    bookList = info.jsonObjectList
                    status = info.status
                    order_detail_tv_step.text = StringUtil.getBookOrderByType(info.status)
                    initCarRecycleView(info.bookOrderItemList)
                    initOrderStatusView(info.status, info.orderSource)
                    initOrderStepView(info.status)
                }

            })
        }
    }

    inner class ProxyClick() {
        fun seeExpressClick() {

            if (bookList != null) {
                val customPopup: BookOrderExpressDialog =
                    BookOrderExpressDialog(this@BookOrderDetailActivity, bookList)

                Log.v("yxy", "=bookList=33333=" + bookList.size)
                XPopup.Builder(this@BookOrderDetailActivity)
                    .popupAnimation(PopupAnimation.ScaleAlphaFromCenter).autoOpenSoftInput(false)
                    .asCustom(customPopup).show()
            } else {
                ToastUtils.showShort("暂无发货信息")
            }

//            showMessage(expressInfo, "物流信息", "确定", {
//
//            }, "复制单号", {
//
//                //获取剪贴板管理器：
//                //获取剪贴板管理器：
//                val cm: ClipboardManager =
//                    getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
//                // 创建普通字符型ClipData
//                // 创建普通字符型ClipData
//                val mClipData: ClipData = ClipData.newPlainText("Label", expressNo)
//                // 将ClipData内容放到系统剪贴板里。
//                // 将ClipData内容放到系统剪贴板里。
//                cm.setPrimaryClip(mClipData)
//                ToastUtils.showShort("复制到剪切板成功")
//            })
        }

        fun confirmReceipt() {
            showMessage("确认收到货物后，才可点击确认收货？", positiveAction = {
                if (StringUtil.isNotBlank(orderId)) {
                    requestViewModel.confirmOrder(orderId)
                }

            })
        }

        fun selectAddress() {
            if(status==2){
                startActivityForResult(
                    Intent(
                        this@BookOrderDetailActivity, AddressActivity::class.java
                    ), PARAMS_SELECT_ADDRESS
                )
            }

        }

        fun gotoPay() {
            startActivity(
                Intent(
                    this@BookOrderDetailActivity, PayWayActivity::class.java
                ).putExtra("isFromOrder", true).putExtra("isBookOrder", true)
                    .putExtra("price", price).putExtra("orderId", orderId)
            )
            finish()
        }

        fun closeOrder() {
            requestViewModel.cancelOrderById(orderId)
        }


        /**
         * 保存地址
         */
        fun updateOrderAddress() {
            val bookOrderId = orderId
            val orderAreaId = areaId
            if (StringUtil.isEmpty(areaId) && StringUtil.isNotBlank(book_order_detail_address.text.toString())) {
                ToastUtils.showShort("保存成功")
                finish()
            } else {
                requestViewModel.updateOrderAddress(bookOrderId, orderAreaId)
            }


        }
    }

}