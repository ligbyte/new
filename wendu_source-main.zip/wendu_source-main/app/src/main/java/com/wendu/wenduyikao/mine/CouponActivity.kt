package com.wendu.wenduyikao.mine

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager2
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.databinding.ActivityCouponBinding
import com.wendu.wenduyikao.mine.fragment.CouponCenterFragment
import com.wendu.wenduyikao.viewmodel.request.CouponCenterViewModel
import kotlinx.android.synthetic.main.activity_coupon.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 8:41 下午
 * @Description: 有回暖
 */
class CouponActivity : BaseActivity<CouponCenterViewModel, ActivityCouponBinding>() {
    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()

    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()

    override fun layoutId(): Int {
        return R.layout.activity_coupon
    }


    override fun initView(savedInstanceState: Bundle?) {

        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, coupon_ll_content)
        tv_toolbar_title.text = "优惠券"
        img_back.setOnClickListener { finish() }
        coupon_view_pager.initActivity(this, fragments)

        //初始化 magic_indicator
        coupon_magic_indicator.bindViewPager2(coupon_view_pager, mDataList)
        initMagicIndicator()
    }


    private fun initMagicIndicator() {
        val typeList = BaseCode.getCouponType()
        Log.v("yxy", "typelist" + typeList.size.toString())
        mDataList.addAll(typeList.map { it.label })
        Log.v("yxy", "mDataList" + mDataList.size.toString())
        typeList.forEach {
            fragments.add(CouponCenterFragment.newInstance(it.type))


        }
        coupon_magic_indicator.navigator.notifyDataSetChanged()
        coupon_view_pager.adapter?.notifyDataSetChanged()
        coupon_view_pager.offscreenPageLimit = fragments.size
    }
}
