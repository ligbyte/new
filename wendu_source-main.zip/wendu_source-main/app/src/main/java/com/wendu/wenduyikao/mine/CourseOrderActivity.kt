package com.wendu.wenduyikao.mine

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager2
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.ext.setUiTheme
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.model.bean.DotEntity
import com.wendu.wenduyikao.databinding.ActivityCourseOrderBinding
import com.wendu.wenduyikao.mine.fragment.CourseOrderFragment
import com.wendu.wenduyikao.viewmodel.request.CourseOrderViewModel
import com.wendu.wenduyikao.viewmodel.request.RequestDotViewModel
import kotlinx.android.synthetic.main.activity_course_order.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.fragment_main.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/10/21 5:31 PM
 * @Description: 课程订单
 */
class CourseOrderActivity : BaseActivity<CourseOrderViewModel, ActivityCourseOrderBinding>() {

    override fun layoutId() = R.layout.activity_course_order

    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()

    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()
    private val requestViewModel: RequestDotViewModel by viewModels()

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, course_order_ll_content)
        tv_toolbar_title.text = "课程订单"
        img_back.setOnClickListener { finish() }
        course_order_view_pager.initActivity(this, fragments)

        //初始化 magic_indicator
        course_order_magic_indicator.bindViewPager2(course_order_view_pager, mDataList)
        initMagicIndicator()
        requestViewModel.queryStudentNews()
    }


    override fun createObserver() {
        requestViewModel.dotResult.observe(this) { it ->
            parseState(it, {
                Log.d("TAG", "createObserver dotResult: " + it.feedback)
                val bean = DotEntity(it.feedback,it.my,it.order,it.orderNumber)
                if (it.orderNumber > 0){
                    dot_tag_order_num.visibility = View.VISIBLE
                    dot_tag_order_num.setText(it.orderNumber.toString())
                }else{
                    dot_tag_order_num.visibility = View.GONE
                }
//                EventBus.getDefault().post(bean)
            }, {
            })
        }


    }

    private fun initMagicIndicator() {
        val typeList = BaseCode.getCourseOrderType()
        Log.v("yxy", "typelist" + typeList.size.toString())
        mDataList.addAll(typeList.map { it.label })
        Log.v("yxy", "mDataList" + mDataList.size.toString())
        typeList.forEach {
            fragments.add(CourseOrderFragment.newInstance(it.type))


        }
        course_order_magic_indicator.navigator.notifyDataSetChanged()
        course_order_view_pager.adapter?.notifyDataSetChanged()
        course_order_view_pager.offscreenPageLimit = fragments.size
    }
}
