package com.wendu.wenduyikao.mine

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.bigkoo.pickerview.builder.OptionsPickerBuilder
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonObject
import com.hjq.permissions.Permission
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.hideSoftKeyboard
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.LocationUtils
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.AddressInfoEntity
import com.wendu.wenduyikao.data.model.bean.Area
import com.wendu.wenduyikao.databinding.ActivityCreateAddressBinding
import com.wendu.wenduyikao.util.HasStoragePermissionListener
import com.wendu.wenduyikao.util.PermissionHelper
import com.wendu.wenduyikao.viewmodel.request.RequestAddressViewModel
import kotlinx.android.synthetic.main.activity_create_address.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/10 9:19 上午
 * @Description: 新建地址
 */
class CreateAddressActivity :
    BaseActivity<RequestAddressViewModel, ActivityCreateAddressBinding>() {
    private val requestViewModel: RequestAddressViewModel by viewModels()
    private var type = 1  //1 新建 2 编辑
    override fun layoutId() = R.layout.activity_create_address
    private var provinceItems = mutableListOf<Area>()
    private var cityItems = mutableListOf<MutableList<Area>>()
    private var areaItems = mutableListOf<MutableList<MutableList<Area>>>()
    private var areaId = ""
    private var addressId = ""
    private var cityStr = ""//行政区域地址
    private var addressStr = ""//详细地址
    private val LOCATION_PERMISSION = 2
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, ll_create_address_content)
        tv_toolbar_title.text = "收货地址"
        type = intent.getIntExtra("type", 1)
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        requestViewModel.getWdOrderAreaList()
        setData()
    }

    private fun setData() {
        if (type == 2) {
            val json = intent.getStringExtra("data")
            if (StringUtil.isBlank(json)) {
                return
            }
            val info = GsonUtils.fromJson<AddressInfoEntity>(json, AddressInfoEntity::class.java)
            if (info == null) {
                return
            }
            Log.v("yxy", "=json==" + json)
            addressId = info.id
            areaId = info.areaNo
            create_address_name.setText(info.name)
            create_address_phone.setText(info.phone)
            create_address_location.setText(info.address)
            create_address_city.setText(info.areaText)
            create_address_code.setText(info.code)
            step_one_check_box.isChecked = info.isdefault == "0"
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == 2023) {
                cityStr = data?.getStringExtra("cityStr") ?: ""
                addressStr = data?.getStringExtra("addressStr") ?: ""
                create_address_city.text = cityStr
                create_address_location.setText(addressStr)
            }
        }
    }

    override fun createObserver() {
        requestViewModel.createAddressResult.observe(this, Observer {
            if (it.success) {
                setResult(RESULT_OK)
                ToastUtils.showShort("新增地址成功")
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.udpateAddressResult.observe(this, Observer {
            if (it.success) {
                Log.v("yxy", "编辑地址信息")
                setResult(RESULT_OK)
                ToastUtils.showShort("编辑地址成功")
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.provinceCityResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {

                    it.listData.forEach { province ->
                        val cityList = mutableListOf<Area>()
                        //存放省内所有辖区
                        val areaList = mutableListOf<MutableList<Area>>()
                        province.cityList.forEach { city ->
                            cityList.add(Area(city.id, city.pid, city.text))
                            //存放市内辖区
                            val areas = mutableListOf<Area>()
                            city.list.forEach { area ->
                                areas.add(area)
                            }
                            areaList.add(areas)
                        }
                        //添加省份
                        provinceItems.add(Area(province.id, province.pid, province.text))
                        //添加市区
                        cityItems.add(cityList)
                        //添加辖区
                        areaItems.add(areaList)
                    }

                }

            }
        })

    }

    private fun showPickerView() { // 弹出选择器
        val pvOptions = OptionsPickerBuilder(
            this
        ) { options1, options2, options3, v -> //返回的分别是三个级别的选中位置
            //省份
            provinceItems[options1]
            //城市
            cityItems[options1][options2]
            //辖区
            areaItems[options1][options2][options3]
            //获得选择的数据
            var tx: String =
                provinceItems[options1].pickerViewText + cityItems[options1][options2].pickerViewText + areaItems[options1][options2][options3].pickerViewText
            areaId = areaItems[options1][options2][options3].id

            create_address_city.text = tx
        }
            .setTitleText("选择地区")
            .setDividerColor(Color.GRAY)
            .setTextColorCenter(Color.BLUE) //设置选中项文字颜色
            .setContentTextSize(20)
            .build<Area>()

        pvOptions.setPicker(provinceItems, cityItems, areaItems) //三级选择器
        pvOptions.show()
    }

    inner class ProxyClick() {
        fun selectPrinceCity() {
            hideSoftKeyboard(this@CreateAddressActivity)
            showPickerView()
        }

        /**
         * 去定位
         */
        fun gotoLocation() {
            if (LocationUtils.isLocationEnabled()) {
                PermissionHelper.checkMyPermission(
                    this@CreateAddressActivity,
                    object : HasStoragePermissionListener {
                        override fun hasPermission(isAll: Boolean) {

                            startActivityForResult(
                                Intent(
                                    this@CreateAddressActivity,
                                    LocationMapActivity::class.java
                                ), 2023
                            )
                        }

                        override fun noPermission() {

                        }

                        override fun cancel() {
                        }
                    },
                    Permission.ACCESS_FINE_LOCATION, Permission.ACCESS_COARSE_LOCATION
                )
            } else {
                showMessage("", "系统检测到未开启GPS定位服务,请开启", "确定", {
                    val i = Intent()
                    i.action = Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    startActivityForResult(i, LOCATION_PERMISSION)
                }, "取消", {
                    Log.v("yxy", "hasPermission    cancel")
                })

            }

        }

        /**
         * 创建地址
         */
        fun saveAddressClick() {
            val city = create_address_city.text.toString()
            val location = create_address_location.text.toString()

            val name = create_address_name.text.toString()
            val phone = create_address_phone.text.toString()
            val code = create_address_code.text.toString()

            if (StringUtil.isBlank(name)) {
                ToastUtils.showShort("请输入收货人姓名")
                return
            }
            if (StringUtil.isBlank(phone)) {
                ToastUtils.showShort("请输入收货人手机号")
                return
            }
            if (StringUtil.isBlank(city)) {
                ToastUtils.showShort("请输入收货人地区")
                return
            }
            if (StringUtil.isBlank(location)) {
                ToastUtils.showShort("请输入收货人详细地址")
                return
            }
            if (StringUtil.isBlank(code)) {
                ToastUtils.showShort("请输入收货人邮政编码")
                return
            }
            val json = JsonObject()
            json.addProperty("address", location)
            json.addProperty("area", areaId)
            json.addProperty("areaText", city)
            json.addProperty("code", code)
            json.addProperty("name", name)
            json.addProperty("phone", phone)
            var isDefault = 0
            isDefault = if (step_one_check_box.isChecked) {
                0
            } else {
                1
            }

            json.addProperty("isdefault", isDefault.toString())
            if (type == 1) {
                requestViewModel.addAddress(json)
            } else {
                json.addProperty("id", addressId)
                requestViewModel.updateAddress(json)
            }

        }
    }
}