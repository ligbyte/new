package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.hideSoftKeyboard
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.ExchangeRecordEntity
import com.wendu.wenduyikao.databinding.ActivityExchangeCourseBinding
import com.wendu.wenduyikao.mine.adapter.ExchangeCourseRecordAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestExchangeViewModel
import kotlinx.android.synthetic.main.activity_exchange_course.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.state.ResultState

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/9 3:02 下午
 * @Description: 兑换课程
 */
class ExchangeCourseActivity :
    BaseActivity<RequestExchangeViewModel, ActivityExchangeCourseBinding>() {

    private val requestViewModel: RequestExchangeViewModel by viewModels()
    private val PARAMS_EXCHANGE_CODE = 2071
    override fun layoutId() = R.layout.activity_exchange_course


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, ll_exchange_content)
        tv_toolbar_title.text = "兑换课程"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        requestViewModel.getCdkRecordList()
    }

    override fun createObserver() {
        requestViewModel.checkCDkoResult.observe(this, Observer { resultState ->
            when (resultState) {
                is ResultState.Success -> {
                    if (resultState.data != null) {
                        startActivityForResult(
                            Intent(this, ExchangeCourseDetailActivity::class.java)
                                .putExtra("data", GsonUtils.toJson(resultState.data))
                                .putExtra(
                                    "cdkCode",
                                    exchange_course_edt.text.toString()
                                ),
                            PARAMS_EXCHANGE_CODE
                        )
                    } else {
                        Log.v("yxy", "==data is empty=")
                    }
                    exchange_course_edt.setText("")
                }

                is ResultState.Error -> {
                    ToastUtils.showShort(resultState.error.errorMsg)
                }

            }

        })

        requestViewModel.exchangeRecordResult.observe(this, Observer {
            if (it.isSuccess) {
                if (!it.isEmpty) {
                    initRecycleView(it.listData)
                }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == PARAMS_EXCHANGE_CODE) {
            requestViewModel.getCdkRecordList()
        }
    }

    private fun initRecycleView(list: ArrayList<ExchangeRecordEntity>) {
        val recordAdapter = ExchangeCourseRecordAdapter(list)
        //初始化recyclerView
        exchange_course_rlv_record.init(
            LinearLayoutManager(this),
            recordAdapter
        )
        recordAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ExchangeRecordEntity =
                    adapter.getItem(position) as ExchangeRecordEntity

            }
        }
    }

    inner class ProxyClick() {
        /**
         * 兑换
         */
        fun exchangeClick() {
            hideSoftKeyboard(this@ExchangeCourseActivity)
            val code = exchange_course_edt.text.toString()
//PZLHKN5B
//53DHUDZ2 1
            if (StringUtil.isBlank(code)) {
                ToastUtils.showShort("请输入兑换码")
                return
            }
            requestViewModel.checkCDK(code)
        }
    }
}