package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.CheckCDkResultEntity
import com.wendu.wenduyikao.data.model.bean.WdClassesBooks
import com.wendu.wenduyikao.databinding.ActivityExchangeCourseDetailBinding
import com.wendu.wenduyikao.mine.adapter.CourseBookAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestExchangeViewModel
import kotlinx.android.synthetic.main.activity_exchange_course_detail.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/11 9:06 下午
 * @Description: 兑换详情
 */
class ExchangeCourseDetailActivity :
    BaseActivity<RequestExchangeViewModel, ActivityExchangeCourseDetailBinding>() {

    private val requestViewModel: RequestExchangeViewModel by viewModels()
    private val PARAMS_SELECT_ADDRESS = 2070
    private var areaId = ""
    private var flg = 0
    private var cdkCode = ""
    override fun layoutId() = R.layout.activity_exchange_course_detail

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, exchange_course_detail_content)
        tv_toolbar_title.text = "兑换课程"
        img_back.setOnClickListener { finish() }
        cdkCode = intent.getStringExtra("cdkCode").toString()
        mDatabind.click = ProxyClick()
        setInfoData()
    }

    private fun setInfoData() {
        val json = intent.getStringExtra("data")
        if (StringUtil.isBlank(json)) {
            return
        }
        val info = GsonUtils.fromJson(json, CheckCDkResultEntity::class.java)
        if (info == null) {
            return
        }
        flg = info.flg
        if (flg == 0) {
            exchange_course_ll_address.visibility = View.VISIBLE
            exchange_course_address.text = "请选择收货地址"
            exchange_course_ll_flg.visibility = View.VISIBLE
        } else {
            exchange_course_ll_address.visibility = View.GONE
            exchange_course_ll_flg.visibility = View.GONE
        }
        if (info.wdClasses != null) {
            Log.v("yxy", "info.wdClasses.classesName---" + info.wdClasses.classesName)
            tv_course_name.text = info.wdClasses.classesName
            Glide.with(this).load(info.wdClasses.classesCover)
                .placeholder(R.drawable.ic_default_pic1).into(iv_course_bg)
        }
        if (info.wdClassesSales != null) {
            tv_price.setText(StringUtil.formatDoublePrice(info.wdClassesSales.fficialPrice))
            tv_all_price.setText(StringUtil.formatDoublePrice(info.wdClassesSales.fficialPrice))
        }

        if (info.wdClassesBooksList != null) {
            initCourseBookRecycleView(info.wdClassesBooksList)
        }

    }


    private fun initCourseBookRecycleView(bookList: ArrayList<WdClassesBooks>) {
        val courseBookAdapter = CourseBookAdapter(bookList)
        //初始化recyclerView
        exchange_course_rlv_book.init(
            LinearLayoutManager(this),
            courseBookAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
        }
        courseBookAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: WdClassesBooks =
                    adapter.getItem(position) as WdClassesBooks
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK && requestCode == PARAMS_SELECT_ADDRESS) {
            areaId = data?.getStringExtra("areaId").toString()
            val address = data?.getStringExtra("address")
            val user = data?.getStringExtra("user")

            if (StringUtil.isNotBlank(address)) {
                exchange_course_address.setText(address)
            }
            if (StringUtil.isNotBlank(user)) {
                exchange_course_user.setText(user)
            }
        }
    }

    override fun createObserver() {
        requestViewModel.exchangeCourseResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("兑换成功")
                setResult(RESULT_OK)
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick {
        fun exchangeCourse() {
            val json = JsonObject()
            json.addProperty("cdkCode", cdkCode)
            json.addProperty("gmqd",5)
            if (flg == 0) {
                json.addProperty("areaId", areaId)
            }
            requestViewModel.exchangeCourse(json)
        }

        fun gotoSelectAddress() {
            startActivityForResult(
                Intent(
                    this@ExchangeCourseDetailActivity,
                    AddressActivity::class.java
                ), PARAMS_SELECT_ADDRESS
            )
        }

    }
}