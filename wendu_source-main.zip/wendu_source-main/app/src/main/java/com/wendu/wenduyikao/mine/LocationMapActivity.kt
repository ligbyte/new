package com.wendu.wenduyikao.mine

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.amap.api.location.AMapLocation
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.amap.api.maps.AMap
import com.amap.api.maps.AMapUtils
import com.amap.api.maps.CameraUpdateFactory
import com.amap.api.maps.MapsInitializer
import com.amap.api.maps.model.*
import com.amap.api.maps.model.animation.AlphaAnimation
import com.amap.api.maps.model.animation.Animation
import com.amap.api.services.core.LatLonPoint
import com.amap.api.services.core.PoiItem
import com.amap.api.services.help.Tip
import com.amap.api.services.poisearch.PoiResult
import com.amap.api.services.poisearch.PoiSearch
import com.bigkoo.pickerview.builder.OptionsPickerBuilder
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.SPUtils
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.hjq.permissions.Permission
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.hideSoftKeyboard
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.LocationUtils
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.model.bean.Area
import com.wendu.wenduyikao.data.model.bean.PositionItem
import com.wendu.wenduyikao.databinding.ActivityLocationMapBinding
import com.wendu.wenduyikao.util.EmptyAdapterHelper
import com.wendu.wenduyikao.util.HasStoragePermissionListener
import com.wendu.wenduyikao.util.PermissionHelper
import com.wendu.wenduyikao.viewmodel.request.RequestLocationViewModel
import kotlinx.android.synthetic.main.activity_create_address.*
import kotlinx.android.synthetic.main.activity_location_map.*
import kotlinx.android.synthetic.main.activity_un_subscribe_step_two.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import java.math.BigDecimal


/**
 * @Author     : xiaoyangyan
 * @Time       : 2023/2/11 15:20
 * @Description: 定位地址
 */
class LocationMapActivity : BaseActivity<RequestLocationViewModel, ActivityLocationMapBinding>() {
    private val requestViewModel: RequestLocationViewModel by viewModels()
    private var provinceItems = mutableListOf<Area>()
    private var cityItems = mutableListOf<MutableList<Area>>()
    private var areaItems = mutableListOf<MutableList<MutableList<Area>>>()
    private var areaId = ""
    private var addressId = ""
    private var searchCity = ""
    private var locationLat: Double = 0.0
    private var locationLng: Double = 0.0


    companion object {
        const val SEARCH_REQUEST_CODE = 3001
        const val POSITION_REQUEST_CODE = 3002
        const val SELECT_POSITION = "SELECT_POSITION"
        const val SURE_POSITION = "SURE_POSITION"
    }

    //地图交互核心方法
    private lateinit var aMap: AMap

    //地图中心点
    private lateinit var centerMaker: Marker

    //定位适配器
    private lateinit var adapter: LocationAdapter
    private lateinit var adapterSearch: LocationSearchAdapter

    //定位列表数据
    private var mLocationList: MutableList<PositionItem> = ArrayList()
    private var mLocationSearchList: MutableList<PositionItem> = ArrayList()

    //判断是来自地图还是列表的点击
    private var isTouch = false //false 不进行附件搜索
    override fun layoutId() = R.layout.activity_location_map

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, location_map_ll_content)
        tv_toolbar_title.text = "定位地址"
        img_back.setOnClickListener { finish() }
        requestViewModel.getWdOrderAreaList()
        mDatabind.click = ProxyClick()
//        MobileUtil.sHA1(this)




        MapsInitializer.updatePrivacyShow(this, true, true);
        MapsInitializer.updatePrivacyAgree(this, true);
        aMap = basicMap.map
        basicMap.onCreate(savedInstanceState)
        //地图初始化
        initMap(aMap)
        initLocationAddress()

        //设置地图拖动监听
        aMap.setOnMapTouchListener {
            isTouch = true
        }
        aMap.setOnCameraChangeListener(object : AMap.OnCameraChangeListener {
            override fun onCameraChangeFinish(cameraPosition: CameraPosition) {
                if (isTouch) {
                    val latLng = cameraPosition.target
                    mLocationList.clear()
                    adapter.setNewInstance(mLocationList)
                    //查找附近数据
                    searchNearby(latLng)
                }
            }

            override fun onCameraChange(p0: CameraPosition?) {
            }

        })
        getCurrentLocation { locationSuccess(it) }
        edt_location_address.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                Log.v("yxy", "-开始输入-")
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                Log.v("yxy", "afterTextChanged" + s.toString())
                mLocationSearchList.clear()
                adapterSearch.notifyDataSetChanged()
                searchNearbyByKeywords(s.toString())
            }
        })
        edt_location_address.setOnFocusChangeListener { v, hasFocus ->
            Log.v("yxy", "hasfocus" + hasFocus)
            if (hasFocus) {
                tv_search_cancel.visibility = View.VISIBLE
                ll_location_map.visibility = View.GONE
                ll_location_address.visibility = View.VISIBLE
            }
//            else {
//                tv_search_cancel.visibility = View.GONE
//                ll_location_map.visibility = View.VISIBLE
//                ll_location_address.visibility = View.GONE
//            }

        }
//        edt_location_address.set(object : TextView.OnEditorActionListener {
//            override fun onEditorAction(textView: TextView?, id: Int, keyEvent: KeyEvent?): Boolean {
//                if (id == EditorInfo.IME_ACTION_NEXT) {
//                    hideSoftKeyboard(this@LocationMapActivity)
//                    edt_location_address.clearFocus();
//                    edt_location_address.setText("")
//                    ll_location_map.visibility = View.VISIBLE
//                    ll_location_address.visibility = View.GONE
//                    return true
//                }
//                return false
//            }
//        })
        // 搜索框的键盘搜索键点击回调
        // 搜索框的键盘搜索键点击回调
        edt_location_address.setOnKeyListener(View.OnKeyListener { v, keyCode, event ->

            // 输入完后按键盘上的搜索键
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN) { // 修改回车键功能
                Log.v("yxy", "搜索所")
//                tv_search_cancel.visibility = View.VISIBLE
//                ll_location_map.visibility = View.GONE
//                ll_location_address.visibility = View.VISIBLE
                hideSoftKeyboard(this@LocationMapActivity)
            }
            false
        })


    }

    override fun onDestroy() {
        super.onDestroy()
        basicMap.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        basicMap.onResume()
    }

    override fun onPause() {
        super.onPause()
        //在activity执行onPause时执行mMapView.onPause ()，暂停地图的绘制
        basicMap.onPause()
    }


    //接收返回的数据
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == SEARCH_REQUEST_CODE && resultCode == RESULT_OK) {
            val resultTip = data!!.getParcelableExtra<Tip>(SELECT_POSITION)
            //清空列表数据
            mLocationList.clear()
            adapter.setNewInstance(mLocationList)
            isTouch = false

            //更改定位图标
//            iv_my_location.setBackgroundResource(R.drawable.ic_my_location)
            //构造列表的第一个定位数据
            if (resultTip != null) {
                val latLng = LatLng(resultTip.point.latitude, resultTip.point.longitude)
                //地图移动
                aMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 18f))

                val poiItem = PositionItem(
                    "",
                    LatLonPoint(resultTip.point.latitude, resultTip.point.longitude),
                    resultTip.name,
                    if (resultTip.address.isEmpty()) resultTip.district else resultTip.address
                )
                poiItem.isSelect = true
                poiItem.isMyLocation = true
                mLocationList.add(poiItem)
                //查找附近的数据
                searchNearby(latLng)
            }


        }
    }

    private fun initLocationAddress() {
        rlv_locations.layoutManager = LinearLayoutManager(this)
        adapter = LocationAdapter(mLocationList)
        rlv_locations.adapter = adapter
        //列表点击事件
        adapter.setOnItemClickListener { adapter, view, position ->
            if (mLocationList.isEmpty()) return@setOnItemClickListener
            isTouch = false
            Log.v("yxy", "==mLocationList[position]=" + GsonUtils.toJson(mLocationList[position]))
            //地图移动
            val latLng = mLocationList[position].latLonPoint?.let {
                mLocationList[position].latLonPoint?.let { it1 ->
                    LatLng(
                        it1.latitude, it.longitude
                    )
                }
            }
            aMap.animateCamera(CameraUpdateFactory.changeLatLng(latLng))
            //更改列表的选中
            mLocationList.forEach {
                it.isSelect = false
            }
            mLocationList[position].isSelect = true
            adapter.notifyDataSetChanged()
            val intent = Intent()
            val city =
                mLocationList[position].provinceName + mLocationList[position].cityName + mLocationList[position].adName
            intent.putExtra("cityStr", city)
            intent.putExtra(
                "addressStr", mLocationList[position].address + mLocationList[position].poiName
            )
            setResult(RESULT_OK, intent)
            finish()

        }
    }

    private fun initLocationSearchAddress() {
        rlv_locations_address.layoutManager = LinearLayoutManager(this)
        adapterSearch = LocationSearchAdapter(mLocationSearchList, locationLat, locationLng)
        rlv_locations_address.adapter = adapterSearch
        //列表点击事件
        adapterSearch.setOnItemClickListener { adapter, view, position ->
            if (mLocationSearchList.isEmpty()) return@setOnItemClickListener
            isTouch = false
            Log.v(
                "yxy",
                "==mLocationList[position]=" + GsonUtils.toJson(mLocationSearchList[position])
            )
            mLocationSearchList[position].isSelect = true
            adapterSearch.notifyDataSetChanged()
            val intent = Intent()
            var city = ""
            if (mLocationSearchList[position].provinceName == mLocationSearchList[position].cityName) {
                city =
                    mLocationSearchList[position].cityName + mLocationSearchList[position].adName
            } else {
                city =
                    mLocationSearchList[position].provinceName + mLocationSearchList[position].cityName + mLocationSearchList[position].adName
            }
            intent.putExtra("cityStr", city)
            intent.putExtra(
                "addressStr",
                mLocationSearchList[position].address + mLocationSearchList[position].poiName
            )
            setResult(RESULT_OK, intent)
            finish()

        }
    }

    //定位成功之后，构造Marker对象和数据
    private fun locationSuccess(location: AMapLocation) {
        Log.v("yxy", "定位成功返回======" + location.address);
        val latLng = LatLng(location.latitude, location.longitude)
        locationLat = location.latitude
        locationLng = location.longitude
        //定位蓝点
        val marker_location_point =
            LayoutInflater.from(this).inflate(R.layout.marker_location_point, basicMap, false)
        val marker = aMap.addMarker(
            MarkerOptions().position(latLng).title("").snippet("").icon(
                BitmapDescriptorFactory.fromView(marker_location_point)
            )
        )
        //蓝点动画
        val alpha = AlphaAnimation(1f, 0.5f)//新建透明度动画
        alpha.setDuration(1000)//设置动画持续时间
        alpha.repeatCount = -1
        alpha.repeatMode = Animation.REVERSE
        marker.setAnimation(alpha)//图片设置动画
        marker.startAnimation()//开始动画
        //定位针
        val marker_position_needle =
            LayoutInflater.from(this).inflate(R.layout.marker_location_point, basicMap, false)
        centerMaker = aMap.addMarker(
            MarkerOptions().icon(
                BitmapDescriptorFactory.fromView(marker_position_needle)
            ).position(latLng).draggable(true).title("").snippet("")
        )
        //定位针一直在中心
        centerMaker.setPositionByPixels(basicMap.width / 2, basicMap.height / 2)
        //移动地图
        aMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 18f))
        //构造列表的第一个定位数据
        val poiItem = PositionItem(
            "当前位置",
            LatLonPoint(location.latitude, location.longitude),
            location.poiName,
            location.address
        )
        searchCity = location.city
        poiItem.provinceName = location.province
        poiItem.cityName = location.city
        poiItem.adName = location.district
        poiItem.cityCode = location.cityCode
        poiItem.isSelect = true
        poiItem.isMyLocation = true
        mLocationList.add(poiItem)
        Log.v("yxy", "ocation.address" + location.address + mLocationList.size);
        //查找附近的数据
        searchNearby(latLng)
        initLocationSearchAddress()
    }

    //查找附近的数据
    private fun searchNearby(latLng: LatLng) {
        //keyWord表示搜索字符串，
        //第二个参数表示POI搜索类型，二者选填其一，选用POI搜索类型时建议填写类型代码，码表可以参考下方（而非文字）
        //cityCode表示POI搜索区域，可以是城市编码也可以是城市名称，也可以传空字符串，空字符串代表全国在全国范围内进行搜索
        val query = PoiSearch.Query("", "", "")
//        query.pageSize = 50// 设置每页最多返回多少条poiitem
//        query.pageNum = 0
        val search = PoiSearch(this, query)
        //设置周边搜索的中心点以及半径
        search.bound = PoiSearch.SearchBound(LatLonPoint(latLng.latitude, latLng.longitude), 1000)
        search.setOnPoiSearchListener(object : PoiSearch.OnPoiSearchListener {
            override fun onPoiItemSearched(p0: PoiItem?, p1: Int) {}

            override fun onPoiSearched(result: PoiResult?, code: Int) {
                //1000为成功，其他为失败
                if (code == 1000) {
                    val pois = result?.pois
                    //重新构造数据
                    pois?.forEach {
                        mLocationList.add(
                            PositionItem(
                                it.poiId,
                                it.latLonPoint,
                                it.title,
                                it.snippet,
                                it.provinceName,
                                it.cityName,
                                it.adName,
                                it.cityCode
                            )
                        )
                    }
                    //如果有当前定位的数据的话，就直接选中，否则用返回的数据的第一条，选中
                    if (mLocationList.isEmpty() || !mLocationList[0].isMyLocation) {
                        mLocationList[0].isSelect = true
                    }
                    adapter.isUseEmpty = mLocationList.isEmpty()
                    //设置数据
                    adapter.setNewInstance(mLocationList)
                    adapter.notifyDataSetChanged()
                } else {
                    adapter.isUseEmpty = true
                }
            }
        })
        //发送请求
        search.searchPOIAsyn()
    }

    private fun searchNearbyByKeywords(keywords: String) {
        //keyWord表示搜索字符串，
        //第二个参数表示POI搜索类型，二者选填其一，选用POI搜索类型时建议填写类型代码，码表可以参考下方（而非文字）
        //cityCode表示POI搜索区域，可以是城市编码也可以是城市名称，也可以传空字符串，空字符串代表全国在全国范围内进行搜索
        Log.v("yxy", "searchCity+" + searchCity)
        val query = PoiSearch.Query(keywords, "", searchCity)
        query.pageSize = 100// 设置每页最多返回多少条poiitem
        query.pageNum = 0
        val search = PoiSearch(this, query)
        //设置周边搜索的中心点以及半径
//        search.bound = PoiSearch.SearchBound(LatLonPoint(latLng.latitude, latLng.longitude), 10000)
        search.setOnPoiSearchListener(object : PoiSearch.OnPoiSearchListener {
            override fun onPoiItemSearched(p0: PoiItem?, p1: Int) {}

            override fun onPoiSearched(result: PoiResult?, code: Int) {
                //1000为成功，其他为失败
                if (code == 1000) {
                    val pois = result?.pois
                    //重新构造数据
                    pois?.forEach {

                        mLocationSearchList.add(
                            PositionItem(
                                it.poiId,
                                it.latLonPoint,
                                it.title,
                                it.snippet,
                                it.provinceName,
                                it.cityName,
                                it.adName,
                                it.cityCode
                            )
                        )
                    }
                    Log.v("yxy", "mLocationSearchList " + GsonUtils.toJson(mLocationSearchList))
                    adapterSearch.isUseEmpty = mLocationSearchList.isEmpty()
                    if (pois != null) {
                        if (pois.size > 0) {
                            tv_locations_address_msg.visibility = View.VISIBLE
                        } else {
                            tv_locations_address_msg.visibility = View.GONE
                        }
                    }

                    //设置数据
                    adapterSearch.setNewInstance(mLocationSearchList)
                    adapterSearch.notifyDataSetChanged()
                    if (adapterSearch.data.isNullOrEmpty()) {
                        EmptyAdapterHelper.setEmptyAdapter(
                            adapterSearch, this@LocationMapActivity, R.mipmap.ic_empty_3, "没有相关搜索结果"
                        )
                    }
                } else {
                    adapterSearch.isUseEmpty = true
                }
            }
        })
        //发送请求
        search.searchPOIAsyn()
    }

    //初始化地图参数
    private fun initMap(aMap: AMap) {
        //设置地图是否显示放大
        aMap.uiSettings.isZoomControlsEnabled = false
        // 设置地图默认的指南针是否显示
        aMap.uiSettings.isCompassEnabled = true
        // 设置默认定位按钮是否显示
        aMap.uiSettings.isMyLocationButtonEnabled = true
        //隐藏logo
        aMap.uiSettings.setLogoBottomMargin(-80)
        // 设置为true表示显示定位层并可触发定位，false表示隐藏定位层并不可触发定位，默认是false
        aMap.isMyLocationEnabled = false

    }

    //获取当前位置
    private fun getCurrentLocation(success: (AMapLocation) -> Unit) {
        //清空列表数据
        mLocationList.clear()
        adapter.setNewInstance(mLocationList)
        val mLocationClient = AMapLocationClient(this)
        val mLocationOption = AMapLocationClientOption()
        //高精度模式
        mLocationOption.locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
        //定位请求超时时间
        mLocationOption.httpTimeOut = 50000
        // 关闭缓存机制
        mLocationOption.isLocationCacheEnable = false
        // 设置是否只定位一次
        mLocationOption.isOnceLocation = true
        //设置参数
        mLocationClient.setLocationOption(mLocationOption)
        // 启动定位
        mLocationClient.startLocation()
        //定位监听
        mLocationClient.setLocationListener { aMapLocation ->
            //定位成功之后取消定位
            mLocationClient.stopLocation()
            if (aMapLocation != null && aMapLocation.errorCode == 0) {
                Log.v("yxy", "地址成功===" + aMapLocation.toStr())
                success(aMapLocation)
            } else {
                Log.v("yxy", "定位失败，请重新定位")
            }
        }
    }

    //定位列表适配器
    class LocationAdapter(data: MutableList<PositionItem>) :
        BaseQuickAdapter<PositionItem, BaseViewHolder>(R.layout.item_location, data) {
        override fun convert(helper: BaseViewHolder, item: PositionItem) {
            helper.apply {
                setText(R.id.tv_location_name, item.poiName)
                setText(
                    R.id.tv_location_name_dec,
                    if (item.isMyLocation) item.address else item.provinceName + item.cityName + item.address
                )
                if (item.isSelect) {
                    setTextColor(R.id.tv_location_name, Color.parseColor("#3D7DFF"))
                    setImageResource(R.id.iv_position_select, R.mipmap.ic_location_mark2)
                } else {
                    setTextColor(R.id.tv_location_name, Color.parseColor("#333333"))
                    setImageResource(R.id.iv_position_select, R.mipmap.ic_location_uncheck)
                }
            }
        }
    }

    //定位列表适配器
    private class LocationSearchAdapter(data: MutableList<PositionItem>, lat: Double, lng: Double) :
        BaseQuickAdapter<PositionItem, BaseViewHolder>(R.layout.item_location_search, data) {
        var isLat = lat
        var isLng = lng
        override fun convert(helper: BaseViewHolder, item: PositionItem) {

            helper.apply {
                setText(R.id.tv_location_name, item.poiName)
                setText(
                    R.id.tv_location_name_dec, item.address
                )
                val locationLatlng = LatLng(isLat, isLng)
                if (item.latLonPoint != null) {
                    val endLocation =
                        LatLng(item.latLonPoint!!.latitude, item.latLonPoint!!.longitude)
                    var distance =
                        AMapUtils.calculateLineDistance(locationLatlng, endLocation).toDouble()
                    var dis = 0
                    if (distance > 1000) {
                        val bigDecimal = BigDecimal(distance / 1000)
                        val dis = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).toDouble()
                        setText(
                            R.id.tv_location_distance,
                            dis.toString() + "km"
                        )
                    } else {
                        val bigDecimal = BigDecimal(distance)
                        val dis = bigDecimal.setScale(1, BigDecimal.ROUND_HALF_UP).toDouble()
                        setText(
                            R.id.tv_location_distance,
                            dis.toString() + "m"
                        )
                    }
                }

            }
        }
    }

    private fun showPickerView() { // 弹出选择器
        val pvOptions = OptionsPickerBuilder(
            this
        ) { options1, options2, options3, v -> //返回的分别是三个级别的选中位置
            //省份
            provinceItems[options1]
            //城市
            cityItems[options1][options2]
            //辖区
//            areaItems[options1][options2][options3]
            //获得选择的数据
            var tx: String = cityItems[options1][options2].pickerViewText
            areaId = cityItems[options1][options2].id
            if (provinceItems[options1].pickerViewText == "北京市" || provinceItems[options1].pickerViewText == "天津市" || provinceItems[options1].pickerViewText == "上海市" || provinceItems[options1].pickerViewText == "重庆市") {
                searchCity = provinceItems[options1].pickerViewText
            } else {
                searchCity = tx
            }
            rt_location_city.text = tx
            edt_location_address.setText("")
            tv_locations_address_msg.visibility = View.GONE
            mLocationSearchList.clear()

            adapterSearch.notifyDataSetChanged()

        }.setTitleText("城市选择").setDividerColor(Color.BLACK)
            .setTextColorCenter(Color.BLACK) //设置选中项文字颜色
            .setCancelText("取消").setSubmitText("确认").setContentTextSize(20).build<Area>()
        pvOptions.setPicker(provinceItems, cityItems) //三级选择器
        pvOptions.show()
    }

    inner class ProxyClick() {
        fun selectPrinceCity() {
            hideSoftKeyboard(this@LocationMapActivity)
            showPickerView()
        }

        /**
         * 动态切换调整布局，输入框输入事件监听
         */
        fun changeLocationView() {
            hideSoftKeyboard(this@LocationMapActivity)
            edt_location_address.clearFocus();
            edt_location_address.setText("")
            ll_location_map.visibility = View.VISIBLE
            ll_location_address.visibility = View.GONE
        }
    }

    override fun createObserver() {
        requestViewModel.provinceCityResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0) {

                    it.listData.forEach { province ->
                        val cityList = mutableListOf<Area>()
                        //存放省内所有辖区
                        val areaList = mutableListOf<MutableList<Area>>()
                        province.cityList.forEach { city ->
                            cityList.add(Area(city.id, city.pid, city.text))
                            //存放市内辖区
                            val areas = mutableListOf<Area>()
                            city.list.forEach { area ->
                                areas.add(area)
                            }
                            areaList.add(areas)
                        }
                        //添加省份
                        provinceItems.add(Area(province.id, province.pid, province.text))
                        //添加市区
                        cityItems.add(cityList)
                    }

                }

            }
        })
    }

}