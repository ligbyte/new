package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.bigkoo.pickerview.builder.OptionsPickerBuilder
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.google.gson.JsonObject
import com.hjq.permissions.Permission
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.listener.OnResultCallbackListener
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.CodeEntity
import com.wendu.wenduyikao.databinding.ActivityMineInfoBinding
import com.wendu.wenduyikao.util.HasStoragePermissionListener
import com.wendu.wenduyikao.util.PermissionHelper
import com.wendu.wenduyikao.util.Storage
import com.wendu.wenduyikao.viewmodel.request.RequestUserViewModel
import com.zhihu.matisse.Matisse
import kotlinx.android.synthetic.main.activity_course_order.*
import kotlinx.android.synthetic.main.activity_mine_info.*
import kotlinx.android.synthetic.main.activity_update_info.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.fragment_me.*
import me.xiaoyang.base.ext.parseState
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 5:07 PM
 * @Description: 个人资料
 */
class MineInfoActivity : BaseActivity<RequestUserViewModel, ActivityMineInfoBinding>() {

    override fun layoutId() = R.layout.activity_mine_info
    private val requestViewModel: RequestUserViewModel by viewModels()
    private val UPDATE_USER_INFO: Int = 2020
    private val userInfo = CacheUtil.getUser()
    private val REQUEST_CODE_CHOOSE: Int = 2021
    var choosePicture: MutableList<LocalMedia> = mutableListOf()
    var pictureResultPath: String = ""
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, mine_info_ll_content)
        tv_toolbar_title.text = "个人资料"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        requestViewModel.getUserInfo()
    }


    override fun createObserver() {
        requestViewModel.userInfo.observe(this, Observer { resultState ->
            parseState(resultState, {
                mDatabind.user = it
                appViewModel.userinfo.value = it
                CacheUtil.setUser(it)
                val mRequestOptions = RequestOptions.circleCropTransform()
                Glide.with(this).load(it.headimgurl).apply(mRequestOptions)
                    .placeholder(R.drawable.icon_default_photo)
                    .into(mine_info_photo)
            })
        })

        requestViewModel.fileResult.observe(this, Observer {

            val mRequestOptions = RequestOptions.circleCropTransform()

            Glide.with(this).load(it).apply(mRequestOptions)
                .placeholder(R.drawable.icon_default_photo)
                .into(mine_info_photo)
            val json = JsonObject()
            json.addProperty("headimgurl", it)
            json.addProperty("id", userInfo?.id)
            requestViewModel.updateUserInfo(json)
        })


        requestViewModel.updateUserResult.observe(this, Observer {
            if (it.success) {
                requestViewModel.getUserInfo()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == UPDATE_USER_INFO) {
                requestViewModel.getUserInfo()
            } else if (requestCode == REQUEST_CODE_CHOOSE) {
                val paths = Matisse.obtainPathResult(data)
                val timeFormatter = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA)
                val time = System.currentTimeMillis()
                val path = paths[0]
                if (StringUtil.isNotBlank(path)) {
                    var parts: List<MultipartBody.Part?>? = null
                    val builder = MultipartBody.Builder()
                        .setType(MultipartBody.FORM) //表单类型
                    val file = File(path)
                    val body =
                        RequestBody.create(MediaType.parse("multipart/form-data"), file);//表单类型
                    builder.addFormDataPart("file", file.name, body)
                    parts = builder.build().parts()
                    requestViewModel.uploadFile(parts)
                }
            }
        }
    }

    inner class ProxyClick() {
        /**
         * 编辑用户姓名
         */
        fun gotoUpdateNameClick() {
            startActivityForResult(
                Intent(this@MineInfoActivity, UpdateInfoActivity::class.java)
                    .putExtra("userId", userInfo?.id)
                    .putExtra("type", "nickname")
                    .putExtra("name", userInfo?.stuName), UPDATE_USER_INFO
            )
        }

        /**
         *编辑专业
         */
        fun gotoUpdateMajorClick() {
            startActivityForResult(
                Intent(this@MineInfoActivity, UpdateInfoActivity::class.java)
                    .putExtra("userId", userInfo?.id)
                    .putExtra("type", "graduationMajor")
                    .putExtra("name", userInfo?.graduationMajor), UPDATE_USER_INFO
            )
        }

        fun gotoUpdateSexClick() {
            val sexList: ArrayList<CodeEntity> = arrayListOf()
            var code = CodeEntity()
            code.label = "男"
            code.type = "1"
            sexList.add(code)
            code = CodeEntity()
            code.label = "女"
            code.type = "2"
            sexList.add(code)
            code = CodeEntity()
            code.label = "未知"
            code.type = "3"
            sexList.add(code)
            val sexStr: MutableList<String> = ArrayList()
            for (sex in sexList) {
                sexStr.add(sex.label)
            }
            val optionsPickerView =
                OptionsPickerBuilder(this@MineInfoActivity) { options1, options2, options3, v ->
                    val codeInfo: CodeEntity = sexList[options1]
                    Log.v("yxy", "codeInfo==" + code.type)
                    val json = JsonObject()
                    json.addProperty("stuSex", codeInfo.type)
                    json.addProperty("id", userInfo?.id)
                    requestViewModel.updateUserInfo(json)
                }.build<String>()
            optionsPickerView.setPicker(sexStr)
            optionsPickerView.show()
        }

        /**
         * 编辑学历
         */
        fun gotoUpdateEducation() {
            startActivityForResult(
                Intent(this@MineInfoActivity, SelectEducationActivity::class.java)
                    .putExtra("userId", userInfo?.id), UPDATE_USER_INFO
            )
        }

        /**
         *选择学校
         */
        fun gotoSelectSchool() {
            startActivityForResult(
                Intent(this@MineInfoActivity, SelectSchoolActivity::class.java)
                    .putExtra("userId", userInfo?.id), UPDATE_USER_INFO
            )
        }

        /**
         * 编辑头像
         */
        fun gotoUpdatePhoto() {
//            Matisse.from(this@MineInfoActivity)
//                .choose(MimeType.ofAll())
//                .countable(true)
//                .maxSelectable(1)
//                .gridExpectedSize(resources.getDimensionPixelSize(R.dimen.grid_expected_size))
//                .restrictOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED)
//                .thumbnailScale(0.85f)
//                .imageEngine(GlideEngine())
//                .showPreview(false) // Def
//                .capture(false)
//                .captureStrategy(CaptureStrategy(true, "PhotoPicker"))
//                .forResult(REQUEST_CODE_CHOOSE)


            checkPermission()
        }
    }

    fun checkPermission() {
        PermissionHelper.checkMyPermission(
            this,
            object : HasStoragePermissionListener {
                override fun hasPermission(isAll: Boolean) {
                    pickPicture()
                }

                override fun noPermission() {}
                override fun cancel() {}
            },
            Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE
        )
    }


    /**
     * 图片选择
     */
    private fun pickPicture() {
        val path = Storage.getImageDir(this).path;//压缩图片
        //结果返回回调，不用再写onActivityResult 方法
        PictureSelector.create(this)
            .themeStyle(R.style.picture_default_style)
            .maxSelectNum(1) //最多选取多少张
            .selectionMode(PictureConfig.MULTIPLE) //多图选择
            .isCamera(true) //是否显示拍照按钮
            .isPreviewImage(true) //是否可预览
            .isCompress(true) //是否压缩
            .compressSavePath(path) //压缩图片保存地址
            .imageEngine(com.wendu.wenduyikao.util.GlideEngine.createGlideEngine()) // 请参考Demo GlideEngine.java
            .selectionData(choosePicture) // 是否传入已选图片
            .forResult(object : OnResultCallbackListener<LocalMedia> {
                override fun onResult(result: List<LocalMedia>) {
                    val builder = MultipartBody.Builder()
                        .setType(MultipartBody.FORM) //表单类型
                    var parts: List<MultipartBody.Part?>? = null
                    val file = File(result.get(0).compressPath)
                    val body =
                        RequestBody.create(MediaType.parse("multipart/form-data"), file);//表单类型
                    builder.addFormDataPart("file", file.name, body)
                    parts = builder.build().parts()
                    requestViewModel.uploadFile(parts)

                }

                override fun onCancel() {}
            })
    }
}