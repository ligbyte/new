package com.wendu.wenduyikao.mine

import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.model.bean.CodeEntity
import com.wendu.wenduyikao.databinding.ActivitySelectEducationBinding
import com.wendu.wenduyikao.mine.adapter.SelectEducationAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestBalanceViewModel
import com.wendu.wenduyikao.viewmodel.request.RequestUserViewModel
import com.google.gson.JsonObject
import com.wendu.wenduyikao.app.util.StringUtil
import kotlinx.android.synthetic.main.activity_account_balance.*
import kotlinx.android.synthetic.main.activity_balance_record.*
import kotlinx.android.synthetic.main.activity_select_education.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/19/21 10:18 AM
 * @Description: 选择学历
 */
class SelectEducationActivity :
    BaseActivity<RequestBalanceViewModel, ActivitySelectEducationBinding>() {

    private var userId: String = ""
    private val requestViewModel: RequestUserViewModel by viewModels()
    private var education = ""

    override fun layoutId() = R.layout.activity_select_education


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, select_education_content)
        tv_toolbar_title.text = "选择学历"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        userId = intent.getStringExtra("userId").toString()
        initRecycleView()
    }

    private fun initRecycleView() {
        val list = BaseCode.getEducationData()

        val educationAdapter = SelectEducationAdapter(list)
        //初始化recyclerView
        rlv_select_education.init(
            LinearLayoutManager(this),
            educationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(8f)))
        }
        educationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: CodeEntity =
                    adapter.getItem(position) as CodeEntity
                educationAdapter.setPosition(position)
                educationAdapter.notifyDataSetChanged()
                education = info.label
            }
        }
    }

    override fun createObserver() {
        requestViewModel.updateUserResult.observe(this, Observer {
            if (it.success) {
                setResult(RESULT_OK)
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun updateEducation() {
            if (StringUtil.isBlank(education)) {
                ToastUtils.showShort("请选择学历")
                return
            }
            val json = JsonObject()
            json.addProperty("education", education)
            json.addProperty("id", userId)
            requestViewModel.updateUserInfo(json)
        }
    }
}