package com.wendu.wenduyikao.mine

import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.hideSoftKeyboard
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.ProvinceInfoEntity
import com.wendu.wenduyikao.data.model.bean.SchoolInfoEntity
import com.wendu.wenduyikao.databinding.ActivitySelectSchoolBinding
import com.wendu.wenduyikao.mine.adapter.SelectProvinceAdapter
import com.wendu.wenduyikao.mine.adapter.SelectSchoolAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestSchoolViewModel
import kotlinx.android.synthetic.main.activity_select_school.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/21/21 9:41 AM
 * @Description: 选择学校
 */
class SelectSchoolActivity :
    BaseActivity<RequestSchoolViewModel, ActivitySelectSchoolBinding>() {


    override fun layoutId() = R.layout.activity_select_school
    private val requestViewModel: RequestSchoolViewModel by viewModels()
    private var school = ""
    private var userId = ""


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, select_school_content)
        tv_toolbar_title.text = "选择学校"
        userId = intent.getStringExtra("userId").toString()
        img_back.setOnClickListener {
            if (StringUtil.isNotBlank(school)) {
                val json = JsonObject()
                json.addProperty("school", school)

                json.addProperty("id", userId)
                requestViewModel.updateUserInfo(json)
            } else {
                finish()
            }

        }
        requestViewModel.getSchoolList()
        initEvent()
    }

    private fun initEvent() {
        select_school_search.setOnEditorActionListener { v, actionId, event ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                if(StringUtil.isNotBlank(select_school_search.text.toString())){
                    requestViewModel.getSchoolByName(select_school_search.text.toString())
                }else{
                    select_rlv_province.visibility=View.VISIBLE
                }
                hideSoftKeyboard(this)
                true;
            }
            false;
        }
    }

    private fun initProvinceRecycleView(provinceList: ArrayList<ProvinceInfoEntity>) {

        val provinceAdapter = SelectProvinceAdapter(provinceList)
        //初始化recyclerView
        select_rlv_province.init(
            LinearLayoutManager(this),
            provinceAdapter
        )
        provinceAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ProvinceInfoEntity =
                    adapter.getItem(position) as ProvinceInfoEntity
                provinceAdapter.setPosition(position)
                provinceAdapter.notifyDataSetChanged()
                info.wdSchoolList?.let { initSchoolRecycleView(it) }
            }
        }
    }

    private fun initSchoolRecycleView(provinceList: ArrayList<SchoolInfoEntity>) {

        val schoolAdapter = SelectSchoolAdapter(provinceList)
        //初始化recyclerView
        select_rlv_school.init(
            LinearLayoutManager(this),
            schoolAdapter
        )
        schoolAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: SchoolInfoEntity =
                    adapter.getItem(position) as SchoolInfoEntity
                schoolAdapter.setPosition(position)
                schoolAdapter.notifyDataSetChanged()
                school = info.id.toString()
            }
        }
    }


    override fun createObserver() {
        requestViewModel.schoolDataState.observe(this, Observer {
            if (it.isSuccess) {
                initProvinceRecycleView(it.listData)
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.schoolResult.observe(this, Observer {
            if (it.isSuccess) {
                initSchoolRecycleView(it.listData)
                if(it.listData.size==0){
                    if(StringUtil.isNotBlank(select_school_search.text.toString())){
                        select_rlv_province.visibility=View.GONE
                    }else{
                        select_rlv_province.visibility=View.VISIBLE
                    }
                }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })

        requestViewModel.updateUserResult.observe(this, Observer {
            if (it.success) {
                setResult(RESULT_OK)
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }
}