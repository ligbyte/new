package com.wendu.wenduyikao.mine

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.azhon.appupdate.config.UpdateConfiguration
import com.azhon.appupdate.listener.OnDownloadListenerAdapter
import com.azhon.appupdate.manager.DownloadManager
import com.blankj.utilcode.util.AppUtils
import com.blankj.utilcode.util.SPUtils
import com.blankj.utilcode.util.ToastUtils
import com.easefun.polyvsdk.PolyvSDKClient
import com.easefun.polyvsdk.PolyvUserClient
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.CacheDataManager
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.eventbus.LogoutEvent
import com.wendu.wenduyikao.databinding.ActivitySettingBinding
import com.wendu.wenduyikao.ui.activity.login.UpdatePwdActivity
import com.wendu.wenduyikao.util.FileUtils
import com.wendu.wenduyikao.util.UserUtil
import com.wendu.wenduyikao.viewmodel.request.RequestMeViewModel
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.base.viewmodel.BaseViewModel
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/12/21 5:04 PM
 * @Description: 设置
 */
class SettingActivity : BaseActivity<BaseViewModel, ActivitySettingBinding>() {

    override fun layoutId() = R.layout.activity_setting

    private val requestViewModel: RequestMeViewModel by viewModels()

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, setting_ll_content)
        tv_toolbar_title.text = "设置"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        if (CacheUtil.isLogin()) {
            setting_logout.visibility = View.VISIBLE

            switch_btn.isChecked = CacheUtil.getUser()?.isPush == 1
        } else {
            setting_logout.visibility = View.GONE
        }

        if (SPUtils.getInstance().getBoolean("isNew")) {
            me_img_new.visibility = View.VISIBLE
        } else {
            me_img_new.visibility = View.GONE
        }
        setTextInfo()


        switch_btn.setOnCheckedChangeListener { buttonView, isChecked ->
            if (CacheUtil.isLogin()) {
                var isPush = 0
                isPush = if (isChecked) {
                    1
                } else {
                    0
                }
                val json = JsonObject()
                json.addProperty("isPush", isPush.toString())
                requestViewModel.changePush(json)
            } else {
                UserUtil.goLogin(this@SettingActivity)
            }

        }

    }

    override fun createObserver() {
        requestViewModel.logoutResult.observe(this, Observer {
            if (it.success) {
                EventBus.getDefault().post(LogoutEvent())
                CacheUtil.setIsLogin(false)
                CacheUtil.setToken("")
                CacheUtil.setUser(null)
                CacheUtil.setNickName("")
                appViewModel.userinfo.value = null
                appViewModel.isLogin.value = false
                appViewModel.majorName.value = ""
                appViewModel.majorId.value = ""
//                UserUtil.goLogin(this)
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.versionResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                Log.v(
                    "yxy",
                    "===" + it.downloadLink + "===" + it.appVersionInt + "===" + AppUtils.getAppVersionCode()
                )
                if (AppUtils.getAppVersionCode() < it.appVersionInt) {
                    me_img_new.visibility = View.VISIBLE
                    val configuration = UpdateConfiguration() //输出错误日志
                        .setEnableLog(true) //设置自定义的下载
                        //.setHttpManager()
                        //下载完成自动跳动安装页面
                        .setJumpInstallPage(true) //设置对话框背景图片 (图片规范参照demo中的示例图)
                        .setDialogImage(R.drawable.icon_update_bg)
                        //设置按钮的颜色
                        .setDialogButtonColor(Color.parseColor("#0989FB"))
                        //设置对话框强制更新时进度条和文字的颜色
                        //.setDialogProgressBarColor(Color.parseColor("#E743DA"))
                        //设置按钮的文字颜色
                        .setDialogButtonTextColor(Color.WHITE) //设置是否显示通知栏进度
                        .setShowNotification(true) //设置是否提示后台下载toast
                        .setShowBgdToast(false) //设置强制更新
                        .setForcedUpgrade(false) //设置对话框按钮的点击监听
                        .setOnDownloadListener(listenerAdapter)
                    val manager = DownloadManager.getInstance(this)

                    manager.setApkName("wenduyikao.apk")
                        .setApkUrl(it.downloadLink)
                        .setSmallIcon(R.mipmap.ic_login_logo)
                        .setShowNewerToast(false)
                        .setConfiguration(configuration)
                        .setApkVersionCode(it.appVersionInt)
                        .setApkVersionName(it.appVersion)
                        .setApkDescription(it.description.replace("\\n", "\n"))
//                .setApkMD5("DC501F04BBAA458C9DC33008EFED5E7F")
                        .download();
                } else {
                    me_img_new.visibility = View.GONE

                    ToastUtils.showShort("当前版本已经是最新版本")
                }

            })
        })
    }

    inner class ProxyClick() {
        fun gotoAccountManage() {
            if (CacheUtil.isLogin()) {
                startActivity(Intent(this@SettingActivity, AccountManageActivity::class.java))
            } else {
                UserUtil.goLogin(this@SettingActivity)
            }
        }

        /**
         * 注销账户
         */
        fun unSubscribeClick() {
            if (CacheUtil.isLogin()) {
                startActivity(Intent(this@SettingActivity, UnSubscribeStepOneActivity::class.java))
            } else {
                UserUtil.goLogin(this@SettingActivity)
            }
        }

        fun logOut() {
            if (CacheUtil.isLogin()) {
                requestViewModel.logout()
                requestViewModel.logoutUmeng()
            } else {
                UserUtil.goLogin(this@SettingActivity)
            }

        }

        /**
         * 修改密码
         */
        fun updatePwd() {
            if (CacheUtil.isLogin()) {
                startActivity(
                    Intent(
                        this@SettingActivity,
                        UpdatePwdActivity::class.java
                    ).putExtra("type", 2)
                )
            } else {
                UserUtil.goLogin(this@SettingActivity)
            }
        }

        /**
         * 清除缓存
         */
        fun clearCache() {

            showMessage(
                "确定清理缓存吗",
                positiveButtonText = "清理",
                negativeButtonText = "取消",
                positiveAction = {
                    CacheDataManager.clearAllCache(this@SettingActivity)
                    setTextInfo()
                })

        }

        /**
         * 推送通知
         */
        fun openPush() {



        }

        /**
         * 版本更新
         */
        fun updateVersion() {
            requestViewModel.checkVersion("0")
        }
    }

    fun setTextInfo() {
        setting_cache_num.text = CacheDataManager.getTotalCacheSize(this)
        setting_version.text = "V" + AppUtils.getAppVersionName()
    }


    private val listenerAdapter: OnDownloadListenerAdapter = object : OnDownloadListenerAdapter() {
        /**
         * 下载中
         *
         * @param max      总进度
         * @param progress 当前进度
         */
        override fun downloading(max: Int, progress: Int) {
            val curr = (progress / max.toDouble() * 100.0).toInt()
            Log.v("yxy", "====")
        }
    }
}