package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.activity.OnBackPressedCallback
import com.blankj.utilcode.util.ToastUtils
import com.just.agentweb.AgentWeb
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.databinding.ActivityUnSubscribeStepOneBinding
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.activity_un_subscribe_step_one.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.base.viewmodel.BaseViewModel

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/2 2:57 下午
 * @Description: 注销账户 第一步
 */
class UnSubscribeStepOneActivity :
    BaseActivity<BaseViewModel, ActivityUnSubscribeStepOneBinding>() {
    private var mAgentWeb: AgentWeb? = null
    private var preWeb: AgentWeb.PreAgentWeb? = null
    private var url: String = ""
    override fun layoutId() = R.layout.activity_un_subscribe_step_one

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, step_one_content)
        tv_toolbar_title.text = "账号注销"
        mDatabind.click = ProxyClick()
        url = "https://yixue.wendu.com/zixun/privacyAgreement.html"
        img_back.setOnClickListener {
            mAgentWeb?.let { web ->
                if (web.webCreator.webView.canGoBack()) {
                    web.webCreator.webView.goBack()
                } else {
                    finish()
                }
            }
        }

        preWeb = AgentWeb.with(this)
            .setAgentWebParent(step_one_webcontent, LinearLayout.LayoutParams(-1, -1))
            .useDefaultIndicator()
            .createAgentWeb()
            .ready()
        lazyLoadData()
    }


    fun lazyLoadData() {
        //加载网页
        mAgentWeb = preWeb?.go(url)
        onBackPressedDispatcher.addCallback(this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    mAgentWeb?.let { web ->
                        if (web.webCreator.webView.canGoBack()) {
                            web.webCreator.webView.goBack()
                        } else {
                            finish()
                        }
                    }
                }
            })
    }

    override fun onPause() {
        mAgentWeb?.webLifeCycle?.onPause()
        super.onPause()
    }

    override fun onResume() {
        mAgentWeb?.webLifeCycle?.onResume()
        super.onResume()
    }

    override fun onDestroy() {
        mAgentWeb?.webLifeCycle?.onDestroy()
        setSupportActionBar(null)
        super.onDestroy()
    }

    inner class ProxyClick() {
        fun nextStep() {
            if (step_one_check_box.isChecked) {
                startActivity(
                    Intent(
                        this@UnSubscribeStepOneActivity,
                        UnSubscribeStepTwoActivity::class.java
                    )
                )

            } else {
                ToastUtils.showShort("请阅读并勾选页面协议")
            }

        }
    }
}