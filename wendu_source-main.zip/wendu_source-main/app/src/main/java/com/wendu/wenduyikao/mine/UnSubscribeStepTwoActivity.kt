package com.wendu.wenduyikao.mine

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.WhichButton
import com.afollestad.materialdialogs.actions.getActionButton
import com.afollestad.materialdialogs.lifecycle.lifecycleOwner
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.model.bean.CodeEntity
import com.wendu.wenduyikao.databinding.ActivityUnSubscribeStepTwoBinding
import com.wendu.wenduyikao.question.adapter.SelectUnSubscribeAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestCancelActionViewModel
import kotlinx.android.synthetic.main.activity_un_subscribe_step_two.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/2 2:57 下午
 * @Description: 注销账户 第一步
 */
class UnSubscribeStepTwoActivity :
    BaseActivity<RequestCancelActionViewModel, ActivityUnSubscribeStepTwoBinding>() {
    private var mType = "0"
    private var cancelContent = ""
    private val maxLen = 100 // the max byte
    private var editStart = 0
    private var editEnd = 0
    override fun layoutId() = R.layout.activity_un_subscribe_step_two
    private val requestViewModel: RequestCancelActionViewModel by viewModels()
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, step_two_content)
        tv_toolbar_title.text = "账号注销"
        mDatabind.click = ProxyClick()
        val user = CacheUtil.getUser()
        if (user != null) {
            step_two_user.text = user.stuName
        }
        img_back.setOnClickListener {
            finish()
        }
        initRecycleView()
        editTextMaxLengthListener()
    }


    private fun initRecycleView() {
        val list = arrayListOf<CodeEntity>()
        var pay = CodeEntity()
        pay.type = "0"
        pay.label = "有多个账号/想要注册新账号"
        list.add(pay)
        pay = CodeEntity()
        pay.label = "没有需要的课程，不想用了"
        pay.type = "1"
        list.add(pay)
        pay = CodeEntity()
        pay.label = "已经学完，不想用了"
        pay.type = "2"
        list.add(pay)
        pay = CodeEntity()
        pay.label = "其他原因"
        pay.type = "3"
        list.add(pay)
//        pay = PayWayEntity(
        val mAdapter = SelectUnSubscribeAdapter(list)
        mAdapter.setPosition(0)
        //初始化recyclerView
        rlv_unsubscribe.init(
            LinearLayoutManager(this),
            mAdapter
        )
        mAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: CodeEntity =
                    adapter.getItem(position) as CodeEntity
                mType = info.type
                cancelContent = info.label
                if (mType == "3") {
                    rl_step_two.visibility = View.VISIBLE
                } else {
                    rl_step_two.visibility = View.GONE
                }
                mAdapter.setPosition(position)
                mAdapter.notifyDataSetChanged()
            }
        }
    }

    override fun createObserver() {
        requestViewModel.cancelResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("注销申请已提交，请等待审核")
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun cancelAction() {
            if (mType == "3") {
                cancelContent = step_two_edt_desc.text.toString()
            }
            Log.v("yxy", "===" + cancelContent)
            MaterialDialog(this@UnSubscribeStepTwoActivity).show {
                cancelable(false)
                lifecycleOwner(this@UnSubscribeStepTwoActivity)
                title(text = "确认注销账户后将不可恢复，请谨慎操作。")


                negativeButton(R.string.cancel, "取消") {

                    dismiss()
                }
                positiveButton(R.string.confirm, "确认") {
                    requestViewModel.cancellation(mType, cancelContent)
                    dismiss()
                }
                getActionButton(WhichButton.POSITIVE).updateTextColor(
                    Color.parseColor("#0077FF")
                )
                getActionButton(WhichButton.NEGATIVE).updateTextColor(
                    Color.parseColor("#707070")
                )
            }


        }
    }


    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        step_two_edt_desc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = step_two_edt_desc.selectionStart
                editEnd = step_two_edt_desc.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(step_two_edt_desc.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                step_two_edt_desc.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(step_two_edt_desc.text.toString())
        currentCount = nowCount
        //
        step_two_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }
}