package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.databinding.ActivityUpdateInfoBinding
import com.wendu.wenduyikao.viewmodel.request.RequestUserViewModel
import com.google.gson.JsonObject
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.ui.activity.login.LoginActivity
import kotlinx.android.synthetic.main.activity_update_info.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import kotlin.reflect.typeOf

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 5:08 PM
 * @Description: 资料修改
 */
class UpdateInfoActivity : BaseActivity<RequestUserViewModel, ActivityUpdateInfoBinding>() {

    override fun layoutId() = R.layout.activity_update_info
    private var updateType: String = "nickname"
    private var userId: String = ""
    private val requestViewModel: RequestUserViewModel by viewModels()
    private var name: String = ""

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, update_info_ll_content)
        tv_toolbar_title.text = "资料修改"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        userId = intent.getStringExtra("userId").toString()
        updateType = intent.getStringExtra("type").toString()

        when (updateType) {
            "nickname" -> {
                name = intent.getStringExtra("name").toString()
                if (StringUtil.isNotBlank(name)) {
                    update_info_name.setText(name)
                }
                update_info_desc.text = "请输入用户昵称"
            }
            "graduationMajor" -> {
                update_info_desc.text = "请输入在校专业"
            }
        }

    }

    override fun createObserver() {
        requestViewModel.updateUserResult.observe(this, Observer {
            if (it.success) {
                setResult(RESULT_OK)
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun updateUseInfo() {
            val json = JsonObject()

            when (updateType) {
                "nickname" -> {
                    if (StringUtil.isBlank(update_info_name.text.toString())) {
                        ToastUtils.showShort("请输入昵称")
                        return
                    }
                    json.addProperty("stuName", update_info_name.text.toString())

                }

                "graduationMajor" -> {
                    if (StringUtil.isBlank(update_info_name.text.toString())) {
                        ToastUtils.showShort("请输入专业")
                        return
                    }
                    json.addProperty("graduationMajor", update_info_name.text.toString())

                }
            }

            json.addProperty("id", userId)
            requestViewModel.updateUserInfo(json)
        }
    }
}