package com.wendu.wenduyikao.mine

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonObject
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.CountDownTimerUtils
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.databinding.ActivityUpdatePhoneBinding
import com.wendu.wenduyikao.ui.activity.login.UpdatePwdActivity
import com.wendu.wenduyikao.viewmodel.request.RequestUserViewModel
import kotlinx.android.synthetic.main.activity_update_phone.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/12/21 4:22 PM
 * @Description: 修改手机号
 */
class UpdatePhoneActivity : BaseActivity<RequestUserViewModel, ActivityUpdatePhoneBinding>() {

    private val requestViewModel: RequestUserViewModel by viewModels()
    override fun layoutId() = R.layout.activity_update_phone
    private var isVerify = true  //是否为验证模式（共用布局）
    val user = CacheUtil.getUser()
    private  var type=1  //1 设置密码,2 修改密码
    private var mCountDownTimerUtils: CountDownTimerUtils? =null
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, update_phone_ll_content)
        update_phone_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        type=intent.getIntExtra("type",1)
        mCountDownTimerUtils = CountDownTimerUtils(update_phone_send_code, 60000, 1000)
        initPhoneData()
    }

    private fun initPhoneData() {
        if (isVerify) {
            update_phone_edt_phone.setText(user?.stuPhone)
        }
    }

    override fun createObserver() {
        requestViewModel.codeInfoResult.observe(this, Observer {
            if (it.success) {
                Log.v("yxy", "发送成功")
//                val mCountDownTimerUtils = CountDownTimerUtils(update_phone_send_code, 60000, 1000)
                mCountDownTimerUtils?.start()
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.verifyPhoneResult.observe(this, Observer {
            if (it.success) {
                isVerify = false
                val mCountDownTimerUtils = CountDownTimerUtils(update_phone_send_code, 60000, 1000)
                mCountDownTimerUtils.onFinish()
                update_phone_label.text = "修改手机号"
                update_phone_desc.text = "请输入新的号码并验证"
                update_phone_send_code.text = "获取验证码"
                update_phone_submit.text = "确认修改"
                update_phone_edt_phone.setText("")
                update_phone_edt_code.setText("")

            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.updatePhoneResult.observe(this, Observer {
            if (it.success) {
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun sendCode() {
            when {
                update_phone_edt_phone.text.isEmpty() ->   ToastUtils.showShort("请输入手机号")
//                !StringUtil.isPhoneNumber(edt_phone.text.toString()) -> showMessage("请填写正确的手机号")
                else -> {
                    requestViewModel.sendCode(update_phone_edt_phone.text.toString().trim())

                }
            }
        }

        fun submitClick() {
            when {
                update_phone_edt_phone.text.isEmpty() ->   ToastUtils.showShort("请输入手机号")
                update_phone_edt_code.text.isEmpty() ->   ToastUtils.showShort("请输入验证码")
                else -> {
                    mCountDownTimerUtils?.cancel()
                    val json = JsonObject()
                    json.addProperty("mobile", update_phone_edt_phone.text.toString())
                    json.addProperty("code", update_phone_edt_code.text.toString())
                    if (isVerify) {
                        if(!CacheUtil.isLogin()){
                            startActivity(Intent(this@UpdatePhoneActivity,UpdatePwdActivity::class.java)
                                .putExtra("phone",update_phone_edt_phone.text.toString())
                                .putExtra("code",update_phone_edt_code.text.toString())
                                .putExtra("type",type))
                            finish()
                        }else{
                            requestViewModel.verifyPhone(json)
                        }

                    } else {
                        json.addProperty("id", user?.id)
                        requestViewModel.updatePhoneInfo(json)
                    }

                }
            }
        }
    }
}