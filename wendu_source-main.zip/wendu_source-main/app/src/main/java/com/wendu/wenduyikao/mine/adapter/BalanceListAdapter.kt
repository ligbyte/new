package com.wendu.wenduyikao.mine.adapter

import android.graphics.Color
import android.util.Log
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 学习币
 */
class BalanceListAdapter(data: ArrayList<BalanceInfoEntity>) :
    BaseQuickAdapter<BalanceInfoEntity, BaseViewHolder>(
        R.layout.balance_tag_view,
        data
    ) {


    private var mPosition = -1

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: BalanceInfoEntity) {
        item.run {
            holder.setText(R.id.balance_tag_name, name)
            if (mPosition == holder.adapterPosition) {
                holder.setTextColor(R.id.balance_tag_name, Color.parseColor("#3B7BFF"))
                holder.setBackgroundResource(
                    R.id.balance_tag_name,
                    R.drawable.shape_bg_light_blue_line_blue
                )
            } else {
                holder.setTextColor(R.id.balance_tag_name, Color.parseColor("#333333"))
                holder.setBackgroundResource(
                    R.id.balance_tag_name,
                    R.drawable.shape_bg_white_line_gray
                )
            }
        }
    }

}