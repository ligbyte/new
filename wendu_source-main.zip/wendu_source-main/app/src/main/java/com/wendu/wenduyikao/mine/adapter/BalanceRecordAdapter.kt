package com.wendu.wenduyikao.mine.adapter

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 充值记录
 */
class BalanceRecordAdapter(data: ArrayList<BalanceRecordInfoEntity>) :
    BaseQuickAdapter<BalanceRecordInfoEntity, BaseViewHolder>(
        R.layout.balance_record_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: BalanceRecordInfoEntity) {
        item.run {
//            holder.setText(R.id.question_boutique_title, name)

        }
    }

}