package com.wendu.wenduyikao.mine.adapter

import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.blankj.utilcode.util.GsonUtils
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.BookOrderEntity
import com.wendu.wenduyikao.data.model.bean.ShopCarInfoEntity
import com.wendu.wenduyikao.discovery.BookDetailActivity
import com.wendu.wenduyikao.discovery.adapter.BookOrderInfoAdapter
import com.wendu.wenduyikao.widget.GridItemDecoration

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 课程订单
 */
class BookOrderAdapter(data: ArrayList<BookOrderEntity>) :
    BaseQuickAdapter<BookOrderEntity, BaseViewHolder>(
        R.layout.book_order_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: BookOrderEntity) {
        item.run {
            holder.setText(R.id.book_order_id, "订单号:$id")
            holder.setText(R.id.book_order_status, StringUtil.getBookOrderByType(status))
            if (item.generationType == 1){
                holder.setText(R.id.book_order_status, "分校发放")
            }
            if (orderSource == 2) {
                holder.getView<TextView>(R.id.ll_book_order_tv_send).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.ll_book_order_tv_send).visibility = View.INVISIBLE
            }
//            val pic = holder.getView<ImageView>(R.id.course_order_pic)
            //待支付：关闭交易，付款 。   如果是课程配套图书两个按钮都不显示
            //待发货：不显示任何按钮
            //待收货：查看物流，确认收货
            //已完成：查看物流
            if (status == 2) {
                holder.getView<TextView>(R.id.book_order_item_update_address).visibility =
                    View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.book_order_item_update_address).visibility =
                    View.GONE
            }
//去支付
            if (status == 0 && orderSource == 1) {
                holder.getView<TextView>(R.id.book_order_item_pay).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.book_order_item_pay).visibility = View.GONE
            }
//关闭交易
            if (status == 0 && orderSource == 1) {
                holder.getView<TextView>(R.id.book_order_item_close).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.book_order_item_close).visibility = View.GONE
            }

            //查看物流
            if (status == 3 || status == 4 || status == 6) {
                holder.getView<TextView>(R.id.book_order_item_check).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.book_order_item_check).visibility = View.GONE
            }
            //确认收货
            if (status == 3) {
                holder.getView<TextView>(R.id.book_order_item_receive).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.book_order_item_receive).visibility = View.GONE
            }

            holder.setText(R.id.book_order_total, StringUtil.formatDoublePrice(totalPrice))
            holder.setText(R.id.book_order_pay, StringUtil.formatDoublePrice(actualPrice))
            val rlvView = holder.getView<RecyclerView>(R.id.book_order_rlv_book)
            initCarRecycleView(rlvView, bookOrderItemList)
        }

    }

    fun initCarRecycleView(rlvBook: RecyclerView, list: ArrayList<ShopCarInfoEntity>) {
        val shopCarAdapter = BookOrderInfoAdapter(list)
        //初始化recyclerView
        rlvBook.init(
            LinearLayoutManager(context),
            shopCarAdapter
        )
        if (rlvBook.itemDecorationCount == 0) {
//            rlvBook.addItemDecoration(DividerItemDecoration(context, DividerItemDecoration.VERTICAL))
            var gridItemDecoration = GridItemDecoration(context, DividerItemDecoration.VERTICAL);
            gridItemDecoration.setDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.divider
                )!!
            );
            rlvBook.addItemDecoration(gridItemDecoration);
        }
        //最后一个不显示分割线且自定义分割线

        shopCarAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity =
                    adapter.getItem(position) as ShopCarInfoEntity

            }
            addChildClickViewIds(R.id.wd_book_item_pic)
            setOnItemChildClickListener { adapter, view, position ->
                val info: ShopCarInfoEntity =
                    adapter.getItem(position) as ShopCarInfoEntity
                when (view.id) {
                    R.id.wd_book_item_pic -> {
                        context.startActivity(
                            Intent(context, BookDetailActivity::class.java)
                                .putExtra(
                                    "data", GsonUtils.toJson(info.wdBook)
                                ).putExtra(
                                    "bookId", info.bookId
                                )
                        )
                    }
                }

            }
        }
    }
}