package com.wendu.wenduyikao.mine.adapter

import android.view.LayoutInflater
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.util.TimeUtil
import com.wendu.wenduyikao.data.model.bean.BookOrderItemEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:05 下午
 * @Description: 优惠券适配器
 */
class BookOrderExpressAdapter(data: ArrayList<BookOrderItemEntity>) :
    BaseQuickAdapter<BookOrderItemEntity, BaseViewHolder>(
        R.layout.book_order_express_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: BookOrderItemEntity) {
        item.run {

            holder.setText(R.id.express_tv_num, "共" + itemList.size + "件")
            holder.setText(R.id.express_tv_type, "$expressCompany：$expressNumber")


            val llContent = holder.getView<LinearLayout>(R.id.express_ll_content)

            for (info in itemList) {
                holder.setText(
                    R.id.express_tv_time,
                    "发货时间：" + TimeUtil.getReserverAppointmentTime(info.confirmTime)
                )
                holder.setText(R.id.express_tv_code, "订单号：${info.id}")
                val view = LayoutInflater.from(context)
                    .inflate(R.layout.book_order_express_books_item_view, llContent, false)
                val pic = view.findViewById<ImageView>(R.id.wd_book_item_pic)
                val tvName = view.findViewById<TextView>(R.id.wd_book_item_name)
                val tvNum = view.findViewById<TextView>(R.id.wd_book_item_num)

                tvName.text = info.wdBook.bookName
                val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
                val pathList = StringUtil.convertStrToList(info.wdBook.images)
                if (pathList.size > 0) {
                    Glide.with(context).load(pathList[0]).apply(operation)
                        .placeholder(R.drawable.ic_default_pic1).into(pic)
                }
                "x${info.bookAmount}".also { tvNum.text = it }
                llContent.addView(view)
            }
        }

    }
}