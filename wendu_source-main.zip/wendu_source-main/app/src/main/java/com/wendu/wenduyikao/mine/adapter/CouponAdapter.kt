package com.wendu.wenduyikao.mine.adapter

import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.WdCouponEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:05 下午
 * @Description: 优惠券适配器
 */
class CouponAdapter(data: ArrayList<WdCouponEntity>) :
    BaseQuickAdapter<WdCouponEntity, BaseViewHolder>(
        R.layout.coupon_item_layout,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: WdCouponEntity) {
        item.run {
            holder.setText(R.id.coupon_item_title, couponName)


            if (timeLimit == 2) {
                holder.setText(R.id.coupon_item_time, "领取"+fixDays.toString() + "天后有效")
            } else {
                val time = "有效期:$effectiveTimeStart-$effectiveTimeEnd"
                holder.setText(R.id.coupon_item_time, time)
            }

            if (flg == 0) {
                holder.setText(R.id.coupon_item_status, "领取并使用")
            } else {
                holder.setText(R.id.coupon_item_status, "去使用")
            }
            holder.setBackgroundResource(R.id.coupon_bg, R.mipmap.icon_bg_coupon_unused)
            val tvType = holder.getView<TextView>(R.id.coupon_item_type)
            StringUtil.getCouponType(category, tvType);
            //优惠券类型（1满减，2折扣）

            when (type) {
                1 -> {
                    val useLimit = "满" + useLimit + "减" + StringUtil.formatDouble(discountAmount)
                    holder.setText(R.id.coupon_item_coupon_type, useLimit)
                    holder.setText(
                        R.id.coupon_item_num,
                        "¥" + StringUtil.formatDouble(discountAmount)
                    )

                }
                2 -> {
                    holder.setText(
                        R.id.coupon_item_num,
                        StringUtil.formatDouble(discountAmount) + "折"
                    )
                }
                else -> {

                }
            }
        }

    }
}