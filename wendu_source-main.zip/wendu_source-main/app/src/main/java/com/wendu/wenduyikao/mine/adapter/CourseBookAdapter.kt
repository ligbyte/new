package com.wendu.wenduyikao.mine.adapter

import android.widget.ImageView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.WdClassesBooks

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 课程资料
 */
class CourseBookAdapter(data: ArrayList<WdClassesBooks>) :
    BaseQuickAdapter<WdClassesBooks, BaseViewHolder>(
        R.layout.course_materials_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: WdClassesBooks) {
        item.run {
            holder.setText(R.id.wd_materials_item_name, wdBook.bookName)
            holder.setText(R.id.wd_materials_item_item_price, "¥" + wdBook.officalPrice.toString())
            val pic = holder.getView<ImageView>(R.id.wd_materials_item_pic)
            val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))

            if (StringUtil.isNotBlank(wdBook.images)) {
                if (wdBook.images.split(",").size > 0) {
                    val imgUrl = wdBook.images.split(",")[0]
                    if (StringUtil.isNotBlank(imgUrl)) {
                        Glide.with(context).load(imgUrl).apply(operation)
                            .placeholder(R.drawable.ic_default_pic1).into(pic)
                    }
                }

            }

        }
    }

}