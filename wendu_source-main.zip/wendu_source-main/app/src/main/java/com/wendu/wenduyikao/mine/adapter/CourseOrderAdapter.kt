package com.wendu.wenduyikao.mine.adapter

import android.graphics.Color
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.CourseOrderEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 课程订单
 */
class CourseOrderAdapter(data: ArrayList<CourseOrderEntity>) :
    BaseQuickAdapter<CourseOrderEntity, BaseViewHolder>(
        R.layout.course_order_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: CourseOrderEntity) {
        item.run {
            holder.setText(R.id.course_order_id, "订单号:$id")
            holder.setText(R.id.course_order_status, status_dictText)
//            holder.setText(R.id.course_order_type, StringUtil.getOrderTypeByType(type))

            val pic = holder.getView<ImageView>(R.id.course_order_pic)
            if (status == "1") {
                holder.getView<TextView>(R.id.order_item_check).visibility = View.GONE
                holder.getView<TextView>(R.id.order_item_close).visibility = View.VISIBLE
                holder.getView<TextView>(R.id.order_item_pay).visibility = View.VISIBLE
            } else {
                holder.getView<TextView>(R.id.order_item_check).visibility = View.VISIBLE
                holder.getView<TextView>(R.id.order_item_close).visibility = View.GONE
                holder.getView<TextView>(R.id.order_item_pay).visibility = View.GONE
            }

            holder.setText(R.id.course_order_total, StringUtil.formatDoublePrice(ddje))
            if (gmqd == "2" ||gmqd == "7") {
                holder.getView<TextView>(R.id.course_order_pay_label).visibility = View.INVISIBLE
                holder.setText(R.id.course_order_pay, "线下开课")
                holder.getView<LinearLayout>(R.id.ll_course_order_total).visibility = View.INVISIBLE
                holder.getView<TextView>(R.id.course_order_price).visibility = View.INVISIBLE
            } else if (gmqd == "6") {
                holder.getView<TextView>(R.id.course_order_pay_label).visibility = View.INVISIBLE
                holder.setText(R.id.course_order_pay, "课程兑换")
                holder.getView<LinearLayout>(R.id.ll_course_order_total).visibility = View.INVISIBLE
                holder.getView<TextView>(R.id.course_order_price).visibility = View.INVISIBLE
            } else {
                holder.getView<TextView>(R.id.course_order_pay_label).visibility = View.VISIBLE
                holder.setText(R.id.course_order_pay, StringUtil.formatDoublePrice(sfje))
                holder.getView<LinearLayout>(R.id.ll_course_order_total).visibility = View.VISIBLE
                holder.getView<TextView>(R.id.course_order_price).visibility = View.VISIBLE
            }
            when {
                wdQuestionPaper != null -> {
                    holder.setText(R.id.order_item_check, "查看题库")
                    holder.setText(R.id.course_order_type, "题库")
                    holder.setTextColor(R.id.course_order_type, Color.parseColor("#3D7DFF"))
                    holder.setBackgroundResource(
                        R.id.course_order_type,
                        R.drawable.shape_order_type_bg_blue
                    )
                    holder.setText(R.id.course_order_name, wdQuestionPaper.paperName)
                    val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
                    Glide.with(context).load(wdQuestionPaper.url).apply(operation)
                        .placeholder(R.drawable.ic_default_pic1).into(pic)
                    holder.setText(R.id.course_order_price, StringUtil.formatDoublePrice(wdQuestionPaper.officialPrice))
                }
                wdClasses != null -> {
                    holder.setText(R.id.course_order_type, "系列课程")
                    holder.setTextColor(R.id.course_order_type, Color.parseColor("#FD2E22"))
                    holder.setText(R.id.order_item_check, "查看课程")
                    holder.setBackgroundResource(
                        R.id.course_order_type,
                        R.drawable.shape_order_type_bg_red
                    )
                    holder.setText(R.id.course_order_name, wdClasses.classesName)
                    val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
                    Glide.with(context).load(wdClasses.classesCover).apply(operation)
                        .placeholder(R.drawable.ic_default_pic1).into(pic)
                }
                type=="8"->{
                    //模块课程
                    holder.setText(R.id.course_order_type, "模块课程")
                    holder.setText(R.id.course_order_name, courseVo.courseName)
                    holder.setTextColor(R.id.course_order_type, Color.parseColor("#FD2E22"))
                    holder.setText(R.id.order_item_check, "查看课程")
                    holder.setBackgroundResource(
                        R.id.course_order_type,
                        R.drawable.shape_order_type_bg_red
                    )
                    val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
                    Glide.with(context).load(courseVo.courseImg).apply(operation)
                        .placeholder(R.drawable.ic_default_pic1).into(pic)
                }
                else -> {

                }

            }


        }
    }

}