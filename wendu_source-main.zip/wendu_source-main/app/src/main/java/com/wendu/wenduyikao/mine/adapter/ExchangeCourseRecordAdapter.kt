package com.wendu.wenduyikao.mine.adapter

import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.ExchangeRecordEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 课程资料
 */
class ExchangeCourseRecordAdapter(data: ArrayList<ExchangeRecordEntity>) :
    BaseQuickAdapter<ExchangeRecordEntity, BaseViewHolder>(
        R.layout.item_exchange_course_record_class,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: ExchangeRecordEntity) {
        item.run {
            holder.setText(R.id.exchange_record_time, usedTime)
            holder.setText(R.id.exchange_record_course_name, wdClassesName)
            holder.setText(R.id.exchange_record_course_brief, wdClassesDescribe)
            holder.setText(R.id.exchange_record_price, "¥$wdClassesFficialPrice")
            val rvTeacher = holder.getView<RecyclerView>(R.id.exchange_record_rv_teacher)
            if (item.wdResourcesTeacherList.isNullOrEmpty()) {
                rvTeacher.visibility = View.GONE
            } else {
                rvTeacher.visibility = View.VISIBLE
            }
            val teacherListAdapter = TeacherListAdapter()
            val manager = LinearLayoutManager(context)
            manager.orientation = RecyclerView.HORIZONTAL
            rvTeacher.layoutManager = manager
            rvTeacher.adapter = teacherListAdapter
            teacherListAdapter.data.clear()
            teacherListAdapter.addData(item.wdResourcesTeacherList)
        }
    }

}