package com.wendu.wenduyikao.mine.adapter

import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.CouponInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:05 下午
 * @Description: 优惠券适配器
 */
class MineCouponAdapter(data: ArrayList<CouponInfoEntity>) :
    BaseQuickAdapter<CouponInfoEntity, BaseViewHolder>(
        R.layout.coupon_item_layout,
        data
    ) {
    private var status = 1

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    fun setStatus(couponStatus: Int) {
        this.status = couponStatus
    }

    override fun convert(holder: BaseViewHolder, item: CouponInfoEntity) {
        item.run {

            holder.setText(R.id.coupon_item_title, wdCoupon.couponName)
            val time = "有效期$effectiveTimeStart-$effectiveTimeEnd"
            holder.setText(R.id.coupon_item_time, time)
            when (status) {
                1 -> {
                    holder.setText(R.id.coupon_item_status, "去使用")
                    holder.setBackgroundResource(R.id.coupon_bg, R.mipmap.icon_bg_coupon_unused)
                    holder.setBackgroundResource(R.id.coupon_item_status,R.drawable.shape_btn_red)
                }
                2 -> {
                    holder.setText(R.id.coupon_item_status, "已使用")
                    holder.setBackgroundResource(R.id.coupon_bg, R.mipmap.icon_bg_coupon_used)
                    holder.setBackgroundResource(R.id.coupon_item_status,R.drawable.shape_bg_tag_gray_30)
                }
                3 -> {
                    holder.setText(R.id.coupon_item_status, "已过期")
                    holder.setBackgroundResource(R.id.coupon_bg, R.mipmap.icon_bg_coupon_used)
                    holder.setBackgroundResource(R.id.coupon_item_status,R.drawable.shape_bg_tag_gray_30)
                }
            }
            //优惠券类型（1满减，2折扣）
            when (wdCoupon.type) {
                1 -> {
                    val useLimit = "满" + wdCoupon.useLimit + "减" + StringUtil.formatDouble(wdCoupon.discountAmount)
                    holder.setText(R.id.coupon_item_coupon_type, useLimit)
                    holder.setText(R.id.coupon_item_num, "¥"+StringUtil.formatDouble(wdCoupon.discountAmount))

                }
                2 -> {
                    holder.setText(R.id.coupon_item_num, (wdCoupon.discountAmount).toString() + "折")
                }
            }


            val tvType = holder.getView<TextView>(R.id.coupon_item_type)
            StringUtil.getCouponType(wdCoupon.category, tvType);
        }

    }
}