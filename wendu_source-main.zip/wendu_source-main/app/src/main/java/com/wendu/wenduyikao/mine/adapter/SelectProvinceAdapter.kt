package com.wendu.wenduyikao.mine.adapter

import android.graphics.Color
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.ProvinceInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/19/21 4:45 PM
 * @Description: 选择省市
 */
class SelectProvinceAdapter(data: ArrayList<ProvinceInfoEntity>) :
    BaseQuickAdapter<ProvinceInfoEntity, BaseViewHolder>(
        R.layout.select_province_view,
        data
    ) {


    private var mPosition = -1

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: ProvinceInfoEntity) {
        item.run {
            holder.setText(R.id.province_item_name, dz)
            if (mPosition == holder.adapterPosition) {
                holder.setTextColor(R.id.province_item_name, Color.parseColor("#3D7DFF"))
                holder.setBackgroundResource(
                    R.id.province_item_name,
                    R.drawable.shape_bg_light_blue_line_blue
                )

            } else {
                holder.setTextColor(R.id.province_item_name, Color.parseColor("#999999"))
                holder.setBackgroundResource(
                    R.id.province_item_name,
                    R.drawable.shape_bg_white
                )

            }
        }
    }

}