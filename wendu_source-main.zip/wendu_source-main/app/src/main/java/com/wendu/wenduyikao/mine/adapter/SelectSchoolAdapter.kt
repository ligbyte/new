package com.wendu.wenduyikao.mine.adapter

import android.graphics.Color
import android.util.Log
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 学习币
 */
class SelectSchoolAdapter(data: ArrayList<SchoolInfoEntity>) :
    BaseQuickAdapter<SchoolInfoEntity, BaseViewHolder>(
        R.layout.select_school_view,
        data
    ) {


    private var mPosition = -1

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: SchoolInfoEntity) {
        item.run {
            holder.setText(R.id.school_item_name, name)
            if (mPosition == holder.adapterPosition) {
                holder.setTextColor(R.id.school_item_name, Color.parseColor("#3D7DFF"))
            } else {
                holder.setTextColor(R.id.school_item_name, Color.parseColor("#666666"))

            }
        }
    }

}