package com.wendu.wenduyikao.mine.adapter

import android.view.View
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseDataBindingHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.data.model.bean.WdResourcesTeacher
import com.wendu.wenduyikao.databinding.ItemExchangeCourseClassTeacherListBinding
import com.wendu.wenduyikao.util.GlideHelper
import com.wendu.wenduyikao.viewmodel.home.ExchangeTeacherViewModel

/**
 * Created：yxm on 2021/8/9 0009.
 * Email：943789510@qq.com
 * Description: 老师列表
 */
class TeacherListAdapter : BaseQuickAdapter<WdResourcesTeacher,
        TeacherListAdapter.TeacherViewHolder>(R.layout.item_exchange_course_class_teacher_list) {

    val maxCount = 5;

    companion object {
        @JvmStatic
        @BindingAdapter("teacherImage")
        fun setTeacherImage(iv: ImageView, resource: String) {
            GlideHelper.loadCircleImage(iv, resource)
        }
    }

    override fun convert(holder: TeacherViewHolder, item: WdResourcesTeacher) {
        holder.myBind(item)
    }


    inner class TeacherViewHolder(view:View):BaseDataBindingHolder<ItemExchangeCourseClassTeacherListBinding>(view){

        fun myBind(item: WdResourcesTeacher){
            dataBinding!!.apply {
                teacherModel = ExchangeTeacherViewModel(item)
            }
        }

    }

    override fun getItemCount(): Int {
        return if(super.getItemCount() > maxCount) maxCount else super.getItemCount()
    }



}