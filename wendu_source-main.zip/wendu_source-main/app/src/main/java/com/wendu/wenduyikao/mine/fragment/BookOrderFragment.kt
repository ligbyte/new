package com.wendu.wenduyikao.mine.fragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.lxj.xpopup.XPopup
import com.lxj.xpopup.enums.PopupAnimation
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseFragment
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.eventbus.RefreshBookOrderEvent
import com.wendu.wenduyikao.data.model.bean.BookOrderEntity
import com.wendu.wenduyikao.databinding.IncludeListBinding
import com.wendu.wenduyikao.dialog.BookOrderExpressDialog
import com.wendu.wenduyikao.mine.BookOrderDetailActivity
import com.wendu.wenduyikao.mine.adapter.BookOrderAdapter
import com.wendu.wenduyikao.question.PayWayActivity
import com.wendu.wenduyikao.ui.home.CoursePayActivity
import com.wendu.wenduyikao.ui.study.activity.PaySuccessActivity
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.include_recyclerview.*
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class BookOrderFragment : BaseFragment<BookOrderViewModel, IncludeListBinding>() {
    private var type = ""

    //请求的ViewModel
    private val requestViewModel: BookOrderViewModel by viewModels()

    //适配器
    private val bookOrderAdapter: BookOrderAdapter by lazy {
        BookOrderAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    private lateinit var footView: DefineLoadMoreView

    override fun layoutId() = R.layout.include_list
    override fun initView(savedInstanceState: Bundle?) {
        arguments?.let {
            type = it.getString("type", "")

        }
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getBookOrderList(true, type)
        }
        EventBus.getDefault().register(this)
        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(mActivity), bookOrderAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getBookOrderList(false, type)
            })
        }
        val list = arrayListOf<BookOrderEntity>()

        bookOrderAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getBookOrderList(true, type)
        }
        bookOrderAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: BookOrderEntity =
                    adapter.getItem(position) as BookOrderEntity
                startActivity(
                    Intent(mActivity, BookOrderDetailActivity::class.java).putExtra(
                        "data",
                        GsonUtils.toJson(info)
                    )
                )
            }

            bookOrderAdapter.addChildClickViewIds(
                R.id.book_order_item_pay,
                R.id.book_order_item_close,
                R.id.book_order_item_check,
                R.id.book_order_item_update_address,
                R.id.book_order_item_receive
            )
            setOnItemChildClickListener { adapter, view, position ->
                val info: BookOrderEntity =
                    adapter.getItem(position) as BookOrderEntity
                when (view.id) {
                    R.id.book_order_item_pay -> {
                        startActivity(
                            Intent(mActivity, PayWayActivity::class.java)
                                .putExtra("isFromOrder", true)
                                .putExtra("isBookOrder", true)
                                .putExtra("price", StringUtil.formatDouble(info.actualPrice))
                                .putExtra("courseClassId", info.id)
                                .putExtra("isNeedUpdateAddress", false)
                                .putExtra("orderId", info.id)
                        )
                        mActivity.finish()
                    }
                    R.id.book_order_item_close -> {
                        requestViewModel.cancelOrderById(info.id)
                    }
                    R.id.book_order_item_check -> {
                        if (info.jsonObjectList.size > 0) {
                            val customPopup: BookOrderExpressDialog =
                                BookOrderExpressDialog(mActivity, info.jsonObjectList)
                            XPopup.Builder(mActivity)
                                .popupAnimation(PopupAnimation.ScaleAlphaFromCenter)
                                .autoOpenSoftInput(false)
                                .asCustom(customPopup)
                                .show()
                        } else {
                            ToastUtils.showShort("暂无发货信息")
                        }

//                        var expressInfo = ""
//                        expressInfo += "订单号：" + info.id + "\n"
//                        expressInfo += "物流公司：" + info.expressCompany + "\n"
//                        expressInfo += "物流单号：" + info.expressNumber + "\n"
//                        showMessage(expressInfo, "物流信息", "确定", {
//
//                        }, "复制单号", {
//                            //获取剪贴板管理器：
//                            //获取剪贴板管理器：
//                            val cm: ClipboardManager =
//                                mActivity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
//                            // 创建普通字符型ClipData
//                            // 创建普通字符型ClipData
//                            val mClipData: ClipData =
//                                ClipData.newPlainText("Label", info.expressNumber)
//                            // 将ClipData内容放到系统剪贴板里。
//                            // 将ClipData内容放到系统剪贴板里。
//                            cm.setPrimaryClip(mClipData)
//                            ToastUtils.showShort("复制到剪切板成功")
//                        })
                    }
                    R.id.book_order_item_receive -> {
                        showMessage("确认收到货物后，才可点击确认收货？", positiveAction = {
                            if (StringUtil.isNotBlank(info.id)) {
                                requestViewModel.confirmOrder(info.id)
                            }

                        })
                    }
                    R.id.book_order_item_update_address -> {

                        startActivity(
                            Intent(mActivity, BookOrderDetailActivity::class.java).putExtra(
                                "data",
                                GsonUtils.toJson(info)
                            )  .putExtra("isNeedUpdateAddress", true)
                        )
                    }
                }
            }

        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun refreshBookOrder(shopCar: RefreshBookOrderEvent) {
        requestViewModel.getBookOrderList(true, type)
    }

    override fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getBookOrderList(true, type)
    }

    override fun createObserver() {
        requestViewModel.bookOrderListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, bookOrderAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                mActivity.finish()
            }
        })
        requestViewModel.confirmOrderResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("确认收货成功")
                requestViewModel.getBookOrderList(true, type)
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.cancelOrderResult.observe(this, Observer {
            if (it.success) {
                requestViewModel.getBookOrderList(true, type)
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    companion object {
        fun newInstance(type: String): BookOrderFragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = BookOrderFragment()
            fragment.arguments = args
            return fragment
        }
    }
}