package com.wendu.wenduyikao.mine.fragment

import androidx.lifecycle.MutableLiveData
import com.google.gson.JsonObject
import com.wendu.wenduyikao.app.network.apiService
import com.wendu.wenduyikao.app.network.stateCallback.ListDataUiState
import com.wendu.wenduyikao.app.network.stateCallback.UpdateUiState
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.BookOrderEntity
import com.wendu.wenduyikao.data.model.bean.BookOrderInfoEntity
import me.xiaoyang.base.base.viewmodel.BaseViewModel
import me.xiaoyang.base.ext.request
import me.xiaoyang.base.state.ResultState

class BookOrderViewModel : BaseViewModel() {
    val token = CacheUtil.getToken();
    var pageNo = 1
    var bookOrderListResult: MutableLiveData<ListDataUiState<BookOrderEntity>> =
        MutableLiveData()
    var cancelOrderResult = MutableLiveData<UpdateUiState<String>>()
    var confirmOrderResult = MutableLiveData<UpdateUiState<String>>()
    var updateAddressResult = MutableLiveData<UpdateUiState<String>>()
    var bookOrderDetail = MutableLiveData<ResultState<BookOrderInfoEntity>>()
    /**
     * 获取课程订单
     * @param isRefresh Boolean
     */
    fun getBookOrderList(isRefresh: Boolean, type: String) {
        if (isRefresh) {
            pageNo = 1
        }
        val mQueryMap = mutableMapOf("pageNo" to pageNo.toString())
        mQueryMap["pageSize"] = "10"
        if (StringUtil.isNotBlank(type)) {
            mQueryMap["status"] = type
        }

        request({ apiService.getBookOrderList(token, mQueryMap) }, {
            //请求成功
            pageNo++
            val listDataUiState =
                ListDataUiState(
                    isSuccess = true,
                    isRefresh = isRefresh,
                    isEmpty = it.isEmpty(),
                    hasMore = it.hasMore(),
                    isFirstEmpty = isRefresh && it.isEmpty(),
                    listData = it.records
                )
            bookOrderListResult.value = listDataUiState
        }, {
            //请求失败
            val listDataUiState =
                ListDataUiState(
                    isSuccess = false,
                    errMessage = it.errorMsg,
                    isRefresh = isRefresh,
                    listData = arrayListOf<BookOrderEntity>()
                )
            bookOrderListResult.value = listDataUiState
        }, true, "图书订单数据加载中")
    }

    /**
     * 获取课程订单
     * @param isRefresh Boolean
     */
    fun getBookOrderListById(id: String) {
        pageNo = 1
        val mQueryMap = mutableMapOf("pageNo" to pageNo.toString())
        mQueryMap["pageSize"] = "10"
        mQueryMap["id"] = id

        request({ apiService.getBookOrderList(token, mQueryMap) }, {
            //请求成功
            pageNo++
            val listDataUiState =
                ListDataUiState(
                    isSuccess = true,
                    isRefresh = true,
                    isEmpty = it.isEmpty(),
                    hasMore = it.hasMore(),
                    isFirstEmpty =  it.isEmpty(),
                    listData = it.records
                )
            bookOrderListResult.value = listDataUiState
        }, {
            //请求失败
            val listDataUiState =
                ListDataUiState(
                    isSuccess = false,
                    errMessage = it.errorMsg,
                    isRefresh = true,
                    listData = arrayListOf<BookOrderEntity>()
                )
            bookOrderListResult.value = listDataUiState
        }, true, "图书订单数据加载中")
    }

    /**
     * 确认收货
     */
    fun confirmOrder(id: String) {
        request({ apiService.confirmOrder(id) }, {
            val updateUiState = UpdateUiState(success = true, result = "")
            confirmOrderResult.value = updateUiState
        }, {
            val updateUiState =
                UpdateUiState(success = false, result = "", message = it.errorMsg)
            confirmOrderResult.value = updateUiState
        })
    }

    /**
     * 关闭交易
     * @param json JsonObject
     */
    fun cancelOrderById(id: String) {
        request({ apiService.cancelBookOrderById(id) }, {
            val updateUiState = UpdateUiState(success = true, result = "")
            cancelOrderResult.value = updateUiState
        }, {
            val updateUiState =
                UpdateUiState(success = false, result = "", message = it.errorMsg)
            cancelOrderResult.value = updateUiState
        })
    }
    /**
     * 完善订单地址信息
     * @param json JsonObject
     */
    fun updateOrderAddress(
        bookOrderId: String,
        orderAreaId: String,
    ) {
        val json = JsonObject()
        json.addProperty("bookOrderId", bookOrderId)
        json.addProperty("orderAreaId", orderAreaId)
        request({ apiService.updateOrderAddress(json) }, {
            val updateUiState = UpdateUiState(success = true, result = "")
            updateAddressResult.value = updateUiState
        }, {
            val updateUiState =
                UpdateUiState(success = false, result = "", message = it.errorMsg)
            updateAddressResult.value = updateUiState
        })
    }

    //获取图书订单详情
    fun getBookOrderDetailById(id: String) {
        request(
            { apiService.getBookOrderDetailById(id) },
            bookOrderDetail,
            true, "加载中~"
        )
    }
}