package com.wendu.wenduyikao.mine.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseFragment
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.constans.MainTabConst
import com.wendu.wenduyikao.data.eventbus.MainTabChooseEvent
import com.wendu.wenduyikao.data.model.bean.CouponInfoEntity
import com.wendu.wenduyikao.databinding.IncludeListBinding
import com.wendu.wenduyikao.discovery.BookListActivity
import com.wendu.wenduyikao.mine.adapter.MineCouponAdapter
import com.wendu.wenduyikao.viewmodel.request.CouponCenterViewModel
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.include_recyclerview.*
import org.greenrobot.eventbus.EventBus

/**
 * @Author     : xiaoyangyan
 * @Time       : 2021/11/21 9:07 下午
 * @Description: 优惠券
 */
class CouponCenterFragment : BaseFragment<CouponCenterViewModel, IncludeListBinding>() {

    private var type = ""

    //请求的ViewModel
    private val requestViewModel: CouponCenterViewModel by viewModels()

    //适配器
    private val couponAdapter: MineCouponAdapter by lazy {
        MineCouponAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    private lateinit var footView: DefineLoadMoreView

    override fun layoutId() = R.layout.include_list
    override fun initView(savedInstanceState: Bundle?) {
        arguments?.let {
            type = it.getString("type", "")

        }
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getCouponList(true, type)
        }

        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(mActivity), couponAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getCouponList(false, type)
            })
        }
        val list = arrayListOf<CouponInfoEntity>()
        couponAdapter.setStatus(type.toInt())
        couponAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getCouponList(true, type)
        }
        couponAdapter.run {

            couponAdapter.addChildClickViewIds(
                R.id.coupon_item_status,
            )
            setOnItemChildClickListener { adapter, view, position ->
                val info: CouponInfoEntity =
                    adapter.getItem(position) as CouponInfoEntity
                when (view.id) {
                    R.id.coupon_item_status -> {
                        if (info.isUsed == 0) {
                            Log.v("yxy","==="+info.wdCoupon.category)
                            when (info.wdCoupon.category) {
                                0, 1 -> {
                                 //跳转首页
                                    mActivity.finish()
                                    EventBus.getDefault().post(MainTabChooseEvent(MainTabConst.HOME))
                                }

                                2 -> {
                                    mActivity.finish()
                                    //题库
                                    EventBus.getDefault().post(MainTabChooseEvent(MainTabConst.QUESTION))
                                }
                                3 -> {
                                    //图书
                                    startActivity(Intent(mActivity, BookListActivity::class.java))
                                }

                            }

                        }
                    }
                }
            }
        }
    }

    override fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getCouponList(true, type)
    }

    override fun createObserver() {
        requestViewModel.couponListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, couponAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.saveCouponResult.observe(this, Observer {
            if (it.success) {
                requestViewModel.getCouponList(true, type)
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }


    companion object {
        fun newInstance(type: String): CouponCenterFragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = CouponCenterFragment()
            fragment.arguments = args
            return fragment
        }
    }
}