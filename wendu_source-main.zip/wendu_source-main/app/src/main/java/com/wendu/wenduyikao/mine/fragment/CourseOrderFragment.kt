package com.wendu.wenduyikao.mine.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseFragment
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.CourseOrderEntity
import com.wendu.wenduyikao.databinding.IncludeListBinding
import com.wendu.wenduyikao.mine.adapter.CourseOrderAdapter
import com.wendu.wenduyikao.question.PayWayActivity
import com.wendu.wenduyikao.question.TestBaseInfoActivity
import com.wendu.wenduyikao.ui.home.CourseClassInfoActivity
import com.wendu.wenduyikao.ui.home.FaceInfoActivity
import com.wendu.wenduyikao.ui.study.activity.CourseInfoActivity
import com.wendu.wenduyikao.util.UmengEventUtils
import com.wendu.wenduyikao.viewmodel.request.CourseOrderViewModel
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.include_recyclerview.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/10/21 6:01 PM
 * @Description: 课程订单
 */
class CourseOrderFragment : BaseFragment<CourseOrderViewModel, IncludeListBinding>() {
    private var type = ""

    //请求的ViewModel
    private val requestViewModel: CourseOrderViewModel by viewModels()

    //适配器
    private val courseOrderAdapter: CourseOrderAdapter by lazy {
        CourseOrderAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    private lateinit var footView: DefineLoadMoreView

    override fun layoutId() = R.layout.include_list
    override fun initView(savedInstanceState: Bundle?) {
        arguments?.let {
            type = it.getString("type", "")

        }
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getCourseOrderList(true, type)
        }


        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(mActivity), courseOrderAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(1f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getCourseOrderList(false, type)
            })
        }
        val list = arrayListOf<CourseOrderEntity>()

        courseOrderAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getCourseOrderList(true, type)
        }
        courseOrderAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: CourseOrderEntity = adapter.getItem(position) as CourseOrderEntity

            }
            courseOrderAdapter.addChildClickViewIds(
                R.id.order_item_pay, R.id.order_item_close, R.id.order_item_check
            )
            setOnItemChildClickListener { adapter, view, position ->
                val info: CourseOrderEntity = adapter.getItem(position) as CourseOrderEntity
                when (view.id) {
                    R.id.order_item_pay -> {
//                        if (info.type == "4") {
//                            startActivity(
//                                Intent(mActivity, PayWayActivity::class.java)
//                                    .putExtra("paperId", info.paperId)
//                                    .putExtra("isFromOrder", true)
//                                    .putExtra("price", info.ddje.toString())
//                                    .putExtra("orderId", info.id)
//                            )
//                        } else {
//
//                            PayWayActivity.toThis(mActivity, info.classesId, info.classesTypeId)
//                        }
                        var isNeedUpdateAddress = false
                        if (info.wdClasses?.wdBookOrder != null) {
                            isNeedUpdateAddress = true
                        } else {
                            isNeedUpdateAddress = false
                        }
                        Log.v("yxy", "isNeedUpdateAddress===" + isNeedUpdateAddress)
                        startActivity(
                            Intent(mActivity, PayWayActivity::class.java).putExtra(
                                "paperId",
                                info.paperId
                            ).putExtra("isFromOrder", true)
                                .putExtra("price", StringUtil.formatDouble(info.sfje))
                                .putExtra("orderId", info.id)
                                .putExtra("courseClassId", info.id)
                                .putExtra("isNeedUpdateAddress", isNeedUpdateAddress)
                        )

                        UmengEventUtils.onEventObject("paying_order","", "待支付", info.id)
                    }
                    R.id.order_item_close -> {
                        requestViewModel.cancelOrderById(info.id)
                        UmengEventUtils.onEventObject("cancel_order","", "取消订单", info.id)
                    }
                    R.id.order_item_check -> {
                        when (info.type) {
                            "4" -> {
                                startActivity(
                                    Intent(
                                        mActivity,
                                        TestBaseInfoActivity::class.java
                                    ).putExtra("paperId", info.wdQuestionPaper.id)
                                        .putExtra("from", "order")
                                )
                            }
                            "6" -> {
                                //为6时需要去判断faceClass:2是面授订单 1是面授赠送的系列课程订单
                                if(info.wdClasses.faceClass==2){
                                    FaceInfoActivity.toThis(mContext!!, info.wdClasses.id)
                                }else if(info.wdClasses.faceClass==1){
                                    if (info.wdClasses != null) {
                                        CourseClassInfoActivity.toThis(mActivity, info.wdClasses.id)
                                    }
                                }

                            }
                            "7" -> {
                                if (info.wdClasses != null) {
                                    CourseClassInfoActivity.toThis(mActivity, info.wdClasses.id)
                                }
                            }
                            "8" -> {
                                CourseInfoActivity.toThis(
                                    mActivity, "", info.moduleCourseId, ""
                                )
                            }
                        }
//
//                        if (info.wdClasses != null) {
//                            CourseClassInfoActivity.toThis(mActivity, info.wdClasses.id)
//                        }
//                        else {
//                            startActivity(
//                                Intent(mActivity, TestBaseInfoActivity::class.java)
//                                    .putExtra("paperId", info.wdQuestionPaper.id)
//                                    .putExtra("from", "order")
//                            )
//                        }

                    }
                }
            }
        }
    }

    override fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getCourseOrderList(true, type)
    }

    override fun createObserver() {
        requestViewModel.courseOrderListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, courseOrderAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                mActivity.finish()
            }
        })
        requestViewModel.cancelOrderResult.observe(this, Observer {
            if (it.success) {
                requestViewModel.getCourseOrderList(true, type)
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    companion object {
        fun newInstance(type: String): CourseOrderFragment {
            val args = Bundle()
            args.putString("type", type)
            val fragment = CourseOrderFragment()
            fragment.arguments = args
            return fragment
        }
    }
}