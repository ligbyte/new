package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.ext.loadServiceInit
import com.wendu.wenduyikao.app.ext.showEmpty
import com.wendu.wenduyikao.app.ext.showLoading
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.QuestionChapterEntity
import com.wendu.wenduyikao.databinding.ActivityChapterBinding
import com.wendu.wenduyikao.question.adapter.QuestionChapterAdapter
import com.wendu.wenduyikao.util.FastClickUtils
import com.wendu.wenduyikao.util.RxSimple
import com.wendu.wenduyikao.viewmodel.request.RequestChapterViewModel
import kotlinx.android.synthetic.main.activity_chapter.*
import kotlinx.android.synthetic.main.content_toolbar_view.*

/**
 * 章节下二级节点
 * @property id String
 * @property requestViewModel RequestChapterViewModel
 */
class ChapterActivity : BaseActivity<RequestChapterViewModel, ActivityChapterBinding>() {


    private var id: String = ""
    private var templateId: String = ""
    private var title: String = ""
    private lateinit var loadsir: LoadService<Any>
    private val requestViewModel: RequestChapterViewModel by viewModels()
    private var from = 0 //0 默认章节联系 1 精品题库章节联系

    override fun layoutId() = R.layout.activity_chapter

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, chapter_ll_content)
        img_back.setOnClickListener { finish() }
        id = intent.getStringExtra("id").toString()
        from = intent.getIntExtra("from", 0)
        templateId = intent.getStringExtra("templateId").toString()
        title = intent.getStringExtra("title").toString()
        if (StringUtil.isNotBlank(title)) {
            tv_toolbar_title.text = title
        }
        if (StringUtil.isNotBlank(id)) {
            if (from == 1) {
                requestViewModel.getChildTemplateListById(id, templateId)
            } else {
                requestViewModel.getQuestionChapterListById(id, templateId)
            }


        }
        loadsir = loadServiceInit(chapter_rlv_question) {
            //点击重试时触发的操作
            loadsir.showLoading()
            if (from == 1) {
                requestViewModel.getChildTemplateListById(id, templateId)
            } else {
                requestViewModel.getQuestionChapterListById(id, templateId)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (from == 1) {
            requestViewModel.getChildTemplateListById(id, templateId)
        } else {
            requestViewModel.getQuestionChapterListById(id, templateId)
        }
    }

    private fun initRecycleView(list: ArrayList<QuestionChapterEntity>) {
        val chapterAdapter = QuestionChapterAdapter(list)
        //初始化recyclerView
        chapter_rlv_question.init(
            LinearLayoutManager(this),
            chapterAdapter
        )
        chapterAdapter.addChildClickViewIds(R.id.question_boutique_lock)
        chapterAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionChapterEntity =
                    adapter.getItem(position) as QuestionChapterEntity
                if (info.isUnlock == 1) {
                    if (info.subjectNumber > 0) {
                        if (from == 1) {
                            var isDo = false
                            isDo = info.doSubjectNumber > 0
                            if (RxSimple.isFastClick(1000)) {
                                return@setOnItemClickListener
                            }
                            startActivity(
                                Intent(this@ChapterActivity, ExamAnswerActivity::class.java)
                                    .putExtra("paperId", id)
                                    .putExtra("total", info.subjectNumber)
                                    .putExtra("type", 2)
                                    .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE)
                                    .putExtra("loadFrom", 1)
                                    .putExtra("templateId", info.templateId)
                                    .putExtra("isDo", isDo)
                                    .putExtra("index", 0)
                            )

                        } else {
                            if (RxSimple.isFastClick(1000)) {
                                return@setOnItemClickListener
                            }
                            startActivity(
                                Intent(this@ChapterActivity, QuestionAnswerActivity::class.java)
                                    .putExtra(Constants.PARAMS_QUESTION_CHAPTER_ID, info.chapterId)
                                    .putExtra(
                                        Constants.PARAMS_QUESTION_TEMPLATE_ID,
                                        info.templateId
                                    )
                                    .putExtra("total", info.subjectNumber)
                                    .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_CHAPTER)
                            )

                        }

                    } else {
                        ToastUtils.showShort("该节暂无题目")
                    }
                } else {
                    ToastUtils.showShort("该章节未解锁")
                }
            }

        }
    }

    override fun createObserver() {
        requestViewModel.chapterDataState.observe(this, Observer {
            if (it.isSuccess) {
                if (it.isEmpty) {
                    loadsir.showEmpty()
                } else {
                    initRecycleView(it.listData)
                    loadsir.showSuccess()
                }

            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
    }
}