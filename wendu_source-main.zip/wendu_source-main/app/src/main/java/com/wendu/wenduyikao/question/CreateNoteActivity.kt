package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Parcelable
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonObject
import com.hjq.permissions.Permission
import com.ligbyte.lib.theme.ActivityTheme
import com.luck.picture.lib.PictureExternalPreviewActivity
import com.luck.picture.lib.PictureSelector
import com.luck.picture.lib.config.PictureConfig
import com.luck.picture.lib.entity.LocalMedia
import com.luck.picture.lib.listener.OnResultCallbackListener
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.databinding.ActivityCreateNoteBinding
import com.wendu.wenduyikao.util.*
import com.wendu.wenduyikao.viewmodel.request.RequestNoteViewModel
import com.zhihu.matisse.Matisse
import kotlinx.android.synthetic.main.activity_create_note.*
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:28 PM
 * @Description: 创建笔记
 */
class CreateNoteActivity : BaseActivity<RequestNoteViewModel, ActivityCreateNoteBinding>() {

    private val requestViewModel: RequestNoteViewModel by viewModels()
    private var subjectId = ""
    private var id = ""
    private var type = 1 //类型 1章节练习 2试卷管理
    private val imageList: ArrayList<String> = arrayListOf()
    private val REQUEST_CODE_CHOOSE: Int = 2050
    override fun layoutId() = R.layout.activity_create_note
    private val maxLen = 100 // the max byte
    private val maxChooseSize: Int = 3
    var choosePicture: MutableList<LocalMedia> = mutableListOf()
    private var editStart = 0
    private var editEnd = 0
    private var content = ""
    private var pictureResultPath: String = ""

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, create_note_content)
        tv_toolbar_title.text = "笔记"
        img_back.setOnClickListener { finish() }
        subjectId = intent.getStringExtra("subjectId").toString()
        type = intent.getIntExtra("type", 1)
        mDatabind.click = ProxyClick()
        iv_pick_img.setOnClickListener {
            checkPermission()
        }
        editTextMaxLengthListener()
    }

    override fun createObserver() {
        var count = 0
        requestViewModel.createNoteResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("添加笔记成功")
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.fileResult.observe(this, Observer {
            pictureResultPath += "$it,"
            count++
            if(count == choosePicture.size){
                when {
                    create_note_ed_desc.text.isEmpty() -> ToastUtils.showShort("请输入笔记内容")
                    else -> {
                        val json = JsonObject()
                        if (pictureResultPath.length > 0) {
                            json.addProperty(
                                "imageUrl",
                                pictureResultPath.substring(0, pictureResultPath.length - 1)
                            )
                        }
                        json.addProperty("note", create_note_ed_desc.text.toString())
                        json.addProperty("subjectId", subjectId)
                        json.addProperty("type", type)
                        json.addProperty("majorId", CacheUtil.getQuestionMajorId())
                        requestViewModel.createNote(json)
                    }
                }
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_CHOOSE) {
                val paths = Matisse.obtainPathResult(data)
                val path = paths[0]
                if (StringUtil.isNotBlank(path)) {
                    var parts: List<MultipartBody.Part?>? = null
                    val builder = MultipartBody.Builder()
                        .setType(MultipartBody.FORM) //表单类型
                    val file = File(path)
                    val body =
                        RequestBody.create(MediaType.parse("multipart/form-data"), file);//表单类型
                    builder.addFormDataPart("file", file.name, body)
                    parts = builder.build().parts()
                    requestViewModel.uploadFile(parts)
                }
            }
        }
    }

    inner class ProxyClick() {
        fun createNote() {
            if (!choosePicture.isNullOrEmpty()) {
                choosePicture.forEach {
                    val builder = MultipartBody.Builder()
                        .setType(MultipartBody.FORM) //表单类型
                    var parts: List<MultipartBody.Part?>? = null
                    val file = File(it.compressPath)
                    val body =
                        RequestBody.create(MediaType.parse("multipart/form-data"), file);//表单类型
                    builder.addFormDataPart("file", file.name, body)
                    parts = builder.build().parts()
                    requestViewModel.uploadFile(parts)
                }
            } else {
                when {
                    create_note_ed_desc.text.isEmpty() -> ToastUtils.showShort("请输入笔记内容")
                    else -> {
                        val json = JsonObject()
                        if (pictureResultPath.length > 0) {
                            json.addProperty(
                                "imageUrl",
                                pictureResultPath.substring(0, pictureResultPath.length - 1)
                            )
                        }
                        json.addProperty("note", create_note_ed_desc.text.toString())
                        json.addProperty("subjectId", subjectId)
                        json.addProperty("type", type)
                        json.addProperty("majorId", CacheUtil.getQuestionMajorId())
                        requestViewModel.createNote(json)
                    }
                }
            }


        }


        fun uploadFile() {
            checkPermission()

        }
    }

    fun checkPermission() {
        PermissionHelper.checkMyPermission(
            this,
            object : HasStoragePermissionListener {
                override fun hasPermission(isAll: Boolean) {
                    pickPicture()
                }

                override fun noPermission() {}
                override fun cancel() {}
            },
            Permission.CAMERA, Permission.WRITE_EXTERNAL_STORAGE
        )
    }

    /**
     * 图片选择
     */
    private fun pickPicture() {
        val path = Storage.getImageDir(this).path;//压缩图片
        //结果返回回调，不用再写onActivityResult 方法
        PictureSelector.create(this)
            .themeStyle(R.style.picture_default_style)
            .maxSelectNum(maxChooseSize) //最多选取多少张
            .selectionMode(PictureConfig.MULTIPLE) //多图选择
            .isCamera(true) //是否显示拍照按钮
            .isPreviewImage(true) //是否可预览
            .isCompress(true) //是否压缩
            .compressSavePath(path) //压缩图片保存地址
            .imageEngine(GlideEngine.createGlideEngine()) // 请参考Demo GlideEngine.java
            .selectionData(choosePicture) // 是否传入已选图片
            .forResult(object : OnResultCallbackListener<LocalMedia?> {
                override fun onResult(result: List<LocalMedia?>?) {
                    bindingImage(result)
                }

                override fun onCancel() {}
            })
    }

    /**
     * 图片绑定到布局上
     */
    private fun bindingImage(result: List<LocalMedia?>?) {
        try {
            if (result.isNullOrEmpty()) return
            if(ll_upload_images.childCount > 1){
                for (i in 0 until ll_upload_images.childCount - 1){
                    ll_upload_images.removeViewAt(i)
                }
            }
            choosePicture.removeAll(choosePicture)

            ll_upload_images.removeAllViews()
            choosePicture.removeAll(choosePicture)
            val view = View.inflate(this, R.layout.layout_add_image, null)
            val ivPickImg = view.findViewById<RTextView>(R.id.iv_pick_img)
            val a = resources.getDimension(R.dimen.dp_95).toInt()
            val layoutParam = FrameLayout.LayoutParams(a,a)
            layoutParam.topMargin = 10
            view.layoutParams = layoutParam
            ll_upload_images.addView(ivPickImg)
            ivPickImg.setOnClickListener {
                checkPermission()
            }
            for (i in result.indices) {
                val localMedia: LocalMedia? = result[i]
                val view = View.inflate(this, R.layout.item_upload_img, null)
                val image = view.findViewById<ImageView>(R.id.iv_to_upload_img)
                GlideHelper.loadRoundRectImage(image, localMedia!!.compressPath, 8)
                val close = view.findViewById<ImageView>(R.id.iv_close)
                close.setOnClickListener { v: View? ->
                    choosePicture.remove(localMedia)
                    ll_upload_images.removeView(view)
                    if (choosePicture.size < maxChooseSize) {
                        iv_pick_img.visibility = View.VISIBLE
                    }
                }
                image.setOnClickListener { v: View? ->
                    val media: MutableList<LocalMedia?> = mutableListOf()
                    media.add(localMedia)
                    viewBigImage(result, i)
                }
                ll_upload_images.addView(view, i)
                choosePicture.add(localMedia)
            }
            if (choosePicture.size == maxChooseSize) {
                iv_pick_img.visibility = View.GONE
            }
        }catch (e:Throwable){
            Log.d("yxm", "bindingImage: " + e.message)
        }
    }

    /**
     * 页面内点击图片预览功能
     *
     * @param localMedia
     * @param position
     */
    private fun viewBigImage(localMedia: List<LocalMedia?>, position: Int) {
        val intent: Intent = Intent(
            this,
            PictureExternalPreviewActivity::class.java
        )
        intent.putParcelableArrayListExtra(
            PictureConfig.EXTRA_PREVIEW_SELECT_LIST,
            localMedia as ArrayList<out Parcelable?>
        )
        intent.putExtra(PictureConfig.EXTRA_POSITION, position)
        startActivity(intent)
        overridePendingTransition(
            R.anim.picture_anim_enter,
            R.anim.picture_anim_fade_in
        )
    }

    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        create_note_ed_desc.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = create_note_ed_desc.selectionStart
                editEnd = create_note_ed_desc.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(create_note_ed_desc.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                create_note_ed_desc.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(create_note_ed_desc.text.toString())
        currentCount = nowCount
        //
        create_note_publish_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }


    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }
}