package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.QuestionPaperEntity
import com.wendu.wenduyikao.databinding.ActivityCreateTestBaseOrderBinding
import com.wendu.wenduyikao.viewmodel.request.RequestTestBaseViewModel
import kotlinx.android.synthetic.main.activity_test_base_info.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/13/21 4:11 PM
 * @Description: 创建题库订单
 */
class CreateTestBaseOrderActivity :
    BaseActivity<RequestTestBaseViewModel, ActivityCreateTestBaseOrderBinding>() {

    private val requestViewModel: RequestTestBaseViewModel by viewModels()
    private var paperId = ""
    override fun layoutId() = R.layout.activity_create_test_base_order
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setDarkMode(this)
        StatusBarUtil.setPaddingSmart(this, create_testbase_ll_content)
        tv_toolbar_title.text = "题库订单"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        paperId = intent.getStringExtra("paperId").toString()
        if (StringUtil.isNotBlank(paperId)) {
            requestViewModel.getQuestionPaperInfoById(paperId)
        }
    }

    override fun createObserver() {
        requestViewModel.paperInfoResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    mDatabind.info = it
                    setPaperDetailInfo(it)
                }
            })
        })
    }

    private fun setPaperDetailInfo(info: QuestionPaperEntity) {

        Glide.with(this).load(info.url).placeholder(R.drawable.ic_default_pic1)
            .into(create_testbase_pic)

    }

    inner class ProxyClick() {
        fun gotoPayClick() {
            startActivity(
                Intent(
                    this@CreateTestBaseOrderActivity,
                    PayWayActivity::class.java
                ).putExtra("paperId", paperId)
                    .putExtra("paperId", paperId)
            )
            finish()
        }
    }

}