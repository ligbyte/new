package com.wendu.wenduyikao.question


import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.WhichButton
import com.afollestad.materialdialogs.actions.getActionButton
import com.afollestad.materialdialogs.lifecycle.lifecycleOwner
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.SPUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.player.PolyvPlayerPreviewView
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.easefun.polyvsdk.video.listener.IPolyvOnPreparedListener2
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.AnswerCountDownTimerUtils
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.CacheUtil.getMajorId
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.countdowntimer.CountDownTimerSupport
import com.wendu.wenduyikao.app.weight.countdowntimer.OnCountDownTimerListener
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.TestPaperSubmitSuccessEvent
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.SubjectFileEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivityExam2Binding
import com.wendu.wenduyikao.dialog.CustomAlertDialog
import com.wendu.wenduyikao.dialog.CustomAlertDialog.EditTextDialogListener
import com.wendu.wenduyikao.dialog.PaperScantronCardDialog
import com.wendu.wenduyikao.dialog.RecoveryErrorDialog
import com.wendu.wenduyikao.dialog.SettingsDialog
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.QuestionPaperMutOperationAdapter
import com.wendu.wenduyikao.question.adapter.QuestionSinPaperOperationAdapter
import com.wendu.wenduyikao.util.RxSimple
import com.wendu.wenduyikao.viewmodel.request.RequestExamViewModel
import kotlinx.android.synthetic.main.activity_exam.exam_data_media_controller
import kotlinx.android.synthetic.main.activity_exam.exam_data_video_view
import kotlinx.android.synthetic.main.activity_exam.exam_data_view_layout
import kotlinx.android.synthetic.main.activity_exam.exam_img_back
import kotlinx.android.synthetic.main.activity_exam.exam_ll_content
import kotlinx.android.synthetic.main.activity_exam.exam_stop
import kotlinx.android.synthetic.main.activity_exam.exam_time
import kotlinx.android.synthetic.main.activity_exam.question_exam_data_img
import kotlinx.android.synthetic.main.activity_exam.question_exam_edt_result
import kotlinx.android.synthetic.main.activity_exam.question_exam_index
import kotlinx.android.synthetic.main.activity_exam.question_exam_ll_stem
import kotlinx.android.synthetic.main.activity_exam.question_exam_rl_result
import kotlinx.android.synthetic.main.activity_exam.question_exam_rlv_operation
import kotlinx.android.synthetic.main.activity_exam.question_exam_score
import kotlinx.android.synthetic.main.activity_exam.question_exam_stem
import kotlinx.android.synthetic.main.activity_exam.question_exam_sub_index
import kotlinx.android.synthetic.main.activity_exam.question_exam_text_num
import kotlinx.android.synthetic.main.activity_exam.question_exam_title
import kotlinx.android.synthetic.main.activity_exam.question_exam_type
import kotlinx.android.synthetic.main.activity_exam2.*
import kotlinx.android.synthetic.main.activity_exam2.exam_up
import kotlinx.android.synthetic.main.activity_question_answer.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.litepal.LitePal


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 8:56 AM
 * @Description: 考试
 */
class Exam2Activity :
    BaseActivity<RequestExamViewModel, ActivityExam2Binding>() {

    private var index = 1//已经完结的题目索引
    private var subIndex = 1   //子题目索引
    private var totalNum = 0  //题目总数
    private var liftingType = 1  //当前题目类型
    private var type = 1; //类型 1章节练习(章节练习) 2 试卷管理(历年真题,精品题库) 3评测试卷 4模拟试卷 5经典试卷
    private var paperId = ""
    private var from = "paper"   //paper 来自试卷   card  来自答题卡
    private val requestViewModel: RequestExamViewModel by viewModels()
    private var mCountDownTimerUtils: AnswerCountDownTimerUtils? = null
    private var useTime = 0L
    private var isPause = false
    private var subjectId = ""//题干id
    private var parentId = ""//主题干id
    private var mTimer: CountDownTimerSupport? = null
    private var solution = "" //主观题答案
    private var goNext = true //多选逻辑，需要做次校验
    private var selectOptions = arrayListOf<QuestionOptionEntity>()
    private var optionId = ""  //选项id
    private var isRight = 0
    private val maxLen = 100 // the max byte
    private var editStart = 0
    private var editEnd = 0
    private var classId = ""
    private var appraisalId = ""
    private var isHasZhuguan = false //题库是否包含主观题
    private var paperType = ""
    private var isMultiple = false; //共用题干类型下是否为多选
    private var loadfrom = ""
    var questionSettingsDialog: BaseBottomSheetDialog? = null

    //适配器
    private var mutOperationAdapter: QuestionPaperMutOperationAdapter =
        QuestionPaperMutOperationAdapter(
            arrayListOf()
        )
    private var singleOperationAdapter: QuestionSinPaperOperationAdapter =
        QuestionSinPaperOperationAdapter(
            arrayListOf()
        )

    override fun layoutId() = R.layout.activity_exam2

    override fun initView(savedInstanceState: Bundle?) {
        if (MultiTheme.getAppTheme() == 1){
            StatusBarUtil.setDarkMode(this)
        }else{
            StatusBarUtil.setLightMode(this)
        }
        StatusBarUtil.setPaddingSmart(this, exam_ll_content)
        EventBus.getDefault().register(this)

        Constants.questionTextSize = (SPUtils.getInstance().getFloat("fontSize",50f) - 50)/100 * 4 *2
        setTextSize()
        exam_img_back.setOnClickListener {
            /*MaterialDialog(this@Exam2Activity).show {
                cancelable(false)
                lifecycleOwner(this@Exam2Activity)
                title(text = "答题未结束，是否确认退出")

                positiveButton(R.string.confirm, "继续做题") {
                    dismiss()
                }
                negativeButton(R.string.cancel, "确认退出") {


                    if(from==Constants.PARAMS_QUESTION_SOURCE_REAL){
                        //ToastUtils.showShort("精品题库重新答题")
                        val json = JsonObject()
                        json.addProperty("type", 2)
                        json.addProperty("paperId", paperId)

                        requestViewModel.questionAgain(json)
                    }
                    finish()


                }

                if (MultiTheme.getAppTheme() == 1) {
                    view.background = resources.getDrawable(R.drawable.dialog_alert_bg_dark)
                    view.titleLayout.findViewById<TextView>(R.id.md_text_title).setTextColor(Color.parseColor("#A2A2A2"))
                }

                getActionButton(WhichButton.POSITIVE).updateTextColor(
                    Color.parseColor("#0077FF")
                )
                getActionButton(WhichButton.NEGATIVE).updateTextColor(
                    Color.parseColor("#FA642D")
                )
            }  */
            val customAlertDialog = CustomAlertDialog(this, "提示", "答题未结束，是否确认退出")
            customAlertDialog.setEditTextDialogListener(object : EditTextDialogListener {
                override fun onCancle() {
                    customAlertDialog.dismiss()
                    if(from==Constants.PARAMS_QUESTION_SOURCE_REAL){
                        //ToastUtils.showShort("精品题库重新答题")
                        val json = JsonObject()
                        json.addProperty("type", 2)
                        json.addProperty("paperId", paperId)

                        requestViewModel.questionAgain(json)
                    }
                    finish()
                }
                override fun onOk(content: String) {

                }
            })
            customAlertDialog.show()
        }
        mDatabind.click = ProxyClick()
        totalNum = intent.getIntExtra("total", 0)
        type = intent.getIntExtra("type", 1)
        index = intent.getIntExtra("index", 1)
        useTime = intent.getLongExtra("useTime", 0)
        from = intent.getStringExtra("from").toString()
//        mCountDownTimerUtils = AnswerCountDownTimerUtils(exam_time, useTime * 60 * 1000, 1000)
        setQuestionIndex(index, totalNum, false)
        if (from == "card") {
            paperId = intent.getStringExtra("paperId").toString()
            loadfrom=intent.getStringExtra("loadfrom").toString()
            exam_stop.visibility = View.GONE
            classId = intent.getStringExtra(Constants.PARAMS_QUESTION_CLASS_ID) ?: ""
            appraisalId = intent.getStringExtra("appraisalId") ?: ""
            totalNum = LitePal.count(QuestionPaperDbEntity::class.java)

            if (totalNum > 0) {
                val info = LitePal.where("position=?", index.toString())
                    .findFirst(QuestionPaperDbEntity::class.java)
                if (info != null) {
                    setQuestionView(info)
                }
            }
          from=loadfrom
        } else if (from == "error") {
            exam_stop.visibility = View.GONE
            exam_time.visibility = View.GONE
            exam_stop.visibility = View.GONE
            val errorLiftType = intent.getIntExtra("errorLiftType", 1)
            val dataType = intent.getIntExtra("dataType", 1)
            val params = mutableMapOf<String, String>()
            params["liftingType"] = errorLiftType.toString()
            params["type"] = dataType.toString()
            requestViewModel.getQuestionByError(params)
        } else if (from == "mock_produce") {
            val examId = intent.getStringExtra("examId").toString()
            val params = mutableMapOf<String, String>()
            params["examId"] = examId
            requestViewModel.getQuestionByExam(params)
            if (useTime > 0) {
                exam_time.visibility = View.VISIBLE
                exam_stop.visibility = View.VISIBLE
                startTimer()
            } else {
                exam_time.visibility = View.GONE
                exam_stop.visibility = View.GONE
            }
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER) {
            paperId = intent.getStringExtra("paperId").toString()
            classId = intent.getStringExtra(Constants.PARAMS_QUESTION_CLASS_ID).toString()
            appraisalId = intent.getStringExtra("appraisalId").toString()
            paperType = intent.getStringExtra("paperType") ?: ""
            if (StringUtil.isNotBlank(paperId)) {
                if (paperType == "4") {
                    requestViewModel.getQuestionPaperSubject2List(paperId)
                } else {
                    requestViewModel.getQuestionPaperSubjectList(paperId)
                }

            }
            if (useTime > 0) {
                exam_time.visibility = View.VISIBLE
                exam_stop.visibility = View.VISIBLE
                startTimer()
            } else {
                exam_time.visibility = View.GONE
                exam_stop.visibility = View.GONE
            }

        } else {
            paperId = intent.getStringExtra("paperId").toString()
            if (StringUtil.isNotBlank(paperId)) {
                requestViewModel.getQuestionPaperSubjectList(paperId)
            }
            if (useTime > 0) {
                exam_time.visibility = View.VISIBLE
                exam_stop.visibility = View.VISIBLE
                startTimer()
            } else {
                exam_time.visibility = View.GONE
                exam_stop.visibility = View.GONE
            }

        }
        Log.v("yxy", "exam2" + paperId)
        editTextMaxLengthListener()

        setIconFont(exam_up,"\ue62e")
        setIconFont(exam_down,"\ue62f")
    }

    /**
     * 开始倒计时
     */
    fun startTimer() {
        if (mTimer != null) {
            mTimer?.stop()
            mTimer = null
        }
        //useTime * 60 * 1000
        mTimer = CountDownTimerSupport(useTime * 60 * 1000, 1000)
        mTimer?.setOnCountDownTimerListener(object : OnCountDownTimerListener {
            override fun onTick(millisUntilFinished: Long) {
                val maxTime = millisUntilFinished / 1000
                var hour = maxTime / 60 / 60 % 60;
                val minute = maxTime / 60 % 60;
                val second = maxTime % 60;
                var hourLabel = ""
                var minLabel = ""
                var secLabel = ""
                hourLabel = if (hour > 9) {
                    hour.toString()
                } else {
                    "0$hour"
                }
                minLabel = if (minute > 9) {
                    minute.toString()
                } else {
                    "0$minute"
                }
                secLabel = if (second > 9) {
                    second.toString()
                } else {
                    "0$second"
                }

                exam_time.text = "$hourLabel:$minLabel:$secLabel " //设置倒计时时间
                Log.d("CountDownTimerSupport", "onTick : " + millisUntilFinished + "ms")
            }

            override fun onFinish() {
                exam_time.setText("00:00:00")
                Log.d("CountDownTimerSupport", "onFinish")

                MaterialDialog(this@Exam2Activity).show {
                    cancelable(false)
                    lifecycleOwner(this@Exam2Activity)
                    title(text = "考试时间已结束")

                    positiveButton(R.string.confirm, "提交答案") {
                        gotoSubmitQuestion()
                    }
                    negativeButton(R.string.cancel, "继续答题") {
                        isPause = false
                        cancel()
                    }

                    if (MultiTheme.getAppTheme() == 1) {
                        view.background = resources.getDrawable(R.drawable.dialog_alert_bg_dark)
                        view.titleLayout.findViewById<TextView>(R.id.md_text_title).setTextColor(Color.parseColor("#A2A2A2"))
                    }
                    getActionButton(WhichButton.POSITIVE).updateTextColor(
                        Color.parseColor("#0077FF")
                    )
                    getActionButton(WhichButton.NEGATIVE).updateTextColor(
                        Color.parseColor("#FA642D")
                    )
                }

            }

            override fun onCancel() {
                Log.d("CountDownTimerSupport", "onCancel")
            }
        })
        mTimer?.start()
    }

    override fun createObserver() {
        requestViewModel.errorCorrectionResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("提交成功")
                questionSettingsDialog?.dismiss()
            }})

        requestViewModel.questionListResult.observe(this, Observer {
            if (it.isSuccess) {
                CacheUtil.setQuestionPaperSubject(it.listData)
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                var position = 0
                var questionIndex = 0
                var total = 0
                for (info in it.listData) {
                    for (quest in info.list) {
                        total += 1
                    }
                }

                for (info in it.listData) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1

                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText = sub.answerText
                                    questionDb.parentId = quest.id
                                    questionDb.total = total
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.questionId = sub.id
                                    questionDb.score = sub.score
                                    questionDb.stem = quest.stem
                                    questionDb.questionIndex = questionIndex
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    if (sub.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(sub.wdQuestionPaperData)
                                    }
                                    if (sub.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)
                                    }
                                    questionDb.save()
                                }

                            }
                            else -> {
                                isHasZhuguan = quest.liftingType == 5
                                questionIndex += 1
                                position += 1
                                Log.v(
                                    "yxy",
                                    "===quest.liftingType=2=" + quest.liftingType + "position" + position + "====" + questionIndex
                                )
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText = quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                questionDb.stem = quest.stem
                                questionDb.parentId = quest.id
                                questionDb.score = quest.score
                                questionDb.total = total
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }

                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)
                                }
                                questionDb.save()
                            }
                        }
                    }
                }
                totalNum = questionIndex
                index = 1
//                Log.v(
//                    "yxy",
//                    "===" + LitePal.count(QuestionPaperDbEntity::class.java) + "====" + index
//                )
                setQuestionView(
                    LitePal.where("position=?", "1")
                        .findLast(QuestionPaperDbEntity::class.java)
                )
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.examQuestionListResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                CacheUtil.setQuestionPaperSubject(it.list)
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                var position = 0
                var questionIndex = 0

                var total = 0
                for (info in it.list) {
                    for (quest in info.list) {
                        total += 1
                    }
                }

                for (info in it.list) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText = sub.answerText
                                    questionDb.isCollect = quest.isCollect
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.parentId = quest.id
                                    questionDb.answer = sub.answer
                                    questionDb.questionId = sub.id
                                    questionDb.total = total
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.score = sub.score
                                    questionDb.stem = quest.stem
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (sub.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(sub.wdQuestionPaperData)
                                    }
                                    if (sub.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)
                                    }
                                    questionDb.save()
                                }

                            }
                            else -> {
                                questionIndex += 1
                                position += 1
                                Log.v(
                                    "yxy",
                                    "===quest.liftingType=2=" + quest.liftingType + "position" + position + "====" + questionIndex
                                )
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText = quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                questionDb.stem = quest.stem
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.parentId = quest.id
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.score = quest.score
                                questionDb.total = total
                                questionDb.position = position
                                questionDb.questionIndex = questionIndex
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)
                                }
                                questionDb.save()
                            }
                        }
                    }
                }
                totalNum = questionIndex
                index = 1
                Log.v(
                    "yxy",
                    "===" + LitePal.count(QuestionPaperDbEntity::class.java) + "====" + index
                )
                paperId = it.paperId
                setQuestionView(
                    LitePal.where("position=?", "1")
                        .findLast(QuestionPaperDbEntity::class.java)
                )
            })
        })
        requestViewModel.paperListResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                var position = 0
                var questionIndex = 0
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)

                var total = 0
                for (info in it.list) {
                    for (quest in info.list) {
                        total += 1
                    }
                }

                for (info in it.list) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    Log.v(
                                        "yxy",
                                        "==duoxuan==>" + questionIndex + "===" + position + "==subIndex=" + subIndex
                                    )
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.parentId = quest.id
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText=sub.answerText
                                    questionDb.total = total
                                    questionDb.score = sub.score
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.paperType = sub.paperType
                                    questionDb.questionId = sub.id
                                    questionDb.stem = quest.stem
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (sub.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(sub.wdQuestionPaperData)
                                    }
                                    if (sub.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                    }
                                    if (sub.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)

                                    }

                                    questionDb.save()
//                                    Log.v(
//                                        "yxy",
//                                        "==duoxuan==>" + it.liftingType + "===" + quest.liftingType + "==subIndex=" + it.subjectId
//                                    )
//                                    if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(
//                                            it.subjectId
//                                        )
//                                    ) {
//                                        if (it.subjectId == sub.id) {
//                                            index = position + 1
//                                        }
//                                    }


                                }

                            }
                            else -> {
                                isHasZhuguan = quest.liftingType == 5
                                questionIndex += 1
                                position += 1
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText=quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.parentId = quest.id
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                questionDb.total = total
                                questionDb.paperType = quest.paperType
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.stem = quest.stem
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.score = quest.score
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)

                                }

                                questionDb.save()
//                                if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(
//                                        it.subjectId
//                                    )
//                                ) {
//                                    if (it.subjectId == quest.id) {
//                                        index = position + 1
//                                    }
//                                }
                            }
                        }
                    }
                }
                index = 1
                totalNum = LitePal.count(QuestionPaperDbEntity::class.java)
                if (index <= totalNum) {
                    setQuestionView(
                        LitePal.where("position=?", index.toString())
                            .findLast(QuestionPaperDbEntity::class.java)
                    )
                } else {
                    gotoSubmitQuestion()
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
    }

    /**
     * 更新题目编号索引
     * @param ind Int
     * @param total Int
     * @param isSub Boolean
     */
    private fun setQuestionIndex(ind: Int, total: Int, isSub: Boolean) {
        val num = ind + 1;
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>$num</font>/ $total  题";
        if (isSub) {
            question_exam_sub_index.text = Html.fromHtml(str);
        } else {
            question_exam_index.text = Html.fromHtml(str);
        }
    }

    private fun setQuestionView(info: QuestionPaperDbEntity) {
        if (info == null) {
            return
        }
        selectOptions = arrayListOf()
        optionId = ""
        isRight = 0
        solution = ""
        exam_data_media_controller.resume()
        exam_data_video_view.onActivityStop()
        question_exam_edt_result.setText("")
        liftingType = info.liftingType
        changeViewByType(info.liftingType)
        question_exam_title.text = info.stem
        subjectId = info.questionId
        parentId = info.parentId
        if (liftingType != 5) {
            question_exam_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            question_exam_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }
        val score = "<font color='#FA642D'>${info.score}</font>  分";
        question_exam_score.text = Html.fromHtml(score);
        exam_data_view_layout.visibility = View.GONE
        question_exam_data_img.visibility = View.GONE
        if (StringUtil.isNotBlank(info.wdQuestionPaperData)) {
            val turnsType = CacheUtil.genericType<java.util.ArrayList<SubjectFileEntity>>()
            val dataList =
                Gson().fromJson<java.util.ArrayList<SubjectFileEntity>>(
                    info.wdQuestionPaperData,
                    turnsType
                )
            if (dataList.size > 0) {
                if (dataList[0].materialType == "2") {
                    exam_data_view_layout.visibility = View.VISIBLE
                    play(
                        dataList[0].videoUrl,
                        exam_data_media_controller,
                        exam_data_video_view,
                        exam_data_view_layout,
                        exam_data_first_start_view
                    );
                } else {
                    if (StringUtil.isNotBlank(dataList[0].imageUrl)) {
                        question_exam_data_img.visibility = View.VISIBLE
                        Glide.with(this).load(dataList[0].imageUrl)
                            .placeholder(R.drawable.ic_default_pic1)
                            .into(question_exam_data_img)
                    }
                }
            }

        }

        val turnsType = CacheUtil.genericType<java.util.ArrayList<QuestionOptionEntity>>()
        val optionList =
            Gson().fromJson<java.util.ArrayList<QuestionOptionEntity>>(
                info.wdQuestionPaperOption,
                turnsType
            )
        var mutSize = 0
        if (optionList != null) {
            for (ope in optionList) {
                if (ope.rightFlag == 0) {
                    mutSize += 1
                }
            }
        }

        isMultiple = mutSize > 1
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>${info.questionIndex}</font>/ ${info.total}  题";
        question_exam_index.text = Html.fromHtml(str);

        val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
            info.wdQuestionChapterPractice,
            WdQuestionChapterPracticeEntity::class.java
        )
        Log.v("yxy", "")
        if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
            practice?.chapterContentList?.also { selectOptions = it }
            optionId = practice?.optionId ?: ""
        }
        when (liftingType) {
            1, 6 -> {
                if (info.wdQuestionPaperOption != null) {
                    initOperationRecycleView(optionList)
                }

            }
            3 -> {
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                question_exam_sub_index.setText(ss)

                question_exam_stem.text = info.childStem
                if (isMultiple) {
                    if (info.wdQuestionPaperOption != null) {
                        initMutOperationRecycleView(optionList)
                    }
                } else {
                    if (info.wdQuestionPaperOption != null) {
                        initOperationRecycleView(optionList)
                    }
                }
            }

            2 -> {
                if (info.wdQuestionPaperOption != null) {
                    initMutOperationRecycleView(optionList)
                }


            }
            4, 7, 8 -> {
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                question_exam_sub_index.setText(ss)

//                question_exam_sub_index.text = Html.fromHtml(info.childIndex);
                question_exam_stem.text = info.childStem
                if (optionList != null) {
                    initOperationRecycleView(optionList)
                }
            }
            5 -> {
                if (practice != null) {
                    if (StringUtil.isNotBlank(practice.solution)) {
                        question_exam_edt_result.setText(practice.solution)
                    }

                }
            }
        }
//        Log.v("yxy", "practice====" + GsonUtils.toJson(info.wdQuestionChapterPractice))
//        info.save()
//
//        val aaa =
//            LitePal.where("position =?", index.toString())
//                .findFirst(QuestionPaperDbEntity::class.java)
//        info.updateAll("position=?", index.toString())
//        Log.v("yxy", "practice==save finish==" + GsonUtils.toJson(aaa.wdQuestionChapterPractice))
    }

    /**
     * 视频处理
     */
    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        if (mTimer != null) {
            mTimer?.resume()
        }
    }


    override fun onPause() {
        super.onPause()
        if (mTimer != null) {
            mTimer?.pause()
        }
    }

    override fun onStop() {
        super.onStop()
        exam_data_media_controller.pause();
        exam_data_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mTimer != null) {
            mTimer?.stop()
        }
        EventBus.getDefault().unregister(this)
        exam_data_media_controller.disable();
        exam_data_video_view.destroy();
    }

    private fun initOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {

        singleOperationAdapter = QuestionSinPaperOperationAdapter(operationList)
        //初始化recyclerView
        question_exam_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        singleOperationAdapter.setAnswer(true)
        singleOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionOptionEntity =
                    adapter.getItem(position) as QuestionOptionEntity
                setPosition(position)
                singleOperationAdapter.notifyDataSetChanged()
                optionId = info.id
                selectOptions.add(info)
                isRight = info.rightFlag
//                saveAnswer()
            }
        }
    }

    private fun initMutOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {

        mutOperationAdapter = QuestionPaperMutOperationAdapter(operationList)
        //初始化recyclerView
        question_exam_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        mutOperationAdapter.setAnswer(true)
//        mutOperationAdapter.run {
//            setOnItemClickListener { adapter, view, position ->
//                val info: QuestionOptionEntity =
//                    adapter.getItem(position) as QuestionOptionEntity
//                setPosition(position)
//                mutOperationAdapter.notifyDataSetChanged()
//            }
//        }
    }

    /**
     * 根据类型更改本地问题布局
     * @param type Int
     */
    private fun changeViewByType(type: Int) {
        when (type) {
            1, 6 -> {
                //单项选择
                question_exam_rl_result.visibility = View.GONE
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_ll_stem.visibility = View.GONE
            }
            2 -> {
                //多项选择
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_ll_stem.visibility = View.GONE
                question_exam_rl_result.visibility = View.GONE
            }
            3, 4, 7, 8 -> {
                //共用题干
                question_exam_ll_stem.visibility = View.VISIBLE
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_rl_result.visibility = View.GONE
            }
            5 -> {
                //主观题
                question_exam_edt_result.setText("")
                question_exam_rlv_operation.visibility = View.GONE
                question_exam_ll_stem.visibility = View.GONE
                question_exam_rl_result.visibility = View.VISIBLE
            }
        }
    }


    inner class ProxyClick() {
        /**
         * 答题卡
         */
        fun gotoQuestionResultCardClick() {
            saveAnswer()
            val chooseDialog = PaperScantronCardDialog.newBuilder(this@Exam2Activity, true, 0,
                object : PaperScantronCardDialog.OnSubmitClickListener {
                    override fun onSubmitClick(content: Int) {
                        index = content
                        val info =
                            LitePal.where("position =?", index.toString())
                                .findFirst(QuestionPaperDbEntity::class.java)

                        Log.v(
                            "yxy",
                            "=答题卡回调数据===" + index + "====" + GsonUtils.toJson(info.wdQuestionChapterPractice)
                        )
                        if (info != null) {
                            setQuestionView(info)
                        }
                    }
                })
            chooseDialog.show()
        }


        /**
         * 设置
         */
        fun gotoQuestionSettings() {
            val chooseDialog =
                SettingsDialog.newBuilder(this@Exam2Activity, false, 1,
                    object : SettingsDialog.OnSubmitClickListener {
                        override fun onSubmitClick(themeMode: Int,fontSize: Float?) {
                            if (fontSize != null) {
                                SPUtils.getInstance().put("fontSize",fontSize)
                            }
                            SPUtils.getInstance().put("themeMode",themeMode)
                            setTextSize()
                            mutOperationAdapter.notifyDataSetChanged()
                            singleOperationAdapter.notifyDataSetChanged()
                        }

                        override fun onModeSelect(mode: Int,value: Float?) {
                            if (mode == 1){
                                MultiTheme.setAppTheme(1);
                            }else {
                                MultiTheme.setAppTheme(0);
                            }
                            if (value != null) {
                                Constants.questionTextSize = ((value - 50)/100) * 4 * 2
                                setTextSize()
                            };
                            updateIcon()
                        }

                        override fun onRangeChanged(value: Float) {
                            Constants.questionTextSize = ((value - 50)/100) * 4 * 2
                            setTextSize()
                        }

                    })
            chooseDialog.show()
        }





        /**
         * 纠错
         */
        fun gotoRecoveryError() {
            questionSettingsDialog =
                RecoveryErrorDialog.newBuilder(this@Exam2Activity, false, 1,
                    object : RecoveryErrorDialog.OnSubmitClickListener {
                        override fun onSubmitClick(tags: String,content: String) {
                            if (tags.isEmpty()){
                                ToastUtils.showShort("请选择错误类型")
                                return
                            }
                            val json = JsonObject()
                            //type传0为意见反馈，传1为试题纠错
                            json.addProperty("type", 1)
                            //试题纠错则需要传subject_id（试题id）
                            if(liftingType == 4 || liftingType == 3 || liftingType == 7 || liftingType == 8){
                                json.addProperty("subjectId", parentId)
                            }else{
                                json.addProperty("subjectId", subjectId)
                            }
                            json.addProperty("majorId", getMajorId())
                            json.addProperty("feedContent", content)
                            json.addProperty("feedType", tags)
                            requestViewModel.errorCorrection(json)
                        }
                    })


            questionSettingsDialog?.show()
        }

        /**
         * 交卷
         */
        fun finishExamClick() {
            if (isPause) {
                ToastUtils.showShort("答题已暂停，不可进行操作")
                return
            }
            saveAnswer()
            gotoSubmitQuestion()
        }

        /**
         * 暂停/开始
         */
        fun stopTimer() {
            if (isPause) {
                exam_stop.setImageResource(if (MultiTheme.getAppTheme() == 1) R.mipmap.ic_stop_dark else R.mipmap.ic_stop)
                if (mTimer != null) {
                    mTimer?.resume()
                }
            } else {
                exam_stop.setImageResource(if (MultiTheme.getAppTheme() == 1) R.mipmap.ic_again_player_dark else R.mipmap.ic_again_player)
                if (mTimer != null) {
                    mTimer?.pause()
                }
            }
            isPause = !isPause
        }

        /**
         * 下一题
         */
        fun nextQuestionClick() {
            if (isPause) {
                ToastUtils.showShort("答题已暂停，不可进行操作")
                return
            }
//            if(liftingType==2 ||liftingType==5){
//                saveAnswer()
//            }
            saveAnswer()
            nextQuestion()
        }

        /**
         * 上一题
         */
        fun upQuestionClick() {
            index -= 1
            if (index >= 0) {
                val info =
                    LitePal.where("position =?", index.toString())
                        .findFirst(QuestionPaperDbEntity::class.java)
                if (info != null) {
                    setQuestionView(info)
                }
            } else {
                ToastUtils.showShort("当前为第一题")
            }
        }
    }

    fun setIconFont(tv:TextView,content:String){
        val typeface: Typeface = Typeface.createFromAsset(
            assets,
            "fonts/iconfont.ttf"
        )
        tv.setTypeface(typeface)
        tv.text = content
    }


    private fun nextQuestion() {
        index += 1
        val count = LitePal.count(QuestionPaperDbEntity::class.java)
        if (index <= count) {
            val info =
                LitePal.where("position =?", index.toString())
                    .findFirst(QuestionPaperDbEntity::class.java)
            if (info != null) {
                setQuestionView(info)
            }
        } else {
            gotoSubmitQuestion()
        }
    }

    /**
     * 保存结果
     */
    private fun saveAnswer() {
        Log.v("yxy", "=saveAnswer=次数==")
        val json = JsonObject()
        var question =
            LitePal.where("position= ?", index.toString())
                .findFirst(QuestionPaperDbEntity::class.java)
        val practice = WdQuestionChapterPracticeEntity()
        practice.type = "1"
        if (question == null) {
            return
        }
        practice.subjectId = question.questionId
        when (liftingType) {
            //单选题型
            1, 6, 4, 7, 8 -> {
                practice.chapterContentList = selectOptions
                practice.isRight = isRight.toString()
                practice.optionId = optionId
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                Log.v(
                    "yxy",
                    "单选保存答案=存=>" + question.index + "==position==" + index + "====" + question.wdQuestionChapterPractice
                );
                if (StringUtil.isNotBlank(optionId)) {
                    question.updateAll("position=?", index.toString())
//                    question.save()
                }
            }
            3 -> {
                if (isMultiple) {
                    val selectOptionList = arrayListOf<QuestionOptionEntity>()
                    optionId = ""
                    val operations = mutOperationAdapter.data
                    var selectValues = ""
                    var rightValues = ""
                    Log.d("yxy", "=多选结果==" + GsonUtils.toJson(operations))

                    for (ope in operations) {
                        if (ope.isSelect) {
                            optionId += ope.id + ","
                            selectValues += ope.selectValue + ","
                            selectOptionList.add(ope)
                        }
                    }

                    Log.d("TAG", "多选结果 selectValues question.answer: " + question.answer + "  selectValues: " + selectValues)
                    for (ope in operations) {
                        if (ope.rightFlag == 0) {
                            rightValues += ope.selectValue + ","
                        }
                    }

                if (rightValues == selectValues) {
                    isRight = 0
                } else {
                    isRight = 1
                }
                    practice.chapterContentList = selectOptionList
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    if (StringUtil.isNotBlank(optionId)) {
                        question.updateAll("position=?", index.toString())
                    }
                } else {
                    practice.chapterContentList = selectOptions
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    if (StringUtil.isNotBlank(optionId)) {
                        question.updateAll("position=?", index.toString())
                    }
                }
            }
            2 -> {
                val selectOptionList = arrayListOf<QuestionOptionEntity>()
                optionId = ""
                val operations = mutOperationAdapter.data
                var selectValues = ""
                var rightValues = ""
                Log.v("yxy", "=多选结果==" + GsonUtils.toJson(operations))
                if (operations != null) {
                    for (ope in operations) {
                        if (ope.isSelect) {
                            optionId += ope.id + ","
                            selectValues += ope.selectValue + ","
                            selectOptionList.add(ope)
                        }
                    }
                    for (ope in operations) {
                        if (ope.rightFlag == 0) {
                            rightValues += ope.selectValue + ","
                        }
                    }
                }

                if (rightValues == selectValues) {
                    isRight = 0
                } else {
                    isRight = 1
                }
                Log.i("TAG", "多选结果 selectValues rightValues: " + rightValues + "  selectValues: " + selectValues)

                practice.chapterContentList = selectOptionList
                practice.isRight = isRight.toString()
                practice.optionId = optionId
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                if (StringUtil.isNotBlank(optionId)) {
                    question.updateAll("position=?", index.toString())
                }

            }
            5 -> {
                solution = question_exam_edt_result.text.toString().trim()
                if (StringUtil.isNotBlank(solution)) {
                    practice.solution = solution
                    isRight = 0
                } else {
                    practice.solution = ""
                }
                optionId = ""
                practice.isRight = isRight.toString()
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)

                if (StringUtil.isNotBlank(solution)) {
                    json.addProperty("solution", solution)
                    question.updateAll("position=?", index.toString())
                }


            }
        }
        if (StringUtil.isNotBlank(optionId) || StringUtil.isNotBlank(solution)) {
            json.addProperty("isRight", isRight)
            if (StringUtil.isNotBlank(optionId)) {
                json.addProperty("optionId", optionId)
            }

            json.addProperty("paperType", type)
            json.addProperty("score", question.score)
            json.addProperty("subjectId", question.questionId)
            json.addProperty("type", type)

            if (type == 3) {
                json.addProperty("paperId", appraisalId)
                json.addProperty("classesId", classId)
                json.addProperty("appraisalId", appraisalId)
            } else {
                Log.v("yxy", "==question.paperId=" + question.paperId)
                if (from == "mock_produce") {
                    json.addProperty("paperId", paperId)
                } else {
                    json.addProperty("paperId", question.paperId)
                }

            }
            if (StringUtil.isNotBlank(solution) || StringUtil.isNotBlank(optionId)) {
                Log.v("yxy", "已做" + question.wdQuestionChapterPractice)
                requestViewModel.submitQuestionResult(json)
            } else {
                Log.v("yxy", "未做")
            }
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public fun onSubmitEvent(event: TestPaperSubmitSuccessEvent) {
        finish()
    }

    private fun gotoSubmitQuestion() {
        Log.v("yxy", "===isHasZhuguan=" + isHasZhuguan + paperId)
        if (RxSimple.isFastClick(1000)) {
            return
        }
        startActivity(
            Intent(this, SubmitConfirmActivity::class.java)
                .putExtra("type", type)
                .putExtra("from", from)
                .putExtra(Constants.PARAMS_QUESTION_CLASS_ID, classId)
                .putExtra("appraisalId", appraisalId)
                .putExtra("paperId", paperId)
                .putExtra("isHasZhuguan", isHasZhuguan)
                .putExtra("paperType", paperType)
                .putExtra("useTime", useTime)
        )
        //finish()
    }


    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout,
        firstView: PolyvPlayerPreviewView
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        firstView.hide()
        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)
        //视频不播放，先显示一张缩略图
        mediaController.hindMenuView()
        videoView.mediaController = mediaController

        videoView.setOnPreparedListener(IPolyvOnPreparedListener2 {
            mediaController.preparedView()
        })

        firstView.setCallback(PolyvPlayerPreviewView.Callback { //在播放视频时设置viewerId方法使用示例
            videoView.setAutoPlay(true)
            videoView.setVid(vid)
        })

        firstView.show(vid)

        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }

    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        question_exam_edt_result.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = question_exam_edt_result.selectionStart
                editEnd = question_exam_edt_result.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(question_exam_edt_result.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                question_exam_edt_result.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(question_exam_edt_result.text.toString())
        currentCount = nowCount
        //
        question_exam_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
//            MaterialDialog(this@Exam2Activity).show {
//                cancelable(false)
//                lifecycleOwner(this@Exam2Activity)
//                title(text = "答题未结束，是否确认退出")
//
//                positiveButton(R.string.confirm, "继续做题") {
//                    dismiss()
//                }
//                negativeButton(R.string.cancel, "确认退出") {
//                    finish()
//                }
//                if (MultiTheme.getAppTheme() == 1) {
//                    view.background = resources.getDrawable(R.drawable.dialog_alert_bg_dark)
//                    view.titleLayout.findViewById<TextView>(R.id.md_text_title).setTextColor(Color.parseColor("#A2A2A2"))
//                }
//                getActionButton(WhichButton.POSITIVE).updateTextColor(
//                    Color.parseColor("#0077FF")
//                )
//                getActionButton(WhichButton.NEGATIVE).updateTextColor(
//                    Color.parseColor("#FA642D")
//                )
//
//
//            }

            val customAlertDialog = CustomAlertDialog(this, "提示", "答题未结束，是否确认退出")
            customAlertDialog.setEditTextDialogListener(object : EditTextDialogListener {
                override fun onCancle() {
                    customAlertDialog.dismiss()
                    finish()
                }
                override fun onOk(content: String) {

                }
            })
            customAlertDialog.show()

            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun setTextSize(){
        question_exam_index.textSize = 13 + Constants.questionTextSize
        question_exam_type.textSize = 13 + Constants.questionTextSize
        question_exam_score.textSize = 13 + Constants.questionTextSize
        exam_recovery_error.textSize = 13 + Constants.questionTextSize
        question_exam_title.textSize = 15 + Constants.questionTextSize
        question_exam_sub_index.textSize = 16 + Constants.questionTextSize
        question_exam_stem.textSize = 15 + Constants.questionTextSize
        question_exam_text_num.textSize = 12 + Constants.questionTextSize
        mutOperationAdapter.notifyDataSetChanged()
        singleOperationAdapter.notifyDataSetChanged()
    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }

    private fun updateIcon(){
        if (MultiTheme.getAppTheme() == 1) {
            exam_card.iconNormal = getDrawable(R.mipmap.ic_question_card_dark)
        }else{
            exam_card.iconNormal = getDrawable(R.mipmap.ic_question_card)
        }
    }

}