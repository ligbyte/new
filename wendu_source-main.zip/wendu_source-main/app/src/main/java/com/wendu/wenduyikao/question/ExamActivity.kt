package com.wendu.wenduyikao.question


import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.Html
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.RelativeLayout
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.WhichButton
import com.afollestad.materialdialogs.actions.getActionButton
import com.afollestad.materialdialogs.lifecycle.lifecycleOwner
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.AnswerCountDownTimerUtils
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.countdowntimer.CountDownTimerSupport
import com.wendu.wenduyikao.app.weight.countdowntimer.OnCountDownTimerListener
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity
import com.wendu.wenduyikao.databinding.ActivityExamBinding
import com.wendu.wenduyikao.dialog.PaperScantronDialog
import com.wendu.wenduyikao.question.adapter.QuestionPaperMutOperationAdapter
import com.wendu.wenduyikao.question.adapter.QuestionSinPaperOperationAdapter
import com.wendu.wenduyikao.util.RxSimple
import com.wendu.wenduyikao.viewmodel.request.RequestExamViewModel
import kotlinx.android.synthetic.main.activity_exam.*


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 8:56 AM
 * @Description: 考试
 */
class ExamActivity :
    BaseActivity<RequestExamViewModel, ActivityExamBinding>() {
    private var index = 0//已经完结的题目索引
    private var subIndex = 0   //子题目索引
    private var totalNum = 0  //题目总数
    private var liftingType = 1  //当前题目类型
    private var type = 1;
    private var paperId = ""
    private var from = "paper"   //paper 来自试卷   card  来自答题卡
    private val requestViewModel: RequestExamViewModel by viewModels()
    private var mCountDownTimerUtils: AnswerCountDownTimerUtils? = null
    private var useTime = 0L
    private var isPause = false
    private var mTimer: CountDownTimerSupport? = null
    private val maxLen = 100 // the max byte

    private var editStart = 0
    private var editEnd = 0
    //适配器
    private var mutOperationAdapter: QuestionPaperMutOperationAdapter =
        QuestionPaperMutOperationAdapter(
            arrayListOf()
        )
    private var singleOperationAdapter: QuestionSinPaperOperationAdapter =
        QuestionSinPaperOperationAdapter(
            arrayListOf()
        )

    override fun layoutId() = R.layout.activity_exam

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, exam_ll_content)
        exam_img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        totalNum = intent.getIntExtra("total", 0)
        type = intent.getIntExtra("type", 1)
        index = intent.getIntExtra("index", 0)
        useTime = intent.getLongExtra("useTime", 0)
        from = intent.getStringExtra("from").toString()
//        mCountDownTimerUtils = AnswerCountDownTimerUtils(exam_time, useTime * 60 * 1000, 1000)
        setQuestionIndex(index, totalNum, false)
        if (from == "card") {
            totalNum = CacheUtil.getQuestionPaperList().size
            if (totalNum > 0) {
                val info = CacheUtil.getQuestionPaperList()[index]
                setQuestionView(info)
            }

        } else if (from == "error") {
            val errorLiftType = intent.getIntExtra("errorLiftType", 1)
            val dataType = intent.getIntExtra("dataType", 1)
            val params = mutableMapOf<String, String>()
            params["liftingType"] = errorLiftType.toString()
            params["type"] = dataType.toString()
            requestViewModel.getQuestionByError(params)
        } else if (from == "mock_produce") {
            val examId = intent.getStringExtra("examId").toString()
            val params = mutableMapOf<String, String>()
            params["examId"] = examId
            requestViewModel.getQuestionByExam(params)
        } else {
            paperId = intent.getStringExtra("paperId").toString()
            if (StringUtil.isNotBlank(paperId)) {
                requestViewModel.getQuestionPaperSubjectList(paperId)
            }
        }
        startTimer()
        editTextMaxLengthListener()
    }

    /**
     * 开始倒计时
     */
    fun startTimer() {
        if (mTimer != null) {
            mTimer?.stop()
            mTimer = null
        }
        //useTime * 60 * 1000
        mTimer = CountDownTimerSupport(useTime * 60 * 1000, 1000)
        mTimer?.setOnCountDownTimerListener(object : OnCountDownTimerListener {
            override fun onTick(millisUntilFinished: Long) {
                val hour = millisUntilFinished / (60 * 60 * 1000)
                val minute = millisUntilFinished / (60 * 1000)
                val second = (millisUntilFinished - minute * (1000 * 60)) / 1000
                var time = ""


                exam_time.text = "0$hour:$minute:$second " //设置倒计时时间
                Log.d("CountDownTimerSupport", "onTick : " + millisUntilFinished + "ms")
            }

            override fun onFinish() {
                exam_time.setText("00:00:00")
                Log.d("CountDownTimerSupport", "onFinish")

                MaterialDialog(this@ExamActivity).show {
                    cancelable(false)
                    lifecycleOwner(this@ExamActivity)
                    title(text = "考试时间已结束")

                    positiveButton(R.string.confirm, "提交答案") {
                        gotoSubmitQuestion()
                    }
                    negativeButton(R.string.cancel, "继续答题") {
                        isPause = false
                        cancel()
                    }
                    getActionButton(WhichButton.POSITIVE).updateTextColor(
                        Color.parseColor("#0077FF")
                    )
                    getActionButton(WhichButton.NEGATIVE).updateTextColor(
                        Color.parseColor("#FA642D")
                    )
                }
            }

            override fun onCancel() {
                Log.d("CountDownTimerSupport", "onCancel")
            }
        })
        mTimer?.start()
    }

    override fun createObserver() {
        requestViewModel.questionListResult.observe(this, Observer {
            if (it.isSuccess) {
                val info = it.listData[0].list[0]
                CacheUtil.setQuestionPaperSubject(it.listData)
                val questions = arrayListOf<QuestionPaperInfoEntity>()
                for (info in it.listData) {
                    questions.addAll(info.list)
                }
                totalNum = questions.size
                setQuestionView(info)
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
//        requestViewModel.errorQuestionListResult.observe(this, Observer {
//            if (it.isSuccess) {
//                val info = it.listData[0].list[0]
//                CacheUtil.setQuestionPaperSubject(it.listData)
//                val questions = arrayListOf<QuestionPaperInfoEntity>()
//                for (info in it.listData) {
//                    questions.addAll(info.list)
//                }
//                totalNum = questions.size
//                setQuestionView(info)
//            } else {
//                ToastUtils.showShort(it.errMessage)
//            }
//        })
//        requestViewModel.examQuestionListResult.observe(this, Observer {
//            if (it.isSuccess) {
//                val info = it.listData[0].list[0]
//                CacheUtil.setQuestionPaperSubject(it.listData)
//                val questions = arrayListOf<QuestionPaperInfoEntity>()
//                for (info in it.listData) {
//                    questions.addAll(info.list)
//                }
//                totalNum = questions.size
//                Log.v("yxy", "==totalNum==" + totalNum)
//                setQuestionView(info)
//            } else {
//                ToastUtils.showShort(it.errMessage)
//            }
//        })
    }

    /**
     * 更新题目编号索引
     * @param ind Int
     * @param total Int
     * @param isSub Boolean
     */
    private fun setQuestionIndex(ind: Int, total: Int, isSub: Boolean) {
        val num = ind + 1;
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>$num</font>/ $total  题";
        if (isSub) {
            question_exam_sub_index.text = Html.fromHtml(str);
        } else {
            question_exam_index.text = Html.fromHtml(str);
        }
    }

    /**
     * 设置试题布局
     * @param info QuestionPaperInfoEntity
     */
    private fun setQuestionView(info: QuestionPaperInfoEntity) {
        exam_data_media_controller.resume()
        exam_data_video_view.onActivityStop()
        question_exam_edt_result.setText("")
        liftingType = info.liftingType
        changeViewByType(info.liftingType)
        question_exam_title.text = info.stem
        if (liftingType != 5) {
            question_exam_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            question_exam_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }
        val str = "<font color='#FA642D'>${info.score}</font>  分";
        question_exam_score.text = Html.fromHtml(str);
        if (info.wdQuestionPaperData.size > 0) {
            if (StringUtil.isNotBlank(info.wdQuestionPaperData[0].imageUrl)) {
                question_exam_data_img.visibility = View.VISIBLE
                Glide.with(this).load(info.wdQuestionPaperData[0].imageUrl)
                    .placeholder(R.drawable.ic_default_pic1)
                    .into(question_exam_data_img)
            } else {
                question_exam_data_img.visibility = View.GONE
            }
            if (StringUtil.isNotBlank(info.wdQuestionPaperData[0].videoUrl)) {
                exam_data_view_layout.visibility = View.VISIBLE
                play(
                    info.wdQuestionPaperData[0].videoUrl,
                    exam_data_media_controller,
                    exam_data_video_view,
                    exam_data_view_layout
                );
            } else {
                exam_data_view_layout.visibility = View.GONE
            }
        }


        when (liftingType) {
            1, 6 -> {
                setQuestionIndex(index, totalNum, false)
                if (info.wdQuestionPaperOption != null) {
                    initOperationRecycleView(info.wdQuestionPaperOption)
                }

            }
            2,3 -> {
                setQuestionIndex(index, totalNum, false)
                if (info.wdQuestionPaperOption != null) {
                    initMutOperationRecycleView(info.wdQuestionPaperOption)
                }


            }
             4, 7, 8 -> {
                setQuestionIndex(index, totalNum, false)
                if (subIndex < info.wdQuestionPaperSubjectSubordinatesList.size) {
                    setQuestionIndex(
                        subIndex,
                        info.wdQuestionPaperSubjectSubordinatesList.size,
                        true
                    )
                    question_exam_stem.text =
                        info.wdQuestionPaperSubjectSubordinatesList[subIndex].stem
                    if (info.wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption != null) {
                        initOperationRecycleView(info.wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption)
                    }
                }

            }

            5 -> {
                setQuestionIndex(index, totalNum, false)
            }
        }
    }

    /**
     * 视频处理
     */
    override fun onBackPressed() {

        super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        if (mTimer != null) {
            mTimer?.resume()
        }
    }


    override fun onPause() {
        super.onPause()
        if (mTimer != null) {
            mTimer?.pause()
        }
    }

    override fun onStop() {
        super.onStop()
        exam_data_media_controller.pause();
        exam_data_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        if (mTimer != null) {
            mTimer?.stop()
        }
        exam_data_media_controller.disable();
        exam_data_video_view.destroy();
    }

    private fun initOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {

        singleOperationAdapter = QuestionSinPaperOperationAdapter(operationList)
        //初始化recyclerView
        question_exam_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        singleOperationAdapter.setAnswer(true)
        singleOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionOptionEntity =
                    adapter.getItem(position) as QuestionOptionEntity
                setPosition(position)
                singleOperationAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun initMutOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {

        mutOperationAdapter = QuestionPaperMutOperationAdapter(operationList)
        //初始化recyclerView
        question_exam_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        mutOperationAdapter.setAnswer(true)
        mutOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionOptionEntity =
                    adapter.getItem(position) as QuestionOptionEntity
                setPosition(position)
                mutOperationAdapter.notifyDataSetChanged()
            }
        }
    }

    /**
     * 根据类型更改本地问题布局
     * @param type Int
     */
    private fun changeViewByType(type: Int) {
        when (type) {
            1, 6 -> {
                //单项选择
                question_exam_rl_result.visibility = View.GONE
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_ll_stem.visibility = View.GONE
            }
            2,3 -> {
                //多项选择
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_ll_stem.visibility = View.GONE
                question_exam_rl_result.visibility = View.GONE
            }
            4, 7, 8 -> {
                //共用题干
                question_exam_ll_stem.visibility = View.VISIBLE
                question_exam_rlv_operation.visibility = View.VISIBLE
                question_exam_rl_result.visibility = View.GONE
            }
            5 -> {
                //主观题
                question_exam_edt_result.setText("")
                question_exam_rlv_operation.visibility = View.GONE
                question_exam_ll_stem.visibility = View.GONE
                question_exam_rl_result.visibility = View.VISIBLE
            }
        }
    }


    inner class ProxyClick() {
        /**
         * 答题卡
         */
        fun gotoQuestionResultCardClick() {
            val chooseDialog = PaperScantronDialog.newBuilder(this@ExamActivity,
                object : PaperScantronDialog.OnSubmitClickListener {
                    override fun onSubmitClick(content: Int) {
                        index = content
                        val list = CacheUtil.getQuestionPaperList()
                        setQuestionView(list[index])
                    }
                })
            chooseDialog.show()
        }

        /**
         * 交卷
         */
        fun finishExamClick() {
            if (isPause) {
                ToastUtils.showShort("答题已暂停，不可进行操作")
                return
            }
            gotoSubmitQuestion()
        }

        /**
         * 暂停/开始
         */
        fun stopTimer() {
            if (isPause) {
                exam_stop.setImageResource(R.mipmap.ic_stop)
                if (mTimer != null) {
                    mTimer?.resume()
                }
            } else {
                exam_stop.setImageResource(R.mipmap.ic_again_player)
                if (mTimer != null) {
                    mTimer?.pause()
                }
            }
            isPause = !isPause
        }

        /**
         * 下一题
         */
        fun nextQuestionClick() {
            if (isPause) {
                ToastUtils.showShort("答题已暂停，不可进行操作")
                return
            }
            val list = CacheUtil.getQuestionPaperList()

            if (index < list.size) {
                Log.v("yxy", "index===2==>" + index + "======" + subIndex)
                saveAnswer()
                when (liftingType) {
                    3, 4, 7, 8 -> {
                        subIndex += 1
                        Log.v(
                            "yxy",
                            "index=====>" + index + "===subIndex===" + subIndex + "==liftingType==" + liftingType + "====" + list[index].wdQuestionPaperSubjectSubordinatesList.size
                        )
                        if (subIndex < list[index].wdQuestionPaperSubjectSubordinatesList.size) {
                            setQuestionView(list[index])
                        } else {
                            subIndex = 0
                            index += 1
                            if (index < list.size) {
                                setQuestionView(list[index])
                            } else {
                                gotoSubmitQuestion()
                            }
                        }
                    }
                    else -> {
                        index += 1
                        if (index < list.size) {
                            setQuestionView(list[index])
                        } else {
                            gotoSubmitQuestion()
                        }
                    }
                }

            } else {
                gotoSubmitQuestion()
            }
        }

        /**
         * 上一题
         */
        fun upQuestionClick() {
            val list = CacheUtil.getQuestionPaperList()
            if (index < list.size) {
                if (liftingType == 3 || liftingType == 4 || liftingType == 7 || liftingType == 8) {
                    subIndex -= 1
                    if (subIndex >= 0) {
                        setQuestionView(list[index])
                    } else {
                        subIndex = list[index].wdQuestionPaperSubjectSubordinatesList.size
                        index -= 1
                        if (index >= 0) {
                            setQuestionView(list[index])
                        } else {
                            index = 0
                            ToastUtils.showShort("当前为第一题")
                        }
                    }
                } else {
                    index -= 1
                    if (index >= 0) {
                        setQuestionView(list[index])
                    } else {
                        index = 0
                        ToastUtils.showShort("当前为第一题")
                    }
                }
            } else {
                ToastUtils.showShort("当前为第一题")
            }
        }
    }

    private fun saveAnswer() {
        val list = CacheUtil.getQuestionPaperList()
        val question = list[index]
        val json = JsonObject()
        var optionId = ""
        var solution = ""
        var isRight = 0
        when (question.liftingType) {
            1, 6 -> {
                val operations = singleOperationAdapter.data
                for (ope in operations) {
                    if (ope.isSelect) {
                        optionId = ope.id
                    }
                }
                for (ope in operations) {
                    if (ope.isSelect && ope.rightFlag == 1) {
                        isRight = 1
                        break
                    }
                }
                list[index].isDo = StringUtil.isNotBlank(optionId)
                list[index].isRight = isRight
                list[index].wdQuestionPaperOption =
                    singleOperationAdapter.data as ArrayList<QuestionOptionEntity>
                CacheUtil.setQuestionPaperList(list)
            }
            2,3 -> {
                optionId = ""
                val operations = mutOperationAdapter.data
                for (ope in operations) {
                    if (ope.isSelect) {
                        optionId += ope.id + ","
                    }
                }
                for (ope in operations) {
                    if (ope.isSelect && ope.rightFlag == 1) {
                        isRight = 1
                        break
                    }
                }
                list[index].isDo = StringUtil.isNotBlank(optionId)
                list[index].isRight = isRight
                list[index].wdQuestionPaperOption =
                    singleOperationAdapter.data as ArrayList<QuestionOptionEntity>
                CacheUtil.setQuestionPaperList(list)
            }
             4, 7, 8 -> {
                for (ope in singleOperationAdapter.data) {
                    if (ope.isSelect) {
                        optionId = ope.id
                    }
                }
                for (ope in singleOperationAdapter.data) {
                    if (ope.isSelect && ope.rightFlag == 1) {
                        isRight = 1
                        break
                    }
                }
                Log.v("yxy", "=optionId==>" + optionId)
                list[index].isDo = StringUtil.isNotBlank(optionId)
                list[index].isRight = isRight
//                list[index].wdQuestionPaperOption =
//                    singleOperationAdapter.data as ArrayList<QuestionOptionEntity>
                subIndex = 0
                if (list[index].wdQuestionPaperSubjectSubordinatesList.size > 0) {
                    list[index].wdQuestionPaperSubjectSubordinatesList[subIndex].isDo =
                        StringUtil.isNotBlank(optionId)
                    list[index].wdQuestionPaperSubjectSubordinatesList[subIndex].isRight = isRight
                    list[index].wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption =
                        singleOperationAdapter.data as ArrayList<QuestionOptionEntity>
                    CacheUtil.setQuestionPaperList(list)
                }

            }
            5 -> {
                solution = question_exam_edt_result.text.toString().trim()
                if (StringUtil.isNotBlank(solution)) {
                    list[index].solution = solution
                    list[index].isDo = true
                    list[index].isRight = 0
                } else {
                    list[index].solution = ""
                    list[index].isDo = false
                }
                optionId = ""
                json.addProperty("solution", solution)
                CacheUtil.setQuestionPaperList(list)

            }
        }
        if (StringUtil.isNotBlank(optionId) || StringUtil.isNotBlank(solution)) {
            json.addProperty("isRight", isRight)
            if (StringUtil.isNotBlank(optionId)) {
                json.addProperty("optionId", optionId)
            }
            json.addProperty("paperId", paperId)
            json.addProperty("paperType", 2)
            json.addProperty("score", question.score)
            json.addProperty("subjectId", question.id)
            json.addProperty("type", 2)

            requestViewModel.submitQuestionResult(json)
        }

    }

    private fun gotoSubmitQuestion() {
        if (RxSimple.isFastClick(1000)) {
            return
        }
        startActivity(
            Intent(this, SubmitConfirmActivity::class.java)
                .putExtra("type", "paper")
                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_PAPER)
                .putExtra("paperId", paperId)
        )
        finish()
    }


    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        videoView.setAutoPlay(false)
        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)
        videoView.setMediaController(mediaController)
        videoView.setVid(vid)


        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }


    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        question_exam_edt_result.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun  afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = question_exam_edt_result.selectionStart
                editEnd = question_exam_edt_result.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(question_exam_edt_result.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                question_exam_edt_result.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(question_exam_edt_result.text.toString())
        currentCount = nowCount
        //
        question_exam_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }
}