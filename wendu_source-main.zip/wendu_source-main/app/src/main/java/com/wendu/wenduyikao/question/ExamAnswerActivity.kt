package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.afollestad.materialdialogs.MaterialDialog
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.SPUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.player.PolyvPlayerPreviewView
import com.easefun.polyvsdk.util.PolyvScreenUtils
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.easefun.polyvsdk.video.listener.IPolyvOnPreparedListener2
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.network.ApiService
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.RefreshErrorQuestionEvent
import com.wendu.wenduyikao.data.eventbus.RefreshQuestionBankEvent
import com.wendu.wenduyikao.data.model.bean.*
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivityExamAnswerBinding
import com.wendu.wenduyikao.dialog.LearnAnalogyMessageDialog
import com.wendu.wenduyikao.dialog.PaperScantronCardDialog
import com.wendu.wenduyikao.dialog.RecoveryErrorDialog
import com.wendu.wenduyikao.dialog.SettingsDialog
import com.wendu.wenduyikao.dialog.base.BaseDialog
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.ExamAnswerOperationAdapter
import com.wendu.wenduyikao.question.adapter.QuestionBankAdapter
import com.wendu.wenduyikao.question.adapter.QuestionResolveOperationAdapter
import com.wendu.wenduyikao.util.FastClickUtils
import com.wendu.wenduyikao.util.RxSimple
import com.wendu.wenduyikao.viewmodel.request.RequestExamViewModel
import kotlinx.android.synthetic.main.activity_exam_answer.*
import kotlinx.android.synthetic.main.activity_exam_answer.question_tv_analyze
import kotlinx.android.synthetic.main.activity_exam_answer.queston_answer_rl_result
import kotlinx.android.synthetic.main.activity_question_answer.*
import kotlinx.android.synthetic.main.content_toolbar_view.img_back
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.litepal.LitePal

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:25 PM
 * @Description: 答题 --- 试卷结构数据
 */
class ExamAnswerActivity :
    BaseActivity<RequestExamViewModel, ActivityExamAnswerBinding>() {

    private val requestViewModel: RequestExamViewModel by viewModels()
    private var paperId = "" //id
    private var optionId = ""  //选项id
    private var id = ""
    private var subjectId = ""//题干id
    private var parentId = ""//题干id
    private var goNext = true //多选逻辑，需要做次校验
    private var isSeeAll = true//查看全部
    private var mCurPosY = 0.0f
    private var mPosY = 0.0f
    private var mCurPosX = 0.0f
    private var mPosX = 0.0f
    var questionSettingsDialog: BaseBottomSheetDialog? = null
    //    private var isAnswer: Boolean = true   // true 答题模式; false 背题模式
    private var answerType = 1   //1 答题，2背题 3 解析模式
    private var isCollect = 0 //0未收藏 1收藏
    private var isCollectId = "" //0未收藏 1收藏
    private var type = 1   //类型 1章节练习(章节练习) 2 试卷管理(历年真题,精品题库) 3评测试卷 4模拟试卷 5经典试卷
    private var index = 1 //已经完结的题目索引
    private var totalNum = 0  //题目总数
    private var queIndex = 1
    private var liftingType = 1  //当前题目类型
    private var isRight = 0// 是否回答正确  默认正确
    lateinit var dialog: MaterialDialog
    private var solution = "" //主观题答案
    private var from = Constants.PARAMS_QUESTION_SOURCE_CHAPTER
    private val maxLen = 100 // the max byte
    private var isCheckResult = false  //多选是否选择完毕
    private var editStart = 0
    private var editEnd = 0
    private var isMockError = false
    private var errorList = arrayListOf<QuestionPaperDbEntity>()
    private var selectOptions = arrayListOf<QuestionOptionEntity>()
    private var isMultiple = false; //共用题干类型下是否为多选
    private var loadFrom = 0 //0 默认正常渠道进入   1，为精品题库=章节类型-举一反三数据
    private var bankListJson = ""
    private var historyFrom = ""//从头记录类型来源
    private var templateId = "" //精品题库节id （章节模式下）
    private var isDo = false;  //题库是否已开始做题
    private var questionInfoJson = ""
    private var bankListData = arrayListOf<QuestionPaperInfoEntity>()
    private var questionBankList = arrayListOf<QuestionPaperInfoEntity>()
    private var js = "<script type=\"text/javascript\">" +
            "var imgs = document.getElementsByTagName('img');" +  // 找到img标签
            "for(var i = 0; i<imgs.length; i++){" +  // 逐个改变
            "imgs[i].style.width = '100%';" +  // 宽度改为100%
            "imgs[i].style.height = 'auto';" +
            "}" +
            "</script>"

    //适配器
    private var mutOperationAdapter: QuestionResolveOperationAdapter =
        QuestionResolveOperationAdapter(
            arrayListOf()
        )
    private var singleOperationAdapter: ExamAnswerOperationAdapter = ExamAnswerOperationAdapter(
        arrayListOf()
    )

    override fun layoutId() = R.layout.activity_exam_answer


    override fun initView(savedInstanceState: Bundle?) {
        if (MultiTheme.getAppTheme() == 1){
            StatusBarUtil.setDarkMode(this)
        }else{
            StatusBarUtil.setLightMode(this)
        }
        StatusBarUtil.setPaddingSmart(this, exam_answer_ll_content)
        img_back.setOnClickListener { finish() }
        Constants.questionTextSize = (SPUtils.getInstance().getFloat("fontSize",50f) - 50)/100 * 4 *2
        setTextSize()
        mDatabind.click = ProxyClick()
        loadFrom = intent.getIntExtra("loadFrom", 0)
        totalNum = intent.getIntExtra("total", 0)
        from = intent.getStringExtra("from").toString()
        type = intent.getIntExtra("type", 1)
        EventBus.getDefault().register(this)
        initWebView()
        if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR) {
            isMockError = intent.getBooleanExtra("isMockError", false)
            index = 1
            val info =
                LitePal.where("position =?", "1")
                    .findFirst(QuestionPaperDbEntity::class.java)
            totalNum = LitePal.count(QuestionPaperDbEntity::class.java)
            if (info != null) {
                setQuestionIndex(1, totalNum, false)
                setQuestionView(info)
            }
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
            exam_answer_up.visibility = View.VISIBLE
            exam_answer_menu.visibility = View.GONE
            exam_answer_toolbar_title.text = "答题解析"
            exam_answer_error.visibility = View.VISIBLE
            index = intent.getIntExtra("index", 1)
//            ToastUtils.showLong("index: " + index)
            answerType = 3

            val info =
                LitePal.where("position =?", index.toString())
                    .findFirst(QuestionPaperDbEntity::class.java)

            historyFrom = intent.getStringExtra("historyFrom") ?: ""
            totalNum = LitePal.count(QuestionPaperDbEntity::class.java)
            if (info != null) {
                setQuestionIndex(1, totalNum, false)
                setQuestionView(info)
            }
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
            exam_answer_up.visibility = View.VISIBLE
            exam_answer_menu.visibility = View.GONE
            exam_answer_toolbar_title.text = "答题解析"
            index = 1
            totalNum = 1
            answerType = 2
            exam_answer_ll_error.visibility = View.GONE
            queston_answer_rl_result.visibility = View.GONE
            val id = intent.getStringExtra("id").toString()
            Log.v("yxy", "==PARAMS_QUESTION_SOURCE_CHAPTER_INFO=" + type)
            if (type == 1) {
                requestViewModel.getQuestionPaperInfoById(id)
            } else {
                requestViewModel.getQuestionPaperInfoByColl(id)
            }

            setQuestionIndex(1, 1, false)
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_NOTE) {
            exam_answer_up.visibility = View.VISIBLE
            exam_answer_menu.visibility = View.GONE
            exam_answer_toolbar_title.text = "答题解析"
            index = 1
            totalNum = 1
            answerType = 2
            exam_answer_ll_error.visibility = View.GONE
            queston_answer_rl_result.visibility = View.GONE
            val id = intent.getStringExtra("id").toString()
            requestViewModel.getQuerySubjectByNote(id)
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE) {

            answerType = 1
            paperId = intent.getStringExtra("paperId").toString()
            val isDo = intent.getBooleanExtra("isDo", false)
            if (StringUtil.isNotBlank(paperId)) {
                if (loadFrom == 1) {
                    Log.v("yxy", "====精品题库数据加载===")
                    exam_answer_menu.visibility = View.GONE
                    exam_answer_toolbar_title.text = "答题模式"
                    templateId = intent.getStringExtra("templateId") ?: ""
//                    if (isDo) {
//                        requestViewModel.getQuestionBankList2(paperId, templateId)
//                    } else {
//                        requestViewModel.getQuestionBankList(paperId, templateId)
//                    }
                    requestViewModel.getQuestionBankList3(paperId, templateId)
                } else {
                    requestViewModel.getQuestionPaperSubject2List(paperId)
                }

            }
        } else {
            answerType = 1
            paperId = intent.getStringExtra("paperId").toString()
            if (StringUtil.isNotBlank(paperId)) {

                requestViewModel.getQuestionPaperSubjectList(paperId)
            }
        }

//        initQuestionView()
        initEvent()
        editTextMaxLengthListener()
        setIconFont(exam_answer_up,"\ue62e")
        setIconFont(exam_answer_submit_next,"\ue62f")
    }

    private fun initEvent() {
        exam_answer_rg_menu.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.exam_answer_rbt_answer -> answerType = 1
                R.id.exam_answer_rbt_recite ->{
                    answerType = 2
                    exam_answer_ll_error.visibility = View.GONE
                    queston_answer_rl_result.visibility = View.GONE}
            }
            initQuestionView()
        }
    }

    private fun initQuestionView() {
        if (answerType == 1) {
            exam_answer_resolve.visibility = View.GONE
        } else if (answerType == 2) {
            exam_answer_resolve.visibility = View.VISIBLE
        } else {
            exam_answer_resolve.visibility = View.VISIBLE
        }
        Log.v("yxy", "===liftingType=answerType=" + liftingType + "====" + answerType)
        if (liftingType == 1 || liftingType == 4 || (liftingType == 3 && !isMultiple) || liftingType == 6 || liftingType == 7 || liftingType == 8) {
            singleOperationAdapter.setAnswer(answerType)
            singleOperationAdapter.notifyDataSetChanged()
        } else if (liftingType == 2 || (liftingType == 3 && isMultiple)) {
            mutOperationAdapter.setAnswer(answerType)
            mutOperationAdapter.notifyDataSetChanged()
        }
    }

    override fun createObserver() {
        requestViewModel.errorCorrectionResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("提交成功")
                questionSettingsDialog?.dismiss()
            }})

        requestViewModel.paperListJsonResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                Log.v("yxy", "==兼容模版=" + it.toString())
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                var position = 0
                var questionIndex = 0
                var total = 0
                val json = GsonUtils.toJson(it)
                Log.v("yxy", "==兼容模版=" + json.get(0))
                if (json.get(0).toString() == "{") {
                    val data = GsonUtils.fromJson<QuestionPaperAllEntity>(
                        GsonUtils.toJson(it),
                        QuestionPaperAllEntity::class.java
                    )
                    Log.v("yxy", "==兼容模版   对象=" + data.list.size)
                    for (info in data.list) {
                        for (quest in info.list) {
                            total += 1
                        }
                    }

                    for (info in data.list) {
                        for (quest in info.list) {
                            when (quest.liftingType) {
                                3, 4, 7, 8 -> {
                                    var subIndex = 0
                                    questionIndex += 1
                                    for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                        position += 1
                                        subIndex += 1
                                        val questionDb = QuestionPaperDbEntity()
                                        questionDb.paperId = quest.paperId
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.templateId = quest.templateId
                                        questionDb.parentId = quest.id
                                        questionDb.isCollect = quest.isCollect
                                        questionDb.answer = sub.answerTxt
                                        questionDb.answerText = sub.answerText
                                        questionDb.total = total
                                        questionDb.facilityValue = sub.facilityValue
                                        questionDb.paperType = sub.paperType
                                        questionDb.questionId = sub.id
                                        questionDb.stem = quest.stem
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId = quest.isCollectId
                                        }
                                        questionDb.questionIndex = questionIndex
                                        questionDb.index = "$questionIndex-$subIndex"
                                        questionDb.childStem = sub.stem
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)

                                        if (sub.wdQuestionPaperData != null) {
                                            questionDb.wdQuestionPaperData =
                                                GsonUtils.toJson(quest.wdQuestionPaperData)
                                        }
                                        if (sub.wdQuestionPaperDataVideo != null) {
                                            questionDb.wdQuestionPaperDataVideo =
                                                GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                        }
                                        if (sub.wdQuestionChapterPractice != null) {
                                            questionDb.wdQuestionChapterPractice =
                                                GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                        }
                                        questionDb.childIndex =
                                            "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                        questionDb.position = position
                                        if (sub.wdQuestionPaperOption != null) {
                                            questionDb.wdQuestionPaperOption =
                                                GsonUtils.toJson(sub.wdQuestionPaperOption)

                                        }

                                        if (quest.wdQuestionBankList.size > 0) {
                                            questionDb.wdQuestionBankList =
                                                GsonUtils.toJson(quest.wdQuestionBankList)
                                        } else {
                                            questionDb.wdQuestionBankList = ""
                                        }
                                        questionDb.save()
//                                    Log.v(
//                                        "yxy",
//                                        "==duoxuan==>" + it.liftingType + "===" + quest.liftingType + "==subIndex=" + it.subjectId
//                                    )
                                        if (data.liftingType == quest.liftingType && StringUtil.isNotBlank(
                                                data.subjectId
                                            )
                                        ) {
                                            if (data.subjectId == sub.id) {
                                                index = position + 1
                                            }
                                        }


                                    }

                                }
                                else -> {
                                    questionIndex += 1
                                    position += 1
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.answer = quest.answerTxt
                                    questionDb.answerText = quest.answerText
                                    questionDb.paperId = quest.paperId
                                    questionDb.parentId = quest.id
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.total = total
                                    questionDb.paperType = quest.paperType
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.facilityValue = quest.facilityValue
                                    questionDb.stem = quest.stem
                                    questionDb.templateId = quest.templateId
                                    questionDb.questionId = quest.id
                                    questionDb.position = position
                                    questionDb.questionIndex = questionIndex
                                    if (quest.liftingType == 5) {
                                        questionDb.topicCategory = quest.topicCategory
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                    } else {
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)
                                    }

                                    questionDb.index = questionIndex.toString()
                                    if (quest.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(quest.wdQuestionPaperData)
                                    }
                                    if (quest.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                    }
                                    if (quest.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                    }
                                    if (quest.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(quest.wdQuestionPaperOption)

                                    }
                                    if (quest.wdQuestionBankList.size > 0) {
                                        questionDb.wdQuestionBankList =
                                            GsonUtils.toJson(quest.wdQuestionBankList)
                                    } else {
                                        questionDb.wdQuestionBankList = ""
                                    }
                                    questionDb.save()
                                    if (data.liftingType == quest.liftingType && StringUtil.isNotBlank(
                                            data.subjectId
                                        )
                                    ) {
                                        if (data.subjectId == quest.id) {
                                            index = position + 1
                                        }
                                    }
                                }
                            }
                        }
                    }

                    totalNum = LitePal.count(QuestionPaperDbEntity::class.java)
                    if (index <= totalNum) {
                        setQuestionView(
                            LitePal.where("position=?", index.toString())
                                .findLast(QuestionPaperDbEntity::class.java)
                        )
                    } else {
                        gotoSubmitQuestion()
                    }
                } else if (json.get(0).toString() == "[") {
                    Log.v("yxy", "==兼容模版   list=")
                    val turnsType = CacheUtil.genericType<ArrayList<QuestionPaperSubjectEntity>>()
                    val dataList =
                        Gson().fromJson<ArrayList<QuestionPaperSubjectEntity>>(
                            GsonUtils.toJson(it),
                            turnsType
                        )
                    CacheUtil.setQuestionPaperSubject(dataList)

                    for (info in dataList) {
                        for (quest in info.list) {
                            total += 1
                        }
                    }
                    for (info in dataList) {
                        for (quest in info.list) {
                            when (quest.liftingType) {
                                3, 4, 7, 8 -> {
                                    var subIndex = 0
                                    questionIndex += 1
                                    for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                        position += 1
                                        subIndex += 1
                                        val questionDb = QuestionPaperDbEntity()
                                        questionDb.paperId = quest.paperId
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.templateId = quest.templateId
                                        questionDb.answer = sub.answerTxt
                                        questionDb.answerText = sub.answerText
                                        questionDb.total = total
                                        questionDb.parentId = quest.id
                                        questionDb.facilityValue = sub.facilityValue
                                        questionDb.paperType = sub.paperType
                                        questionDb.isCollect = quest.isCollect
                                        questionDb.questionId = sub.id
                                        questionDb.score = sub.score
                                        questionDb.stem = quest.stem
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId = quest.isCollectId
                                        }
                                        questionDb.questionIndex = questionIndex
                                        questionDb.index = "$questionIndex-$subIndex"
                                        questionDb.childStem = sub.stem
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)

                                        if (quest.wdQuestionPaperData != null) {
                                            questionDb.wdQuestionPaperData =
                                                GsonUtils.toJson(quest.wdQuestionPaperData)
                                        }
                                        if (quest.wdQuestionPaperDataVideo != null) {
                                            questionDb.wdQuestionPaperDataVideo =
                                                GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                        }
                                        questionDb.childIndex =
                                            "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                        questionDb.position = position
                                        if (sub.wdQuestionPaperOption != null) {
                                            questionDb.wdQuestionPaperOption =
                                                GsonUtils.toJson(sub.wdQuestionPaperOption)

                                        }
                                        if (sub.wdQuestionChapterPractice != null) {
                                            questionDb.wdQuestionChapterPractice =
                                                GsonUtils.toJson(sub.wdQuestionChapterPractice)

                                        }
                                        if (quest.wdQuestionBankList.size > 0) {
                                            questionDb.wdQuestionBankList =
                                                GsonUtils.toJson(quest.wdQuestionBankList)
                                        } else {
                                            questionDb.wdQuestionBankList = ""
                                        }
                                        questionDb.save()
                                    }

                                }
                                else -> {
                                    questionIndex += 1
                                    position += 1

                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.answer = quest.answerTxt
                                    questionDb.answerText = quest.answerText
                                    questionDb.paperId = quest.paperId
                                    questionDb.total = total
                                    questionDb.parentId = quest.id
                                    questionDb.paperType = quest.paperType
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.isCollect = quest.isCollect
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.facilityValue = quest.facilityValue
                                    questionDb.stem = quest.stem
                                    questionDb.templateId = quest.templateId
                                    questionDb.questionId = quest.id
                                    questionDb.position = position
                                    questionDb.score = quest.score
                                    questionDb.questionIndex = questionIndex
                                    if (quest.liftingType == 5) {
                                        questionDb.topicCategory = quest.topicCategory
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                    } else {
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)
                                    }

                                    questionDb.index = questionIndex.toString()
                                    if (quest.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(quest.wdQuestionPaperData)
                                    }
                                    if (quest.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                    }
                                    if (quest.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(quest.wdQuestionPaperOption)

                                    }

                                    if (quest.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(quest.wdQuestionChapterPractice)

                                    }
                                    if (quest.wdQuestionBankList.size > 0) {
                                        questionDb.wdQuestionBankList =
                                            GsonUtils.toJson(quest.wdQuestionBankList)
                                    } else {
                                        questionDb.wdQuestionBankList = ""
                                    }
                                    questionDb.save()
                                }
                            }
                        }
                    }
                    totalNum = questionIndex
                    index = 1
                    setQuestionView(
                        LitePal.where("position=?", "1")
                            .findLast(QuestionPaperDbEntity::class.java)
                    )
                } else {
                    Log.v("yxy", "==兼容模版   未知=")
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
        requestViewModel.questionListResult.observe(this, Observer {
            if (it.isSuccess) {
                CacheUtil.setQuestionPaperSubject(it.listData)
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                var position = 0
                var questionIndex = 0
                var total = 0
                for (info in it.listData) {
                    for (quest in info.list) {
                        total += 1
                    }
                }
                for (info in it.listData) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText = sub.answerText
                                    questionDb.total = total
                                    questionDb.parentId = quest.id
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.paperType = sub.paperType
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.questionId = sub.id
                                    questionDb.stem = quest.stem
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.score = sub.score
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (quest.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(quest.wdQuestionPaperData)
                                    }
                                    if (quest.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)

                                    }
                                    if (sub.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(sub.wdQuestionChapterPractice)

                                    }
                                    if (quest.wdQuestionBankList.size > 0) {
                                        questionDb.wdQuestionBankList =
                                            GsonUtils.toJson(quest.wdQuestionBankList)
                                    } else {
                                        questionDb.wdQuestionBankList = ""
                                    }
                                    questionDb.save()
                                }

                            }
                            else -> {
                                questionIndex += 1
                                position += 1

                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText = quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.total = total
                                questionDb.parentId = quest.id
                                questionDb.paperType = quest.paperType
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.stem = quest.stem
                                questionDb.score = quest.score
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)

                                }

                                if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)

                                }
                                if (quest.wdQuestionBankList.size > 0) {
                                    questionDb.wdQuestionBankList =
                                        GsonUtils.toJson(quest.wdQuestionBankList)
                                } else {
                                    questionDb.wdQuestionBankList = ""
                                }
                                questionDb.save()
                            }
                        }
                    }
                }
                totalNum = questionIndex
                index = 1
                setQuestionView(
                    LitePal.where("position=?", "1")
                        .findLast(QuestionPaperDbEntity::class.java)
                )
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.paperQuestionInfoResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                    totalNum = 1
                    var position = 0
                    var questionIndex = 0
                    when (it.liftingType) {
                        3, 4, 7, 8 -> {
                            var subIndex = 0
                            questionIndex += 1
                            for (sub in it.wdQuestionPaperSubjectSubordinatesList) {
                                position += 1
                                subIndex += 1
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.paperId = it.paperId
                                questionDb.liftingType = it.liftingType
                                questionDb.position = position
                                questionDb.templateId = it.templateId
                                questionDb.parentId = it.id
                                questionDb.answer = sub.answerTxt
                                questionDb.answerText = sub.answerText
                                questionDb.isCollect = it.isCollect
                                questionDb.questionId = sub.id
                                questionDb.stem = it.stem
                                questionDb.total = 1
                                questionDb.score = sub.score
                                questionDb.facilityValue = sub.facilityValue
                                questionDb.paperType = sub.paperType
                                if (StringUtil.isNotBlank(it.isCollectId)) {
                                    questionDb.isCollectId = it.isCollectId
                                }
                                questionDb.questionIndex = questionIndex
                                questionDb.index = "$questionIndex-$subIndex"
                                questionDb.childStem = sub.stem
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeByType(it.liftingType)

                                if (it.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(it.wdQuestionPaperData)
                                }
                                if (it.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(it.wdQuestionPaperDataVideo)
                                }
                                questionDb.childIndex =
                                    "$subIndex/ ${it.wdQuestionPaperSubjectSubordinatesList.size}"
                                questionDb.position = position
                                if (sub.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(sub.wdQuestionPaperOption)

                                }
                                questionDb.save()
                            }

                        }
                        else -> {
                            questionIndex += 1
                            position += 1
                            val questionDb = QuestionPaperDbEntity()
                            questionDb.answer = it.answerTxt
                            questionDb.answerText = it.answerText
                            questionDb.paperId = it.paperId
                            questionDb.liftingType = it.liftingType
                            questionDb.paperType = it.paperType
                            questionDb.isCollect = it.isCollect
                            questionDb.parentId = it.id
                            questionDb.facilityValue = it.facilityValue
                            if (StringUtil.isNotBlank(it.isCollectId)) {
                                questionDb.isCollectId = it.isCollectId
                            }

                            questionDb.stem = it.stem
                            questionDb.templateId = it.templateId
                            questionDb.questionId = it.id
                            questionDb.position = position
                            questionDb.total = 1
                            questionDb.score = it.score
                            questionDb.questionIndex = 1
                            if (it.liftingType == 5) {
                                questionDb.topicCategory = it.topicCategory
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeBy5(it.topicCategory)
                            } else {
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeByType(it.liftingType)
                            }

                            questionDb.index = questionIndex.toString()
                            if (it.wdQuestionPaperData != null) {
                                questionDb.wdQuestionPaperData =
                                    GsonUtils.toJson(it.wdQuestionPaperData)
                            }
                            if (it.wdQuestionPaperDataVideo != null) {
                                questionDb.wdQuestionPaperDataVideo =
                                    GsonUtils.toJson(it.wdQuestionPaperDataVideo)
                            }

                            if (it.wdQuestionChapterPractice != null) {
                                questionDb.wdQuestionChapterPractice =
                                    GsonUtils.toJson(it.wdQuestionChapterPractice)
                            }
                            if (it.wdQuestionPaperOption != null) {
                                questionDb.wdQuestionPaperOption =
                                    GsonUtils.toJson(it.wdQuestionPaperOption)

                            }
                            questionDb.save()
                        }
                    }
                    totalNum = 1
                    index = 1
//                    Log.v(
//                        "yxy", "= LitePal.where==" + GsonUtils.toJson(
//                            LitePal.where("position=?", "1")
//                                .findLast(QuestionPaperDbEntity::class.java)
//                        )
//                    )
                    setQuestionView(
                        LitePal.where("position=?", "1")
                            .findLast(QuestionPaperDbEntity::class.java)
                    )
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
        requestViewModel.paperListResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                var position = 0
                var questionIndex = 0
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)

                var total = 0
                for (info in it.list) {
                    for (quest in info.list) {
                        total += 1
                    }
                }
                for (info in it.list) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    Log.v(
                                        "yxy",
                                        "==duoxuan==>" + questionIndex + "===" + position + "==subIndex=" + subIndex
                                    )
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.parentId = quest.id
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText = sub.answerText
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.total = total
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.paperType = sub.paperType
                                    questionDb.questionId = sub.id
                                    questionDb.stem = quest.stem
                                    questionDb.score = sub.score
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (quest.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(quest.wdQuestionPaperData)
                                    }
                                    if (quest.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                    }
                                    if (sub.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)

                                    }
//                                    if (quest.wdQuestionBankList.size > 0) {
//                                        questionDb.wdQuestionBankList =
//                                            GsonUtils.toJson(quest.wdQuestionBankList)
//                                    } else {
//                                        questionDb.wdQuestionBankList = ""
//                                    }
                                    questionDb.wdQuestionBankList = ""
                                    questionDb.save()
//                                    Log.v(
//                                        "yxy",
//                                        "==duoxuan==>" + it.liftingType + "===" + quest.liftingType + "==subIndex=" + it.subjectId
//                                    )
                                    if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(
                                            it.subjectId
                                        )
                                    ) {
                                        if (it.subjectId == sub.id) {
                                            index = position + 1
                                        }
                                    }


                                }

                            }
                            else -> {
                                questionIndex += 1
                                position += 1
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText = quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.parentId = quest.id
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                questionDb.total = total
                                questionDb.paperType = quest.paperType
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.stem = quest.stem
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.score = quest.score
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)

                                }
//                                if (quest.wdQuestionBankList.size > 0) {
//                                    questionDb.wdQuestionBankList =
//                                        GsonUtils.toJson(quest.wdQuestionBankList)
//                                } else {
//                                    questionDb.wdQuestionBankList = ""
//                                }
                                questionDb.wdQuestionBankList = ""
                                questionDb.save()
                                if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(it.subjectId)) {
                                    if (it.subjectId == quest.id) {
                                        index = position + 1
                                    }
                                }
                            }
                        }
                    }
                }

                totalNum = LitePal.count(QuestionPaperDbEntity::class.java)
                if (index <= totalNum) {
                    setQuestionView(
                        LitePal.where("position=?", index.toString())
                            .findLast(QuestionPaperDbEntity::class.java)
                    )
                } else {
                    gotoSubmitQuestion()
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })

        requestViewModel.questionSubmitResult.observe(this, Observer {
            if (it.success) {
                if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR) {
                    EventBus.getDefault().post(RefreshErrorQuestionEvent())
                }
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.collectResult.observe(this, Observer {
            isCollect = 1
            isCollectId = it.toString()

            exam_answer_fav.text = "取消"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
            }

            val questionIndex = queIndex
            val list = LitePal.where("questionIndex =?", questionIndex.toString()).find(
                QuestionPaperDbEntity::class.java
            )
            if (list != null) {
                for (info in list) {
                    info.isCollect = isCollect
                    info.isCollectId = isCollectId
                    info.save()
                }
            }

        })

        requestViewModel.delCollectResult.observe(this, Observer
        {
            if (it.success) {
                isCollect = 0
                isCollectId = ""
                exam_answer_fav.text = "收藏"
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    if (MultiTheme.getAppTheme() == 1){
                        exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                    }else{
                        exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                    }

                }
                val questionIndex = queIndex
                val list = LitePal.where("questionIndex =?", questionIndex.toString()).find(
                    QuestionPaperDbEntity::class.java
                )
                if (list != null) {
                    for (info in list) {
                        info.isCollect = isCollect
                        info.isCollectId = isCollectId
                        info.save()
                    }
                }
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    override fun onStop() {
        super.onStop()
        exam_answer_data_media_controller.pause();
        exam_answer_select_media_controller.pause();
        exam_answer_data_video_view.onActivityStop();
        exam_answer_select_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        exam_answer_data_video_view.destroy();
        exam_answer_select_video_view.destroy();
        exam_answer_data_media_controller.disable();
        exam_answer_select_media_controller.disable();
    }

    /**
     * 更新问题布局及数据
     * @param info QuestionPaperInfoEntity
     */
    private fun setQuestionView(info: QuestionPaperDbEntity) {
        questionInfoJson = GsonUtils.toJson(info)
        selectOptions = arrayListOf()
        optionId = ""
        isRight = 0
        isCheckResult = false
        goNext = true
        exam_answer_data_media_controller.resume();
        exam_answer_select_media_controller.resume();
        exam_answer_data_video_view.onActivityStop();
        exam_answer_select_video_view.onActivityStop();
        index = info.position
        isCollect = info.isCollect
        if (StringUtil.isNotBlank(info.paperId)) {
            parentId = info.parentId
        }
        bankListJson = info.wdQuestionBankList ?: ""
        if (StringUtil.isNotBlank(info.wdQuestionBankList)) {
            setQuestionBankView(info.wdQuestionBankList)
        } else {
            exam_answer_juyifansan.visibility = View.GONE
        }

        queIndex = info.questionIndex
        exam_answer_edt_solution.setText("")
        exam_answer_fav.text = "收藏"
        Log.v("yxy", "=isCollect==" + isCollect)
        if (isCollect == 0) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                if (MultiTheme.getAppTheme() == 1){
                    exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                }else{
                    exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                }
                exam_answer_fav.text = "收藏"
            }
        } else {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
                exam_answer_fav.text = "取消"
            }
        }
        if (StringUtil.isNotBlank(info.isCollectId)) {
            isCollectId = info.isCollectId
        }

        Log.v("yxy", "==难易程度==" + info.facilityValue + "====")
        if (info.facilityValue > 0) {
            StringUtil.setLevel(info.facilityValue, exam_answer_img_level)
        }
        if (isMockError) {
            if (StringUtil.isNotBlank(info.paperType)) {
                type = info.paperType.toInt()
            }

        }
        liftingType = info.liftingType
        changeViewByType(info.liftingType)
        exam_answer_title.text = info.stem
        parentId = info.parentId
//        question_tv_analyze.text = info.answer
//        if (StringUtil.isNotBlank(info.answer)) {
//            question_tv_analyze.visibility = View.VISIBLE
//            question_tv_analyze.loadDataWithBaseURL(
//                null,
//                info.answer + js, "text/html; charset=UTF-8", null, null
//            );
//        } else {
//            question_tv_analyze.visibility = View.GONE
//        }



        Log.v("yxy", "===info.answerText===" + info.answerText + "=historyFrom==" + historyFrom)
        if (historyFrom == Constants.PARAMS_QUESTION_SOURCE_REAL) {
            exam_answer_tv_statistics.visibility = View.GONE
        } else {
            exam_answer_tv_statistics.visibility = View.VISIBLE
        }

        exam_answer_tv_statistics.text = info.answerText
        Log.v("yxy", "=exam_answer_title==" + info.stem)
        if (liftingType != 5) {
            exam_answer_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            exam_answer_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }
        id = info.questionId
        subjectId = info.questionId
        updateWebView();
        val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
        exam_answer_data_view_layout.visibility = View.GONE
        exam_answer_data_img.visibility = View.GONE
        if (StringUtil.isNotBlank(info.wdQuestionPaperData)) {
            val turnsType = CacheUtil.genericType<java.util.ArrayList<SubjectFileEntity>>()
            val dataList =
                Gson().fromJson<java.util.ArrayList<SubjectFileEntity>>(
                    info.wdQuestionPaperData,
                    turnsType
                )
            if (dataList.size > 0) {
                if (dataList[0].materialType == "2") {
                    exam_answer_data_view_layout.visibility = View.VISIBLE
                    play(
                        dataList[0].videoUrl,
                        exam_answer_data_media_controller,
                        exam_answer_data_video_view,
                        exam_answer_data_view_layout,
                        exam_answer_data_first_start_view
                    );
                } else {
                    exam_answer_data_view_layout.visibility = View.GONE
                    if (StringUtil.isNotBlank(dataList[0].imageUrl)) {
                        exam_answer_data_img.visibility = View.VISIBLE
                        Glide.with(this).load(dataList[0].imageUrl).apply(operation)
                            .into(exam_answer_data_img)
                    }
                }
            }

        }
        if (StringUtil.isNotBlank(info.wdQuestionPaperDataVideo)) {
            val turnsType = CacheUtil.genericType<ArrayList<SubjectFileEntity>>()
            val dataList =
                Gson().fromJson<ArrayList<SubjectFileEntity>>(
                    info.wdQuestionPaperDataVideo,
                    turnsType
                )
            if (dataList.size > 0) {
                if (dataList[0].materialType == "2") {
                    exam_answer_select_view_layout.visibility = View.GONE
                    play(
                        dataList[0].videoUrl,
                        exam_answer_select_media_controller,
                        exam_answer_select_video_view,
                        exam_answer_select_view_layout,
                        exam_answer_select_first_start_view
                    );
                } else {
                    exam_answer_select_view_layout.visibility = View.GONE
                }
            }

        }
        val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
        val optionList =
            Gson().fromJson<ArrayList<QuestionOptionEntity>>(
                info.wdQuestionPaperOption,
                turnsType
            )
        totalNum = info.total
        var mutSize = 0

        if (optionList != null) {
            for (ope in optionList) {
                if (ope.rightFlag == 0) {
                    mutSize += 1
                }
            }
        }

        isMultiple = mutSize > 1
        Log.v("yxy", "mutSize" + mutSize + "==isMultiple=" + isMultiple)
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>${info.questionIndex}</font>/ ${totalNum}  题";
        exam_answer_index.text = Html.fromHtml(str);
        if (optionList != null) {
            exam_answer_right_result.text = getRightResult(optionList)
        }

        val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
            info.wdQuestionChapterPractice,
            WdQuestionChapterPracticeEntity::class.java
        )

        Log.v("yxy", "practice==》" + info.wdQuestionChapterPractice)
        if (practice != null && from != Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
            queston_answer_rl_result.visibility = View.VISIBLE
            if (practice.isRight == "0") {
                exam_answer_result.setText("回答正确")
                if (MultiTheme.getAppTheme() != 1){
                    ll_exam_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_right)
                }
                if (liftingType != 5) {
                    exam_answer_ll_error.visibility = View.VISIBLE
                } else {
                    exam_answer_ll_error.visibility = View.GONE
                }
                if (practice.wdQuestionPaperOption != null) {
                    exam_answer_error_result.text = getRightResult(practice.wdQuestionPaperOption)
                } else if (practice.chapterContentList != null) {
                    exam_answer_error_result.text = getRightResult(practice.chapterContentList)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    exam_answer_result.setIconNormal(getDrawable(R.mipmap.icon_answer_right))
                }
            } else {
                exam_answer_result.setText("回答错误")
                exam_answer_ll_error.visibility = View.VISIBLE

//                if(loadFrom==1){
//                    if (practice.wdQuestionPaperOption != null) {
//                        exam_answer_error_result.text = getErrorResult(practice.wdQuestionPaperOption)
//                    }
//                }else{
//                    if (practice.chapterContentList != null) {
//                        exam_answer_error_result.text = getErrorResult(practice.chapterContentList)
//                    }
//                }
                if (practice.wdQuestionPaperOption != null) {
                    exam_answer_error_result.text = getErrorResult(practice.wdQuestionPaperOption)
                } else if (practice.chapterContentList != null) {
                    exam_answer_error_result.text = getErrorResult(practice.chapterContentList)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    exam_answer_result.setIconNormal(getDrawable(R.mipmap.icon_answer_error))
                }

                if (MultiTheme.getAppTheme() != 1){
                    ll_exam_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_error)
                }
            }
            answerType = 3
        } else {
            if (loadFrom == 1 && from != Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
                answerType = 1
            } else {
                if (!exam_answer_menu.isVisible) {
                    exam_answer_ll_error.visibility = View.GONE
                    queston_answer_rl_result.visibility = View.GONE
                    answerType = 3
                } else {
                    if (exam_answer_rbt_recite.isChecked || from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
                        answerType = 2
                        exam_answer_ll_error.visibility = View.GONE
                        queston_answer_rl_result.visibility = View.GONE
                    } else {
                        answerType = 1
                    }
                }
            }

        }
        initQuestionView()
        when (liftingType) {
            1, 6 -> {
                //exam_answer_submit_next.text = "下一题"
                setIconFont(exam_answer_submit_next,"\ue62f")
                if (info.wdQuestionPaperOption != null) {
                    initOperationRecycleView(optionList)
                }
            }
            3 -> {
                //exam_answer_submit_next.text = "下一题"
                setIconFont(exam_answer_submit_next,"\ue62f")
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                exam_answer_sub_index.setText(ss)
                exam_answer_stem.text = info.childStem
                if (isMultiple) {
                    if(answerType != 3) {
                        exam_answer_submit_next.text = "确定"
                    }
                    if (info.wdQuestionPaperOption != null) {
                        initMutOperationRecycleView(optionList)
                    }
                } else {
                    //exam_answer_submit_next.text = "下一题"
                    setIconFont(exam_answer_submit_next,"\ue62f")
                    if (info.wdQuestionPaperOption != null) {
                        initOperationRecycleView(optionList)
                    }
                }
            }
            2 -> {
                if(answerType != 3) {
                    exam_answer_submit_next.text = "确定"
                }
                if (info.wdQuestionPaperOption != null) {
                    initMutOperationRecycleView(optionList)
                }
            }
            4, 7, 8 -> {
                //exam_answer_submit_next.text = "下一题"
                setIconFont(exam_answer_submit_next,"\ue62f")
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                exam_answer_sub_index.setText(ss)
                exam_answer_stem.text = info.childStem
                if (optionList != null) {
                    initOperationRecycleView(optionList)
                }
            }
            5 -> {
                //exam_answer_submit_next.text = "下一题"
                setIconFont(exam_answer_submit_next,"\ue62f")
                if (practice != null) {
                    if (StringUtil.isNotBlank(practice.solution)) {
                        exam_answer_rl_result.visibility = View.VISIBLE
                        exam_answer_edt_solution.setText(practice.solution)
                    } else {
                        exam_answer_rl_result.visibility = View.GONE
                    }
                }
            }
        }


    }

    private fun updateWebView(){
        var BASE_URL = ApiService.SERVER_URL
        if (BuildConfig.FLAVOR.contains("product")) {
            BASE_URL = ApiService.WEB_SERVER_URL
        }
        var url =
            BASE_URL + "/zixun/subjectAnswer.html?subjectId=" + subjectId + "&type=" + 0
        if (MultiTheme.getAppTheme() == 1) {
            url = BASE_URL + "/zixun/subjectAnswer.html?subjectId=" + subjectId + "&type=" + 0  + "&background=1"
        }
        Log.d("TAG", "setQuestionView url: " + url)
        question_tv_analyze.loadUrl(url);
    }

    /**
     * 设置举一反三数据
     */
    private fun setQuestionBankView(bankListJSon: String) {
//        Log.v("yxy", "==setQuestionBankView=" + bankListJSon)
        if (StringUtil.isNotBlank(bankListJSon)) {
            bankListJson = bankListJSon
            exam_answer_juyifansan.visibility = View.VISIBLE
            val turnsType = CacheUtil.genericType<ArrayList<QuestionPaperInfoEntity>>()
            val bankList =
                Gson().fromJson<ArrayList<QuestionPaperInfoEntity>>(
                    bankListJSon,
                    turnsType
                )
            bankListData = bankList
            val total = bankList.size
            questionBankList = arrayListOf<QuestionPaperInfoEntity>()
            for ((index, info) in bankList.withIndex()) {
                if (info.wdQuestionPaperSubjectSubordinatesList.size > 0) {
                    for ((subIndex, subInfo) in info.wdQuestionPaperSubjectSubordinatesList.withIndex()) {
                        val indexStr = (index + 1).toString() + "-" + (subIndex + 1)
                        subInfo.index = indexStr
                        subInfo.total = total
                        subInfo.title = info.stem
                        if (info.wdQuestionPaperData != null) {
                            subInfo.wdQuestionPaperData = info.wdQuestionPaperData
                        }
                        if (info.wdQuestionPaperDataVideo != null) {
                            subInfo.wdQuestionPaperDataVideo = info.wdQuestionPaperDataVideo
                        }
                        subInfo.questionIndex = (index + 1)
                        questionBankList.add(subInfo)
                    }
                } else {
                    if (StringUtil.isBlank(info.index)) {
                        info.index = (index + 1).toString()
                        info.total = total
                        info.title = info.stem
                        info.questionIndex = (index + 1)
                    }
                    questionBankList.add(info)
                }
            }
            val info =
                LitePal.where("position =?", index.toString())
                    .findFirst(QuestionPaperDbEntity::class.java)
            info.wdQuestionBankList = GsonUtils.toJson(questionBankList)
            info.save()
            exam_answer_tv_juyifansan_count.text = "本题有${questionBankList.size}道同类题目推荐"
//            if (questionBankList.size > 6) {
//                val selectList = arrayListOf<QuestionPaperInfoEntity>()
//                for ((index, bankInfo) in questionBankList.withIndex()) {
//                    if (index < 6) {
//                        selectList.add(bankInfo)
//                    }
//                }
//                initBankRecycleView(selectList)
//            } else {
//                initBankRecycleView(questionBankList)
//            }
            initBankRecycleView(questionBankList)
        } else {
            exam_answer_juyifansan.visibility = View.GONE
        }

    }

    private fun initBankRecycleView(list: ArrayList<QuestionPaperInfoEntity>) {
        val bankAdapter = QuestionBankAdapter(list)
        //初始化recyclerView
        exam_answer_rlv_juyifansan.init(
            LinearLayoutManager(this, RecyclerView.HORIZONTAL, false),
            bankAdapter
        )
        bankAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info =
                    LitePal.where("position =?", index.toString())
                        .findFirst(QuestionPaperDbEntity::class.java)
                if (info != null) {
                    startActivity(
                        Intent(this@ExamAnswerActivity, LearnByAnalogyActivity::class.java)
                            .putExtra("bankList", info.wdQuestionBankList ?: "")
                            .putExtra("index", position)
                            .putExtra("from", from)
                            .putExtra("data", GsonUtils.toJson(info))
                    )
                }

            }
        }
    }

    /**
     * 背题模式下获取当前题目的正确答案
     * @param list ArrayList<QuestionOptionEntity>
     * @return String
     */
    private fun getRightResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            if (info.rightFlag == 0) {
                result += info.selectValue + ","
            }
        }
        return StringUtil.convertStr(result)
    }

    private fun getErrorResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            result += info.selectValue + ","

        }
        return StringUtil.convertStr(result)
    }

    /**
     * 更新题目编号索引
     * @param ind Int
     * @param total Int
     * @param isSub Boolean
     */
    private fun setQuestionIndex(ind: Int, total: Int, isSub: Boolean) {
        val num = ind + 1;
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>$num</font>/ $total  题";
        if (isSub) {
            exam_answer_sub_index.text = Html.fromHtml(str);
        } else {
            exam_answer_index.text = Html.fromHtml(str);
        }
    }

    /**
     * 根据类型更改本地问题布局
     * @param type Int
     */
    private fun changeViewByType(type: Int) {
        when (type) {
            1, 6 -> {
                //单项选择
                exam_answer_rl_result.visibility = View.GONE
                exam_answer_rlv_operation.visibility = View.VISIBLE
                exam_answer_ll_stem.visibility = View.GONE
                exam_answer_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    exam_answer_resolve.visibility = View.GONE
                } else {
                    queston_answer_rl_result.visibility = View.VISIBLE

                    if (answerType == 2) {
                        queston_answer_rl_result.visibility = View.GONE
                        exam_answer_ll_error.visibility = View.GONE
                    } else {
                        queston_answer_rl_result.visibility = View.VISIBLE
                        exam_answer_ll_error.visibility = View.VISIBLE
                    }
                    exam_answer_resolve.visibility = View.VISIBLE
                    updateAnswerBg()
                    Log.d("TAG", "jeek exam_answer_resolve: " + 1655)
                }
            }
            2 -> {
                //多项选择
                exam_answer_rlv_operation.visibility = View.VISIBLE
                exam_answer_ll_stem.visibility = View.GONE
                exam_answer_rl_result.visibility = View.GONE
                exam_answer_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    exam_answer_resolve.visibility = View.GONE
                } else {
                    queston_answer_rl_result.visibility = View.GONE
                    if (answerType == 2) {
                        queston_answer_rl_result.visibility = View.GONE
                        exam_answer_ll_error.visibility = View.GONE
                    } else {
                        queston_answer_rl_result.visibility = View.VISIBLE
                        exam_answer_ll_error.visibility = View.VISIBLE
                    }
                    Log.d("TAG", "jeek exam_answer_resolve: " + 1676)
                    exam_answer_resolve.visibility = View.VISIBLE
                    updateAnswerBg()
                }
            }
            3, 4, 7, 8 -> {
                //共用题干
                exam_answer_ll_stem.visibility = View.VISIBLE
                exam_answer_rlv_operation.visibility = View.VISIBLE
                exam_answer_rl_result.visibility = View.GONE
                exam_answer_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE

                    exam_answer_resolve.visibility = View.GONE
                } else {
                    exam_answer_resolve.visibility = View.VISIBLE
                    updateAnswerBg()
                    Log.d("TAG", "jeek exam_answer_resolve: " + 1693)
                    if (answerType == 2) {
                        queston_answer_rl_result.visibility = View.GONE
                        exam_answer_ll_error.visibility = View.GONE
                    } else {
                        queston_answer_rl_result.visibility = View.VISIBLE
                        exam_answer_ll_error.visibility = View.VISIBLE
                    }

                }
            }

            5 -> {
                //主观题
                exam_answer_rlv_operation.visibility = View.GONE
                exam_answer_ll_stem.visibility = View.GONE
                exam_answer_ll_right.visibility = View.GONE
                exam_answer_rl_result.visibility = View.VISIBLE
                if (answerType == 1) {
                    exam_answer_resolve.visibility = View.GONE
                } else {
                    Log.d("TAG", "jeek exam_answer_resolve: " + 1714)
                    exam_answer_resolve.visibility = View.VISIBLE
                    exam_answer_ll_error.visibility = View.GONE
                    updateAnswerBg()

                }
            }
        }
    }

    private fun initOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        singleOperationAdapter = ExamAnswerOperationAdapter(operationList)
        //初始化recyclerView
        exam_answer_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        singleOperationAdapter.setAnswer(answerType)
        var isCheck = false
        singleOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheck && answerType == 1) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    optionId = info.id
                    setPosition(position)
                    selectOptions.add(info)
                    isRight = info.rightFlag
                    singleOperationAdapter.notifyDataSetChanged()
                    saveAnswer()
                    if (info.rightFlag == 1) {
                        Log.d("TAG", "jeek exam_answer_resolve: " + 1746)
                        exam_answer_resolve.visibility = View.VISIBLE
                        val rightresult = getRightResult(operationList)
                        exam_answer_right_result.text = rightresult
                        exam_answer_error_result.text = info.selectValue
                        updateAnswerBg()
                    } else {
                        if (loadFrom == 0) {
                            nextQuestion()
                        }

                    }
                }

                isCheck = true
                setIsCheck(isCheck)
                singleOperationAdapter.notifyDataSetChanged()
            }


        }
    }

    /**
     * 多选选项处理器
     */
    private fun initMutOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        mutOperationAdapter = QuestionResolveOperationAdapter(operationList)
        //初始化recyclerView
        exam_answer_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        mutOperationAdapter.setAnswer(answerType)
        mutOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheckResult) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    setPosition(position)
                    mutOperationAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    /**
     * 查验举一反三是否答完
     */
    private fun checkLearnByAnalogy(): Boolean {
        var isFinish = false
        val unDoList = arrayListOf<QuestionPaperInfoEntity>()
        Log.v("yxy", "==bankListData==" + bankListData.size)


        val info =
            LitePal.where("questionIndex =?", queIndex.toString())
                .findFirst(QuestionPaperDbEntity::class.java)
        bankListJson = info.wdQuestionBankList?: ""
        Log.v(
            "yxy",
            "==判断前置条件==" + StringUtil.isNotBlank(bankListJson) + "==answerType==" + answerType+from
        )
        if (StringUtil.isNotBlank(bankListJson)
            && (answerType==1 || (answerType==3 &&from != Constants.PARAMS_QUESTION_SOURCE_RESOLVE))) {
            val turnsType = CacheUtil.genericType<ArrayList<QuestionPaperInfoEntity>>()
            val bankListData =
                Gson().fromJson<ArrayList<QuestionPaperInfoEntity>>(
                    bankListJson,
                    turnsType
                )
            for (info in bankListData) {
                if (info.wdQuestionChapterPractice == null) {
                    unDoList.add(info)
                }
            }
            isFinish = unDoList.size == 0

            if (!isFinish) {
                val messageDialog = LearnAnalogyMessageDialog.Builder(this)
                    .setTitle("提示")
                    .setCancel("确定")
                    .setConfirm("继续做题")
                    .setMessage("您还有子题未做，确定要进入下一题吗？")
                    .setListener(object : LearnAnalogyMessageDialog.OnListener {
                        override fun onConfirm(dialog: BaseDialog) {
                            dialog.dismiss()

                        }

                        override fun onCancel(dialog: BaseDialog) {
                            dialog.dismiss()
                            goNext=true
                            nextQuestion()
                        }
                    })
                messageDialog!!.show()
            }
        } else {
            isFinish = true
        }

        Log.v(
            "yxy",
            "==isFinish==" + isFinish )
        return isFinish
    }

    inner class ProxyClick() {
        /**
         * 答题卡
         */
        fun gotoQuestionResultCardClick() {
            if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO || from == Constants.PARAMS_QUESTION_SOURCE_NOTE) {
                ToastUtils.showShort("当前为最后一道题")
                return
            }
            val chooseDialog =
                PaperScantronCardDialog.newBuilder(this@ExamAnswerActivity, isSeeAll, loadFrom,
                    object : PaperScantronCardDialog.OnSubmitClickListener {
                        override fun onSubmitClick(content: Int) {
                            index = content
                            val info =
                                LitePal.where("position =?", index.toString())
                                    .findFirst(QuestionPaperDbEntity::class.java)
                            if (info != null) {
                                setQuestionView(info)
                            }
                        }
                    })
            chooseDialog.show()
        }

        /**
         * 收藏
         */
        fun favClick() {
            if (isCollect == 1) {
                requestViewModel.delCollect(isCollectId)
            } else {
                val json = JsonObject()
                json.addProperty("subjectId", parentId)
                json.addProperty("type", type)
                requestViewModel.addCollect(json)
            }
        }

        /**
         * 笔记
         */
        fun goCreateNoteClick() {
            startActivity(
                Intent(this@ExamAnswerActivity, CreateNoteActivity::class.java)
                    .putExtra("id", id)
                    .putExtra("subjectId", subjectId)
                    .putExtra("type", 2)
            )
        }

        /**
         * 设置
         */
        fun goSettingsDialog() {
            val chooseDialog =
                SettingsDialog.newBuilder(this@ExamAnswerActivity, false, 1,
                    object : SettingsDialog.OnSubmitClickListener {
                        override fun onSubmitClick(themeMode: Int,fontSize: Float?) {
                            if (fontSize != null) {
                                SPUtils.getInstance().put("fontSize",fontSize)
                            }
                            SPUtils.getInstance().put("themeMode",themeMode)
                            setTextSize()
                            mutOperationAdapter.notifyDataSetChanged()
                            singleOperationAdapter.notifyDataSetChanged()
                        }

                        override fun onModeSelect(mode: Int,value: Float?) {
                            if (mode == 1){
                                MultiTheme.setAppTheme(1);
                            }else {
                                MultiTheme.setAppTheme(0);
                            }
                            updateWebView()
                            updateIcon()
                            if (value != null) {
                                Constants.questionTextSize = ((value - 50)/100) * 4 * 2
                                setTextSize()
                            };
                            if (MultiTheme.getAppTheme() != 1){
                                if ( exam_answer_result.text.contains("回答错误")) {
                                    ll_exam_answer_bg.background =
                                        resources.getDrawable(R.drawable.shape_bg_answer_error)
                                }else if ( exam_answer_result.text.contains("回答正确")) {
                                    ll_exam_answer_bg.background =
                                        resources.getDrawable(R.drawable.shape_bg_answer_right)
                                }
                            }
                        }

                        override fun onRangeChanged(value: Float) {
                            Constants.questionTextSize = ((value - 50)/100) * 4 * 2
                            setTextSize()
                        }

                    })
            chooseDialog.show()
        }


        /**
         * 上一题
         */
        fun upQuestionClick() {
            index -= 1
            if (index >= 1) {
                if (isSeeAll) {
                    val info =
                        LitePal.where("position =?", index.toString())
                            .findFirst(QuestionPaperDbEntity::class.java)
                    if (info != null) {
                        setQuestionView(info)
                    }
                } else {
                    val list = LitePal.where("position <= ?", index.toString())
                        .find(QuestionPaperDbEntity::class.java)
                    list.reverse();
                    Log.v("yxy", "=list==" + list.size + "===index==" + index)
                    for (info in list) {
                        var isRight = "1"
                        if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                            val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                                info.wdQuestionChapterPractice,
                                WdQuestionChapterPracticeEntity::class.java
                            )
                            if (practice != null) {
                                isRight = practice.isRight
                            }
                        }
                        if (info.liftingType != 5 && info.position < index && (isRight == "1" || StringUtil.isBlank(
                                info.wdQuestionChapterPractice
                            ))
                        ) {
                            setQuestionView(info)
                            break
                        }
                    }
                }

            } else {
                ToastUtils.showShort("当前为第一题")
            }
        }

        /**
         * 下一题
         */
        fun nextQuestionClick() {

            if (liftingType == 2 || liftingType == 3 || liftingType == 5) {
                if (from != Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
                    saveAnswer()
                }

            }
//            Log.v("yxy", "===checkLearnByAnalogy()=" + checkLearnByAnalogy())
            if (checkLearnByAnalogy()) {
                nextQuestion()
            }


        }

        /**
         * 举一反三
         */
        fun gotoQuestionBankList() {
            if(!FastClickUtils.validClick()){
                return
            }
            val info =
                LitePal.where("questionIndex =?", queIndex.toString())
                    .findFirst(QuestionPaperDbEntity::class.java)
            val bankList = ""
            if (info != null) {
                startActivity(
                    Intent(this@ExamAnswerActivity, LearnByAnalogyActivity::class.java)
                        .putExtra("bankList", info.wdQuestionBankList ?: "")
                        .putExtra("index", 0)
                        .putExtra("from", from)
                        .putExtra("data", GsonUtils.toJson(info))
                )
            }
//            Log.v("yxy","=bankListJson="+bankListJson)
//            Log.v("yxy","=data="+questionInfoJson)
//            startActivity(
//                Intent(this@ExamAnswerActivity, LearnByAnalogyActivity::class.java)
//                    .putExtra("bankList", bankListJson)
//                    .putExtra("index", 0)
//                    .putExtra("from", from)
//                    .putExtra("data",questionInfoJson)
//            )
        }


        /**
         * 纠错
         */
        fun gotoRecoveryError() {
            questionSettingsDialog =
                RecoveryErrorDialog.newBuilder(this@ExamAnswerActivity, false, 1,
                    object : RecoveryErrorDialog.OnSubmitClickListener {
                        override fun onSubmitClick(tags: String,content: String) {
                            if (tags.isEmpty()){
                                ToastUtils.showShort("请选择错误类型")
                                return
                            }
                            val json = JsonObject()
                            //type传0为意见反馈，传1为试题纠错
                            json.addProperty("type", 1)
                            //试题纠错则需要传subject_id（试题id）
                            if(liftingType == 4 || liftingType == 3 || liftingType == 7 || liftingType == 8){
                                json.addProperty("subjectId", parentId)
                            }else{
                                json.addProperty("subjectId", subjectId)
                            }
                            json.addProperty("majorId", CacheUtil.getMajorId())
                            json.addProperty("feedContent", content)
                            json.addProperty("feedType", tags)
                            requestViewModel.errorCorrection(json)
                        }
                    })


            questionSettingsDialog?.show()
        }

        /**
         * 只看错题
         */
        fun seeErrorClick() {
            isSeeAll = !isSeeAll
            val errorList = arrayListOf<QuestionPaperDbEntity>()
            val list = LitePal.findAll(QuestionPaperDbEntity::class.java)
            for (info in list) {
                if (info.liftingType != 5) {
                    if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                        val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                            info.wdQuestionChapterPractice,
                            WdQuestionChapterPracticeEntity::class.java
                        )
                        if (practice != null) {
                            if (practice.isRight == "1") {
                                errorList.add(info)
                            }
                        }
                    } else {
                        errorList.add(info)
                    }
                }
            }
            if (errorList.size == 0) {
                isSeeAll = true
                ToastUtils.showShort("无错题")
            }
            Log.v("yxy", "=see=all2=" + list.size + "===error==" + errorList.size)
            //错题大于0 切换，否则显示全部
            if (!isSeeAll && errorList.size > 0) {
                exam_answer_error.text = "查看全部"
                index = 1
                totalNum = errorList.size
                setQuestionIndex(index, totalNum, false)
                setQuestionView(errorList[0])
            } else {
                exam_answer_error.text = "只看错题"
                totalNum = list.size
                setQuestionIndex(index, totalNum, false)
                setQuestionView(list[0])
            }

        }
    }

    private fun nextQuestion() {
        Log.v("yxy", "==goNext=" + goNext + from)
        if (goNext) {
            index += 1
            val count = LitePal.count(QuestionPaperDbEntity::class.java)
            if (index <= count) {

                if (isSeeAll) {
                    val info =
                        LitePal.where("position =?", index.toString())
                            .findFirst(QuestionPaperDbEntity::class.java)
                    if (info != null) {
                        setQuestionView(info)
                    }
                } else {
                    val list = LitePal.where("position >= ?", index.toString())
                        .find(QuestionPaperDbEntity::class.java)
//                    Log.v("yxy", "=error==" + list.size + "==" + index)
                    for (info in list) {
                        var isRight = "1"
                        if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                            val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                                info.wdQuestionChapterPractice,
                                WdQuestionChapterPracticeEntity::class.java
                            )
                            if (practice != null) {
                                isRight = practice.isRight
                            }
                        }
//                        Log.v(
//                            "yxy",
//                            "===" + isRight + "===" + StringUtil.isBlank(info.wdQuestionChapterPractice) + "==" + info.position + "==" + index
//                        )
                        if (info.liftingType != 5 && (info.position > index) && (isRight == "1" || StringUtil.isBlank(
                                info.wdQuestionChapterPractice
                            ))
                        ) {
                            setQuestionView(info)
                            break
                        }
                    }
                }

            } else {
                if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO || from == Constants.PARAMS_QUESTION_SOURCE_NOTE) {
                    return
                } else {
                    gotoSubmitQuestion()
                }
            }
        }
    }

    /**
     * 保存答案
     */
    private fun saveAnswer() {
        val json = JsonObject()
        solution = ""
        val question =
            LitePal.where("position= ?", index.toString())
                .findFirst(QuestionPaperDbEntity::class.java)

        val practice = WdQuestionChapterPracticeEntity()
        practice.type = type.toString()
        if (question == null) {
            return
        }
        if (StringUtil.isNotBlank(isCollectId)) {
            question.isCollectId = isCollectId
        }

        question.isCollect = isCollect
        practice.subjectId = question.questionId
        when (liftingType) {
            //单选题型
            1, 6, 4, 7, 8 -> {

                practice.chapterContentList = selectOptions
                practice.isRight = isRight.toString()
                practice.optionId = optionId
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                if (StringUtil.isNotBlank(optionId)) {
                    question.updateAll("position=?", index.toString())
                }
            }
            3 -> {
                if (!isMultiple) {
                    practice.chapterContentList = selectOptions
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    if (StringUtil.isNotBlank(optionId)) {
                        question.updateAll("position=?", index.toString())
                    }
                } else {
                    val selectOptionList = arrayListOf<QuestionOptionEntity>()
                    optionId = ""
                    val operations = mutOperationAdapter.data
                    var selectValues = ""
                    var rightValues = ""
                    for (ope in operations) {
                        if (ope.isSelect) {
                            optionId += ope.id + ","
                            selectValues += ope.selectValue + ","
                            selectOptionList.add(ope)
                        }
                    }
                    val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                    val oprationList =
                        Gson().fromJson<ArrayList<QuestionOptionEntity>>(
                            question.wdQuestionPaperOption,
                            turnsType
                        )
                    if (oprationList != null) {
                        for (ope in oprationList) {
                            if (ope.rightFlag == 0) {
                                rightValues += ope.selectValue + ","
                            }
                        }
                    }


                    if (rightValues == selectValues) {
                        isRight = 0
                    } else {
                        isRight = 1
                    }
                    Log.v("yxy", "=多选结果==" + rightValues + "====" + selectValues + "===" + isRight)
                    if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                        practice.chapterContentList = selectOptionList
                        practice.isRight = isRight.toString()
                        practice.optionId = optionId
                        question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                        if (StringUtil.isNotBlank(optionId)) {
                            question.updateAll("position=?", index.toString())
                        }
                        if (isRight == 1) {
                            goNext = !goNext
                            exam_answer_resolve.visibility = View.VISIBLE
                            Log.d("TAG", "jeek exam_answer_resolve: " + 2265)
                            //exam_answer_submit_next.text = "下一题"
                            setIconFont(exam_answer_submit_next,"\ue62f")
                            exam_answer_error_result.text = selectValues
                            mutOperationAdapter.setCheck(true)
                            isCheckResult = true
                            mutOperationAdapter.notifyDataSetChanged()
                            updateAnswerBg()
                            if (goNext) {
                                return
                            }
                        }
                    }
                }
            }
            2 -> {

                val selectOptionList = arrayListOf<QuestionOptionEntity>()
                optionId = ""
                val operations = mutOperationAdapter.data
                var selectValues = ""
                var rightValues = ""
                for (ope in operations) {
                    if (ope.isSelect) {
                        optionId += ope.id + ","
                        selectValues += ope.selectValue + ","
                        selectOptionList.add(ope)
                    }
                }
                val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                val oprationList =
                    Gson().fromJson<ArrayList<QuestionOptionEntity>>(
                        question.wdQuestionPaperOption,
                        turnsType
                    )
                if (oprationList != null) {
                    for (ope in oprationList) {
                        if (ope.rightFlag == 0) {
                            rightValues += ope.selectValue + ","
                        }
                    }
                }


                if (rightValues == selectValues) {
                    isRight = 0
                } else {
                    isRight = 1
                }
                if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                    practice.chapterContentList = selectOptionList
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    if (StringUtil.isNotBlank(optionId)) {
                        question.updateAll("position=?", index.toString())
                    }
                    if (isRight == 1) {
                        goNext = !goNext
                        exam_answer_resolve.visibility = View.VISIBLE
                        updateAnswerBg()
                        //exam_answer_submit_next.text = "下一题"
                        setIconFont(exam_answer_submit_next,"\ue62f")
                        exam_answer_error_result.text = selectValues
                        mutOperationAdapter.setCheck(true)
                        isCheckResult = true
                        mutOperationAdapter.notifyDataSetChanged()
                        if (goNext) {
                            return
                        }
                    }
                }
            }
            5 -> {
                solution = exam_answer_edt_solution.text.toString().trim()
                if (StringUtil.isNotBlank(solution)) {
                    practice.solution = solution
                    isRight = 0
                } else {
                    practice.solution = ""
                }
                optionId = ""
                practice.isRight = isRight.toString()
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)

                if (StringUtil.isNotBlank(solution)) {
                    json.addProperty("solution", solution)
                    question.updateAll("position=?", index.toString())
                }


            }
        }
        if (StringUtil.isNotBlank(optionId) || StringUtil.isNotBlank(solution)) {
            json.addProperty("isRight", isRight)
            if (StringUtil.isNotBlank(optionId)) {
                json.addProperty("optionId", optionId)
            }
            json.addProperty("paperId", question.paperId)
            json.addProperty("paperType", type)
            json.addProperty("score", question.score)
            json.addProperty("subjectId", question.questionId)
            json.addProperty("type", type)

            if (StringUtil.isNotBlank(solution)) {
                json.addProperty("solution", solution)
            }
            if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR) {
                json.addProperty("errorType", 1)
            }
            if (StringUtil.isNotBlank(solution) || StringUtil.isNotBlank(optionId)) {
                Log.v("yxy", "已做" + question.wdQuestionChapterPractice)
                requestViewModel.submitQuestionResult(json)
            } else {
                Log.v("yxy", "未做")
            }
        }
    }

    private fun gotoSubmitQuestion() {
        if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE || answerType == 2) {
            ToastUtils.showShort("这是最后一题")
        } else {
            if (RxSimple.isFastClick(2000)) {
                return
            }
            startActivity(
                Intent(this@ExamAnswerActivity, ExamInformActivity::class.java)
                    .putExtra("type", type)
                    .putExtra("from", from)
                    .putExtra("errorFrom", 2)
                    .putExtra(Constants.PARAMS_QUESTION_ERROR, intent.getIntExtra(Constants.PARAMS_QUESTION_ERROR,0))
                    .putExtra("paperId", paperId)
                    .putExtra("loadFrom", loadFrom)
                    .putExtra("templateId", templateId)
            )
            finish()
        }

    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun refreshQuestionBankEvent(questionBank: RefreshQuestionBankEvent) {
        val info =
            LitePal.where("position =?", index.toString())
                .findFirst(QuestionPaperDbEntity::class.java)
//        Log.v("yxy", "===刷新数据="+index+"-----"+info.wdQuestionBankList)
        when {
            StringUtil.isNotBlank(info.wdQuestionBankList) -> {
                val turnsType = CacheUtil.genericType<ArrayList<QuestionPaperInfoEntity>>()
                val bankList =
                    Gson().fromJson<ArrayList<QuestionPaperInfoEntity>>(
                        info.wdQuestionBankList,
                        turnsType
                    )
//                if (bankList.size > 6) {
//                    val selectList = arrayListOf<QuestionPaperInfoEntity>()
//                    for ((index, bankInfo) in bankList.withIndex()) {
//                        if (index < 6) {
//                            selectList.add(bankInfo)
//                        }
//                    }
//                    initBankRecycleView(selectList)
//                } else {
//                    initBankRecycleView(bankList)
//                }
                initBankRecycleView(bankList)
//                Log.v("yxy", "===刷新数呜呜呜呜呜据=" + info.wdQuestionBankList)
//                setQuestionBankView(info.wdQuestionBankList)
            }
        }

    }

    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout,
        firstView: PolyvPlayerPreviewView
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        firstView.hide()
        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)

        //视频不播放，先显示一张缩略图
        mediaController.hindMenuView()
        videoView.mediaController = mediaController
        videoView.setOnPreparedListener(IPolyvOnPreparedListener2 {
            mediaController.preparedView()
        })


//        videoView.aspectRatio = PolyvPlayerScreenRatio.AR_ASPECT_FIT_PARENT;
        //视频不播放，先显示一张缩略图

        firstView.setCallback(PolyvPlayerPreviewView.Callback { //在播放视频时设置viewerId方法使用示例
            videoView.setAutoPlay(true)
            videoView.setVid(vid)
        })

        firstView.show(vid)
        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }


    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        exam_answer_edt_solution.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = exam_answer_edt_solution.selectionStart
                editEnd = exam_answer_edt_solution.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(exam_answer_edt_solution.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                exam_answer_edt_solution.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(exam_answer_edt_solution.text.toString())
        currentCount = nowCount
        //
        exam_answer_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }


    private fun initWebView() {
        val webSettings: WebSettings = question_tv_analyze.getSettings()
        webSettings.javaScriptEnabled = true //允许使用js
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false
        question_tv_analyze.setWebViewClient(object : WebViewClient() {
            //覆盖shouldOverrideUrlLoading 方法
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

        })


    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }


    fun setIconFont(tv: TextView, content:String){
        val typeface: Typeface = Typeface.createFromAsset(
            assets,
            "fonts/iconfont.ttf"
        )
        tv.setTypeface(typeface)
        tv.text = content
    }


    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if(answerType != 2){
            return super.dispatchTouchEvent(ev)
        }
        when (ev?.action) {
            MotionEvent.ACTION_DOWN -> {
                mPosX = ev?.getX();
                mPosY = ev?.getY();
                mCurPosX = ev?.getX();
                mCurPosY = ev?.getY();
            }
            MotionEvent.ACTION_MOVE -> {
                mCurPosX = ev?.getX();
                mCurPosY = ev?.getY();
            }
            MotionEvent.ACTION_UP -> {
                var Y = mCurPosY - mPosY;
                var X = mCurPosX - mPosX;
                if (mPosY < ConvertUtils.dp2px(180f) || mPosY > (PolyvScreenUtils.getNormalWH(this)[1] -  ConvertUtils.dp2px(50f))){
                    return super.dispatchTouchEvent(ev)
                }

                if (Math.abs(Y) > Math.abs(X)) {
//                            if (Y > 0) {
//                                slideDown();
//                            } else {
//                                slideUp();
//                            }
                } else {
                    if (X < -20) {
                        if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                            saveAnswer()
                        }
                        nextQuestion()
                    } else if (X > 20) {
                        if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                            saveAnswer()
                        }
                        mDatabind?.click?.upQuestionClick()
                    }
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun setTextSize(){
        exam_answer_index.textSize = 13 + Constants.questionTextSize
        exam_answer_type.textSize  = 13 + Constants.questionTextSize
        exam_answer_title.textSize  = 15 + Constants.questionTextSize
        exam_answer_sub_index.textSize  = 17 + Constants.questionTextSize
        exam_answer_stem.textSize  = 15 + Constants.questionTextSize
        exam_answer_text_num.textSize  = 12 + Constants.questionTextSize
        tv_nyd.textSize  = 13 + Constants.questionTextSize
        exam_answer_label.textSize  = 13 + Constants.questionTextSize
        exam_answer_result.textSize  = 12 + Constants.questionTextSize
        exam_answer_right_label.textSize  = 13 + Constants.questionTextSize
        exam_answer_right_result.textSize  = 13 + Constants.questionTextSize
        exam_answer_my_label.textSize  = 13 + Constants.questionTextSize
        exam_answer_error_result.textSize  = 13 + Constants.questionTextSize
        exam_answer_tv_statistics.textSize  = 13 + Constants.questionTextSize
        exam_answer_tv_juyifansan_count.textSize  = 14 + Constants.questionTextSize
        exam_answer_test.textSize  = 16 + Constants.questionTextSize
        exam_answer_card.textSize  = 12 + Constants.questionTextSize
        exam_answer_fav.textSize  = 12 + Constants.questionTextSize
        exam_answer_note.textSize  = 13 + Constants.questionTextSize
        exam_recovery_error.textSize  = 13 + Constants.questionTextSize
        exam_answer_settings.textSize  = 13 + Constants.questionTextSize
        exam_answer_up.textSize  = 16 + Constants.questionTextSize
        exam_answer_submit_next.textSize  = 16 + Constants.questionTextSize
        mutOperationAdapter.notifyDataSetChanged()
        singleOperationAdapter.notifyDataSetChanged()
    }

    private fun updateIcon(){
        if (MultiTheme.getAppTheme() == 1) {
            exam_answer_settings.iconNormal = getDrawable(R.mipmap.ic_bottom_settings_dark)
            exam_answer_note.iconNormal = getDrawable(R.mipmap.ic_question_answer_note_dark)
            exam_answer_card.iconNormal = getDrawable(R.mipmap.ic_question_card_dark)
            if (exam_answer_fav.text.equals("收藏")) {
                exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
            }
        }else{
            exam_answer_settings.iconNormal = getDrawable(R.mipmap.ic_bottom_settings)
            exam_answer_note.iconNormal = getDrawable(R.mipmap.ic_question_answer_note)
            exam_answer_card.iconNormal = getDrawable(R.mipmap.ic_question_card)
            if (exam_answer_fav.text.equals("收藏")) {
                exam_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
            }
        }
    }

    private fun updateAnswerBg(){
        if (MultiTheme.getAppTheme() != 1){
            if (exam_answer_result.text.contains("回答错误")) {
                ll_exam_answer_bg.background =
                    resources.getDrawable(R.drawable.shape_bg_answer_error)
            }else if (exam_answer_result.text.contains("回答正确")) {
                ll_exam_answer_bg.background =
                    resources.getDrawable(R.drawable.shape_bg_answer_right)
            }
        }
    }


}