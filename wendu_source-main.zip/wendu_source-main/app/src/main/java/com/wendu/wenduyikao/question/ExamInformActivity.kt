package com.wendu.wenduyikao.question

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.collection.arrayMapOf
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.LoginEvent
import com.wendu.wenduyikao.data.eventbus.UpdateDailyPracticeEvent
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.data.model.bean.ShareEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivityExamInformBinding
import com.wendu.wenduyikao.dialog.ShareImgDialog
import com.wendu.wenduyikao.dialog.ShareImgPreviewDialog
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.QuestionCardDbAdapter
import com.wendu.wenduyikao.question.adapter.QuestionPaperResultAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestQuestionViewModel
import kotlinx.android.synthetic.main.activity_exam_inform.*
import me.xiaoyang.base.ext.parseState
import me.xiaoyang.base.ext.util.setOnclickNoRepeat
import org.greenrobot.eventbus.EventBus
import org.litepal.LitePal
import java.math.BigDecimal
import java.math.BigDecimal.ROUND_HALF_DOWN

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/11/21 4:05 PM
 * @Description: 考试报告
 */
class ExamInformActivity :
    BaseActivity<RequestQuestionViewModel, ActivityExamInformBinding>() {
    private val requestViewModel: RequestQuestionViewModel by viewModels()
    private var dataId = ""
    private var total = 0
    private var type = Constants.PARAMS_QUESTION_LOAD_TYPE_CHAPTER   //chapter 练习   chapter 试卷
    private var templateId = ""
    override fun layoutId() = R.layout.activity_exam_inform
    private var mData: List<QuestionResultEntity> = arrayListOf()
    private var from = ""
    private var classId = ""
    private var appraisalId = ""
    private var useTime = 0L
//    private  var loadFrom=0 //正常进入  1//精品题库举一反三
    var shareDialog: BaseBottomSheetDialog? = null
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setDarkMode(this)
        StatusBarUtil.setPaddingSmart(this, exam_inform_ll_content)
        if (MultiTheme.getAppTheme() == 1){
            StatusBarUtil.setColor(this, Color.parseColor("#0E0E10"))
        }else{
            StatusBarUtil.setColor(this, Color.parseColor("#4C87FF"))
        }
        exam_inform_toolbar_title.text = "答题报告"
        exam_inform_img_back.setOnClickListener {
            EventBus.getDefault().post(UpdateDailyPracticeEvent())
            finish() }
        type = intent.getIntExtra("type", 1)
        from = intent.getStringExtra("from").toString()
        useTime = intent.getLongExtra("useTime", 0)
        templateId = intent.getStringExtra("templateId") ?: ""
        if (type == Constants.PARAMS_QUESTION_LOAD_TYPE_CHAPTER) {
            templateId = intent.getStringExtra("templateId").toString()
            dataId = intent.getStringExtra(Constants.PARAMS_QUESTION_CHAPTER_ID).toString()
            initRecycleView()
        } else {
            dataId = intent.getStringExtra("paperId").toString()
            if (from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER) {
                val paperType = intent.getStringExtra("paperType")
                Log.v("yxy", "===papperTtyper=" + paperType);
                if (paperType == "4") {
                    requestViewModel.getQuestionPaperSubject2List(dataId)
                } else {
                    requestViewModel.getQuestionPaperSubjectList(dataId)
                }

            } else {
                initPaperRecycleView()
            }
        }
        if (from == Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE || type == Constants.PARAMS_QUESTION_LOAD_TYPE_CHAPTER) {
            exam_inform_rl_score.visibility = View.INVISIBLE
        } else {
            exam_inform_rl_score.visibility = View.VISIBLE
        }


        if (intent.getIntExtra(Constants.PARAMS_QUESTION_ERROR,0) == 1){
            exam_inform_rl_score.visibility = View.INVISIBLE
        }


//                || from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER
        if (from == Constants.PARAMS_QUESTION_SOURCE_REAL || from == Constants.PARAMS_QUESTION_SOURCE_MOCK || from == "mock_produce") {

        } else {
            val json = JsonObject()
            json.addProperty("paperId", dataId)
            json.addProperty("type", type)
            if (type == 3) {
                classId = intent.getStringExtra(Constants.PARAMS_QUESTION_CLASS_ID).toString()
                appraisalId = intent.getStringExtra("appraisalId").toString()
                json.addProperty("classesId", classId)
                json.addProperty("appraisalId", appraisalId)
            }

            if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER || from == Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE) {
                json.addProperty("templateId", templateId)
            }
            requestViewModel.submitPaperResult(json)
        }

        if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR || from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {

        } else {
            val map = arrayMapOf<String, String>()
            if (type == 3) {
                classId = intent.getStringExtra(Constants.PARAMS_QUESTION_CLASS_ID).toString()
                appraisalId = intent.getStringExtra("appraisalId").toString()
                map.put("appraisalId", appraisalId)
                map.put("classesId", classId)
            }
            if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER || from == Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE) {
                map.put("templateId", templateId)
            }
            map.put("paperId", dataId)
            map.put("type", type.toString())
            requestViewModel.getExamScore(map)
        }

        if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR || from == Constants.PARAMS_QUESTION_SOURCE_ERROR
            || from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER || from == "mock_produce" || type == 3
        ) {
            exam_inform_retry.visibility = View.GONE
        } else {
            exam_inform_retry.visibility = View.VISIBLE
        }
        var url = ""
        if (type == Constants.PARAMS_QUESTION_LOAD_TYPE_CHAPTER) {
            url =
                BuildConfig.BASE_URL + "/api/share/wdWeixinShare/getShareImg?chapterId=" + dataId + "&templateId=" + templateId + "&subjectType=" + type + "&pageSource=questionDetail&token=" + CacheUtil.getToken()
        } else {
            url =
                BuildConfig.BASE_URL + "/api/share/wdWeixinShare/getShareImg?paperId=" + dataId + "&subjectType=" + type + "&templateId=" + templateId+ "&pageSource=questionDetail&token=" + CacheUtil.getToken()

        }
        if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR || from == Constants.PARAMS_QUESTION_SOURCE_ERROR
            || from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER
        ) {
            img_exam_share.visibility = View.GONE
        } else {
            img_exam_share.visibility = View.VISIBLE
        }


        img_exam_share.setOnClickListener {
            val sharePreviewDialog = ShareImgPreviewDialog.newBuilder(this,
                url,
                object : ShareImgPreviewDialog.OnSubmitClickListener {
                    override fun onSubmitClick() {
                        if (shareDialog != null) {
                            shareDialog!!.dismiss()
                            shareDialog = null
                        }
                        val shareEntity = ShareEntity("", "", url, "")
                        shareDialog =
                            ShareImgDialog.newBuilder(this@ExamInformActivity, shareEntity, null)
                        shareDialog!!.show()
                    }
                })
            sharePreviewDialog.show()

        }
    }

    // 除法运算
    fun div(d1: Double, d2: Double): Double =
        BigDecimal(d1).divide(BigDecimal(d2)).setScale(2, BigDecimal.ROUND_DOWN).toDouble()

    private fun initRecycleView() {
        var rightNum = 0
        var errorNum = 0
        var noAnswer = 0
        val list = LitePal.findAll(QuestionDbEntity::class.java)
        val total = LitePal.count(QuestionDbEntity::class.java)
        var scoreTotal = 0.0
        for (info in list) {
            if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                    info.wdQuestionChapterPractice,
                    WdQuestionChapterPracticeEntity::class.java
                )
                if (practice != null) {
                    if (practice.isRight == "0") {
                        rightNum += 1
                        scoreTotal += info.score;
                    } else {
                        errorNum += 1
                    }
                } else {
                    noAnswer += 1
                }
            } else {
                noAnswer += 1
            }
        }
        var proportion = BigDecimal(0)
        if (total > 0) {
            proportion = BigDecimal(rightNum).divide(BigDecimal(total), 2, ROUND_HALF_DOWN);
        }

        Log.v("yxy", "==proportion==>" + proportion + "======" + rightNum + "===" + total + "==")
        arc_progress.progress = proportion.toFloat() * 100
        exam_info_percent.text = (proportion.toFloat() * 100).toInt().toString()
        "答对$rightNum 题 答错$errorNum 题 未答$noAnswer 题".also { exam_inform_result_num.text = it }
        exam_inform_rlv_question.layoutManager = GridLayoutManager(this, 6)
//        val list = CacheUtil.getQuestionSubject();
        mData = BaseCode.getQuestionCardData2()
        val questionCardDbAdapter =
            QuestionCardDbAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        questionCardDbAdapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val question: QuestionDbEntity =
                    mySection.getObject() as QuestionDbEntity
                dataId = question.questionId
                startActivity(
                    Intent(this, QuestionAnswerActivity::class.java)
                        .putExtra("chapterId", question.chapterId)
                        .putExtra("templateId", question.templateId)
                        .putExtra("total", total)
                        .putExtra("index", question.position)
                        .putExtra("from", Constants.PARAMS_QUESTION_RESULT)
                )
            }
        })

        exam_inform_rlv_question.adapter = questionCardDbAdapter
    }

    private fun initPaperRecycleView() {
        var rightNum = 0
        var errorNum = 0
        var noAnswer = 0
        var totalScore: Double = 0.0
        val list = LitePal.findAll(QuestionPaperDbEntity::class.java)
        val total = LitePal.count(QuestionPaperDbEntity::class.java)
        for (info in list) {
            if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                    info.wdQuestionChapterPractice,
                    WdQuestionChapterPracticeEntity::class.java
                )
                if (practice != null) {
                    if (practice.isRight == "0") {
                        rightNum += 1
                        totalScore += info.score;

                    } else {
                        errorNum += 1
                    }
                } else {
                    noAnswer += 1
                }
            } else {
                noAnswer += 1
            }
        }
        if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR || from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {
            "答对$rightNum 题 答错$errorNum 题 未答$noAnswer 题".also { exam_inform_result_num.text = it }
            val proportion = BigDecimal(rightNum).divide(BigDecimal(total), 2, ROUND_HALF_DOWN);
            Log.v(
                "yxy",
                "==proportion==>" + proportion + "======" + rightNum + "===" + total + "=="
            )
            exam_info_percent.text = (proportion.toFloat() * 100).toInt().toString()
            exam_inform_result_score.text = "${totalScore} 分"
        }
        exam_inform_rlv_question.setLayoutManager(GridLayoutManager(this, 6))
        mData = BaseCode.getQuestionPaperCardData2()

        val count = LitePal.count(QuestionPaperDbEntity::class.java)
        val adapter =
            QuestionPaperResultAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val loadFrom = intent.getIntExtra("loadFrom", 0)
                var headerCount = 0
                for (i in 0 until position) {
                    if (mData.get(i).isHeader) {
                        headerCount++;
                    }
                }
                startActivity(
                    Intent(this@ExamInformActivity, ExamAnswerActivity::class.java)
                        .putExtra("paperId", dataId)
                        .putExtra("total", 0)
                        .putExtra("index", position - headerCount + 1)
                        .putExtra("type", type)
                        .putExtra("loadFrom", loadFrom)
                        .putExtra("templateId", templateId)
                        .putExtra("isDo", false)
                        .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_RESOLVE)
                )


            }
        })

        exam_inform_rlv_question.adapter = adapter
    }


    override fun createObserver() {
        requestViewModel.questionPaperListResult.observe(this, Observer {
            if (it.isSuccess) {
                CacheUtil.setQuestionPaperSubject(it.listData)
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                var position = 0
                var questionIndex = 0
                var total = 0
                for (info in it.listData) {
                    for (quest in info.list) {
                        total += 1
                    }
                }
                for (info in it.listData) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.answer = sub.answer
                                    questionDb.total = total
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.paperType = sub.paperType
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText = sub.answerText
                                    questionDb.questionId = sub.id
                                    questionDb.parentId = quest.id
                                    questionDb.stem = quest.stem
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (sub.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(sub.wdQuestionPaperData)
                                    }
                                    if (sub.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)

                                    }
                                    if (sub.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(sub.wdQuestionChapterPractice)

                                    }
                                    questionDb.save()
                                }

                            }
                            else -> {
                                questionIndex += 1
                                position += 1

                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText=quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.total = total
                                questionDb.parentId = quest.id
                                questionDb.paperType = quest.paperType
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.stem = quest.stem
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)

                                }
                                if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)

                                }
                                questionDb.save()
                            }
                        }
                    }
                }
                initPaperRecycleView()
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.paperListResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                var position = 0
                var questionIndex = 0
                LitePal.deleteAll(QuestionPaperDbEntity::class.java)

                var total = 0
                for (info in it.list) {
                    for (quest in info.list) {
                        total += 1
                    }
                }

                for (info in it.list) {
                    for (quest in info.list) {
                        when (quest.liftingType) {
                            3, 4, 7, 8 -> {
                                var subIndex = 0
                                questionIndex += 1
                                for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                    position += 1
                                    subIndex += 1
                                    Log.v(
                                        "yxy",
                                        "==duoxuan==>" + questionIndex + "===" + position + "==subIndex=" + subIndex
                                    )
                                    val questionDb = QuestionPaperDbEntity()
                                    questionDb.paperId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.templateId = quest.templateId
                                    questionDb.parentId = quest.id
                                    questionDb.answer = sub.answerTxt
                                    questionDb.answerText=sub.answerText
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.answer = sub.answer
                                    questionDb.total = total
                                    questionDb.facilityValue = sub.facilityValue
                                    questionDb.paperType = sub.paperType
                                    questionDb.questionId = sub.id
                                    questionDb.stem = quest.stem
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.questionIndex = questionIndex
                                    questionDb.index = "$questionIndex-$subIndex"
                                    questionDb.childStem = sub.stem
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)

                                    if (sub.wdQuestionPaperData != null) {
                                        questionDb.wdQuestionPaperData =
                                            GsonUtils.toJson(sub.wdQuestionPaperData)
                                    }
                                    if (sub.wdQuestionPaperDataVideo != null) {
                                        questionDb.wdQuestionPaperDataVideo =
                                            GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                    }
                                    if (sub.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                    }
                                    questionDb.childIndex =
                                        "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                    questionDb.position = position
                                    if (sub.wdQuestionPaperOption != null) {
                                        questionDb.wdQuestionPaperOption =
                                            GsonUtils.toJson(sub.wdQuestionPaperOption)

                                    }

                                    questionDb.save()

                                }

                            }
                            else -> {
                                questionIndex += 1
                                position += 1
                                val questionDb = QuestionPaperDbEntity()
                                questionDb.answer = quest.answerTxt
                                questionDb.answerText=quest.answerText
                                questionDb.paperId = quest.paperId
                                questionDb.parentId = quest.id
                                questionDb.liftingType = quest.liftingType
                                questionDb.isCollect = quest.isCollect
                                questionDb.total = total
                                questionDb.paperType = quest.paperType
                                if (StringUtil.isNotBlank(quest.isCollectId)) {
                                    questionDb.isCollectId = quest.isCollectId
                                }
                                questionDb.facilityValue = quest.facilityValue
                                questionDb.stem = quest.stem
                                questionDb.templateId = quest.templateId
                                questionDb.questionId = quest.id
                                questionDb.position = position
                                questionDb.questionIndex = questionIndex
                                if (quest.liftingType == 5) {
                                    questionDb.topicCategory = quest.topicCategory
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                } else {
                                    questionDb.typeLabel =
                                        StringUtil.getSubjectTypeByType(quest.liftingType)
                                }

                                questionDb.index = questionIndex.toString()
                                if (quest.wdQuestionPaperData != null) {
                                    questionDb.wdQuestionPaperData =
                                        GsonUtils.toJson(quest.wdQuestionPaperData)
                                }
                                if (quest.wdQuestionPaperDataVideo != null) {
                                    questionDb.wdQuestionPaperDataVideo =
                                        GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                }
                                if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                }
                                if (quest.wdQuestionPaperOption != null) {
                                    questionDb.wdQuestionPaperOption =
                                        GsonUtils.toJson(quest.wdQuestionPaperOption)

                                }

                                questionDb.save()

                            }
                        }
                    }
                }
                initPaperRecycleView()
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })

        requestViewModel.paperSubmitResult.observe(this, Observer { resultState ->
            parseState(resultState, {

                if (type == 1 || type == 2 || type == 3) {
                    val score = it.successScore
                    exam_inform_result_score.text = "$score 分"
                    exam_info_percent.text = it.proportion.toDouble().toInt().toString()
                    "答对${it.successCount} 题 答错${it.doCount - it.successCount} 题 未答${it.countAll - it.doCount} 题".also {
                        exam_inform_result_num.text = it
                    }
                }
            })
        })
        requestViewModel.examScoreResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    val score = it.successScore
                    exam_inform_result_score.text = "$score 分"
                    exam_info_percent.text = it.proportion.toDouble().toInt().toString()
                    "答对${it.successCount} 题 答错${it.doCount - it.successCount} 题 未答${it.countAll - it.doCount} 题".also {
                        exam_inform_result_num.text = it
                    }
                }
            })
        })

        requestViewModel.questionAgainResult.observe(this, Observer {
            if (it.success) {
                EventBus.getDefault().post(UpdateDailyPracticeEvent())
                when (from) {
                    Constants.PARAMS_QUESTION_SOURCE_CHAPTER -> {
                        startActivity(
                            Intent(this@ExamInformActivity, QuestionAnswerActivity::class.java)
                                .putExtra(Constants.PARAMS_QUESTION_CHAPTER_ID, dataId)
                                .putExtra(Constants.PARAMS_QUESTION_TEMPLATE_ID, templateId)
                                .putExtra("total", CacheUtil.getQuestionList().size)
                                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_CHAPTER)
                        )
                    }
//                    Constants.PARAMS_QUESTION_SOURCE_REAL,
                    Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE -> {
                        val loadFrom = intent.getIntExtra("loadFrom", 0)
                        startActivity(
                            Intent(this@ExamInformActivity, ExamAnswerActivity::class.java)
                                .putExtra("paperId", dataId)
                                .putExtra("total", 0)
                                .putExtra("index", 0)
                                .putExtra("type", type)
                                .putExtra("loadFrom", loadFrom)
                                .putExtra("templateId", templateId)
                                .putExtra("isDo", false)
                                .putExtra("from", from)
                        )
                        Log.v("yxy","=from==="+from)
                    }
                    else -> {
                        val intent = Intent(this@ExamInformActivity, Exam2Activity::class.java)
                        intent.putExtra("paperId", dataId)
                        intent.putExtra("total", 0)
                        intent.putExtra("index", 0)
                        intent.putExtra("type", type)
                        intent.putExtra("useTime", useTime)
                        intent.putExtra("from", from)
                        if (type == 3) {
                            intent.putExtra(Constants.PARAMS_QUESTION_CLASS_ID, classId)
                            intent.putExtra("appraisalId", appraisalId)
                        }
                        startActivity(intent)
                    }
                }
                finish()
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }


    override fun onViewClicked() {
        setOnclickNoRepeat(exam_inform_retry, exam_inform_resolve) {
            when (it.id) {
                R.id.exam_inform_retry -> {
                    val json = JsonObject()
                    json.addProperty("type", type)
                    json.addProperty("paperId", dataId)
                    if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER || from == Constants.PARAMS_QUESTION_SOURCE_BOUTIQUE) {
                        json.addProperty("templateId", templateId)
                    }
                    if (from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER) {
                        json.addProperty("classesId", classId)
                        json.addProperty("appraisalId", appraisalId)
                    }
                    requestViewModel.questionAgain(json)
                }
                R.id.exam_inform_resolve -> {
                    if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER) {
                        startActivity(
                            Intent(this@ExamInformActivity, QuestionAnswerActivity::class.java)
                                .putExtra(Constants.PARAMS_QUESTION_CHAPTER_ID, dataId)
                                .putExtra(Constants.PARAMS_QUESTION_TEMPLATE_ID, templateId)
                                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_RESOLVE)
                        )
//                        finish()
                    } else if (from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {
                        startActivity(
                            Intent(this@ExamInformActivity, QuestionAnswerActivity::class.java)
                                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_RESOLVE)
                                .putExtra("type", type)
                                .putExtra("errorfrom", 1)
                        )
                        //finish()
                    } else {
                        val loadFrom = intent.getIntExtra("loadFrom", 0)
                        //if (from == Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR || from == Constants.PARAMS_QUESTION_SOURCE_STUDY_PAPER)
                        startActivity(
                            Intent(this@ExamInformActivity, ExamAnswerActivity::class.java)
                                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_RESOLVE)
                                .putExtra("type", type)
                                .putExtra("loadFrom", loadFrom)
                                .putExtra("historyFrom", from)
                                .putExtra("errorfrom", 1)
                        )
                        //finish()
                    }


                }
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        EventBus.getDefault().post(UpdateDailyPracticeEvent())
    }

    override fun onResume() {
        super.onResume()
        MultiTheme.setAppTheme(MultiTheme.getAppTheme())
        exam_inform_rlv_question.adapter?.notifyDataSetChanged()
    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }

}