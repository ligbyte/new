package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RelativeLayout
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.afollestad.materialdialogs.WhichButton
import com.afollestad.materialdialogs.actions.getActionButton
import com.afollestad.materialdialogs.lifecycle.lifecycleOwner
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.SPUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.player.PolyvPlayerPreviewView
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.easefun.polyvsdk.video.listener.IPolyvOnPreparedListener2
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.network.ApiService
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.RefreshQuestionBankEvent
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivityLearnByAnalogyBinding
import com.wendu.wenduyikao.dialog.CustomAlertDialog
import com.wendu.wenduyikao.dialog.LearnAnalogyMessageDialog
import com.wendu.wenduyikao.dialog.RecoveryErrorDialog
import com.wendu.wenduyikao.dialog.base.BaseDialog
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.question.adapter.LearnOperationAdapter
import com.wendu.wenduyikao.question.adapter.LearnResolveOperationAdapter
import com.wendu.wenduyikao.question.adapter.QuestionBankAnswerAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestExamViewModel
import kotlinx.android.synthetic.main.activity_learn_by_analogy.*
import kotlinx.android.synthetic.main.activity_learn_by_analogy.img_back
import kotlinx.android.synthetic.main.activity_learn_by_analogy.queston_answer_rl_result
import kotlinx.android.synthetic.main.activity_question_answer.*
import org.greenrobot.eventbus.EventBus
import org.litepal.LitePal

/**
 * @Author     : xiaoyangyan
 * @Time       : 2022/5/27 15:25
 * @Description: 举一反三
 */
class LearnByAnalogyActivity : BaseActivity<RequestExamViewModel, ActivityLearnByAnalogyBinding>() {

    private val requestViewModel: RequestExamViewModel by viewModels()
    private var bankJson = ""
    private var questionList = arrayListOf<QuestionPaperInfoEntity>()
    private var index = 0
    private var paperId = "" //id
    private var optionId = ""  //选项id
    private var id = ""
    private var subjectId = ""//题干id
    private var parentId = ""//题干id
    private var goNext = true //多选逻辑，需要做次校验
    private var isSeeAll = true//查看全部
    private var answerType = 1   //1 答题，2背题 3 解析模式
    private var type = 1   //类型 1章节练习(章节练习) 2 试卷管理(历年真题,精品题库) 3评测试卷 4模拟试卷 5经典试卷
    private var totalNum = 0  //题目总数
    private var liftingType = 1  //当前题目类型
    private var isRight = 0// 是否回答正确  默认正确
    lateinit var dialog: MaterialDialog
    private var solution = "" //主观题答案
    private var from = Constants.PARAMS_QUESTION_SOURCE_CHAPTER
    private val maxLen = 100 // the max byte
    private var isCheckResult = false  //多选是否选择完毕
    private var editStart = 0
    private var editEnd = 0
    private var errorList = arrayListOf<QuestionPaperDbEntity>()
    private var selectOptions = arrayListOf<QuestionOptionEntity>()
    private var isMultiple = false; //共用题干类型下是否为多选
    private var loadFrom = 0 //0 默认正常渠道进入   1，为精品题库=章节类型-举一反三数据
    private var questionInfo = QuestionPaperDbEntity()
    private var js = "<script type=\"text/javascript\">" +
            "var imgs = document.getElementsByTagName('img');" +  // 找到img标签
            "for(var i = 0; i<imgs.length; i++){" +  // 逐个改变
            "imgs[i].style.width = '100%';" +  // 宽度改为100%
            "imgs[i].style.height = 'auto';" +
            "}" +
            "</script>"
    var questionSettingsDialog: BaseBottomSheetDialog? = null
    //适配器
    private var mutOperationAdapter: LearnResolveOperationAdapter =
        LearnResolveOperationAdapter(
            arrayListOf()
        )
    private var bankAdapter: QuestionBankAnswerAdapter =
        QuestionBankAnswerAdapter(
            arrayListOf()
        )
    private var singleOperationAdapter: LearnOperationAdapter = LearnOperationAdapter(
        arrayListOf()
    )

    override fun layoutId() = R.layout.activity_learn_by_analogy

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, learn_by_analogy_ll_content)
        tv_toolbar_title.text = "举一反三"
        bankJson = intent.getStringExtra("bankList") ?: ""
        index = intent.getIntExtra("index", 0)
        from = intent.getStringExtra("from") ?: ""
        val questionInfoJson = intent.getStringExtra("data")
        Constants.questionTextSize = (SPUtils.getInstance().getFloat("fontSize",50f) - 50)/100 * 4 *2
        Log.v("yxy","=bankListJson111="+bankJson)
        Log.v("yxy","=data=1111+"+questionInfoJson)
        if (StringUtil.isNotBlank(questionInfoJson)) {
            questionInfo = GsonUtils.fromJson<QuestionPaperDbEntity>(
                questionInfoJson,
                QuestionPaperDbEntity::class.java
            )
        }
        if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
            answerType = 3
        } else {
            answerType = 1
        }
        initWebView()
        setQuestionBankView(bankJson);
        mDatabind.click = ProxyClick()
        img_back.setOnClickListener {
            var isFinish = false
            val unDoList = arrayListOf<QuestionPaperInfoEntity>()
            for (info in questionList) {
                if (info.wdQuestionChapterPractice == null) {
                    unDoList.add(info)
                }
            }
            isFinish = unDoList.size == 0

            Log.v("yxy", "=isFinish==" + isFinish + "===" + unDoList.size)
            if (!isFinish && from != Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
//                MaterialDialog(this).show {
//                    cancelable(false)
//                    lifecycleOwner(this@LearnByAnalogyActivity)
//                    title(text = "您还有子题未做确定要进入下一题吗？")
//
//                    positiveButton(R.string.confirm, "确定") {
//                        dismiss()
//                    }
//                    negativeButton(R.string.cancel, "继续做题") {
//                        finish()
//                    }
//                    getActionButton(WhichButton.POSITIVE).updateTextColor(
//                        Color.parseColor("#0077FF")
//                    )
//                    getActionButton(WhichButton.NEGATIVE).updateTextColor(
//                        Color.parseColor("#FA642D")
//                    )
//                }


//                val messageDialog = LearnAnalogyMessageDialog.Builder(this)
//                    .setTitle("提示")
//                    .setCancel("确定")
//                    .setConfirm("继续做题")
//                    .setMessage("您还有子题未做确定要进入下一题吗？")
//                    .setListener(object : LearnAnalogyMessageDialog.OnListener {
//                        override fun onConfirm(dialog: BaseDialog) {
//                            dialog.dismiss()
//
//                        }
//
//                        override fun onCancel(dialog: BaseDialog) {
//                            dialog.dismiss()
//                            finish()
//                        }
//                    })
//                messageDialog!!.show()


                val customAlertDialog = CustomAlertDialog(this, "提示", "您还有子题未做确定要进入下一题吗？","确定","继续做题")
                customAlertDialog.setEditTextDialogListener(object :
                    CustomAlertDialog.EditTextDialogListener {
                    override fun onCancle() {
                        finish()

                    }
                    override fun onOk(content: String) {
                        customAlertDialog.dismiss()
                    }
                })
                customAlertDialog.show()

            } else {
                finish()
            }

        }
        editTextMaxLengthListener()
    }

    override fun createObserver() {
        requestViewModel.errorCorrectionResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("提交成功")
                questionSettingsDialog?.dismiss()
            }
        })

    }


    /**
     * 设置举一反三数据
     */
    private fun setQuestionBankView(bankListJSon: String) {
        if (StringUtil.isNotBlank(bankListJSon)) {
            val turnsType = CacheUtil.genericType<ArrayList<QuestionPaperInfoEntity>>()
            val bankList =
                Gson().fromJson<ArrayList<QuestionPaperInfoEntity>>(
                    bankListJSon,
                    turnsType
                )
            questionList = bankList
            totalNum = bankList.size
            setQuestionView(questionList[index])

            initBankRecycleView(bankList)
        } else {
            learn_by_analogy_juyifansan.visibility = View.GONE
        }

    }

    /**
     * 更新问题布局及数据
     * @param info QuestionPaperInfoEntity
     */
    private fun setQuestionView(info: QuestionPaperInfoEntity) {
        subjectId = info.id
        selectOptions = arrayListOf()
        optionId = ""
        isRight = 0
        isCheckResult = false
        goNext = true
        learn_by_analogy_edt_solution.setText("")
        learn_by_analogy_data_media_controller.resume();
        learn_by_analogy_select_media_controller.resume();
        learn_by_analogy_data_video_view.onActivityStop();
        learn_by_analogy_select_video_view.onActivityStop();
        if (StringUtil.isNotBlank(info.paperId)) {
            parentId = info.parentId
        }

        if (info.facilityValue > 0) {
            StringUtil.setLevel(info.facilityValue, learn_by_analogy_img_level)
        }

        liftingType = info.liftingType
        changeViewByType(info.liftingType)
        learn_by_analogy_title.text = info.title
        parentId = info.parentId
//        learn_by_analogy_tv_analyze.text = info.answer


//        if(StringUtil.isNotBlank(info.answerTxt)){
//            learn_by_analogy_tv_analyze.visibility=View.VISIBLE
//            learn_by_analogy_tv_analyze.loadDataWithBaseURL(
//                null,
//                info.answerTxt+js, "text/html; charset=UTF-8", null, null
//            );
//        }else{
//            learn_by_analogy_tv_analyze.visibility=View.GONE
//        }
        val url =
            ApiService.WEB_SERVER_URL + "/zixun/subjectAnswer.html?subjectId=" + info.id + "&type=" + 0
        learn_by_analogy_tv_analyze.loadUrl(url);

        learn_by_analogy_tv_statistics.text = info.answerText

        if (liftingType != 5) {
            learn_by_analogy_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            learn_by_analogy_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }
        val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
        learn_by_analogy_data_view_layout.visibility = View.GONE
        learn_by_analogy_data_img.visibility = View.GONE
        val dataList = info.wdQuestionPaperData
        if (dataList.size > 0) {
            if (dataList[0].materialType == "2") {
                learn_by_analogy_data_view_layout.visibility = View.VISIBLE
                play(
                    dataList[0].videoUrl,
                    learn_by_analogy_data_media_controller,
                    learn_by_analogy_data_video_view,
                    learn_by_analogy_data_view_layout,
                    learn_by_analogy_data_first_start_view
                );
            } else {
                learn_by_analogy_data_view_layout.visibility = View.GONE
                if (StringUtil.isNotBlank(dataList[0].imageUrl)) {
                    learn_by_analogy_data_img.visibility = View.VISIBLE
                    Glide.with(this).load(dataList[0].imageUrl).apply(operation)
                        .into(learn_by_analogy_data_img)
                }
            }
        }

        val dataVideoList = info.wdQuestionPaperDataVideo
        if (dataVideoList.size > 0) {
            if (dataVideoList[0].materialType == "2") {
                learn_by_analogy_select_view_layout.visibility = View.GONE
                play(
                    dataVideoList[0].videoUrl,
                    learn_by_analogy_select_media_controller,
                    learn_by_analogy_select_video_view,
                    learn_by_analogy_select_view_layout,
                    learn_by_analogy_select_first_start_view
                );
            } else {
                learn_by_analogy_select_view_layout.visibility = View.GONE
            }
        }
        val optionList = info.wdQuestionPaperOption
        var mutSize = 0
        if (optionList != null) {
            for (ope in optionList) {
                if (ope.rightFlag == 0) {
                    mutSize += 1
                }
            }
        }

        isMultiple = mutSize > 1
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>${info.questionIndex}</font>/ ${info.total}  题";
        learn_by_analogy_index.text = Html.fromHtml(str);
        if (optionList != null) {
            learn_by_analogy_right_result.text = getRightResult(optionList)
        }
        val practice = info.wdQuestionChapterPractice
        Log.v(
            "yxy",
            "==practice=" + GsonUtils.toJson(info.wdQuestionChapterPractice) + "==" + answerType
        )
        if (practice != null) {
            queston_answer_rl_result.visibility = View.VISIBLE
            if (practice.isRight == "0") {
                learn_by_analogy_result.setText("回答正确")
                if (liftingType != 5) {
                    learn_by_analogy_ll_error.visibility = View.VISIBLE
                } else {
                    learn_by_analogy_ll_error.visibility = View.GONE
                }
                if (practice.wdQuestionPaperOption != null) {
                    learn_by_analogy_error_result.text =
                        getRightResult(practice.wdQuestionPaperOption)
                } else if (practice.chapterContentList != null) {
                    learn_by_analogy_error_result.text =
                        getRightResult(practice.chapterContentList)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    learn_by_analogy_result.setIconNormal(getDrawable(R.mipmap.icon_answer_right))
                }
            } else {
                learn_by_analogy_result.setText("回答错误")
                if (MultiTheme.getAppTheme() != 1){
                    ll_learn_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_error)
                }
                learn_by_analogy_ll_error.visibility = View.VISIBLE
                if (practice.wdQuestionPaperOption != null) {
                    learn_by_analogy_error_result.text =
                        getErrorResult(practice.wdQuestionPaperOption)
                } else if (practice.chapterContentList != null) {
                    learn_by_analogy_error_result.text =
                        getErrorResult(practice.chapterContentList)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    learn_by_analogy_result.setIconNormal(getDrawable(R.mipmap.icon_answer_error))
                }
            }
            answerType = 3
        } else {
            if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
                answerType = 3
                learn_by_analogy_ll_error.visibility = View.GONE
                queston_answer_rl_result.visibility = View.GONE
            } else {
                answerType = 1
            }

        }
        initQuestionView()
        when (liftingType) {
            1, 6 -> {
                learn_by_analogy_submit_next.text = "下一题"
                if (info.wdQuestionPaperOption != null) {
                    initOperationRecycleView(optionList, info)
                }
            }
            3 -> {
                learn_by_analogy_submit_next.text = "下一题"
                if (info.index != null) {
                    val ss = SpannableStringBuilder("问题" + info.index)
                    if (ss.length > 4) {
                        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                        ss.setSpan(
                            ForegroundColorSpan(Color.parseColor(colorIndex)),
                            2,
                            4,
                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                    }
                    learn_by_analogy_sub_index.text = ss
                }




                learn_by_analogy_stem.text = info.stem
                if (isMultiple) {
                    learn_by_analogy_submit_next.text = "确定"
                    if (info.wdQuestionPaperOption != null) {
                        initMutOperationRecycleView(optionList, info)
                    }
                } else {
                    learn_by_analogy_submit_next.text = "下一题"
                    if (info.wdQuestionPaperOption != null) {
                        initOperationRecycleView(optionList, info)
                    }
                }
            }
            2 -> {
                learn_by_analogy_submit_next.text = "确定"
                if (info.wdQuestionPaperOption != null) {
                    initMutOperationRecycleView(optionList, info)
                }
            }
            4, 7, 8 -> {
                learn_by_analogy_submit_next.text = "下一题"
                if (info.index != null) {
                    val ss = SpannableStringBuilder("问题" + info.index)
                    val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                    ss.setSpan(
                        ForegroundColorSpan(Color.parseColor(colorIndex)),
                        2,
                        4,
                        Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    learn_by_analogy_sub_index.setText(ss)
                }


                learn_by_analogy_stem.text = info.stem
                if (optionList != null) {
                    initOperationRecycleView(optionList, info)
                }
            }
            5 -> {
                learn_by_analogy_submit_next.text = "下一题"
                if (answerType == 1) {
                    learn_by_analogy_rl_result.visibility = View.VISIBLE
                } else {
                    if (practice != null) {
                        if (StringUtil.isNotBlank(practice.solution)) {
                            learn_by_analogy_rl_result.visibility = View.VISIBLE
                            learn_by_analogy_edt_solution.setText(practice.solution)
                        } else {
                            learn_by_analogy_rl_result.visibility = View.GONE
                        }
                    } else {
                        learn_by_analogy_rl_result.visibility = View.GONE

                    }
                }

            }
        }
    }

    override fun onStop() {
        super.onStop()
        learn_by_analogy_data_media_controller.pause();
        learn_by_analogy_select_media_controller.pause();
        learn_by_analogy_data_video_view.onActivityStop();
        learn_by_analogy_select_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        learn_by_analogy_data_video_view.destroy();
        learn_by_analogy_select_video_view.destroy();
        learn_by_analogy_data_media_controller.disable();
        learn_by_analogy_select_media_controller.disable();
    }

    /**
     * 根据类型更改本地问题布局
     * @param type Int
     */
    private fun changeViewByType(type: Int) {
        when (type) {
            1, 6 -> {
                //单项选择
                learn_by_analogy_rl_result.visibility = View.GONE
                learn_by_analogy_rlv_operation.visibility = View.VISIBLE
                learn_by_analogy_ll_stem.visibility = View.GONE
                learn_by_analogy_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    learn_by_analogy_resolve.visibility = View.GONE
                } else {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    queston_answer_rl_result.visibility = View.VISIBLE
                    learn_by_analogy_ll_error.visibility = View.VISIBLE
                    learn_by_analogy_resolve.visibility = View.VISIBLE
                }
            }
            2 -> {
                //多项选择
                learn_by_analogy_rlv_operation.visibility = View.VISIBLE
                learn_by_analogy_ll_stem.visibility = View.GONE
                learn_by_analogy_rl_result.visibility = View.GONE
                learn_by_analogy_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    learn_by_analogy_resolve.visibility = View.GONE
                } else {
                    queston_answer_rl_result.visibility = View.GONE
                    if (answerType == 2) {
                        queston_answer_rl_result.visibility = View.GONE
                        learn_by_analogy_ll_error.visibility = View.GONE
                    } else {
                        queston_answer_rl_result.visibility = View.VISIBLE
                        learn_by_analogy_ll_error.visibility = View.VISIBLE
                    }

                    learn_by_analogy_resolve.visibility = View.VISIBLE

                }
            }
            3, 4, 7, 8 -> {
                //共用题干
                learn_by_analogy_ll_stem.visibility = View.VISIBLE
                learn_by_analogy_rlv_operation.visibility = View.VISIBLE
                learn_by_analogy_rl_result.visibility = View.GONE
                learn_by_analogy_ll_right.visibility = View.VISIBLE
                if (answerType == 1) {
                    queston_answer_rl_result.visibility = View.VISIBLE
                    learn_by_analogy_resolve.visibility = View.GONE
                } else {
                    learn_by_analogy_resolve.visibility = View.VISIBLE
                    if (answerType == 2) {
                        queston_answer_rl_result.visibility = View.GONE
                        learn_by_analogy_ll_error.visibility = View.GONE
                    } else {
                        queston_answer_rl_result.visibility = View.VISIBLE
                        learn_by_analogy_ll_error.visibility = View.VISIBLE
                    }
                }
            }

            5 -> {
                //主观题
                learn_by_analogy_rlv_operation.visibility = View.GONE
                learn_by_analogy_ll_stem.visibility = View.GONE
                learn_by_analogy_ll_right.visibility = View.GONE
                learn_by_analogy_rl_result.visibility = View.VISIBLE
                if (answerType == 1) {
                    Log.v("yxy", "设置布局  解答题 ")
                    learn_by_analogy_resolve.visibility = View.GONE
                } else {
                    learn_by_analogy_resolve.visibility = View.VISIBLE
                    learn_by_analogy_ll_error.visibility = View.GONE
                }
            }
        }
    }

    private fun initOperationRecycleView(
        operationList: ArrayList<QuestionOptionEntity>,
        info: QuestionPaperInfoEntity
    ) {
        singleOperationAdapter = LearnOperationAdapter(operationList)
        singleOperationAdapter.setQuestionInfo(info)
        //初始化recyclerView
        learn_by_analogy_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        singleOperationAdapter.setAnswer(answerType)
        var isCheck = false
        singleOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheck && answerType == 1) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    optionId = info.id
                    setPosition(position)
                    selectOptions.add(info)
                    isRight = info.rightFlag
                    singleOperationAdapter.notifyDataSetChanged()
                    saveAnswer()
                    if (info.rightFlag == 1) {
                        learn_by_analogy_resolve.visibility = View.VISIBLE
                        val rightresult = getRightResult(operationList)
                        learn_by_analogy_right_result.text = rightresult
                        learn_by_analogy_error_result.text = info.selectValue
                    } else {
                        nextQuestion()
                    }
                }

                isCheck = true
                setIsCheck(isCheck)
                singleOperationAdapter.notifyDataSetChanged()
            }


        }
    }

    /**
     * 多选选项处理器
     */
    private fun initMutOperationRecycleView(
        operationList: ArrayList<QuestionOptionEntity>,
        info: QuestionPaperInfoEntity
    ) {
        mutOperationAdapter = LearnResolveOperationAdapter(operationList)
        mutOperationAdapter.setQuestionInfo(info)
        //初始化recyclerView
        learn_by_analogy_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        mutOperationAdapter.setAnswer(answerType)
        mutOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheckResult) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    setPosition(position)
                    mutOperationAdapter.notifyDataSetChanged()
                }
            }
        }
    }

    private fun initQuestionView() {
        if (answerType == 1) {
            learn_by_analogy_resolve.visibility = View.GONE
        } else if (answerType == 2) {
            learn_by_analogy_resolve.visibility = View.VISIBLE
        } else {
            learn_by_analogy_resolve.visibility = View.VISIBLE
        }
        Log.v("yxy", "===liftingType=answerType=" + liftingType + "====" + answerType)
        if (liftingType == 1 || liftingType == 4 || (liftingType == 3 && !isMultiple) || liftingType == 6 || liftingType == 7 || liftingType == 8) {
            singleOperationAdapter.setAnswer(answerType)
            singleOperationAdapter.notifyDataSetChanged()
        } else if (liftingType == 2 || (liftingType == 3 && isMultiple)) {
            mutOperationAdapter.setAnswer(answerType)
            mutOperationAdapter.notifyDataSetChanged()
        }
    }

    private fun saveAnswer() {
        if (index >= questionList.size) {
            return
        }
        val json = JsonObject()
        solution = ""
        Log.v("yxy", "==selectOptions==" + GsonUtils.toJson(selectOptions));

        val practice = WdQuestionChapterPracticeEntity()
        practice.type = type.toString()
        val question = questionList[index]
        if (question == null) {
            return
        }
        practice.subjectId = question.id
        Log.v("yxy", "==question= 详情=" + GsonUtils.toJson(question));

        when (liftingType) {
            //单选题型
            1, 6, 4, 7, 8 -> {
                practice.chapterContentList = selectOptions
                practice.isRight = isRight.toString()
                practice.optionId = optionId
                if (StringUtil.isNotBlank(optionId)) {
                    question.wdQuestionChapterPractice = practice
                    val parentList = LitePal.where("parentId =?", questionInfo.parentId)
                        .find(QuestionPaperDbEntity::class.java)
                    Log.v("yxy", "==子题答题母题数量==" + parentList.size)
                    if (parentList != null) {
                        for (info in parentList) {
                            info.wdQuestionBankList = GsonUtils.toJson(questionList)
                            info.save()
                        }

                    } else {
                        questionInfo.wdQuestionBankList = GsonUtils.toJson(questionList)
                        questionInfo.save()
                    }


                }
            }
            3 -> {
                if (isMultiple) {
                    Log.v("yxy", "==共用多选保存==" + GsonUtils.toJson(selectOptions));
                    val selectOptionList = arrayListOf<QuestionOptionEntity>()
                    optionId = ""
                    val operations = mutOperationAdapter.data
                    var selectValues = ""
                    var rightValues = ""
                    for (ope in operations) {
                        if (ope.isSelect) {
                            optionId += ope.id + ","
                            selectValues += ope.selectValue + ","
                            selectOptionList.add(ope)
                        }
                    }
                    val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                    val oprationList = questionList[index].wdQuestionPaperOption
                    if (oprationList != null) {
                        for (ope in oprationList) {
                            if (ope.rightFlag == 0) {
                                rightValues += ope.selectValue + ","
                            }
                        }
                    }


                    if (rightValues == selectValues) {
                        isRight = 0
                    } else {
                        isRight = 1
                    }
                    Log.v(
                        "yxy",
                        "=多选结果==" + rightValues + "====" + selectValues + "===" + isRight + "+" + GsonUtils.toJson(
                            selectOptionList
                        ) + "===" + answerType
                    )
                    if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                        practice.chapterContentList = selectOptionList
                        practice.isRight = isRight.toString()
                        practice.optionId = optionId


                        if (StringUtil.isNotBlank(optionId)) {
                            question.wdQuestionChapterPractice = practice
                            val parentList = LitePal.where("parentId =?", questionInfo.parentId)
                                .find(QuestionPaperDbEntity::class.java)
                            if (parentList != null) {
                                for (info in parentList) {
                                    info.wdQuestionBankList = GsonUtils.toJson(questionList)
                                    info.save()
                                }

                            } else {
                                questionInfo.wdQuestionBankList = GsonUtils.toJson(questionList)
                                questionInfo.save()
                            }

                        }
                        if (isRight == 1) {
                            goNext = !goNext
                            learn_by_analogy_resolve.visibility = View.VISIBLE
                            learn_by_analogy_submit_next.text = "下一题"
                            queston_answer_rl_result.visibility = View.VISIBLE
                            learn_by_analogy_error_result.text = selectValues
                            learn_by_analogy_ll_error.visibility = View.VISIBLE
                            mutOperationAdapter.setCheck(true)
                            isCheckResult = true
                            mutOperationAdapter.notifyDataSetChanged()
                            if (goNext) {
                                return
                            }
                        } else {
                            queston_answer_rl_result.visibility = View.GONE
                        }
                    }
                    Log.v(
                        "yxy",
                        "=question.wdQuestionChapterPractice=" + practice + "===questionInfo.wdQuestionBankList==" + questionInfo.wdQuestionBankList
                    )
                } else {
                    Log.v("yxy", "==共用单选保存= 未判断=" + (liftingType == 3 && isMultiple))
                    if (liftingType == 3 && isMultiple) {
                        return
                    }
                    Log.v("yxy", "==共用单选保存==" + GsonUtils.toJson(selectOptions));
                    practice.chapterContentList = selectOptions
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId

                    if (StringUtil.isNotBlank(optionId)) {
                        question.wdQuestionChapterPractice = practice
                        val parentList = LitePal.where("parentId =?", questionInfo.parentId)
                            .find(QuestionPaperDbEntity::class.java)
                        if (parentList != null) {
                            for (info in parentList) {
                                info.wdQuestionBankList = GsonUtils.toJson(questionList)
                                info.save()
                            }

                        } else {
                            questionInfo.wdQuestionBankList = GsonUtils.toJson(questionList)
                            questionInfo.save()
                        }
                    }
                }
            }
            2 -> {
//                if (liftingType == 3 && !isMultiple) {
//                    return
//                }
                val selectOptionList = arrayListOf<QuestionOptionEntity>()
                optionId = ""
                val operations = mutOperationAdapter.data
                var selectValues = ""
                var rightValues = ""
                for (ope in operations) {
                    if (ope.isSelect) {
                        optionId += ope.id + ","
                        selectValues += ope.selectValue + ","
                        selectOptionList.add(ope)
                    }
                }
                val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                val oprationList = questionList[index].wdQuestionPaperOption
                if (oprationList != null) {
                    for (ope in oprationList) {
                        if (ope.rightFlag == 0) {
                            rightValues += ope.selectValue + ","
                        }
                    }
                }


                if (rightValues == selectValues) {
                    isRight = 0
                } else {
                    isRight = 1
                }

                if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                    practice.chapterContentList = selectOptionList
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId


                    if (StringUtil.isNotBlank(optionId)) {
                        question.wdQuestionChapterPractice = practice
                        val parentList = LitePal.where("parentId =?", questionInfo.parentId)
                            .find(QuestionPaperDbEntity::class.java)
                        if (parentList != null) {
                            for (info in parentList) {
                                info.wdQuestionBankList = GsonUtils.toJson(questionList)
                                info.save()
                            }

                        } else {
                            questionInfo.wdQuestionBankList = GsonUtils.toJson(questionList)
                            questionInfo.save()
                        }

                    }
                    if (isRight == 1) {
                        goNext = !goNext
                        learn_by_analogy_resolve.visibility = View.VISIBLE
                        learn_by_analogy_submit_next.text = "下一题"
                        queston_answer_rl_result.visibility = View.VISIBLE
                        learn_by_analogy_error_result.text = selectValues
                        learn_by_analogy_ll_error.visibility = View.VISIBLE
                        mutOperationAdapter.setCheck(true)
                        isCheckResult = true
                        mutOperationAdapter.notifyDataSetChanged()
                        if (goNext) {
                            return
                        }
                    } else {
                        queston_answer_rl_result.visibility = View.GONE
                    }
                }
                Log.v(
                    "yxy",
                    "=question.wdQuestionChapterPractice=" + practice + "===questionInfo.wdQuestionBankList==" + questionInfo.wdQuestionBankList
                )
            }
            5 -> {
                solution = learn_by_analogy_edt_solution.text.toString().trim()
                if (StringUtil.isNotBlank(solution)) {
                    practice.solution = solution
                    isRight = 0
                } else {
                    practice.solution = ""
                }
                optionId = ""
                practice.isRight = isRight.toString()
                Log.v("yxy", "wdQuestionChapterPractice==solution==》" + solution + "====");
                if (StringUtil.isNotBlank(solution)) {
                    question.wdQuestionChapterPractice = practice
                    val parentList = LitePal.where("parentId =?", questionInfo.parentId)
                        .find(QuestionPaperDbEntity::class.java)
                    if (parentList != null) {
                        for (info in parentList) {
                            info.wdQuestionBankList = GsonUtils.toJson(questionList)
                            info.save()
                        }

                    } else {
                        questionInfo.wdQuestionBankList = GsonUtils.toJson(questionList)
                        questionInfo.save()
                    }
                }


            }
        }
        if (StringUtil.isNotBlank(optionId) || StringUtil.isNotBlank(solution)) {
            json.addProperty("isRight", isRight)
            if (StringUtil.isNotBlank(optionId)) {
                json.addProperty("optionId", optionId)
            }
            json.addProperty("paperId", question.paperId)
            json.addProperty("paperType", 2)
            json.addProperty("score", question.score)
            json.addProperty("subjectId", question.id)
            json.addProperty("type", 2)

            if (StringUtil.isNotBlank(solution)) {
                json.addProperty("solution", solution)
            }
            if (StringUtil.isNotBlank(solution) || StringUtil.isNotBlank(optionId)) {
                Log.v("yxy", "已做" + question.wdQuestionChapterPractice)
                Log.v("yxy", "答题结果" + GsonUtils.toJson(json))
                requestViewModel.submitQuestionResult(json)
                EventBus.getDefault().post(RefreshQuestionBankEvent())
                bankAdapter.notifyDataSetChanged()
            } else {
                Log.v("yxy", "未做")
            }
        }
    }

    /**
     * 背题模式下获取当前题目的正确答案
     * @param list ArrayList<QuestionOptionEntity>
     * @return String
     */
    private fun getRightResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            if (info.rightFlag == 0) {
                result += info.selectValue + ","
            }
        }
        return StringUtil.convertStr(result)
    }

    private fun getErrorResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            result += info.selectValue + ","
        }
        return StringUtil.convertStr(result)
    }

    private fun moveToPosition(manager: LinearLayoutManager, n: Int) {
        manager.scrollToPositionWithOffset(n, 0);
        manager.setStackFromEnd(true);
    }

    private fun nextQuestion() {
        if (goNext) {
            index += 1
            if (index < totalNum) {
                setQuestionView(questionList[index])
                if (MultiTheme.getAppTheme() != 1 && learn_by_analogy_result.text.toString().contains("回答错误")){
                    ll_learn_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_error)
                }
                learn_by_analogy_rlv_juyifansan.smoothScrollToPosition(index)
//                moveToPosition(
//                    learn_by_analogy_rlv_juyifansan.getLayoutManager() as LinearLayoutManager,
//                    index
//                )
            } else {
                if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE || answerType == 2) {
                    ToastUtils.showShort("这是最后一道题")
                } else {
                    var isFinish = false
                    val unDoList = arrayListOf<QuestionPaperInfoEntity>()
                    for (info in questionList) {
                        if (info.wdQuestionChapterPractice == null) {
                            unDoList.add(info)
                        }
                    }
                    isFinish = unDoList.size == 0

                    var title = ""
                    if (!isFinish) {
                        title = "当前子题还未完全答完，确定要返回母题进行答题吗？"
                    } else {
                        title = "当前子题已答完，点击确定返回母题进行答题哦"
                    }
                    Log.v("yxy", "=isFinish==" + isFinish + "===" + unDoList.size)



//                    MaterialDialog(this).show {
//                        cancelable(false)
//                        lifecycleOwner(this@LearnByAnalogyActivity)
//                        title(text = title)
//
//                        positiveButton(
//                            R.string.confirm, "取消"
//                        ) {
//                            dismiss()
//                        }
//                        negativeButton(R.string.cancel, "确定") {
//                            finish()
//                        }
//                        getActionButton(WhichButton.POSITIVE).updateTextColor(
//                            Color.parseColor("#0077FF")
//                        )
//                        getActionButton(WhichButton.NEGATIVE).updateTextColor(
//                            Color.parseColor("#FA642D")
//                        )
//                    }
                    val customAlertDialog = CustomAlertDialog(this, "提示", title,"确定","继续答题")
                    customAlertDialog.setEditTextDialogListener(object :
                        CustomAlertDialog.EditTextDialogListener {
                        override fun onCancle() {
                            finish()
                        }
                        override fun onOk(content: String) {
                            customAlertDialog.dismiss()
                        }
                    })
                    customAlertDialog.show()

                }
            }
        }


    }

    inner class ProxyClick() {
        /**
         * 下一题
         */
        fun nextQuestionClick() {
            if (liftingType == 2 || liftingType == 3 || liftingType == 5) {
                if (from != Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
                    saveAnswer()
                }
            }
            nextQuestion()
        }





        /**
         * 纠错
         */
        fun gotoRecoveryError() {
            questionSettingsDialog =
                RecoveryErrorDialog.newBuilder(this@LearnByAnalogyActivity, false, 1,
                    object : RecoveryErrorDialog.OnSubmitClickListener {
                        override fun onSubmitClick(tags: String,content: String) {
                            if (tags.isEmpty()){
                                ToastUtils.showShort("请选择错误类型")
                                return
                            }
                            val json = JsonObject()
                            //type传0为意见反馈，传1为试题纠错
                            json.addProperty("type", 1)
                            //试题纠错则需要传subject_id（试题id）
                            if(liftingType == 4 || liftingType == 3 || liftingType == 7 || liftingType == 8){
                                json.addProperty("subjectId", parentId)
                            }else{
                                json.addProperty("subjectId", subjectId)
                            }
                            json.addProperty("majorId", CacheUtil.getMajorId())
                            json.addProperty("feedContent", content)
                            json.addProperty("feedType", tags)
                            requestViewModel.errorCorrection(json)
                        }
                    })


            questionSettingsDialog?.show()
        }
    }




    private fun initBankRecycleView(list: ArrayList<QuestionPaperInfoEntity>) {
        bankAdapter.data = list
        //初始化recyclerView
        val layoutManager = LinearLayoutManager(this);
        layoutManager.orientation = LinearLayoutManager.HORIZONTAL;//设置为横向滑动
        learn_by_analogy_rlv_juyifansan.init(
            layoutManager,
            bankAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(ConvertUtils.dp2px(4f), 0))
        }
        bankAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionPaperInfoEntity =
                    adapter.getItem(position) as QuestionPaperInfoEntity
                index = position
                answerType = 1
                setQuestionView(info)
            }
        }
    }

    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout,
        firstView: PolyvPlayerPreviewView
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        firstView.hide()
        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)

        //视频不播放，先显示一张缩略图
        mediaController.hindMenuView()
        videoView.mediaController = mediaController
        videoView.setOnPreparedListener(IPolyvOnPreparedListener2 {
            mediaController.preparedView()
        })


//        videoView.aspectRatio = PolyvPlayerScreenRatio.AR_ASPECT_FIT_PARENT;
        //视频不播放，先显示一张缩略图

        firstView.setCallback(PolyvPlayerPreviewView.Callback { //在播放视频时设置viewerId方法使用示例
            videoView.setAutoPlay(true)
            videoView.setVid(vid)
        })

        firstView.show(vid)
        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }

    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        learn_by_analogy_edt_solution.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = learn_by_analogy_edt_solution.selectionStart
                editEnd = learn_by_analogy_edt_solution.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(learn_by_analogy_edt_solution.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                learn_by_analogy_edt_solution.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(learn_by_analogy_edt_solution.text.toString())
        currentCount = nowCount
        //
        learn_by_analogy_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }

    private fun initWebView() {
        val webSettings: WebSettings = learn_by_analogy_tv_analyze.getSettings()
        webSettings.javaScriptEnabled = true //允许使用js
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false
        learn_by_analogy_tv_analyze.setWebViewClient(object : WebViewClient() {
            //覆盖shouldOverrideUrlLoading 方法
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

        })

    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }

}