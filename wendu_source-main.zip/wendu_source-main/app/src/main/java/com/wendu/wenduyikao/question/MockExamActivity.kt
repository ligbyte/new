package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ToastUtils
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.PaperInfoEntity
import com.wendu.wenduyikao.data.model.bean.PaperRecordEntity
import com.wendu.wenduyikao.databinding.ActivityMockExamBinding
import com.wendu.wenduyikao.dialog.SelectExamDialog
import com.wendu.wenduyikao.question.adapter.PaperListAdapter
import com.wendu.wenduyikao.question.adapter.PaperRecordListAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestMockExamViewModel
import kotlinx.android.synthetic.main.activity_mock_exam.*
import kotlinx.android.synthetic.main.activity_my_error.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.question_error_item_view.*
import me.xiaoyang.base.ext.parseState

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:24 PM
 * @Description:模拟考试
 */
class MockExamActivity : BaseActivity<RequestMockExamViewModel, ActivityMockExamBinding>() {

    private val requestViewModel: RequestMockExamViewModel by viewModels()

    override fun layoutId() = R.layout.activity_mock_exam
    private var from = "question"
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, mock_ll_content)
        tv_toolbar_title.text = "模拟自测"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        from=intent.getStringExtra("from").toString()
        if(from=="question"){
            requestViewModel.getPaperSubjectList(CacheUtil.getQuestionMajorId())
        }else{
            requestViewModel.getPaperSubjectList(CacheUtil.getMajorId())
        }

    }

    override fun onResume() {
        super.onResume()
        if(from=="question"){
            requestViewModel.getPaperSubjectList(CacheUtil.getQuestionMajorId())
        }else{
            requestViewModel.getPaperSubjectList(CacheUtil.getMajorId())
        }
    }

    override fun createObserver() {
        requestViewModel.mockResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    if (it.classicList.size > 0) {
                        mock_exam_jingdian.visibility = View.VISIBLE
                        initClassicRecycleView(it.classicList)
                    } else {
                        mock_exam_jingdian.visibility = View.GONE
                    }
                    if (it.alreadyList.size > 0) {
                        mock_exam_record.visibility = View.VISIBLE
                        initRecordRecycleView(it.alreadyList)
                    } else {
                        mock_exam_record.visibility = View.GONE
                    }

                }
            })
        })
        requestViewModel.examResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    if (it.examList.size <= 0) {
                        ToastUtils.showShort("暂无科目数据")
                    } else {
                        val chooseDialog = SelectExamDialog.newBuilder(this, it.examList,
                            object : SelectExamDialog.OnSubmitClickListener {
                                override fun onSubmitClick(content: String, useTime: Int) {
                                    Log.v("yxy", "==examId=" + content + "use=====" + useTime)
                                    startActivity(
                                        Intent(this@MockExamActivity, Exam2Activity::class.java)
                                            .putExtra("from", "mock_produce")
                                            .putExtra("examId", content)
                                            .putExtra("index", 1)
                                            .putExtra("type", 4)
                                            .putExtra("useTime", useTime.toLong())
                                            .putExtra(
                                                "type",
                                                Constants.PARAMS_QUESTION_LOAD_TYPE_MOCK
                                            )
                                    )
                                }

                            })
                        chooseDialog.show()
                    }

                }
            })
        })

    }

    private fun initClassicRecycleView(list: ArrayList<PaperInfoEntity>) {
        Log.v("yxy", "=initClassicRecycleView==>" + list.size)
        val paperAdapter = PaperListAdapter(list)
        //初始化recyclerView
        mock_exam_rlv_classic.init(
            LinearLayoutManager(this),
            paperAdapter
        )
        paperAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: PaperInfoEntity = adapter.getItem(position) as PaperInfoEntity
                if (info.total > 0) {
                    startActivity(
                        Intent(this@MockExamActivity, Exam2Activity::class.java)
                            .putExtra("paperId", info.id)
                            .putExtra("total", info.total)
                            .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_MOCK)
                            .putExtra("type", 5)
                            .putExtra("useTime", info.useTime.toLong())
                            .putExtra("index", 0)
                    )
                } else {
                    ToastUtils.showShort("该试卷下暂无题目")
                }
            }
        }
    }

    private fun initRecordRecycleView(list: ArrayList<PaperRecordEntity>) {

        val paperAdapter = PaperRecordListAdapter(list)
        //初始化recyclerView
        mock_exam_rlv_record.init(
            LinearLayoutManager(this),
            paperAdapter
        )
        paperAdapter.run {
            setOnItemChildClickListener { adapter, view, position ->

            }
        }
    }

    inner class ProxyClick() {
        /**
         * 选择科目
         */
        fun gotoGetExamList() {
            requestViewModel.getExamList()
        }
    }
}