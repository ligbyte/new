package com.wendu.wenduyikao.question

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IFillFormatter
import com.google.gson.JsonObject
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.ext.loadServiceInit
import com.wendu.wenduyikao.app.ext.showEmpty
import com.wendu.wenduyikao.app.ext.showLoading
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.dropdownmenu.FilterUrl
import com.wendu.wenduyikao.app.weight.dropdownmenu.interfaces.OnFilterDoneListener
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.RefreshErrorQuestionEvent
import com.wendu.wenduyikao.data.model.bean.CodeEntity
import com.wendu.wenduyikao.data.model.bean.QuestionCollectEntity
import com.wendu.wenduyikao.data.model.bean.QuestionErrorProportionEntity
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivityMyErrorBinding
import com.wendu.wenduyikao.question.adapter.DropMenuAdapter
import com.wendu.wenduyikao.question.adapter.MyErrorAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestMyErrorViewModel
import kotlinx.android.synthetic.main.activity_my_error.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import org.litepal.LitePal

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:25 PM
 * @Description: 我的错题
 */
class MyErrorActivity : BaseActivity<RequestMyErrorViewModel, ActivityMyErrorBinding>(),
    OnFilterDoneListener {

    private val requestViewModel: RequestMyErrorViewModel by viewModels()
    override fun layoutId() = R.layout.activity_my_error
    private var isCollect = false
    private var liftingType = 0
    private var type = 1   //1章节练习 3//历年真题 4//精品题库
    private var total = 0
    private var selectIndex = -1
    private lateinit var loadsir: LoadService<Any>
    private var liftTypeList: ArrayList<CodeEntity> = arrayListOf()
    private var paperTypeList: ArrayList<CodeEntity> = arrayListOf()
    private val errorAdapter: MyErrorAdapter by lazy {
        MyErrorAdapter(
            arrayListOf()
        )
    }

    override fun initView(savedInstanceState: Bundle?) {
        EventBus.getDefault().register(this)
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, error_ll_content)
        tv_toolbar_title.text = "我的错题"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        requestViewModel.getErrorTypeList()
        loadsir = loadServiceInit(mFilterContentView) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getQuestionErrorList(type.toString(), liftingType.toString(), total)
        }

        requestViewModel.getQuestionErrorProportion()
        initChartView()
        initRecycleView()


    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun refreshErrorQuestion(error: RefreshErrorQuestionEvent?) {
        Log.v("yxy", "=错题刷新==>")
        requestViewModel.getQuestionErrorList(type.toString(), liftingType.toString(), total)
    }

    private fun initChartView() {
        chart_statistics.setViewPortOffsets(0f, 0f, 0f, 0f)
        chart_statistics.setBackgroundColor(Color.WHITE)
        chart_statistics.setNoDataText("暂时没有数据")
        chart_statistics.setNoDataTextColor(Color.BLUE)
        chart_statistics.description.isEnabled = false
        chart_statistics.setTouchEnabled(true)
        chart_statistics.isDragEnabled = true
        chart_statistics.setScaleEnabled(true)
        chart_statistics.setPinchZoom(false)

        chart_statistics.setDrawGridBackground(false)
        chart_statistics.maxHighlightDistance = 300f

        val x: XAxis = chart_statistics.getXAxis()
        x.isEnabled = false

        val y: YAxis = chart_statistics.getAxisLeft()
//        y.typeface = tfLight
        y.setLabelCount(6, false)
        y.textColor = Color.WHITE
        y.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART)
        y.setDrawGridLines(false)
        y.axisLineColor = Color.WHITE
        chart_statistics.axisRight.isEnabled = false
        chart_statistics.legend.isEnabled = false
        chart_statistics.animateXY(2000, 2000)

    }

    private fun setData(proportionList: ArrayList<QuestionErrorProportionEntity>) {
        val values = java.util.ArrayList<Entry>()
        for (index in proportionList.indices) {
            values.add(Entry(index.toFloat(), proportionList[index].proportion))
        }
        val set1: LineDataSet
        if (chart_statistics.data != null &&
            chart_statistics.data.dataSetCount > 0
        ) {
            set1 = chart_statistics.data.getDataSetByIndex(0) as LineDataSet
            set1.values = values
            chart_statistics.data.notifyDataChanged()
            chart_statistics.notifyDataSetChanged()
        } else {
            // create a dataset and give it a type
            set1 = LineDataSet(values, "DataSet 1")
            set1.mode = LineDataSet.Mode.CUBIC_BEZIER
            set1.cubicIntensity = 0.2f
            set1.setDrawFilled(true)
            set1.setDrawCircles(false)
            set1.lineWidth = 1.8f
            set1.circleRadius = 4f
            set1.setCircleColor(Color.WHITE)
            set1.highLightColor = Color.rgb(244, 117, 117)
            set1.color = Color.BLUE
            set1.fillColor = Color.parseColor("#3B7BFF")
            set1.fillAlpha = 100
            set1.setDrawHorizontalHighlightIndicator(false)
            set1.fillFormatter =
                IFillFormatter { dataSet, dataProvider ->
                    chart_statistics.getAxisLeft().getAxisMinimum()
                }

            // create a data object with the data sets
            val data = LineData(set1)
            data.setValueTextSize(9f)
            data.setDrawValues(false)
            chart_statistics.setData(data)
            chart_statistics.invalidate()
        }
    }

    override fun createObserver() {
        requestViewModel.collectResult.observe(this, Observer {
            if (it.success) {
                isCollect = !isCollect
                requestViewModel.getQuestionErrorList(
                    type.toString(),
                    liftingType.toString(),
                    total
                )
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.errorTypeResult.observe(this) {
            parseState(it, { it ->
                liftTypeList = arrayListOf()
                paperTypeList = arrayListOf()
                val work = CodeEntity()
                work.type = "0"
                work.label = "全部"
                liftTypeList.add(work)
                it.liftingType.forEach {
                    val work = CodeEntity()
                    work.type = it.key
                    work.label = it.value
                    liftTypeList.add(work)
                }
                it.pageType.forEach {
                    val work = CodeEntity()
                    work.type = it.key
                    work.label = it.value
                    paperTypeList.add(work)
                }

                val titleList = arrayOf("题型", "次数", "题库类型")
                dropDownMenu.setMenuAdapter(
                    DropMenuAdapter(
                        this,
                        titleList,
                        liftTypeList,
                        paperTypeList,
                        this
                    )
                )
                if (paperTypeList.size > 0) {
                    type = paperTypeList[0].type.toInt()
                    dropDownMenu.setPositionIndicatorText(
                        2,
                        paperTypeList[0].label
                    )
                }
                requestViewModel.getQuestionErrorList(
                    type.toString(),
                    liftingType.toString(),
                    total
                )
            }, {
            })
        }
        requestViewModel.errorListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.isEmpty) {
                    loadsir.showEmpty()
                } else {
                    loadsir.showSuccess()
                    errorAdapter.data = it.listData
                    Log.v("yxy","==selectIndex=="+selectIndex)
                    if (selectIndex >= 0) {
                        errorAdapter.notifyItemChanged(selectIndex)
                    } else {
                        errorAdapter.notifyDataSetChanged()
                    }

                }

            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.errorProportionResult.observe(this, Observer {
            if (it.isSuccess) {
                if (!it.isEmpty) {
                    setData(it.listData)
                }

            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
        requestViewModel.errorQuestionListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.isEmpty) {
                    ToastUtils.showShort("暂无题目，请返回")
                } else {
                    val result = it.listData[0]
                    if (result.chapterList.size > 0) {
                        LitePal.deleteAll(QuestionDbEntity::class.java)
                        var position = 0
                        var questionIndex = 0
                        var total = 0
                        for (info in it.listData) {
                            for (quest in info.chapterList) {
                                total += 1
                            }
                        }
                        for (info in it.listData) {
                            for (quest in info.chapterList) {
                                when (info.type) {
                                    3, 4, 7, 8 -> {
                                        var subIndex = 0
                                        questionIndex += 1
                                        for (sub in quest.questionList) {
                                            position += 1
                                            subIndex += 1
                                            val questionDb = QuestionDbEntity()
                                            questionDb.chapterId = quest.chapterId
                                            questionDb.liftingType = quest.liftingType
                                            questionDb.templateId = quest.templateId
                                            questionDb.answer = sub.answer
                                            questionDb.isCollect = quest.isCollect
                                            questionDb.answer = sub.answer
                                            questionDb.questionId = sub.id
                                            questionDb.parentId = quest.id
                                            questionDb.stem = quest.stem
                                            questionDb.facilityValue = quest.facilityValue
                                            questionDb.name = quest.name
                                            questionDb.questionIndex = questionIndex
                                            questionDb.total = total
                                            questionDb.index = "$questionIndex-$subIndex"
                                            questionDb.childStem = sub.stem
                                            if (StringUtil.isNotBlank(quest.isCollectId)) {
                                                questionDb.isCollectId = quest.isCollectId
                                            }
                                            if (sub.wdQuestionChapterPractice != null) {
                                                questionDb.wdQuestionChapterPractice =
                                                    GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                            }
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeByType(quest.liftingType)

                                            if (sub.dataList != null) {
                                                questionDb.dataList =
                                                    GsonUtils.toJson(sub.dataList)
                                            }
                                            if (sub.selectList != null) {
                                                questionDb.selectList =
                                                    GsonUtils.toJson(sub.selectList)
                                            }
                                            questionDb.childIndex =
                                                "$subIndex/ ${quest.questionList.size}"
                                            questionDb.position = position
                                            questionDb.optionList =
                                                GsonUtils.toJson(sub.optionList)

                                            questionDb.save()
                                        }
                                    }
                                    else -> {
                                        questionIndex += 1
                                        position += 1
                                        val questionDb = QuestionDbEntity()
                                        questionDb.answer = quest.answer
                                        questionDb.chapterId = quest.chapterId
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.isCollect = quest.isCollect
                                        questionDb.stem = quest.stem
                                        questionDb.parentId = quest.id
                                        questionDb.templateId = quest.templateId
                                        questionDb.name = quest.name
                                        questionDb.facilityValue = quest.facilityValue
                                        questionDb.total = total
                                        questionDb.questionId = quest.id
                                        questionDb.questionIndex = questionIndex
                                        questionDb.position = position
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId = quest.isCollectId
                                        }
                                        if (quest.wdQuestionChapterPractice != null) {
                                            questionDb.wdQuestionChapterPractice =
                                                GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                        }
                                        if (quest.liftingType == 5) {
                                            questionDb.topicCategory = quest.topicCategory
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                        } else {
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeByType(quest.liftingType)
                                        }
                                        questionDb.index = questionIndex.toString()
                                        if (quest.dataList != null) {
                                            questionDb.dataList =
                                                GsonUtils.toJson(quest.dataList)
                                        }
                                        if (quest.selectList != null) {
                                            questionDb.selectList =
                                                GsonUtils.toJson(quest.selectList)
                                        }
                                        questionDb.optionList =
                                            GsonUtils.toJson(quest.optionList)
                                        questionDb.save()

                                    }
                                }
                            }
                        }


                        startActivity(
                            Intent(this@MyErrorActivity, QuestionAnswerActivity::class.java)
                                .putExtra("errorLiftType", liftingType)
                                .putExtra("dataType", type)
                                .putExtra(Constants.PARAMS_QUESTION_ERROR, 1)
                                .putExtra("index", 1)
                                .putExtra("total", questionIndex)
                                .putExtra("from", "error")
                        )
                    } else if (result.list.size > 0) {
                        CacheUtil.setQuestionPaperSubject(it.listData)
                        Log.v("yxy", "==模考错题==")
                        LitePal.deleteAll(QuestionPaperDbEntity::class.java)
                        var position = 0
                        var questionIndex = 0
                        var total = 0
                        for (info in it.listData) {
                            for (quest in info.list) {
                                total += 1
                            }
                        }
                        for (info in it.listData) {
                            for (quest in info.list) {
                                when (quest.liftingType) {
                                    3, 4, 7, 8 -> {
                                        var subIndex = 0
                                        questionIndex += 1
                                        for (sub in quest.wdQuestionPaperSubjectSubordinatesList) {
                                            position += 1
                                            subIndex += 1
                                            val questionDb = QuestionPaperDbEntity()
                                            questionDb.paperId = quest.paperId
                                            questionDb.liftingType = quest.liftingType
                                            questionDb.templateId = quest.templateId
                                            questionDb.answer = sub.answer
                                            questionDb.total = total
                                            questionDb.paperType = sub.paperType
                                            questionDb.isCollect = quest.isCollect
                                            questionDb.answer = sub.answer
                                            questionDb.questionId = sub.id
                                            questionDb.parentId = quest.id
                                            questionDb.stem = quest.stem
                                            if (StringUtil.isNotBlank(quest.isCollectId)) {
                                                questionDb.isCollectId = quest.isCollectId
                                            }
                                            questionDb.questionIndex = questionIndex
                                            questionDb.index = "$questionIndex-$subIndex"
                                            questionDb.childStem = sub.stem
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeByType(quest.liftingType)

                                            if (sub.wdQuestionPaperData != null) {
                                                questionDb.wdQuestionPaperData =
                                                    GsonUtils.toJson(sub.wdQuestionPaperData)
                                            }
                                            if (sub.wdQuestionPaperDataVideo != null) {
                                                questionDb.wdQuestionPaperDataVideo =
                                                    GsonUtils.toJson(sub.wdQuestionPaperDataVideo)
                                            }
                                            questionDb.childIndex =
                                                "$subIndex/ ${quest.wdQuestionPaperSubjectSubordinatesList.size}"
                                            questionDb.position = position
                                            if (sub.wdQuestionPaperOption != null) {
                                                questionDb.wdQuestionPaperOption =
                                                    GsonUtils.toJson(sub.wdQuestionPaperOption)

                                            }

                                            questionDb.save()
                                        }

                                    }
                                    else -> {
                                        questionIndex += 1
                                        position += 1
                                        val questionDb = QuestionPaperDbEntity()
                                        questionDb.answer = quest.answer
                                        questionDb.paperId = quest.paperId
                                        questionDb.total = total
                                        questionDb.parentId = quest.id
                                        questionDb.paperType = quest.paperType
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.isCollect = quest.isCollect
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId = quest.isCollectId
                                        }

                                        questionDb.stem = quest.stem
                                        questionDb.templateId = quest.templateId
                                        questionDb.questionId = quest.id
                                        questionDb.position = position
                                        questionDb.questionIndex = questionIndex
                                        if (quest.liftingType == 5) {
                                            questionDb.topicCategory = quest.topicCategory
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                        } else {
                                            questionDb.typeLabel =
                                                StringUtil.getSubjectTypeByType(quest.liftingType)
                                        }

                                        questionDb.index = questionIndex.toString()
                                        if (quest.wdQuestionPaperData != null) {
                                            questionDb.wdQuestionPaperData =
                                                GsonUtils.toJson(quest.wdQuestionPaperData)
                                        }
                                        if (quest.wdQuestionPaperDataVideo != null) {
                                            questionDb.wdQuestionPaperDataVideo =
                                                GsonUtils.toJson(quest.wdQuestionPaperDataVideo)
                                        }
                                        if (quest.wdQuestionPaperOption != null) {
                                            questionDb.wdQuestionPaperOption =
                                                GsonUtils.toJson(quest.wdQuestionPaperOption)
                                        }

                                        questionDb.save()
                                    }
                                }
                            }
                        }

                        var quesitonType = 1
                        var isMockError = false
                        when (type) {
                            1 -> quesitonType = 1
                            2, 3 -> quesitonType = 2
                            4 -> isMockError = true
                        }

                        startActivity(
                            Intent(this@MyErrorActivity, ExamAnswerActivity::class.java)
                                .putExtra("errorLiftType", liftingType)
                                .putExtra(Constants.PARAMS_QUESTION_ERROR, 1)
                                .putExtra("type", quesitonType)
                                .putExtra("isMockError", isMockError)
                                .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_PAPER_ERROR)
                        )
                    } else {
                        ToastUtils.showShort("暂无题目，请返回")
                    }
                }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
    }

    private fun initRecycleView() {
//        errorAdapter = MyErrorAdapter(list)
        //初始化recyclerView
        mFilterContentView.init(
            LinearLayoutManager(this),
            errorAdapter
        )
        errorAdapter.addChildClickViewIds(R.id.error_ll_fav)
        mFilterContentView.itemAnimator?.changeDuration=0
        errorAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionCollectEntity =
                    adapter.getItem(position) as QuestionCollectEntity
                Log.v("yxy", "==" + info.type)
                if (info.type == "1") {
                    startActivity(
                        Intent(this@MyErrorActivity, QuestionAnswerActivity::class.java)
                            .putExtra("id", info.subjectId)
                            .putExtra(Constants.PARAMS_QUESTION_ERROR, 1)
                            .putExtra("type", info.type.toInt())
                            .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO)
                    )
                } else {
                    startActivity(
                        Intent(this@MyErrorActivity, ExamAnswerActivity::class.java)
                            .putExtra("id", info.subjectId)
                            .putExtra(Constants.PARAMS_QUESTION_ERROR, 1)
                            .putExtra("type", info.type.toInt())
                            .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO)
                    )
                }

            }

            setOnItemChildClickListener { adapter, view, position ->
                val info: QuestionCollectEntity =
                    adapter.getItem(position) as QuestionCollectEntity
                when (view.id) {
                    R.id.error_ll_fav -> {
                        selectIndex = position
                        if (info.isCollect == 0) {
//                            question_error_fav.setImageResource(R.mipmap.ic_fav_unselcted)
//                            question_error_fav.isSelected = isCollect
                            val json = JsonObject()
                            json.addProperty("subjectId", info.subjectId)
                            json.addProperty("type", type)
                            requestViewModel.addCollect(json)
                        } else {
//                            question_error_fav.setImageResource(R.mipmap.ic_fav_selected)
//                            question_error_fav.isSelected = isCollect

                            if (StringUtil.isNotBlank(info.isCollectId)) {
                                requestViewModel.delCollect(info.isCollectId)
                            } else {
                                ToastUtils.showShort("收藏数据异常")
                            }
                        }
                    }
                }
            }
        }
    }

    inner class ProxyClick() {
        fun gotoAnswer() {
            val params = mutableMapOf<String, String>()
            if (liftingType > 0) {
                params["liftingType"] = liftingType.toString()
            }
            params["type"] = type.toString()
            if (total > 0) {
                params["number"] = total.toString()
            }
            params["majorId"] = CacheUtil.getQuestionMajorId()
            requestViewModel.getQuestionByError(params)

        }
    }


    override fun onFilterDone(position: Int, positionTitle: String, urlValue: String) {
        Log.v("yxy", "====>" + position + "---" + positionTitle)
        dropDownMenu.setPositionIndicatorText(
            FilterUrl.instance().position,
            FilterUrl.instance().positionTitle
        )
        dropDownMenu.close()

        when (position) {
            0 -> {
                liftingType = urlValue.toInt()
            }
            1 -> {
                total = urlValue.toInt()
            }
            2 -> {
                type = urlValue.toInt()
            }
        }
        requestViewModel.getQuestionErrorList(type.toString(), liftingType.toString(), total)

    }
}