package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import com.blankj.utilcode.util.GsonUtils
import com.blankj.utilcode.util.ToastUtils
import com.google.gson.JsonArray
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.bindViewPager3
import com.wendu.wenduyikao.app.ext.initActivity
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.SearchQuestionEvent
import com.wendu.wenduyikao.data.model.bean.CollectNumEntity
import com.wendu.wenduyikao.data.model.bean.DictCodeEntity
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity
import com.wendu.wenduyikao.databinding.ActivityMyFavBinding
import com.wendu.wenduyikao.dialog.SelectLiftingTypeNumDialog
import com.wendu.wenduyikao.question.fragment.CollectListFragment
import com.wendu.wenduyikao.viewmodel.request.RequestQuestionViewModel
import kotlinx.android.synthetic.main.activity_my_fav.*
import kotlinx.android.synthetic.main.activity_my_fav.magic_indicator
import kotlinx.android.synthetic.main.activity_my_fav.view_pager
import kotlinx.android.synthetic.main.activity_question_answer.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.content_toolbar_view.img_back
import kotlinx.android.synthetic.main.include_viewpager.*
import org.greenrobot.eventbus.EventBus
import org.litepal.LitePal


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:25 PM
 * @Description: 我的收藏
 */
class MyFavActivity : BaseActivity<RequestQuestionViewModel, ActivityMyFavBinding>() {
    private val requestViewModel: RequestQuestionViewModel by viewModels()

    override fun layoutId() = R.layout.activity_my_fav

    //fragment集合
    private var fragments: ArrayList<Fragment> = arrayListOf()

    //标题集合
    private var mDataList: ArrayList<String> = arrayListOf()

    private var liftingType = 1
    private var keywords = ""


    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, fav_ll_content)
        tv_toolbar_title.text = "我的收藏"
        img_back.setOnClickListener { finish() }
        liftingType = intent.getIntExtra("liftingType", 1)
        mDatabind.click = ProxyClick()
        view_pager.initActivity(this, fragments)

        magic_indicator.bindViewPager3(view_pager, mDataList)

        requestViewModel.getCollectType()
    }

    private fun initMagicIndicator( list:ArrayList<CollectNumEntity>)  {
        val typeList = CacheUtil.getDictCodeList()

        var list2 = arrayListOf<DictCodeEntity>()
        for (type in list) {
            if (type.liftingType == 5) {
                if(type.topicCategory==1){
                    list2.add(DictCodeEntity("5-1", "解答题", "解答题", 0))
                }
                if(type.topicCategory==2){
                    list2.add(DictCodeEntity("5-2", "翻译题", "翻译题", 0))
                }
                if(type.topicCategory==3){
                    list2.add(DictCodeEntity("5-3", "作文", "作文", 0))
                }
            } else {
                list2.add(DictCodeEntity(type.liftingType.toString(),StringUtil.getSubjectTypeByType(type.liftingType),StringUtil.getSubjectTypeByType(type.liftingType),type.number ))
            }
        }
        mDataList.addAll(list2.map { it.title })

        list2.forEach {
            fragments.add(CollectListFragment.newInstance(it.value))
        }
        magic_indicator.navigator.notifyDataSetChanged()
        view_pager.adapter?.notifyDataSetChanged()
        view_pager.offscreenPageLimit = fragments.size
    }

    override fun createObserver() {
        requestViewModel.questionFavListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (it.listData.size > 0 ) {
                    LitePal.deleteAll(QuestionDbEntity::class.java)
                    var position = 0
                    var questionIndex = 0
                    var total = 0
                    for (info in it.listData) {
                        for (quest in info.list) {
                            total += 1
                        }
                    }
                    for (info in it.listData) {
                        for (quest in info.list) {
                            when (info.type) {
                                3, 4, 7, 8 -> {
                                    var subIndex = 0
                                    questionIndex += 1
                                    for (sub in quest.questionList) {
                                        position += 1
                                        subIndex += 1
                                        val questionDb = QuestionDbEntity()
                                        questionDb.chapterId = quest.paperId
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.templateId = quest.templateId
                                        questionDb.answer = sub.answer
                                        questionDb.total=total
                                        questionDb.isCollect = quest.isCollect
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId=quest.isCollectId
                                        }
                                        questionDb.answer = sub.answer
                                        questionDb.questionId = sub.id
                                        questionDb.parentId=quest.id
                                        questionDb.stem = quest.stem
                                        questionDb.name = quest.name
                                        questionDb.questionIndex = questionIndex
                                        questionDb.facilityValue=sub.facilityValue
                                        questionDb.index = "$questionIndex-$subIndex"
                                        questionDb.childStem = sub.stem
                                        if (sub.wdQuestionChapterPractice != null) {
//                                            questionDb.wdQuestionChapterPractice =
//                                                GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                            questionDb.wdQuestionChapterPractice = null
                                        }
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)

                                        if (sub.dataList != null) {
                                            questionDb.dataList =
                                                GsonUtils.toJson(sub.dataList)
                                        }
                                        if (sub.selectList != null) {
                                            questionDb.selectList =
                                                GsonUtils.toJson(sub.selectList)
                                        }
                                        questionDb.childIndex =
                                            "$subIndex/ ${quest.questionList.size}"
                                        questionDb.position = position
                                        questionDb.optionList =
                                            GsonUtils.toJson(sub.optionList)

                                        questionDb.save()
                                    }
                                }
                                else -> {
                                    questionIndex += 1
                                    position += 1
                                    val questionDb = QuestionDbEntity()
                                    questionDb.answer = quest.answer
                                    questionDb.chapterId = quest.paperId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.isCollect = quest.isCollect
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId=quest.isCollectId
                                    }

                                    questionDb.stem = quest.stem
                                    questionDb.templateId = quest.templateId
                                    questionDb.name = quest.name
                                    questionDb.questionId = quest.id
                                    questionDb.parentId=quest.id
                                    questionDb.questionIndex = questionIndex
                                    questionDb.total=total
                                    questionDb.facilityValue=quest.facilityValue
                                    questionDb.position = position
                                    if (quest.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(quest.wdQuestionChapterPractice)}
                                    if (quest.liftingType == 5) {
                                        questionDb.topicCategory = quest.topicCategory
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                    } else {
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)
                                    }

                                    questionDb.index = questionIndex.toString()
                                    if (quest.dataList != null) {
                                        questionDb.dataList =
                                            GsonUtils.toJson(quest.dataList)
                                    }
                                    if (quest.selectList != null) {
                                        questionDb.selectList =
                                            GsonUtils.toJson(quest.selectList)
                                    }

                                    questionDb.optionList =
                                        GsonUtils.toJson(quest.optionList)
                                    questionDb.save()

                                }
                            }
                        }
                    }

                    startActivity(
                        Intent(this, QuestionAnswerActivity::class.java)
                            .putExtra("index", 1)
                            .putExtra("total", LitePal.count(QuestionDbEntity::class.java))
                            .putExtra("favType",1)
                            .putExtra("isFav",1)
                            .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_ERROR)
                    )
                } else {
                    ToastUtils.showShort("暂无题目，请返回")
                    finish()
                }


            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })

        requestViewModel.collectTypeListResult.observe(this, Observer {
            if (it.isSuccess) {
                if (!it.isEmpty) {
                    val chooseTime =
                        SelectLiftingTypeNumDialog.newBuilder(this@MyFavActivity, it.listData,
                            object : SelectLiftingTypeNumDialog.OnSubmitClickListener {
                                override fun onSubmitClick(content: JsonArray) {
                                    Log.v("yxy", "==jsonarray=" + GsonUtils.toJson(content))
                                    requestViewModel.getQuestionCollectPracticeList(content)
                                }

                            })
                    chooseTime.show()
                } else {
                    ToastUtils.showShort("暂无收藏数据")
                }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })


        requestViewModel.collectFilterTypeResult.observe(this, Observer {
            if (it.isSuccess) {
                if (!it.isEmpty) {
                    initMagicIndicator(it.listData)
                    } else {
                        ToastUtils.showShort("暂无收藏数据")
                    }
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })
    }

    inner class ProxyClick() {
        fun searchClick() {
            keywords = my_fav_edt_search.text.toString().trim()
                EventBus.getDefault().post( SearchQuestionEvent(keywords));

        }

        /**
         * 智能练习
         */
        fun gotoPaperPractice() {
            requestViewModel.getQuestionCollectTypeNumList()
        }
    }
}