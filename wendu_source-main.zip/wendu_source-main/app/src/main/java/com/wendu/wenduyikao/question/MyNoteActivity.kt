package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.weight.recyclerview.DefineLoadMoreView
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.NoteInfoEntity
import com.wendu.wenduyikao.databinding.ActivityMyNoteBinding
import com.wendu.wenduyikao.question.adapter.MyNoteAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestNoteViewModel
import com.yanzhenjie.recyclerview.SwipeRecyclerView
import kotlinx.android.synthetic.main.activity_my_note.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.include_recyclerview.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:25 PM
 * @Description: 我的笔记
 */
class MyNoteActivity : BaseActivity<RequestNoteViewModel, ActivityMyNoteBinding>() {

    private val requestViewModel: RequestNoteViewModel by viewModels()

    //适配器
    private val noteAdapter: MyNoteAdapter by lazy {
        MyNoteAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    private lateinit var footView: DefineLoadMoreView

    override fun layoutId() = R.layout.activity_my_note

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, note_ll_content)
        tv_toolbar_title.text = "我的笔记"
        img_back.setOnClickListener { finish() }
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getNoteList(true)
        }
        initRecycleView()

    }

    private fun initRecycleView() {
        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(this), noteAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
            footView = it.initFooter(SwipeRecyclerView.LoadMoreListener {
                //触发加载更多时请求数据
                requestViewModel.getNoteList(false)
            })
        }
        val list = arrayListOf<NoteInfoEntity>()
        noteAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getNoteList(true)
        }
        noteAdapter.addChildClickViewIds(R.id.note_delete, R.id.note_from)
        noteAdapter.run {
            setOnItemChildClickListener { adapter, view, position ->
                val info: NoteInfoEntity =
                    adapter.getItem(position) as NoteInfoEntity
                when (view.id) {
                    R.id.note_from -> {
                        if(info.type=="1"){
                            startActivity(Intent(this@MyNoteActivity,QuestionAnswerActivity::class.java)
                                .putExtra("id",info.id)
                                .putExtra("from",Constants.PARAMS_QUESTION_SOURCE_NOTE))
                        }else{
                            startActivity(
                                Intent(this@MyNoteActivity, ExamAnswerActivity::class.java)
                                    .putExtra("id", info.id)
                                    .putExtra("type", info.type.toInt())
                                    .putExtra("from", Constants.PARAMS_QUESTION_SOURCE_NOTE)
                            )
                        }
                    }
                    R.id.note_delete -> {
                        requestViewModel.delNoteInfoById(info.id)
                    }
                }
            }
        }
        lazyLoadData()
    }


    fun lazyLoadData() {
        loadsir.showLoading()
        requestViewModel.getNoteList(true)
    }

    override fun createObserver() {
        requestViewModel.noteListResult.observe(this, Observer {
            if (it.isSuccess) {
                loadsir.showSuccess()
                loadListData(it, noteAdapter, loadsir, recyclerView, swipeRefresh)
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })

        requestViewModel.delNoteResult.observe(this, Observer {
            if (it.success) {
                requestViewModel.getNoteList(true)
            } else {
                ToastUtils.showShort(it.message)
            }
        })

    }
}