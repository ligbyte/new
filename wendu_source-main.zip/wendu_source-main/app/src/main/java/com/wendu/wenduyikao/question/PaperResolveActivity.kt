package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.Html
import android.view.View
import android.widget.RelativeLayout
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.bumptech.glide.Glide
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity
import com.wendu.wenduyikao.databinding.ActivityPaperResolveBinding
import com.wendu.wenduyikao.dialog.PaperScantronDialog
import com.wendu.wenduyikao.question.adapter.*
import com.wendu.wenduyikao.viewmodel.request.RequestPaperResolveViewModel
import kotlinx.android.synthetic.main.activity_exam.*
import kotlinx.android.synthetic.main.activity_my_note.*
import kotlinx.android.synthetic.main.activity_paper_resolve.*
import kotlinx.android.synthetic.main.activity_paper_resolve.question_tv_analyze
import kotlinx.android.synthetic.main.activity_question_answer.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.content_toolbar_view.img_back

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/4/21 10:16 AM
 * @Description: 试卷解析
 */
class PaperResolveActivity :
    BaseActivity<RequestPaperResolveViewModel, ActivityPaperResolveBinding>() {
    private var index = 0//已经完结的题目索引
    private var subIndex = 0   //子题目索引
    private var totalNum = 0  //题目总数
    private var subjectId = ""
    private var liftingType = 1  //当前题目类型
    private var paperId = ""
    private var isCollect = 0
    private var isCollectId = ""
    private val requestViewModel: RequestPaperResolveViewModel by viewModels()

    //适配器
    private var mutOperationAdapter: QuestionMutResolveAdapter =
        QuestionMutResolveAdapter(
            arrayListOf()
        )
    private var singleOperationAdapter: QuestionResolveOperationAdapter =
        QuestionResolveOperationAdapter(
            arrayListOf()
        )

    override fun layoutId() = R.layout.activity_paper_resolve

    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, paper_resolve_ll_content)
        img_back.setOnClickListener { finish() }

        mDatabind.click = ProxyClick()
        val info = CacheUtil.getQuestionPaperList()[index]
        totalNum = CacheUtil.getQuestionPaperList().size
        setQuestionView(info)
        setQuestionIndex(index, totalNum, false)
    }

    /**
     * 更新题目编号索引
     * @param ind Int
     * @param total Int
     * @param isSub Boolean
     */
    private fun setQuestionIndex(ind: Int, total: Int, isSub: Boolean) {
        val num = ind + 1;
        val str = "第<font color='#3B7BFF'>$num</font>/ $total  题";
        if (isSub) {
            paper_resolve_sub_index.text = Html.fromHtml(str);
        } else {
            paper_resolve_index.text = Html.fromHtml(str);
        }
    }

    override fun onStop() {
        super.onStop()
        paper_resolve_data_media_controller.pause();
        paper_resolve_select_media_controller.pause();
        paper_resolve_data_video_view.onActivityStop();
        paper_resolve_select_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        paper_resolve_data_media_controller.disable();
        paper_resolve_select_media_controller.disable();
        paper_resolve_data_video_view.destroy();
        paper_resolve_select_video_view.destroy();
    }

    private fun setQuestionView(info: QuestionPaperInfoEntity) {
        paper_resolve_data_media_controller.resume();
        paper_resolve_select_media_controller.resume();
        paper_resolve_data_video_view.onActivityStop();
        paper_resolve_select_video_view.onActivityStop();
        isCollect = info.isCollect
        isCollectId = info.isCollectId
        if (isCollect == 1) {
            paper_resolve_fav.text = "取消"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
            }
        } else {
            paper_resolve_fav.text = "收藏"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                if (MultiTheme.getAppTheme() == 1){
                    paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                }else{
                    paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                }
            }
        }
        subjectId = info.id
        liftingType = info.liftingType
        changeViewByType(info.liftingType)
        paper_resolve_title.text = info.stem
        if (liftingType != 5) {
            paper_resolve_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            paper_resolve_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }
        question_tv_analyze.text = info.answer
        if (info.isDo) {
            paper_resolve_rl_result.visibility = View.VISIBLE
            paper_resolve_ll_right.visibility = View.VISIBLE
            if (info.isRight == 0) {
                paper_resolve_result.setIconNormal(getDrawable(R.mipmap.icon_answer_right))
                paper_resolve_result.setText("回答正确")
                paper_resolve_ll_error.visibility = View.GONE
            } else {
                paper_resolve_result.setIconNormal(getDrawable(R.mipmap.icon_answer_error))
                paper_resolve_result.setText("回答错误")
                if (MultiTheme.getAppTheme() != 1){
                    paper_resolve_rl_result.background = resources.getDrawable(R.drawable.shape_bg_answer_error)
                }
                paper_resolve_ll_error.visibility = View.VISIBLE
            }
        } else {
            paper_resolve_rl_result.visibility = View.GONE
            paper_resolve_ll_right.visibility = View.VISIBLE
            paper_resolve_ll_error.visibility = View.GONE
        }
        if (info.wdQuestionPaperData != null) {
            if (info.wdQuestionPaperData.size > 0) {
                if (StringUtil.isNotBlank(info.wdQuestionPaperData[0].imageUrl)) {
                    paper_resolve_data_img.visibility = View.VISIBLE
                    Glide.with(this).load(info.wdQuestionPaperData[0].imageUrl)
                        .placeholder(R.drawable.ic_default_pic1)
                        .into(paper_resolve_data_img)
                } else {
                    paper_resolve_data_img.visibility = View.GONE
                }

                if (StringUtil.isNotBlank(info.wdQuestionPaperData[0].videoUrl)) {
                    paper_resolve_data_view_layout.visibility = View.VISIBLE
                    play(
                        info.wdQuestionPaperDataVideo[0].videoUrl,
                        paper_resolve_data_media_controller,
                        paper_resolve_data_video_view,
                        paper_resolve_data_view_layout
                    );
                } else {
                    paper_resolve_data_view_layout.visibility = View.GONE
                }


            } else {
                paper_resolve_data_img.visibility = View.GONE
            }
        }
        if (info.wdQuestionPaperDataVideo != null) {
            if (info.wdQuestionPaperDataVideo.size > 0) {
                if (StringUtil.isNotBlank(info.wdQuestionPaperDataVideo[0].videoUrl)) {
                    paper_resolve_select_view_layout.visibility = View.VISIBLE
                    play(
                        info.wdQuestionPaperDataVideo[0].videoUrl,
                        paper_resolve_select_media_controller,
                        paper_resolve_select_video_view,
                        paper_resolve_select_view_layout
                    );
                } else {
                    paper_resolve_select_view_layout.visibility = View.GONE
                }

            } else {
                paper_resolve_select_view_layout.visibility = View.GONE
            }

        }
        when (liftingType) {
            1, 6 -> {
                setQuestionIndex(index, totalNum, false)
                if (info.wdQuestionPaperOption != null) {
                    initOperationRecycleView(info.wdQuestionPaperOption)
                    paper_resolve_right_result.text = getRightResult(info.wdQuestionPaperOption)
                }

            }
            2 -> {
                setQuestionIndex(index, totalNum, false)
                if (info.wdQuestionPaperOption != null) {
                    initMutOperationRecycleView(info.wdQuestionPaperOption)
                    paper_resolve_right_result.text = getRightResult(info.wdQuestionPaperOption)
                }
            }
             3,4, 7, 8 -> {
                setQuestionIndex(index, totalNum, false)
                if (subIndex < info.wdQuestionPaperSubjectSubordinatesList.size) {
                    setQuestionIndex(
                        subIndex,
                        info.wdQuestionPaperSubjectSubordinatesList.size,
                        true
                    )
                    paper_resolve_stem.text =
                        info.wdQuestionPaperSubjectSubordinatesList[subIndex].stem
                    if (info.wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption != null) {
                        initOperationRecycleView(info.wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption)
                        paper_resolve_right_result.text =
                            getRightResult(info.wdQuestionPaperSubjectSubordinatesList[subIndex].wdQuestionPaperOption)
                    }

                }

            }
            5 -> {
                setQuestionIndex(index, totalNum, false)
            }
        }
    }

    private fun getRightResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            if (liftingType == 1 || liftingType == 3 || liftingType == 4) {
                if (info.rightFlag == 0) {
                    result = info.selectValue
                }
            } else {
                if (info.rightFlag == 0) {
                    result += info.selectValue + ","
                }
            }
        }
        return result
    }

    private fun initOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        singleOperationAdapter = QuestionResolveOperationAdapter(operationList)
        //初始化recyclerView
        paper_resolve_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }

    }

    private fun initMutOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        mutOperationAdapter = QuestionMutResolveAdapter(operationList)
        //初始化recyclerView
        paper_resolve_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
    }

    /**
     * 根据类型更改本地问题布局
     * @param type Int
     */
    private fun changeViewByType(type: Int) {
        when (type) {
            1, 6 -> {
                //单项选择
                paper_resolve_rl_solution.visibility = View.GONE
                paper_resolve_rlv_operation.visibility = View.VISIBLE
                paper_resolve_ll_stem.visibility = View.GONE
            }
            2 -> {
                //多项选择
                paper_resolve_rlv_operation.visibility = View.VISIBLE
                paper_resolve_ll_stem.visibility = View.GONE
                paper_resolve_rl_solution.visibility = View.GONE
            }
            3,4, 7, 8 -> {
                //共用题干
                paper_resolve_ll_stem.visibility = View.VISIBLE
                paper_resolve_rlv_operation.visibility = View.VISIBLE
                paper_resolve_rl_solution.visibility = View.GONE
            }
            5 -> {
                //主观题
                paper_resolve_rlv_operation.visibility = View.GONE
                paper_resolve_ll_stem.visibility = View.GONE
                paper_resolve_rl_solution.visibility = View.VISIBLE
            }
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun createObserver() {
        requestViewModel.questionPracticeResult.observe(this, Observer {
            if (it.isSuccess) {
                CacheUtil.setQuestionResultList(it.listData)
            } else {
                ToastUtils.showShort(it.errMessage)
            }
        })

        requestViewModel.questionSubmitResult.observe(this, Observer {
            if (it.success) {
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.collectResult.observe(this, Observer {
            if (it.success) {
                isCollect = 1
                paper_resolve_fav.text = "取消"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
                }
            } else {
                ToastUtils.showShort(it.message)
            }
        })
        requestViewModel.delCollectResult.observe(this, Observer {
            if (it.success) {
                isCollect = 0
                paper_resolve_fav.text = "收藏"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    if (MultiTheme.getAppTheme() == 1){
                        paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                    }else{
                        paper_resolve_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                    }
                }
            } else {
                ToastUtils.showShort(it.message)
            }
        })

    }

    inner class ProxyClick() {
        /**
         * 答题卡
         */
        fun gotoQuestionResultCardClick() {
            val chooseDialog = PaperScantronDialog.newBuilder(this@PaperResolveActivity,
                object : PaperScantronDialog.OnSubmitClickListener {
                    override fun onSubmitClick(content: Int) {
                        index = content
                        val list = CacheUtil.getQuestionPaperList()
                        if (list.size > 0 && index < list.size) {
                            setQuestionView(list[index ])
                        }

                    }

                })
            chooseDialog.show()
        }

        /**
         * 收藏
         */
        fun favClick() {
            if (isCollect == 1) {
                requestViewModel.delCollect(isCollectId)
            } else {
                val json = JsonObject()
                json.addProperty("subjectId", subjectId)
                json.addProperty("type", 2)
                requestViewModel.addCollect(json)
            }
        }

        /**
         * 笔记
         */
        fun goCreateNoteClick() {
            startActivity(
                Intent(this@PaperResolveActivity, CreateNoteActivity::class.java)
                    .putExtra("id", subjectId)
                    .putExtra("subjectId", subjectId)
                    .putExtra("type", 2)
            )
        }

        fun nextQuestionClick() {
            val list = CacheUtil.getQuestionPaperList()
            if (index < list.size) {
                if (liftingType == 3 || liftingType == 4) {
                    subIndex += 1
                    if (subIndex < list[index].wdQuestionPaperSubjectSubordinatesList.size) {
                        setQuestionView(list[index])
                    } else {
                        subIndex = 0
                        index += 1
                        if (index < list.size) {
                            setQuestionView(list[index])
                        }
                    }
                } else {
                    index += 1
                    if (index < list.size) {
                        setQuestionView(list[index])
                    } else {
                        ToastUtils.showShort("当前为最后一题")
                    }
                }
            }
        }

        fun upQuestionClick() {
            val list = CacheUtil.getQuestionPaperList()
            if (index < list.size) {
                if (liftingType == 3 || liftingType == 4) {
                    subIndex -= 1
                    if (subIndex >= 0) {
                        setQuestionView(list[index])
                    } else {
                        subIndex = list[index].wdQuestionPaperSubjectSubordinatesList.size
                        index -= 1
                        if (index >= 0) {
                            setQuestionView(list[index])
                        } else {
                            ToastUtils.showShort("当前为第一题")
                        }
                    }

                } else {
                    index -= 1
                    if (index >= 0) {
                        setQuestionView(list[index])
                    } else {
                        ToastUtils.showShort("当前为第一题")
                    }
                }
            } else {
                ToastUtils.showShort("当前为第一题")
            }
        }
    }


    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        videoView.setAutoPlay(false)
        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)
        videoView.setMediaController(mediaController)
        videoView.setVid(vid)


        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }

}