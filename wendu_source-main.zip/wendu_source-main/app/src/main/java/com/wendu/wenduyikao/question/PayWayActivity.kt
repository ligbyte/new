package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.TextUtils
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.alipay.sdk.app.PayTask
import com.google.gson.Gson
import com.tencent.mm.opensdk.modelpay.PayReq
import com.tencent.mm.opensdk.openapi.WXAPIFactory
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.PayCountDownTimerUtils
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.LoginEvent
import com.wendu.wenduyikao.data.eventbus.PayResultEvent
import com.wendu.wenduyikao.data.eventbus.TryBuyEvent
import com.wendu.wenduyikao.data.model.bean.AuthResult
import com.wendu.wenduyikao.data.model.bean.PayResult
import com.wendu.wenduyikao.data.model.bean.PayWayEntity
import com.wendu.wenduyikao.data.model.bean.QuestionOrderEntity
import com.wendu.wenduyikao.databinding.ActivityPayWayBinding
import com.wendu.wenduyikao.question.adapter.SelectPayAdapter
import com.wendu.wenduyikao.ui.home.CoursePayActivity
import com.wendu.wenduyikao.ui.study.activity.PaySuccessActivity
import com.wendu.wenduyikao.util.UmengEventUtils
import com.wendu.wenduyikao.viewmodel.request.RequestPayViewModel
import kotlinx.android.synthetic.main.activity_exam.*
import kotlinx.android.synthetic.main.activity_pay_way.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.content_toolbar_view.tv_toolbar_title
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

/**
 * @Author     : xiaoyangyan
 * @Time       : 9/2/21 11:01 AM
 * @Description: 支付方式
 */
class PayWayActivity : BaseActivity<RequestPayViewModel, ActivityPayWayBinding>() {

    private val requestPayViewModel: RequestPayViewModel by viewModels()
    private var paperId = ""
    private var classCourseId = ""
    private var courseClassTypeId = ""
    private var couponId = ""
    private var areaId = ""
    private var orderId = ""
    private var payType = "ali"
    private val SDK_PAY_FLAG = 1
    private val SDK_AUTH_FLAG = 2
    private var price = ""
    private var payForType = 0
    private var mCountDownTimerUtils: PayCountDownTimerUtils? = null
    private var orderEntity: QuestionOrderEntity? = null
    private var isFromOrder = false
    private var ddje = ""
    private var isBookOrder = false

    companion object {
        //        const val CLASS_COURSE_ID = "classCourseId"
//        const val COURSE_CLASS_TYPE_ID = "courseClassTypeId"
//        const val COUPON_ID = "couponId"
//        const val AREA_ID = "areaId"
        const val ORDER_ID = "orderId"
        const val ORDER_ENTITY = "orderEntity"
        fun toThis(
            activity: Context,
            classCourseId: String,
            courseClassTypeId: String,
            couponId: String,
            areaId: String
        ) {
            val intent = Intent(activity, PayWayActivity::class.java)
//            intent.putExtra(CLASS_COURSE_ID, classCourseId)
//            intent.putExtra(COURSE_CLASS_TYPE_ID, courseClassTypeId)
//            intent.putExtra(COUPON_ID, couponId)
//            intent.putExtra(AREA_ID, areaId)

            activity.startActivity(intent)
        }

        fun toThis(activity: Context, orderId: String, orderEntity: String) {
            val intent = Intent(activity, PayWayActivity::class.java)
            intent.putExtra(ORDER_ID, orderId)
            intent.putExtra(ORDER_ENTITY, orderEntity)

            activity.startActivity(intent)
        }
    }

    override fun layoutId() = R.layout.activity_pay_way

    override fun initView(savedInstanceState: Bundle?) {
        EventBus.getDefault().register(this)
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, pay_way_ll_content)
        tv_toolbar_title.text = "收银台"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        mCountDownTimerUtils = PayCountDownTimerUtils(tv_count_down, 30 * 60 * 1000, 1000)
        mCountDownTimerUtils?.start()
        if (intent.getStringExtra("paperId") != null) {
            paperId = intent.getStringExtra("paperId").toString()
        }
        Log.v("yxy", "==classCourseId1=" + classCourseId)
        classCourseId = intent.getStringExtra("courseClassId") ?: ""
        Log.v("yxy", "==classCourseId2=" + classCourseId)
        if (intent.getStringExtra(ORDER_ID) != null) {
            orderId = intent.getStringExtra(ORDER_ID).toString()

            orderEntity = Gson().fromJson(
                intent.getStringExtra(ORDER_ENTITY), QuestionOrderEntity::class.java
            )
            if (orderEntity != null) {
                ddje = orderEntity!!.sfje.toString()
                price = orderEntity!!.sfje.toString()
                pay_way_price.text = StringUtil.formatDoublePrice(orderEntity!!.sfje)
            }
        }
        isFromOrder = intent.getBooleanExtra("isFromOrder", false)
        isBookOrder = intent.getBooleanExtra("isBookOrder", false)
        if (isFromOrder) {
            price = intent.getStringExtra("price").toString()
            ddje = intent.getStringExtra("price").toString()
            orderId = intent.getStringExtra("orderId").toString()
            pay_way_price.text = "¥${price}"
        } else {
            if (StringUtil.isNotBlank(paperId)) {
                requestPayViewModel.createQuestionOrder(paperId)
            }
            if (StringUtil.isNotBlank(classCourseId)) {
                requestPayViewModel.createCourseOrder(
                    classCourseId, courseClassTypeId, couponId, areaId
                )
            }
        }

        initRecycleView()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
    }

    private fun initRecycleView() {
        val list = arrayListOf<PayWayEntity>()
        var pay = PayWayEntity()
        pay.img = R.mipmap.ic_pay_ali
        pay.type = "ali"
        pay.label = "支付宝支付"
        list.add(pay)
        pay = PayWayEntity()
        pay.img = R.mipmap.ic_pay_wechat
        pay.label = "微信支付"
        pay.type = "wechat"
        list.add(pay)
//        pay = PayWayEntity(
        val payAdapter = SelectPayAdapter(list)
        payAdapter.setPosition(0)
        //初始化recyclerView
        rlv_pay_way.init(
            LinearLayoutManager(this), payAdapter
        )
        payAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: PayWayEntity = adapter.getItem(position) as PayWayEntity
                payType = info.type
                payAdapter.setPosition(position)
                payAdapter.notifyDataSetChanged()
            }
        }
    }


    override fun createObserver() {
        requestPayViewModel.payResult.observe(this, Observer {
            //异步调起支付
            val payRunnable = Runnable {
                kotlin.run {
                    val alipay = PayTask(this)
                    val result = alipay.payV2(
                        it, true
                    )//传入true表示用户在商户app内部点击付款，是否需要一个 loading 做为在钱包唤起之前的过渡，这个值设置为 true，将会在调用 pay 接口的时候直接唤起一个 loading，直到唤起H5支付页面或者唤起外部的钱包付款页面 loading 才消失
                    val msg = Message()
                    msg.what = SDK_PAY_FLAG
                    msg.obj = result
                    mHandler.sendMessage(msg)
                }
            }

            // 必须异步调用
            val payThread = Thread(payRunnable)
            payThread.start()
        })


        requestPayViewModel.wxPayResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                val req = PayReq()

                req.appId = it.appid //（应用签约时生成）
                req.partnerId = it.partnerid //（商户号）
                req.prepayId = it.prepayid // (服务器字段)
                req.nonceStr = it.noncestr// (服务器字段)
                req.timeStamp = it.timestamp // (服务器字段)
                req.sign = it.sign // (服务器字段)
                req.packageValue = "Sign=WXPay" // (固定写法，目前不知道该字段何用，可能是SDK里面需要校验)

                val api = WXAPIFactory.createWXAPI(this, Constants.WX_APP_ID) // 获取到微信支付api对象

                api.sendReq(req)
            })
        })
        requestPayViewModel.questionOrderResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    orderId = it.id
                    orderEntity = it
                    ddje = StringUtil.formatDouble(it.ddje)
                    price = StringUtil.formatDouble(it.ddje)
                    pay_way_price.text = StringUtil.formatDoublePrice(it.ddje)
                }
            })
        })
    }

    inner class ProxyClick() {
        fun gotoPay() {
            when (payType) {
                "ali" -> {
                    if (isBookOrder) {
                        requestPayViewModel.bookOrderAliPay(orderId)
                    } else {
                        requestPayViewModel.aliPay(orderId)
                    }
                }
                "wechat" -> {
                    if (isBookOrder) {
                        requestPayViewModel.bookOrderWxPay(orderId)
                    } else {
                        requestPayViewModel.wxPay(orderId)
                    }
                }
            }

        }
    }

    @SuppressLint("HandlerLeak")
    private val mHandler = object : Handler() {
        override fun handleMessage(msg: Message) {
            Log.v("yxy", "handleMessage===>" + msg.what)
            when (msg.what) {
                SDK_PAY_FLAG -> {
                    val payResult = PayResult(msg.obj as Map<String, String>)

                    /**
                     * 对于支付结果，请商户依赖服务端的异步通知结果。同步通知结果，仅作为支付结束的通知。
                     */
                    val resultInfo: String = payResult.result // 同步返回需要验证的信息
                    val resultStatus: String = payResult.resultStatus
                    // 判断resultStatus 为9000则代表支付成功
                    if (TextUtils.equals(resultStatus, "9000")) {
                        // 该笔订单是否真实支付成功，需要依赖服务端的异步通知。
                        Log.v("yxy", "pay_success===>" + resultInfo)
                        val priceStr = ddje
                        if (StringUtil.isNotBlank(classCourseId)) {


                            val courseClassPrice =
                                intent.getDoubleExtra(CoursePayActivity.COURSE_CLASS_PRICE, 0.0)
                            val isNeedUpdateAddress =
                                intent.getBooleanExtra("isNeedUpdateAddress", false)
                            val intent = Intent(this@PayWayActivity, PaySuccessActivity::class.java)

                            intent.putExtra(PaySuccessActivity.PAY_TYPE, PaySuccessActivity.COURSE)
                            intent.putExtra(PaySuccessActivity.PRICE, priceStr.toString())
                            intent.putExtra("isNeedUpdateAddress", isNeedUpdateAddress)
                            intent.putExtra("orderId", orderId)
                            intent.putExtra("isBookOrder",isBookOrder)
                            startActivity(intent)
                            //加这个是为了 购课成后刷新课程列表
                            EventBus.getDefault().postSticky(LoginEvent())

                        } else {

                            UmengEventUtils.onEventObject("pay_order","", "支付完成", orderId)
                            if (CacheUtil.isTryBuy()){
                                CacheUtil.setTryBuy(false)
                                Log.d("TAG", "PaySuccessActivitycreateObserver :  305 ")
                                PaySuccessActivity.toThis(this@PayWayActivity, PaySuccessActivity.COURSE_FREE, "")
                                EventBus.getDefault().post(TryBuyEvent())
                                finish();
                                return
                            }
                            Log.d("TAG", "PaySuccessActivitycreateObserver :  311 ")
                            PaySuccessActivity.toThis(
                                this@PayWayActivity,
                                PaySuccessActivity.CQUESTION,
                                priceStr.toString()
                            )
                        }

                        finish()
                    } else {
                        // 该笔订单真实的支付结果，需要依赖服务端的异步通知。
                        Log.v("yxy", "pay_failed===>" + payResult)
                    }
                }
                SDK_AUTH_FLAG -> {
                    val authResult = AuthResult(msg.obj as Map<String?, String?>, true)
                    val resultStatus: String = authResult.getResultStatus()

                    // 判断resultStatus 为“9000”且result_code
                    // 为“200”则代表授权成功，具体状态码代表含义可参考授权接口文档
                    if (TextUtils.equals(
                            resultStatus, "9000"
                        ) && TextUtils.equals(authResult.getResultCode(), "200")
                    ) {
                        // 获取alipay_open_id，调支付时作为参数extern_token 的value
                        // 传入，则支付账户为该授权账户\
                        Log.v("yxy", "auth_success===>" + authResult)
                    } else {
                        // 其他状态值则为授权失败
                        Log.v("yxy", "auth_failed===>" + authResult)
                    }
                }
                else -> {
                }
            }
        }
    }

    /**
     * 接收支付成功或者支付失败的结果
     */
    @Subscribe(threadMode = ThreadMode.MAIN)
    fun paymentResult(event: PayResultEvent) {
        if (event.isSuccess) {
            Log.v("yxy", "==classCourseId=" + classCourseId)
            if (StringUtil.isNotBlank(classCourseId)) {

                val courseClassPrice =
                    intent.getDoubleExtra(CoursePayActivity.COURSE_CLASS_PRICE, 0.0)
                val isNeedUpdateAddress = intent.getBooleanExtra("isNeedUpdateAddress", false)
                val intent = Intent(this@PayWayActivity, PaySuccessActivity::class.java)

                intent.putExtra(PaySuccessActivity.PAY_TYPE, PaySuccessActivity.COURSE)
                intent.putExtra(PaySuccessActivity.PRICE, price.toString())
                intent.putExtra("isNeedUpdateAddress", isNeedUpdateAddress)
                intent.putExtra("courseClassPrice", courseClassPrice)
                intent.putExtra("orderId", orderId)
                intent.putExtra("isBookOrder",isBookOrder)
                startActivity(intent)
            } else {
                UmengEventUtils.onEventObject("pay_order","", "支付完成", orderId)
                if (CacheUtil.isTryBuy()){
                    CacheUtil.setTryBuy(false)
                    Log.d("TAG", "PaySuccessActivitycreateObserver :  374 ")
                    PaySuccessActivity.toThis(this, PaySuccessActivity.COURSE_FREE, "")
                    EventBus.getDefault().post(TryBuyEvent())
                    finish();
                    return
                }
                Log.d("TAG", "PaySuccessActivitycreateObserver :  380 ")
                PaySuccessActivity.toThis(
                    this@PayWayActivity, PaySuccessActivity.CQUESTION, price.toString()
                )
            }
        }
        finish()
    }

}