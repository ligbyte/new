package com.wendu.wenduyikao.question

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.*
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.view.isVisible
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.afollestad.materialdialogs.MaterialDialog
import com.azhon.appupdate.utils.ScreenUtil
import com.blankj.utilcode.util.*
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.easefun.polyvsdk.fragment.PolyvPlayerDanmuFragment
import com.easefun.polyvsdk.player.PolyvPlayerMediaController
import com.easefun.polyvsdk.player.PolyvPlayerPreviewView
import com.easefun.polyvsdk.util.PolyvScreenUtils
import com.easefun.polyvsdk.video.PolyvVideoView
import com.easefun.polyvsdk.video.listener.IPolyvOnPlayPauseListener
import com.easefun.polyvsdk.video.listener.IPolyvOnPreparedListener2
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.huawei.hms.push.utils.JsonUtil
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.init
import com.wendu.wenduyikao.app.network.ApiService
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.RefreshErrorQuestionEvent
import com.wendu.wenduyikao.data.model.bean.QuestionInfoEntity
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.SubjectFileEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionDbEntity
import com.wendu.wenduyikao.databinding.ActivityQuestionAnswerBinding
import com.wendu.wenduyikao.dialog.RecoveryErrorDialog
import com.wendu.wenduyikao.dialog.ScantronDialog
import com.wendu.wenduyikao.dialog.SettingsDialog
import com.wendu.wenduyikao.question.adapter.QuestionMutOperationAdapter
import com.wendu.wenduyikao.question.adapter.QuestionOperationAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestQuestionViewModel
import kotlinx.android.synthetic.main.activity_question_answer.*
import kotlinx.android.synthetic.main.content_toolbar_view.img_back
import me.xiaoyang.base.ext.parseState
import me.xiaoyang.base.ext.util.setOnclickNoRepeat
import org.greenrobot.eventbus.EventBus
import org.litepal.LitePal
import com.ligbyte.lib.theme.ActivityTheme
import com.ligbyte.lib.theme.MultiTheme
import com.nirvana.tools.jsoner.JsonHelper
import com.wendu.wenduyikao.BuildConfig
import com.wendu.wenduyikao.app.event.LoginWeiXinEvent
import com.wendu.wenduyikao.data.eventbus.TestPaperSubmitSuccessEvent
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.dialog.bottom_sheet.BaseBottomSheetDialog
import com.wendu.wenduyikao.util.FastClickUtils
import com.wendu.wenduyikao.util.RxSimple
import kotlinx.android.synthetic.main.activity_exam_answer.*
import kotlinx.android.synthetic.main.activity_question_answer.question_tv_analyze
import kotlinx.android.synthetic.main.activity_question_answer.queston_answer_rl_result
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode


/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 3:25 PM
 * @Description: 问题解析
 */
class QuestionAnswerActivity :
    BaseActivity<RequestQuestionViewModel, ActivityQuestionAnswerBinding>() {

    private val requestViewModel: RequestQuestionViewModel by viewModels()
    private var chapterId = "" //章节id
    private var templateId = ""
    private var optionId = ""  //选项id
    private var id = ""
    private var favType = 0
    private var subjectId = ""//题干id
    private var parentId = ""//主题干id
    private var isCollectId = ""//题干id
    private var mCurPosY = 0.0f
    private var mPosY = 0.0f
    private var mCurPosX = 0.0f
    private var mPosX = 0.0f
    //    private var isAnswer: Boolean = true   // true 答题模式; false 背题模式
    private var answerType = 1   //1 答题，2背题 3 解析模式
    private var isAnswer = false   //当前题目是否已答
    private var isCollect = 0 //0未收藏 1收藏
    private var type = 1   //1章节  2 试题
    private var index = 1//已经完结的题目索引
    private var isRight = 0//已经完结的题目索引
    private var queIndex = 0//已经完结的题目索引
    private var totalNum = 0  //题目总数
    private var liftingType = 1  //当前题目类型
    private var isMultiple = false; //共用题干类型下是否为多选
    lateinit var dialog: MaterialDialog
    private var solution = "" //主观题答案
    private var goNext = true //多选逻辑，需要做次校验
    private var from = Constants.PARAMS_QUESTION_SOURCE_CHAPTER
    private var selectOptions = arrayListOf<QuestionOptionEntity>()
    private val maxLen = 100 // the max byte
    private var isCheckResult = false  //多选是否选择完毕
    private var editStart = 0
    private var editEnd = 0
    private var isSeeAll = true//查看全部
    private var js = "<script type=\"text/javascript\">" +
            "var imgs = document.getElementsByTagName('img');" +  // 找到img标签
            "for(var i = 0; i<imgs.length; i++){" +  // 逐个改变
            "imgs[i].style.width = '100%';" +  // 宽度改为100%
            "imgs[i].style.height = 'auto';" +
            "}" +
            "</script>"
    var questionSettingsDialog: BaseBottomSheetDialog? = null

    //适配器
    private var mutOperationAdapter: QuestionMutOperationAdapter = QuestionMutOperationAdapter(
        arrayListOf()
    )
    private var singleOperationAdapter: QuestionOperationAdapter = QuestionOperationAdapter(
        arrayListOf()
    )

    override fun layoutId() = R.layout.activity_question_answer


    override fun initView(savedInstanceState: Bundle?) {
        if (MultiTheme.getAppTheme() == 1){
            StatusBarUtil.setDarkMode(this)
        }else{
            StatusBarUtil.setLightMode(this)
        }
        StatusBarUtil.setPaddingSmart(this, question_answer_ll_content)
        Constants.questionTextSize = (SPUtils.getInstance().getFloat("fontSize",50f) - 50)/100 * 4 *2
        setTextSize()
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        initWebView()
        totalNum = intent.getIntExtra("total", 0)
        from = intent.getStringExtra("from").toString()
        if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER) {
            question_answer_rbt_answer.visibility = View.VISIBLE
            answerType = 1
            chapterId = intent.getStringExtra("chapterId").toString()
            templateId = intent.getStringExtra("templateId").toString()
            requestViewModel.getQuestionChapterSubjectList(chapterId, templateId)
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_NOTE) {
            answerType = 2
            mDatabind.click = ProxyClick()
            question_answer_toolbar_title.text = "答题解析"
            question_answer_rg_menu.visibility = View.GONE
            val id = intent.getStringExtra("id").toString()
            requestViewModel.getQuerySubjectByNote(id)
            setQuestionIndex(1, 1, false)
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
            answerType = 2
            mDatabind.click = ProxyClick()
            question_answer_rg_menu.visibility = View.GONE
            question_answer_toolbar_title.text = "答题解析"
            val id = intent.getStringExtra("id").toString()
            requestViewModel.getQuestionChapterById(id)
            setQuestionIndex(1, 1, false)
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {
            favType = intent.getIntExtra("favType", 0)
            answerType = 1

            question_answer_rbt_recite.visibility = View.VISIBLE
            question_answer_rbt_answer.visibility = View.VISIBLE
            val info =
                LitePal.where("position =?", "1")
                    .findFirst(QuestionDbEntity::class.java)
            index = 1
            if (info != null) {
                setQuestionIndex(1, totalNum, false)
                Log.d("TAG", "setQuestionView22 193: " + info.dataList)
                setQuestionView2(info)
            }
        } else if (from == Constants.PARAMS_QUESTION_SOURCE_CARD) {
            answerType = 2
            question_answer_rg_menu.visibility = View.GONE
            val position = intent.getIntExtra("index", 0)
            val total = intent.getIntExtra("total", 0)
            val info =
                LitePal.where("position =?", position.toString())
                    .findFirst(QuestionDbEntity::class.java)
            if (info != null) {
                setQuestionIndex(position, total, false)
                Log.d("TAG", "setQuestionView22: " + 205)
                setQuestionView2(info)
            }

        } else if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE) {
            answerType = 3
            mDatabind.click = ProxyClick()
            question_answer_rg_menu.visibility = View.GONE
            question_answer_error.visibility = View.VISIBLE
            index = 1

            question_answer_toolbar_title.text = "答题解析"
            val info =
                LitePal.where("position =?", index.toString())
                    .findFirst(QuestionDbEntity::class.java)
            if (info != null) {
                Log.d("TAG", "setQuestionView22: " + 222)
                setQuestionView2(info)
            }

        } else if (from == Constants.PARAMS_QUESTION_RESULT) {
            answerType = 3
            mDatabind.click = ProxyClick()
            question_answer_rg_menu.visibility = View.GONE
            question_answer_error.visibility = View.VISIBLE
            index = intent.getIntExtra("index", 1)
            question_answer_toolbar_title.text = "答题解析"
            val info =
                LitePal.where("position =?", index.toString())
                    .findFirst(QuestionDbEntity::class.java)
            if (info != null) {
                Log.d("TAG", "setQuestionView22: " + 222)
                setQuestionView2(info)
            }

        } else {
            question_answer_rbt_answer.visibility = View.GONE
            answerType = 2
            chapterId = intent.getStringExtra("chapterId").toString()
            templateId = intent.getStringExtra("templateId").toString()
            requestViewModel.getQuestionChapterSubjectList(chapterId, templateId)
        }
//        initQuestionView()
        initEvent()
        editTextMaxLengthListener()
        setIconFont(exam_up,"\ue62e")
        setIconFont(question_answer_submit_next,"\ue62f")
    }

    private fun initEvent() {
        question_answer_rg_menu.setOnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.question_answer_rbt_answer -> {
                    answerType = 1
                    val info =
                        LitePal.where("position =?", index.toString())
                            .findFirst(QuestionDbEntity::class.java)
                    if (info != null) {
                        setQuestionView2(info)
                    }
                }
                R.id.question_answer_rbt_recite -> {
                    answerType = 2
                    if (MultiTheme.getAppTheme() != 1){
                        ll_question_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_right)
                    }
                }
            }
            initQuestionViewByAnswer()
        }
    }

    private fun initQuestionViewByAnswer() {
        if (answerType == 1) {
            question_answer_resolve.visibility = View.GONE
            question_answer_ll_right.visibility = View.VISIBLE
        } else if (answerType == 2) {
            question_answer_resolve.visibility = View.VISIBLE
            question_answer_ll_right.visibility = View.VISIBLE
            queston_answer_rl_result.visibility = View.GONE
            question_answer_ll_error.visibility = View.GONE
        } else if (isAnswer || answerType == 3) {
            question_answer_resolve.visibility = View.VISIBLE
            question_answer_ll_right.visibility = View.VISIBLE
        }
        if (liftingType == 1 || liftingType == 4 || (liftingType == 3 && !isMultiple) || liftingType == 6 || liftingType == 7 || liftingType == 8) {
            if (question_answer_rg_menu.checkedRadioButtonId == R.id.question_answer_rbt_recite){
                singleOperationAdapter.setAnswer(2)
            }else{
                singleOperationAdapter.setAnswer(answerType)
            }
            singleOperationAdapter.notifyDataSetChanged()
        } else if (liftingType == 2 || (liftingType == 3 && isMultiple)) {
            if (question_answer_rg_menu.checkedRadioButtonId == R.id.question_answer_rbt_recite){
                mutOperationAdapter.setAnswer(2)
            }else{
                mutOperationAdapter.setAnswer(answerType)
            }

            mutOperationAdapter.notifyDataSetChanged()
        }
    }

    /**
     * 判断试题是否能进入题库
     */
    private fun isSaveDB(info: QuestionInfoEntity) {
        when (info.liftingType) {
            3, 4, 7, 8 -> {
                for (sub in info.questionList) {

                }
            }
            else -> {

            }

        }
        false
    }

    override fun createObserver() {
        requestViewModel.errorCorrectionResult.observe(this, Observer {
            if (it.success) {
                ToastUtils.showShort("提交成功")
                questionSettingsDialog?.dismiss()
            }})

        requestViewModel.questionListResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    LitePal.deleteAll(QuestionDbEntity::class.java)
                    val info = it.list[0].list[0]
                    id = info.id
                    var position = 0
                    var questionIndex = 0
                    var total = 0
                    for (info in it.list) {
                        for (quest in info.list) {
                            total += 1
                        }
                    }
                    for (info in it.list) {
                        for (quest in info.list) {
                            when (quest.liftingType) {
                                3, 4, 7, 8 -> {
                                    var subIndex = 0
                                    questionIndex += 1
                                    for (sub in quest.questionList) {
                                        position += 1
                                        subIndex += 1
                                        val questionDb = QuestionDbEntity()
                                        questionDb.chapterId = quest.chapterId
                                        questionDb.liftingType = quest.liftingType
                                        questionDb.templateId = quest.templateId
                                        questionDb.answer = sub.answerTxt
                                        questionDb.isCollect = quest.isCollect
                                        questionDb.total = total
                                        questionDb.facilityValue = sub.facilityValue
                                        questionDb.answerText = sub.answerText
                                        if (StringUtil.isNotBlank(quest.isCollectId)) {
                                            questionDb.isCollectId = quest.isCollectId
                                        }
                                        questionDb.questionId = sub.id
                                        questionDb.parentId = quest.id
                                        questionDb.stem = quest.stem
                                        questionDb.name = quest.name
                                        questionDb.score = quest.score
                                        questionDb.questionIndex = questionIndex
                                        questionDb.index = "$questionIndex-$subIndex"
                                        questionDb.childStem = sub.stem
                                        if (sub.wdQuestionChapterPractice != null) {
                                            questionDb.wdQuestionChapterPractice =
                                                GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                        }

                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)
                                        Log.d("TAG", "jeek quest.dataList 347: " + (quest.dataList != null))
                                        if (quest.dataList != null) {
                                            questionDb.dataList = GsonUtils.toJson(quest.dataList)
                                        }
                                        if (sub.selectList != null) {
                                            questionDb.selectList =
                                                GsonUtils.toJson(sub.selectList)
                                        }
                                        questionDb.childIndex =
                                            "$subIndex/ ${quest.questionList.size}"
                                        questionDb.position = position
                                        questionDb.optionList = GsonUtils.toJson(sub.optionList)

                                        questionDb.save()

                                        if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(
                                                it.subjectId
                                            )
                                        ) {
                                            if (it.subjectId == sub.id) {
                                                index = position + 1
                                            }
//                                            Log.v(
//                                                "yxy",
//                                                "===duoxuan===index==" + index + quest.isCollectId.toString()
//                                            )
                                        }
                                    }

                                }
                                else -> {
                                    questionIndex += 1
                                    position += 1
//                                    Log.v(
//                                        "yxy",
//                                        "===quest.liftingType=2=" + quest.liftingType + "position" + position + "====" + questionIndex
//                                    )
                                    val questionDb = QuestionDbEntity()
                                    questionDb.chapterId = quest.chapterId
                                    questionDb.liftingType = quest.liftingType
                                    questionDb.isCollect = quest.isCollect
                                    questionDb.parentId = quest.id
                                    questionDb.stem = quest.stem
                                    questionDb.answer = quest.answerTxt
                                    questionDb.answerText = quest.answerText
                                    questionDb.templateId = quest.templateId
                                    questionDb.name = quest.name
                                    questionDb.questionId = quest.id
                                    questionDb.total = total
                                    questionDb.score = quest.score
                                    questionDb.facilityValue = quest.facilityValue
                                    questionDb.position = position
                                    questionDb.index = questionIndex.toString()
                                    if (StringUtil.isNotBlank(quest.isCollectId)) {
                                        questionDb.isCollectId = quest.isCollectId
                                    }
                                    questionDb.questionIndex = questionIndex
                                    if (quest.wdQuestionChapterPractice != null) {
                                        questionDb.wdQuestionChapterPractice =
                                            GsonUtils.toJson(quest.wdQuestionChapterPractice)
                                    }
                                    if (quest.liftingType == 5) {
                                        questionDb.topicCategory = quest.topicCategory
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeBy5(quest.topicCategory)
                                    } else {
                                        questionDb.typeLabel =
                                            StringUtil.getSubjectTypeByType(quest.liftingType)
                                    }

                                    questionDb.index = questionIndex.toString()
                                    Log.d("TAG", "jeek quest.dataList 418: " + (quest.dataList != null))
                                    if (quest.dataList != null) {
                                        questionDb.dataList = GsonUtils.toJson(quest.dataList)
                                    }
                                    if (quest.selectList != null) {
                                        questionDb.selectList =
                                            GsonUtils.toJson(quest.selectList)
                                    }

                                    questionDb.optionList = GsonUtils.toJson(quest.optionList)
                                    questionDb.save()
                                    if (it.liftingType == quest.liftingType && StringUtil.isNotBlank(
                                            it.subjectId
                                        )
                                    ) {
                                        if (it.subjectId == quest.id) {
                                            index = position + 1
                                        }
                                    }
                                }
                            }
                        }
                    }

                    totalNum = LitePal.count(QuestionDbEntity::class.java)
                    if (index <= totalNum) {
                        Log.d("TAG", "setQuestionView22: " + 443)
                        setQuestionView2(
                            LitePal.where("position=?", index.toString())
                                .findLast(QuestionDbEntity::class.java)
                        )
                    } else {
                        gotoSubmitQuestion()
                    }

                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })
        requestViewModel.noteQuestionInfoResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                LitePal.deleteAll(QuestionDbEntity::class.java)
                if (it != null) {
                    totalNum = 1
                    var position = 0
                    var questionIndex = 0
                    when (it.liftingType) {
                        3, 4, 7, 8 -> {
                            var subIndex = 0
                            questionIndex += 1
                            for (sub in it.questionList) {
                                position += 1
                                subIndex += 1
                                val questionDb = QuestionDbEntity()
                                questionDb.position = position
                                questionDb.questionIndex = 1
                                questionDb.chapterId = it.chapterId
                                questionDb.liftingType = it.liftingType
                                questionDb.templateId = it.templateId
                                questionDb.answer = sub.answerTxt
                                questionDb.isCollect = it.isCollect
                                questionDb.parentId = it.id
                                questionDb.answerText = sub.answerText
                                questionDb.questionId = sub.id
                                questionDb.total = 1
                                questionDb.stem = it.stem
                                questionDb.score = it.score
                                questionDb.name = it.name
                                questionDb.facilityValue = sub.facilityValue
                                if (StringUtil.isNotBlank(it.isCollectId)) {
                                    questionDb.isCollectId = it.isCollectId
                                }
                                questionDb.index = "$questionIndex-$subIndex"
                                questionDb.childStem = sub.stem
                                if (sub.wdQuestionChapterPractice != null) {
                                    questionDb.wdQuestionChapterPractice =
                                        GsonUtils.toJson(sub.wdQuestionChapterPractice)
                                }
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeByType(it.liftingType)

                                if (it.dataList != null) {
                                    questionDb.dataList = GsonUtils.toJson(it.dataList)
                                }
                                if (sub.selectList != null) {
                                    questionDb.selectList = GsonUtils.toJson(sub.selectList)
                                }
                                questionDb.childIndex =
                                    "$subIndex/ ${it.questionList.size}"
                                questionDb.optionList = GsonUtils.toJson(sub.optionList)
                                Log.d("TAG", "setQuestionView22 508: " + questionDb.dataList)
                                questionDb.save()
                            }
                        }
                        else -> {
                            questionIndex += 1
                            position += 1
                            val questionDb = QuestionDbEntity()
                            questionDb.position = position
                            questionDb.questionIndex = 1
                            questionDb.total = 1
                            questionDb.parentId = it.id
                            questionDb.chapterId = it.chapterId
                            questionDb.liftingType = it.liftingType
                            questionDb.isCollect = it.isCollect
                            questionDb.stem = it.stem
                            questionDb.answer = it.answerTxt
                            questionDb.answerText = it.answerText
                            questionDb.facilityValue = it.facilityValue
                            questionDb.templateId = it.templateId
                            questionDb.name = it.name
                            questionDb.score = it.score
                            questionDb.questionId = it.id
                            if (StringUtil.isNotBlank(isCollectId)) {
                                questionDb.isCollectId = it.isCollectId
                            }

                            if (it.wdQuestionChapterPractice != null) {
                                questionDb.wdQuestionChapterPractice =
                                    GsonUtils.toJson(it.wdQuestionChapterPractice)
                            }
                            if (it.liftingType == 5) {
                                questionDb.topicCategory = it.topicCategory
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeBy5(it.topicCategory)
                            } else {
                                questionDb.typeLabel =
                                    StringUtil.getSubjectTypeByType(it.liftingType)
                            }
                            questionDb.index = questionIndex.toString()
                            if (it.dataList != null) {
                                questionDb.dataList = GsonUtils.toJson(it.dataList)
                            }
                            if (it.selectList != null) {
                                questionDb.selectList = GsonUtils.toJson(it.selectList)
                            }
                            questionDb.optionList = GsonUtils.toJson(it.optionList)
                            questionDb.save()

                        }


                    }
                    Log.v(
                        "yxy",
                        "===" + index + "--" + totalNum + "===" + LitePal.count(QuestionDbEntity::class.java)
                    )
                    totalNum = 1
                    index = 1
                    if (index <= totalNum) {
                        Log.d("TAG", "setQuestionView22 568: " + GsonUtils.toJson(LitePal.where("position=?", index.toString())
                            .findLast(QuestionDbEntity::class.java)))
                        setQuestionView2(
                            LitePal.where("position=?", index.toString())
                                .findLast(QuestionDbEntity::class.java)
                        )
                    }
                }
            }, {
                ToastUtils.showShort(it.errorMsg)
            })
        })

        requestViewModel.questionSubmitResult.observe(this, Observer {
            if (it.success) {
                if (from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {
                    EventBus.getDefault().post(RefreshErrorQuestionEvent())
                }
            } else {
                ToastUtils.showShort(it.message)
            }
        })

        requestViewModel.collectResult.observe(this, Observer {
            isCollect = 1
            isCollectId = it.toString()
            question_answer_fav.text = "取消"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
            }
            val questionIndex = queIndex
            val list = LitePal.where("questionIndex =?", questionIndex.toString()).find(
                QuestionDbEntity::class.java
            )
            if (list != null) {
                for (info in list) {
                    info.isCollect = isCollect
                    info.isCollectId = isCollectId
                    info.save()
                }
            }
        })


        requestViewModel.delcollectResult.observe(this, Observer {
            if (it.success) {
                isCollect = 0
                isCollectId = ""
                question_answer_fav.text = "收藏"
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                    if (MultiTheme.getAppTheme() == 1){
                        question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                    }else{
                        question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                    }
                }
                val questionIndex = queIndex
                val list = LitePal.where("questionIndex =?", questionIndex.toString()).find(
                    QuestionDbEntity::class.java
                )
                if (list != null) {
                    for (info in list) {
                        Log.v(
                            "yxy",
                            "===delcollectResult==" + isCollect + "==id=" + info.questionId + "====" + questionIndex + "=position==" + info.position
                        )
                        info.isCollect = isCollect
                        info.isCollectId = isCollectId
                        info.save()
                    }
                }
                val info =
                    LitePal.where("questionIndex =?", questionIndex.toString()).findFirst(
                        QuestionDbEntity::class.java
                    )
            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }


    private fun setQuestionView2(info: QuestionDbEntity) {
        selectOptions = arrayListOf()
        optionId = ""
        isRight = 0
        isCheckResult = false
        goNext = true
        question_answer_data_media_controller.resetView();
        question_answer_select_media_controller.resume();
        question_answer_data_video_view.onActivityStop();
        question_answer_select_video_view.onActivityStop();
        liftingType = info.liftingType
        index = info.position
        Log.d("TAG", "jeek parentId: " + parentId)
        queIndex = info.questionIndex

        if (info.facilityValue > 0) {
            StringUtil.setLevel(info.facilityValue, question_answer_img_level)
        }
        if (StringUtil.isNotBlank(info.chapterId)) {
            chapterId = info.chapterId
        }
        isCollect = info.isCollect
        question_answer_edt_solution.setText("")
        question_answer_fav.text = "收藏"
        if (isCollect == 0) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                if (MultiTheme.getAppTheme() == 1){
                    question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
                }else{
                    question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
                }
                question_answer_fav.text = "收藏"
            }
        } else {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_selected)
                question_answer_fav.text = "取消"
            }
        }
        isCollectId = info.isCollectId

        question_answer_title.text = info.stem
        parentId = info.parentId
//        question_tv_analyze.text = info.answer
//        if(StringUtil.isNotBlank(info.answer)){
//            question_tv_analyze.visibility=View.VISIBLE
//            question_tv_analyze.loadDataWithBaseURL(
//                null,
//                info.answer+js, "text/html; charset=UTF-8", null, null
//            );
//        }else{
//            question_tv_analyze.visibility=View.GONE
//        }


        question_answer_tv_statistics.text = info.answerText
        if (liftingType != 5) {
            question_answer_type.text = StringUtil.getSubjectTypeByType(info.liftingType)
        } else {
            question_answer_type.text = StringUtil.getSubjectTypeBy5(info.topicCategory)
        }

        subjectId = info.questionId
        updateWebview()
        val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
        val oprationList =
            Gson().fromJson<ArrayList<QuestionOptionEntity>>(info.optionList, turnsType)
        var mutSize = 0

        if (oprationList != null) {
            for (ope in oprationList) {
                if (ope.rightFlag == 0) {
                    mutSize += 1
                }
            }
        }

        isMultiple = mutSize > 1
        Log.v("yxy", "mutSize" + mutSize + "==isMultiple=" + isMultiple)
        val operation = RequestOptions().centerCrop().transform(RoundedCorners(5))
        question_answer_data_view_layout.visibility = View.GONE
        question_answer_data_img.visibility = View.GONE
        Log.d("TAG", "question_answer_data_img 722: " + info.dataList)
        if (StringUtil.isNotBlank(info.dataList)) {
            val turnsType = CacheUtil.genericType<ArrayList<SubjectFileEntity>>()
            val dataList =
                Gson().fromJson<ArrayList<SubjectFileEntity>>(info.dataList, turnsType)
            Log.d("TAG", "question_answer_data_img: " + 727)
            if (dataList.size > 0) {
                Log.d("TAG", "question_answer_data_img: " + 728)
                if (dataList[0].materialType == "2") {
                    question_answer_data_view_layout.visibility = View.VISIBLE
                    play(
                        dataList[0].videoUrl,
                        question_answer_data_media_controller,
                        question_answer_data_video_view,
                        question_answer_data_view_layout,
                        question_answer_data_first_start_view
                    );
                } else {
                    question_answer_data_view_layout.visibility = View.GONE
                    Log.d("TAG", "question_answer_data_img: " + 739)
                    if (StringUtil.isNotBlank(dataList[0].imageUrl)) {
                        question_answer_data_img.visibility = View.VISIBLE
                        Glide.with(this).load(dataList[0].imageUrl).apply(operation)
                            .into(question_answer_data_img)
                    } else {
                        question_answer_data_img.visibility = View.GONE
                    }
                }
            }
        }
//
        if (StringUtil.isNotBlank(info.selectList)) {
            val turnsType = CacheUtil.genericType<ArrayList<SubjectFileEntity>>()
            val selectList =
                Gson().fromJson<ArrayList<SubjectFileEntity>>(info.selectList, turnsType)
            if (selectList.size > 0) {
                if (StringUtil.isNotBlank(selectList[0].videoUrl)) {
                    question_answer_select_view_layout.visibility = View.GONE
                    play(
                        selectList[0].videoUrl,
                        question_answer_select_media_controller,
                        question_answer_select_video_view,
                        question_answer_select_view_layout,
                        question_answer_select_first_start_view
                    );
                }
            }

        }
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>${info.questionIndex}</font>/ ${info.total}  题";
        question_answer_index.text = Html.fromHtml(str);
        if (oprationList != null) {
            question_answer_right_result.text = getRightResult(oprationList)
        }
        if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
            val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                info.wdQuestionChapterPractice,
                WdQuestionChapterPracticeEntity::class.java
            )
            if (practice != null && from != Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO && (question_answer_rg_menu.checkedRadioButtonId != R.id.question_answer_rbt_recite)) {
                queston_answer_rl_result.visibility = View.VISIBLE
                if (liftingType != 5) {
                    question_answer_ll_error.visibility = View.VISIBLE
                } else {
                    question_answer_ll_error.visibility = View.GONE
                }
                if (practice.isRight == "0") {
                    question_answer_result.setText("回答正确")
                    if (MultiTheme.getAppTheme() != 1){
                        ll_question_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_right)
                    }
                    if (practice.chapterContentList != null) {
                        question_answer_error_result.text =
                            getRightResult(practice.chapterContentList)
                    } else if (practice.wdQuestionPaperOption != null) {
                        question_answer_error_result.text =
                            getRightResult(practice.wdQuestionPaperOption)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        question_answer_result.setIconNormal(getDrawable(R.mipmap.icon_answer_right))
                    }
                } else {
                    question_answer_result.setText("回答错误")
                    if (MultiTheme.getAppTheme() != 1){
                        ll_question_answer_bg.background = resources.getDrawable(R.drawable.shape_bg_answer_error)
                    }
                    if (practice.chapterContentList != null) {
                        question_answer_error_result.text =
                            getResults(practice.chapterContentList)
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        question_answer_result.setIconNormal(getDrawable(R.mipmap.icon_answer_error))
                    }
                }
                    answerType = 3
                    isAnswer = true
                Log.v("yxy", "==结果=已达=" + answerType + "====")
            } else {
                if (!question_answer_rg_menu.isVisible) {
                    question_answer_ll_error.visibility = View.GONE
                    queston_answer_rl_result.visibility = View.GONE
                    answerType = 3
                } else {
                    if (question_answer_rbt_recite.isChecked || from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
                        answerType = 2
                    } else {
                        answerType = 1
                    }
                }
                Log.v("yxy", "==结果=已达=2---" + answerType + "====")
            }
        } else {
            if (!question_answer_rg_menu.isVisible) {
                question_answer_ll_error.visibility = View.GONE
                queston_answer_rl_result.visibility = View.GONE
                answerType = 3
            } else {
                if (question_answer_rbt_recite.isChecked) {
                    answerType = 2
                } else {
                    answerType = 1
                }
            }
            isAnswer = false
        }
        initQuestionViewByAnswer()

        when (info.liftingType) {
            1, 6 -> {
                question_answer_rl_result.visibility = View.GONE
                question_answer_rlv_operation.visibility = View.VISIBLE
                question_answer_ll_stem.visibility = View.GONE
                question_answer_result_info.visibility = View.VISIBLE
                //question_answer_submit_next.text = "下一题"
                setIconFont(question_answer_submit_next,"\ue62f")
                if (oprationList != null) {
                    initOperationRecycleView(oprationList)
                }
            }
            3 -> {
                question_answer_ll_stem.visibility = View.VISIBLE
                question_answer_rlv_operation.visibility = View.VISIBLE
                question_answer_rl_result.visibility = View.GONE
                question_answer_result_info.visibility = View.VISIBLE
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                question_answer_sub_index.setText(ss)
                question_answer_stem.text = info.childStem

                if (isMultiple) {
                    if (answerType != 3) {
                        question_answer_submit_next.text = "确定"
                    }
                    if (oprationList != null) {
                        initMutOperationRecycleView(oprationList)
                    }
                } else {
                    //question_answer_submit_next.text = "下一题"
                    setIconFont(question_answer_submit_next,"\ue62f")
                    if (oprationList != null) {
                        initOperationRecycleView(oprationList)
                    }
                }
            }

            2 -> {
                question_answer_rlv_operation.visibility = View.VISIBLE
                question_answer_ll_stem.visibility = View.GONE
                question_answer_rl_result.visibility = View.GONE
                if (answerType != 3) {
                    question_answer_submit_next.text = "确定"
                }
                question_answer_result_info.visibility = View.VISIBLE
                if (oprationList != null) {
                    initMutOperationRecycleView(oprationList)
                }
            }

            4, 7, 8 -> {
                question_answer_ll_stem.visibility = View.VISIBLE
                question_answer_rlv_operation.visibility = View.VISIBLE
                question_answer_rl_result.visibility = View.GONE
                question_answer_result_info.visibility = View.VISIBLE
                //question_answer_submit_next.text = "下一题"
                setIconFont(question_answer_submit_next,"\ue62f")
                val ss = SpannableStringBuilder("问题" + info.childIndex)
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                ss.setSpan(
                    ForegroundColorSpan(Color.parseColor(colorIndex)),
                    2,
                    4,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                question_answer_sub_index.setText(ss)
                question_answer_stem.text = info.childStem
//                Log.v("yxy", "==childIndex===" + info.childIndex + "===" + info.childStem)
                initOperationRecycleView(oprationList)

            }
            5 -> {
                question_answer_rlv_operation.visibility = View.GONE
                question_answer_ll_stem.visibility = View.GONE
                queston_answer_rl_result.visibility = View.GONE
                question_answer_rl_result.visibility = View.VISIBLE
                //question_answer_submit_next.text = "下一题"
                setIconFont(question_answer_submit_next,"\ue62f")
                question_answer_result_info.visibility = View.GONE
                val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                    info.wdQuestionChapterPractice,
                    WdQuestionChapterPracticeEntity::class.java
                )
                Log.v(
                    "yxy",
                    "=question_answer_edt_solution=" + GsonUtils.toJson(practice) + "===" + answerType
                )
                if (practice != null) {
                    if (StringUtil.isNotBlank(practice.solution)) {
                        question_answer_edt_solution.visibility = View.VISIBLE
                        question_answer_edt_solution.setFocusable(false);
                        question_answer_edt_solution.setFocusableInTouchMode(false);
                        question_answer_edt_solution.setText(practice.solution)
                    } else {
                        question_answer_edt_solution.visibility = View.GONE
                    }
                } else {
                    if (answerType != 1) {
                        question_answer_edt_solution.visibility = View.GONE
                    } else {
                        question_answer_edt_solution.visibility = View.VISIBLE
                        question_answer_edt_solution.setFocusable(true);
                        question_answer_edt_solution.setFocusableInTouchMode(true);
                    }

                }
            }
            else -> {
                //question_answer_submit_next.text = "下一题"
                setIconFont(question_answer_submit_next,"\ue62f")
            }

        }

    }

    /**
     * 背题模式下获取当前题目的正确答案
     * @param list ArrayList<QuestionOptionEntity>
     * @return String
     */
    private fun getRightResult(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            if (info.rightFlag == 0) {
                result += info.selectValue + ","
            }
        }
        return StringUtil.convertStr(result)
    }

    /**
     * 获取答题结果的结果
     */
    private fun getResults(list: ArrayList<QuestionOptionEntity>): String {
        var result = ""
        for (info in list) {
            result += info.selectValue + ","
        }
        return StringUtil.convertStr(result)
    }

    /**
     * 更新题目编号索引
     * @param ind Int
     * @param total Int
     * @param isSub Boolean
     */
    private fun setQuestionIndex(ind: Int, total: Int, isSub: Boolean) {
        val num = ind + 1;
        val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
        val str = "第<font color='" + colorIndex +"'>$num</font>/ $total  题";
        if (isSub) {
            question_answer_sub_index.text = Html.fromHtml(str);
        } else {
            question_answer_index.text = Html.fromHtml(str);
        }
    }


    private fun initOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        singleOperationAdapter = QuestionOperationAdapter(operationList)
        //初始化recyclerView
        question_answer_rlv_operation.init(
            LinearLayoutManager(this),
            singleOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        if (question_answer_rg_menu.checkedRadioButtonId == R.id.question_answer_rbt_recite){
            singleOperationAdapter.setAnswer(2)
        }else{
            singleOperationAdapter.setAnswer(answerType)
        }
        var isCheck = false
        singleOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheck && answerType == 1) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    optionId = info.id
                    setPosition(position)
                    selectOptions.add(info)
                    isRight = info.rightFlag
                    singleOperationAdapter.notifyDataSetChanged()
                    saveAnswer()
                    if (info.rightFlag == 1) {
                        Log.d("TAG", "jeek question_answer_resolve: " + 1037)
                        question_answer_resolve.visibility = View.VISIBLE
                        val rightresult = getRightResult(operationList)
                        question_answer_right_result.text = rightresult
                        question_answer_error_result.text = info.selectValue
                    } else {
                        nextQuestion(true)
                    }
                }
                isCheck = true
                setIsCheck(isCheck)
                singleOperationAdapter.notifyDataSetChanged()
            }
        }
    }


    /**
     * 多选选项处理器
     */
    private fun initMutOperationRecycleView(operationList: ArrayList<QuestionOptionEntity>) {
        mutOperationAdapter = QuestionMutOperationAdapter(operationList)
        //初始化recyclerView
        question_answer_rlv_operation.init(
            LinearLayoutManager(this),
            mutOperationAdapter
        ).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        if (question_answer_rg_menu.checkedRadioButtonId == R.id.question_answer_rbt_recite){
            mutOperationAdapter.setAnswer(2)
        }else{
            mutOperationAdapter.setAnswer(answerType)
        }
        mutOperationAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                if (!isCheckResult) {
                    val info: QuestionOptionEntity =
                        adapter.getItem(position) as QuestionOptionEntity
                    setPosition(position)
                    mutOperationAdapter.notifyDataSetChanged()
                }

            }
        }
    }


    inner class ProxyClick() {
        /**
         * 答题卡
         */
        fun gotoQuestionResultCardClick() {
            if (from == Constants.PARAMS_QUESTION_SOURCE_NOTE || from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO) {
                ToastUtils.showShort("当前为最后一道题")
                return
            }
            val chooseDialog = ScantronDialog.newBuilder(this@QuestionAnswerActivity,
                Constants.PARAMS_QUESTION_SOURCE_CHAPTER,
                isSeeAll,
                object : ScantronDialog.OnSubmitClickListener {
                    override fun onSubmitClick(content: Int) {
                        index = content
                        val info =
                            LitePal.where("position =?", index.toString())
                                .findFirst(QuestionDbEntity::class.java)
                        if (info != null) {
                            Log.d("TAG", "setQuestionView22: " + 1112)
                            setQuestionView2(info)
                        }
                    }

                })
            chooseDialog.show()
        }

        /**
         * 纠错
         */
        fun gotoRecoveryError() {
            questionSettingsDialog =
                RecoveryErrorDialog.newBuilder(this@QuestionAnswerActivity, false, 1,
                    object : RecoveryErrorDialog.OnSubmitClickListener {
                        override fun onSubmitClick(tags: String,content: String) {
                            if (tags.isEmpty()){
                                ToastUtils.showShort("请选择错误类型")
                                return
                            }
                            val json = JsonObject()
                            //type传0为意见反馈，传1为试题纠错
                            json.addProperty("type", 1)
                            //试题纠错则需要传subject_id（试题id）
                            Log.d("TAG", "onSubmitClickliftingType liftingType: " + liftingType + "  parentId: " + parentId + " subjectId: " +subjectId)
                            if(liftingType == 4 || liftingType == 3 || liftingType == 7 || liftingType == 8){
                                json.addProperty("subjectId", parentId)
                            }else{
                                json.addProperty("subjectId", subjectId)
                            }
                            json.addProperty("majorId", CacheUtil.getMajorId())
                            json.addProperty("feedContent", content)
                            json.addProperty("feedType", tags)
                            requestViewModel.errorCorrection(json)
                        }
                    })


            questionSettingsDialog?.show()
        }

        /**
         * 收藏
         */
        fun favClick() {
            if (isCollect == 1) {
                requestViewModel.delCollect(isCollectId)
            } else {
                val json = JsonObject()
                json.addProperty("subjectId", parentId)
                json.addProperty("type", 1)
                requestViewModel.addCollect(json)
            }
        }

        /**
         * 下一题
         */
        fun nextQuestionClick() {
            Log.v("yxy", "====" + liftingType)
            if (liftingType == 2 || liftingType == 5) {
                saveAnswer()
            }
            nextQuestion(true)
        }

        /**
         * 上一题
         */
        fun upQuestionClick() {
            index -= 1
            if (index >= 0) {
                val info =
                    LitePal.where("position =?", index.toString())
                        .findFirst(QuestionDbEntity::class.java)
                if (info != null) {
                    Log.d("TAG", "setQuestionView22: " + 1188)
                    setQuestionView2(info)
                }
            } else {
                ToastUtils.showShort("当前为第一题")
            }
        }
        /**
         * 只看错题
         */
        fun seeErrorClick() {
            isSeeAll = !isSeeAll
            val errorList = arrayListOf<QuestionDbEntity>()
            val list = LitePal.findAll(QuestionDbEntity::class.java)
            for (info in list) {
                if (info.liftingType != 5) {
                    if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                        val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                            info.wdQuestionChapterPractice,
                            WdQuestionChapterPracticeEntity::class.java
                        )
                        if (practice != null) {
                            if (practice.isRight == "1") {
                                errorList.add(info)
                            }
                        }
                    } else {
                        errorList.add(info)
                    }
                }
            }
            if (errorList.size == 0) {
                isSeeAll = true
                ToastUtils.showShort("无错题")
            }
            Log.v("yxy", "=see=all2=" + list.size + "===error==" + errorList.size)
            //错题大于0 切换，否则显示全部
            if (!isSeeAll && errorList.size > 0) {
                question_answer_error.text = "查看全部"
                index = 1
                totalNum = errorList.size
                setQuestionIndex(index, totalNum, false)
                setQuestionView2(errorList[0])
            } else {

                question_answer_error.text = "只看错题"
                totalNum = list.size
                setQuestionIndex(index, totalNum, false)
                setQuestionView2(list[0])
            }

        }
    }

    override fun onViewClicked() {
        setOnclickNoRepeat(question_answer_submit_next, exam_up,question_answer_note,question_answer_settings) {
            when (it.id) {
                R.id.question_answer_submit_next -> {
                    if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                        saveAnswer()
                    }
                    nextQuestion(true)
                }

                R.id.exam_up  -> {
                    if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                        saveAnswer()
                    }
                    nextQuestion(false)
                }

                R.id.question_answer_note -> {
                    startActivity(
                        Intent(this@QuestionAnswerActivity, CreateNoteActivity::class.java)
                            .putExtra("id", id)
                            .putExtra("subjectId", parentId)
                            .putExtra("type", type)
                    )
                }

                R.id.question_answer_settings -> {
                    val chooseDialog =
                        SettingsDialog.newBuilder(this@QuestionAnswerActivity, false, 1,
                            object : SettingsDialog.OnSubmitClickListener {
                                override fun onSubmitClick(themeMode: Int,fontSize: Float?) {
                                    if (fontSize != null) {
                                        SPUtils.getInstance().put("fontSize",fontSize)
                                    }
                                    SPUtils.getInstance().put("themeMode",themeMode)
                                    setTextSize()
                                    mutOperationAdapter.notifyDataSetChanged()
                                    singleOperationAdapter.notifyDataSetChanged()
                                }

                                override fun onModeSelect(mode: Int,value: Float?) {
                                    if (value != null) {
                                        Constants.questionTextSize = ((value - 50)/100) * 4 *2

                                    };
                                    if (mode == 1){
                                        MultiTheme.setAppTheme(1);
                                    }else {
                                        MultiTheme.setAppTheme(0);
                                    }
                                    setTextSize()
                                    updateIcon()
                                    updateWebview()
                                    if (MultiTheme.getAppTheme() != 1){
                                        if (question_answer_result.text.contains("回答错误")) {
                                            ll_question_answer_bg.background =
                                                resources.getDrawable(R.drawable.shape_bg_answer_error)
                                        }else if (question_answer_result.text.contains("回答正确")) {
                                            ll_question_answer_bg.background =
                                                resources.getDrawable(R.drawable.shape_bg_answer_right)
                                        }
                                    }
                                }

                                override fun onRangeChanged(value: Float) {
                                    Constants.questionTextSize = ((value - 50)/100) * 4 *2
                                    setTextSize()
                                }

                            })
                    chooseDialog.show()
                }
            }
        }
    }


    private fun nextQuestion(isNext: Boolean) {
        if (goNext) {
            if (isNext) {
                index += 1
            }else{
                index -= 1
                if (index < 0){
                    ToastUtils.showShort("已是第一道题目")
                    return
                }
            }

            val count = LitePal.count(QuestionDbEntity::class.java)
            if (index <= count) {
                if (isSeeAll) {
                    val info =
                        LitePal.where("position =?", index.toString())
                            .findFirst(QuestionDbEntity::class.java)
                    if (info != null) {
                        setQuestionView2(info)
                    }
                } else {
                    val list = LitePal.where("position >= ?", index.toString())
                        .find(QuestionDbEntity::class.java)
                    Log.v("yxy", "=error==" + list.size + "==" + index)
                    for (info in list) {
                        var isRight = "1"
                        if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                            val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                                info.wdQuestionChapterPractice,
                                WdQuestionChapterPracticeEntity::class.java
                            )
                            if (practice != null) {
                                isRight = practice.isRight
                            }
                        }
                        Log.v(
                            "yxy",
                            "===" + isRight + "===" + StringUtil.isBlank(info.wdQuestionChapterPractice) + "==" + info.position + "==" + index
                        )
                        if (info.liftingType != 5 && (info.position >= index) && (isRight == "1" || StringUtil.isBlank(
                                info.wdQuestionChapterPractice
                            ))
                        ) {
                            setQuestionView2(info)
                            break
                        }
                    }
                }


            } else {
                if (from == Constants.PARAMS_QUESTION_SOURCE_NOTE || from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO || answerType == 2) {
                    ToastUtils.showShort("当前为最后一道题")
                    return
                }
                gotoSubmitQuestion()
            }
        }
    }


    /**
     * 保存结果
     */
    private fun saveAnswer() {
        val json = JsonObject()
        val question =
            LitePal.where("position= ?", index.toString())
                .findFirst(QuestionDbEntity::class.java)
        val practice = WdQuestionChapterPracticeEntity()
        practice.subjectId = subjectId
        practice.type = "1"
        if (question == null) {
            Log.v("yxy", "===question= is null=")
            return
        }
//        if (StringUtil.isNotBlank(isCollectId)) {
//            question.isCollectId = isCollectId
//        }
//
//        question.isCollect = isCollect
        when (liftingType) {
            //单选题型
            1, 6, 4, 7, 8 -> {
                practice.chapterContentList = selectOptions
                practice.isRight = isRight.toString()
                practice.optionId = optionId
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                    question.updateAll("position=?", index.toString())
                }
            }
            3 -> {
                if (isMultiple) {
                    var selectOptionList = arrayListOf<QuestionOptionEntity>()
                    optionId = ""
                    val operations = mutOperationAdapter.data
                    var selectValues = ""
                    var rightValues = ""
                    Log.v("yxy", "=多选结果==" + GsonUtils.toJson(operations))
                    for (ope in operations) {
                        if (ope.isSelect) {
                            optionId += ope.id + ","
                            selectValues += ope.selectValue + ","
                            selectOptionList.add(ope)
                        }
                    }
                    val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                    val oprationList =
                        Gson().fromJson<ArrayList<QuestionOptionEntity>>(
                            question.optionList,
                            turnsType
                        )
                    if (oprationList != null) {
                        for (ope in oprationList) {
                            if (ope.rightFlag == 0) {
                                rightValues += ope.selectValue + ","
                            }
                        }
                    }

                    if (rightValues == selectValues) {
                        isRight = 0
                    } else {
                        isRight = 1
                    }
                    if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                        practice.chapterContentList = selectOptionList
                        practice.isRight = isRight.toString()
                        practice.optionId = optionId
                        question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                        question.updateAll("position=?", index.toString())
                        Log.v("yxy", "==goNext=>" + goNext)
                        if (isRight == 1) {
                            goNext = !goNext
                            question_answer_resolve.visibility = View.VISIBLE
                            //question_answer_submit_next.text = "下一题"
                            setIconFont(question_answer_submit_next,"\ue62f")
                            question_answer_ll_error.visibility = View.VISIBLE
                            question_answer_error_result.text = selectValues
                            mutOperationAdapter.setCheck(true)
                            isCheckResult = true
                            mutOperationAdapter.notifyDataSetChanged()
                            if (MultiTheme.getAppTheme() != 1){
                                if (question_answer_result.text.contains("回答错误")) {
                                    ll_question_answer_bg.background =
                                        resources.getDrawable(R.drawable.shape_bg_answer_error)
                                }else if (question_answer_result.text.contains("回答正确")) {
                                    ll_question_answer_bg.background =
                                        resources.getDrawable(R.drawable.shape_bg_answer_right)
                                }
                            }
                            if (goNext) {
                                return
                            }

                        }
                    }
                } else {
                    practice.chapterContentList = selectOptions
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                        question.updateAll("position=?", index.toString())
                    }
                }
            }
            2 -> {
                var selectOptionList = arrayListOf<QuestionOptionEntity>()
                optionId = ""
                val operations = mutOperationAdapter.data
                var selectValues = ""
                var rightValues = ""
                Log.v("yxy", "=多选结果==" + GsonUtils.toJson(operations))
                for (ope in operations) {
                    if (ope.isSelect) {
                        optionId += ope.id + ","
                        selectValues += ope.selectValue + ","
                        selectOptionList.add(ope)
                    }
                }
                val turnsType = CacheUtil.genericType<ArrayList<QuestionOptionEntity>>()
                val oprationList =
                    Gson().fromJson<ArrayList<QuestionOptionEntity>>(
                        question.optionList,
                        turnsType
                    )
                if (oprationList != null) {
                    for (ope in oprationList) {
                        if (ope.rightFlag == 0) {
                            rightValues += ope.selectValue + ","
                        }
                    }
                }

                if (rightValues == selectValues) {
                    isRight = 0
                } else {
                    isRight = 1
                }
                if (answerType == 1 && StringUtil.isNotBlank(optionId)) {
                    practice.chapterContentList = selectOptionList
                    practice.isRight = isRight.toString()
                    practice.optionId = optionId
                    question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                    question.updateAll("position=?", index.toString())
                    Log.v("yxy", "==goNext=>" + goNext)
                    if (isRight == 1) {
                        goNext = !goNext
                        Log.d("TAG", "jeek question_answer_resolve: " + 1501)
                        question_answer_resolve.visibility = View.VISIBLE
                        //question_answer_submit_next.text = "下一题"
                        setIconFont(question_answer_submit_next,"\ue62f")
                        question_answer_ll_error.visibility = View.VISIBLE
                        question_answer_error_result.text = selectValues
                        mutOperationAdapter.setCheck(true)
                        isCheckResult = true
                        mutOperationAdapter.notifyDataSetChanged()
                        if (goNext) {
                            return
                        }
                    }
                }
            }
            5 -> {
                solution = question_answer_edt_solution.text.toString().trim()
                if (StringUtil.isNotBlank(solution)) {
                    isRight = 0
                    practice.solution = solution
                    practice.isRight = isRight.toString()
                } else {
                    practice.solution = ""
                }
                optionId = ""
                question.wdQuestionChapterPractice = GsonUtils.toJson(practice)
                if (answerType == 1 && StringUtil.isNotBlank(solution)) {
                    question.updateAll("position=?", index.toString())
                }
                json.addProperty("solution", solution)

            }
        }

        json.addProperty("isRight", isRight)
        if (StringUtil.isNotBlank(optionId)) {
            json.addProperty("optionId", optionId)
        }
        if (from == Constants.PARAMS_QUESTION_SOURCE_ERROR) {
            json.addProperty("errorType", "1")
        }
        json.addProperty("paperId", chapterId)
        json.addProperty("score", question.score)
        json.addProperty("subjectId", question.questionId)
        json.addProperty("type", 1)
        json.addProperty("paperType", 1)
        Log.v("yxy", "==favType==" + favType)
        if (answerType == 1 && (StringUtil.isNotBlank(solution) || StringUtil.isNotBlank(
                optionId
            )) && favType != 1
        ) {
            Log.v("yxy", "已做" + question.wdQuestionChapterPractice)
            requestViewModel.submitQuestionResult(json)
        } else {
            Log.v("yxy", "未做")
        }
    }


    private fun gotoSubmitQuestion() {
        if (from == Constants.PARAMS_QUESTION_SOURCE_RESOLVE || from == Constants.PARAMS_QUESTION_SOURCE_NOTE || from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER_INFO || answerType ==2) {
            ToastUtils.showShort("这是最后一道题")
        } else {
            if (RxSimple.isFastClick(2000)) {
                return
            }
                startActivity(
                    Intent(this@QuestionAnswerActivity, ExamInformActivity::class.java)
                        .putExtra("type", Constants.PARAMS_QUESTION_LOAD_TYPE_CHAPTER)
                        .putExtra(Constants.PARAMS_QUESTION_ERROR, intent.getIntExtra(Constants.PARAMS_QUESTION_ERROR,0))
                        .putExtra("from", from)
                        .putExtra(Constants.PARAMS_QUESTION_CHAPTER_ID, chapterId)
                        .putExtra(Constants.PARAMS_QUESTION_TEMPLATE_ID, templateId)
                )
                finish()
        }
    }


    override fun onStop() {
        super.onStop()
        question_answer_data_media_controller.pause();
        question_answer_select_media_controller.pause();
        question_answer_data_video_view.onActivityStop();
        question_answer_select_video_view.onActivityStop();
    }

    override fun onDestroy() {
        super.onDestroy()
        question_answer_data_video_view.destroy();
        question_answer_select_video_view.destroy();
        question_answer_data_media_controller.disable();
        question_answer_select_media_controller.disable();
    }


    /**
     * 播放视频
     */
    fun play(
        vid: String,
        mediaController: PolyvPlayerMediaController,
        videoView: PolyvVideoView,
        viewLayout: RelativeLayout,
        firstView: PolyvPlayerPreviewView
    ) {
        val danmuFragment: PolyvPlayerDanmuFragment = PolyvPlayerDanmuFragment();
        videoView.release();
        firstView.hide()

        mediaController.setDanmuFragment(danmuFragment);
        mediaController.initConfig(viewLayout)
        mediaController.hindMenuView()

        videoView.mediaController = mediaController

        videoView.setOnPreparedListener(IPolyvOnPreparedListener2 {
            mediaController.preparedView()
        })

        videoView.setOnVideoStatusListener { status ->
            if (status < 60) {
//                Toast.makeText(
//                    this,
//                    "状态错误 $status",
//                    Toast.LENGTH_SHORT
//                ).show()
            } else {
//                Log.d(
//                    "yxy",
//                    String.format("状态正常 %d", status)
//                )
            }
        }

//        videoView.setOnVideoPlayerErrorListener { tipsZhCn, tipsEn, code ->
//            question_answer_polyv_error_view.show(
//                tipsZhCn,
//                code,
//                videoView
//            )
//        }

        //视频不播放，先显示一张缩略图
        firstView.setCallback(PolyvPlayerPreviewView.Callback { //在播放视频时设置viewerId方法使用示例
            videoView.setAutoPlay(true)
            videoView.setVid(vid)

        })

        firstView.show(vid)

        videoView.setOnPlayPauseListener(object : IPolyvOnPlayPauseListener {
            override fun onPause() {
                Log.v(
                    "yxy",
                    String.format("状态正常 onPause")
                )
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }

            override fun onPlay() {
                Log.v(
                    "yxy",
                    String.format("状态正常 onPlay")
                )
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_pause_port,
                    "start",
                    2,
                    2
                )
            }

            override fun onCompletion() {
                Log.v(
                    "yxy",
                    String.format("状态正常 onCompletion")
                )
                mediaController.updatePictureInPictureActions(
                    R.drawable.polyv_btn_play_port,
                    "pause",
                    1,
                    1
                )
            }
        })

    }

    /**
     * 输入框字符数限制监听
     */
    private fun editTextMaxLengthListener() {
        question_answer_edt_solution.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(
                s: CharSequence,
                start: Int,
                count: Int,
                after: Int
            ) {
                editStart = 0
                editEnd = 0
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                // add by zyf 0825 . 多余的从新输入的位置删除，而不是最后
                editStart = question_answer_edt_solution.selectionStart
                editEnd = question_answer_edt_solution.selectionEnd
                // 先去掉监听器，否则会出现栈溢出
//                et_content.removeTextChangedListener(this);

                // 因为是中英文混合，单个字符而言，calculateLength函数都会返回1
                while (calculateLength(question_answer_edt_solution.text.toString()) > maxLen) { // 当输入字符个数超过限制的大小时，进行截断操作
                    s.delete(editStart - 1, editEnd)
                    editStart--
                    editEnd--
                }
                question_answer_edt_solution.setSelection(editStart)

                // 恢复监听器
//                et_content.addTextChangedListener(this);

                //update
                configCount()
            }
        })
    }

    private fun calculateLength(c: CharSequence): Long {
        var len = 0.0
        for (element in c) {
            val tmp = element.toInt()
            if (tmp > 0 && tmp < 127) {
                len += 0.5
            } else {
                len++
            }
        }
        return Math.round(len)
    }

    @SuppressLint("SetTextI18n")
    private fun configCount() {
        val currentCount: Long
        val nowCount = calculateLength(question_answer_edt_solution.text.toString())
        currentCount = nowCount
        //
        question_answer_text_num.text = (nowCount).toString() + "/" + maxLen
        if (maxLen.toLong() == currentCount) {
            ToastUtils.showShort("最多输入" + maxLen + "个字符")
        }
    }

    private fun setTextSize(){
        question_answer_index.textSize = 13 + Constants.questionTextSize
        question_answer_type.textSize = 13 + Constants.questionTextSize
        question_answer_title.textSize = 15 + Constants.questionTextSize
        question_answer_edt_solution.textSize = 12 + Constants.questionTextSize
        question_answer_sub_index.textSize = 17 + Constants.questionTextSize
        question_answer_stem.textSize = 15 + Constants.questionTextSize
        mutOperationAdapter.notifyDataSetChanged()
        singleOperationAdapter.notifyDataSetChanged()
    }

    private fun initWebView() {
        val webSettings: WebSettings = question_tv_analyze.getSettings()
        webSettings.javaScriptEnabled = true //允许使用js
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false
        webSettings.setUseWideViewPort(true);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setTextZoom(100);
        question_tv_analyze.setWebViewClient(object : WebViewClient() {
            //覆盖shouldOverrideUrlLoading 方法
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }

        })


    }

    override fun dispatchTouchEvent(ev: MotionEvent?): Boolean {
        if(answerType != 2){
            return super.dispatchTouchEvent(ev)
        }
        when (ev?.action) {
            MotionEvent.ACTION_DOWN -> {
                mPosX = ev?.getX();
                mPosY = ev?.getY();
                mCurPosX = ev?.getX();
                mCurPosY = ev?.getY();
            }
            MotionEvent.ACTION_MOVE -> {
                mCurPosX = ev?.getX();
                mCurPosY = ev?.getY();
            }
            MotionEvent.ACTION_UP -> {
                var Y = mCurPosY - mPosY;
                var X = mCurPosX - mPosX;
                if (mPosY < ConvertUtils.dp2px(180f) || mPosY > (PolyvScreenUtils.getNormalWH(this)[1] -  ConvertUtils.dp2px(50f))){
                    return super.dispatchTouchEvent(ev)
                }

                if (Math.abs(Y) > Math.abs(X)) {
//                            if (Y > 0) {
//                                slideDown();
//                            } else {
//                                slideUp();
//                            }
                } else {
                    if (X > 20) {
                        if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                            saveAnswer()
                        }
                        nextQuestion(false)
                    } else if (X < -20) {
                        if (liftingType == 2 || (liftingType == 3 && isMultiple) || liftingType == 5) {
                            saveAnswer()
                        }
                        nextQuestion(true)
                    }
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

//    override fun onTouchEvent(event: MotionEvent?): Boolean {
//        ToastUtils.showShort("onTouchEvent")
//
//        return super.onTouchEvent(event)
//    }


    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }
    fun setIconFont(tv: TextView, content:String){
        val typeface: Typeface = Typeface.createFromAsset(
            assets,
            "fonts/iconfont.ttf"
        )
        tv.setTypeface(typeface)
        tv.text = content
    }

    private fun updateWebview(){
        var BASE_URL = ApiService.SERVER_URL
        if (BuildConfig.FLAVOR.contains("product")) {
            BASE_URL = ApiService.WEB_SERVER_URL
        }
        var url =
            BASE_URL + "/zixun/subjectAnswer.html?subjectId=" + subjectId + "&type=" + 1
        if (MultiTheme.getAppTheme() == 1) {
            url = BASE_URL + "/zixun/subjectAnswer.html?subjectId=" + subjectId + "&type=" + 1  + "&background=1"
        }
        Log.d("TAG", "setQuestionView2 url: " + url)
        question_tv_analyze.loadUrl(url);
    }

    private fun updateIcon(){
        if (MultiTheme.getAppTheme() == 1) {
            question_answer_settings.iconNormal = getDrawable(R.mipmap.ic_bottom_settings_dark)
            question_answer_note.iconNormal = getDrawable(R.mipmap.ic_question_answer_note_dark)
            question_answer_card.iconNormal = getDrawable(R.mipmap.ic_question_card_dark)
            if (question_answer_fav.text.equals("收藏")) {
                question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted_dark)
            }
        }else{
            question_answer_settings.iconNormal = getDrawable(R.mipmap.ic_bottom_settings)
            question_answer_note.iconNormal = getDrawable(R.mipmap.ic_question_answer_note)
            question_answer_card.iconNormal = getDrawable(R.mipmap.ic_question_card)
            if (question_answer_fav.text.equals("收藏")) {
                question_answer_fav.iconNormal = getDrawable(R.mipmap.ic_fav_unselcted)
            }
        }
    }

}