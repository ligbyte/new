package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import com.blankj.utilcode.util.ToastUtils
import com.chad.library.adapter.base.listener.OnItemChildClickListener
import com.chad.library.adapter.base.listener.OnItemClickListener
import com.google.gson.JsonObject
import com.ligbyte.lib.theme.ActivityTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.showMessage
import com.wendu.wenduyikao.app.util.CacheUtil
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.BaseCode
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.eventbus.TestPaperSubmitSuccessEvent
import com.wendu.wenduyikao.data.model.bean.QuestionInfoEntity
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import com.wendu.wenduyikao.databinding.ActivitySubmitConfirmBinding
import com.wendu.wenduyikao.question.adapter.QuestionPaperCardAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestQuestionViewModel
import kotlinx.android.synthetic.main.activity_exam.tv_toolbar_title
import kotlinx.android.synthetic.main.activity_submit_confirm.*
import me.xiaoyang.base.ext.parseState
import org.greenrobot.eventbus.EventBus
import org.litepal.LitePal

class SubmitConfirmActivity :
    BaseActivity<RequestQuestionViewModel, ActivitySubmitConfirmBinding>() {

    private val requestViewModel: RequestQuestionViewModel by viewModels()
    private var type = 1   //chapter 练习   chapter 试卷
    private var paperId = ""
    private var from = ""
    private var classId = ""
    private var appraisalId = ""
    private var useTime = 0L
    private var isHasZhuguan = false
    private var paperType = ""
    override fun layoutId() = R.layout.activity_submit_confirm

    private var mData: List<QuestionResultEntity> = arrayListOf()
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setDarkMode(this)
        StatusBarUtil.setPaddingSmart(this, submit_confirm_ll_content)
        tv_toolbar_title.text = "提交确认"
        img_back.setOnClickListener { finish() }
        type = intent.getIntExtra("type", 1)
        if (type == 3) {
            submit_confirm_label.text = "提交答案后无法重新做题哦，确认提交吗？"
            isHasZhuguan = intent.getBooleanExtra("isHasZhuguan", false)
            paperType = intent.getStringExtra("paperType") ?: ""
            classId = intent.getStringExtra(Constants.PARAMS_QUESTION_CLASS_ID).toString()
            appraisalId = intent.getStringExtra("appraisalId").toString()
        } else {
            submit_confirm_label.text = "认真对待每道题才能有所进步！"
        }
        from = intent.getStringExtra("from").toString()
        useTime = intent.getLongExtra("useTime", 0L)
        if (from == Constants.PARAMS_QUESTION_SOURCE_CHAPTER) {
            initRecycleView()
        } else {
            paperId = intent.getStringExtra("paperId").toString()
            initPaperRecycleView()
        }
        mDatabind.click = ProxyClick()
    }

    private fun initRecycleView() {
        submit_confirm_rlv_question.setLayoutManager(GridLayoutManager(this, 6))
        val list = CacheUtil.getQuestionSubject();
        mData = BaseCode.getQuestionCardData(list)
        val adapter =
            QuestionPaperCardAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (mySection.isHeader) {
//                Tips.show(mySection.getObject() as String)
            } else {
                val video: QuestionInfoEntity = mySection.getObject() as QuestionInfoEntity
//                Tips.show(video.getName())
            }
        })
        adapter.setOnItemChildClickListener(OnItemChildClickListener { adapter, view, position ->
//            Tips.show(
//                "onItemChildClick: $position"
//            )
        })
        submit_confirm_rlv_question.adapter = adapter
    }

    private fun initPaperRecycleView() {
        submit_confirm_rlv_question.setLayoutManager(GridLayoutManager(this, 6))
        val list = LitePal.findAll(QuestionPaperDbEntity::class.java);
        mData = BaseCode.getQuestionPaperCardData2()
        var unAnswerNum = 0
        for (info in list) {
            if (StringUtil.isBlank(info.wdQuestionChapterPractice)) {
                unAnswerNum += 1
            }
        }
        submit_confirm_info_content.text = "有$unAnswerNum 题未作答\n请选择是否继续答题？"
        val adapter =
            QuestionPaperCardAdapter(
                R.layout.item_question_result_content,
                R.layout.def_question_result_head,
                mData
            )

        adapter.setOnItemClickListener(OnItemClickListener { adapter, view, position ->
            val mySection: QuestionResultEntity = mData.get(position)
            if (!mySection.isHeader) {
                val question: QuestionPaperDbEntity =
                    mySection.getObject() as QuestionPaperDbEntity
                val count = LitePal.count(QuestionPaperDbEntity::class.java)

                Log.v(
                    "yxy",
                    ":=====SubmitConfirmActivity++question.paperId+" + question.paperId + "===paperId====" + paperId
                )
                EventBus.getDefault().post(TestPaperSubmitSuccessEvent())
                startActivity(
                    Intent(this, Exam2Activity::class.java)
                        .putExtra("paperId", paperId)
                        .putExtra("total", count)
                        .putExtra("index", question.position)
                        .putExtra("type", type)
                        .putExtra(Constants.PARAMS_QUESTION_CLASS_ID, classId)
                        .putExtra("appraisalId", appraisalId)
                        .putExtra("loadfrom", from)
                        .putExtra("from", "card")
                )
                finish()
            }
        })

        submit_confirm_rlv_question.adapter = adapter
    }

    override fun createObserver() {

        requestViewModel.paperSubmitResult.observe(this, Observer { resultState ->
            parseState(resultState, {
//                if (it != null) {
//                    val score = it.successScore.toDouble().toInt()
//                    exam_inform_result_score.text = "$score 分"
//                    exam_info_percent.text = it.proportion.toDouble().toInt().toString()
//                    "答对${it.successCount} 题 答错${it.doCount - it.successCount} 题 未答${it.countAll - it.doCount} 题".also {
//                        exam_inform_result_num.text = it
//                    }
//                }
                dismissLoading()
                EventBus.getDefault().post(TestPaperSubmitSuccessEvent())
                val intent = Intent(this@SubmitConfirmActivity, ExamInformActivity::class.java)
                intent.putExtra("from", from)
                intent.putExtra("type", type)
                Log.v("yxy", "=SubmitConfirmActivity==" + type)
                if (type == 3) {
                    intent.putExtra(Constants.PARAMS_QUESTION_CLASS_ID, classId)
                    intent.putExtra("appraisalId", appraisalId)
                    intent.putExtra("paperType", paperType)
                }
                intent.putExtra("paperId", paperId)
                intent.putExtra("useTime", useTime)
                startActivity(intent)
                finish()
            }, {
                showMessage(it.errorMsg)
            })
        })


        requestViewModel.paperTestSubmitResult.observe(this, Observer {
            if (it.success) {
                dismissLoading()
                //EventBus.getDefault().post(TestPaperSubmitSuccessEvent())
                if (isHasZhuguan) {
                    showMessage("因为您答的试卷中存在主观题！请等待老师给你打分！", positiveAction = {
                        finish()
                    })

                } else {
                    val intent = Intent(this@SubmitConfirmActivity, ExamInformActivity::class.java)
                    intent.putExtra("from", from)
                    intent.putExtra("type", type)
                    if (type == 3) {
                        intent.putExtra(Constants.PARAMS_QUESTION_CLASS_ID, classId)
                        intent.putExtra("appraisalId", appraisalId)
                    }
                    intent.putExtra("paperId", paperId)
                    intent.putExtra("paperType", paperType)

                    Log.d("TAG", "paperTestSubmitResult from: " + from + " type: " + type + " paperId: " + paperId + " paperType: " + paperType)

                    startActivity(intent)
                    finish()
                }


            } else {
                ToastUtils.showShort(it.message)
            }
        })
    }

    inner class ProxyClick() {
        fun submitClick() {
            showLoading("数据提交中")
            if (type == 3) {
                val json = JsonObject()
                Log.v("yxy", "===classId=" + classId + "=====" + appraisalId)
                json.addProperty("classesId", classId)
                json.addProperty("appraisalId", appraisalId)
                requestViewModel.submitRoll(json)
            } else {
                val json = JsonObject()
                json.addProperty("paperId", paperId)
                json.addProperty("type", type)
                requestViewModel.submitPaperResult(json)
            }
        }
    }
//    override fun onViewClicked() {
//        setOnclickNoRepeat(submit_confirm_exercise) {
//            when (it.id) {
//                R.id.submit_confirm_exercise -> {
//                    if (type == 3) {
//                        val json = JsonObject()
//                        Log.v("yxy", "===classId=" + classId + "=====" + appraisalId)
//                        json.addProperty("classesId", classId)
//                        json.addProperty("appraisalId", appraisalId)
//                        requestViewModel.submitRoll(json)
//                    } else {
//                        val json = JsonObject()
//                        json.addProperty("paperId", paperId)
//                        json.addProperty("type", type)
//                        requestViewModel.submitPaperResult(json)
//                    }
//
//
//                }
//
//            }
//        }
//    }

    override fun configTheme(activityTheme: ActivityTheme?) {
        activityTheme?.setThemes(
            intArrayOf(
                R.style.AppTheme_Light,
                R.style.AppTheme_NIGHT
            )
        )
        activityTheme?.setStatusBarColorAttrRes(android.R.attr.colorPrimary)
        activityTheme?.setSupportMenuItemThemeEnable(true)
    }

}