package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.blankj.utilcode.util.ConvertUtils
import com.blankj.utilcode.util.ToastUtils
import com.kingja.loadsir.core.LoadService
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.ext.*
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.app.weight.recyclerview.SpaceItemDecoration
import com.wendu.wenduyikao.data.model.bean.QuestionCatalogEntity
import com.wendu.wenduyikao.databinding.ActivityTemplateListBinding
import com.wendu.wenduyikao.question.adapter.QuestionCatalogAdapter
import com.wendu.wenduyikao.viewmodel.request.RequestTemplateListViewModel
import kotlinx.android.synthetic.main.activity_template_list.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import kotlinx.android.synthetic.main.include_recyclerview.*

/**
 * @Author     : xiaoyangyan
 * @Time       :  15:25
 * @Description: 章列表
 */
class TemplateListActivity :
    BaseActivity<RequestTemplateListViewModel, ActivityTemplateListBinding>() {
    private val requestViewModel: RequestTemplateListViewModel by viewModels()
    private var paperId = ""

    //适配器
    private val catalogAdapter: QuestionCatalogAdapter by lazy {
        QuestionCatalogAdapter(
            arrayListOf()
        )
    }

    //界面状态管理者
    private lateinit var loadsir: LoadService<Any>
    override fun layoutId() = R.layout.activity_template_list


    override fun initView(savedInstanceState: Bundle?) {
        paperId = intent.getStringExtra("paperId") ?: ""
        img_back.setOnClickListener { finish() }
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, ll_template_content)
        val title = intent.getStringExtra("title").toString()
        if (StringUtil.isNotBlank(title)) {
            tv_toolbar_title.text = title
        }
        loadsir = loadServiceInit(swipeRefresh) {
            //点击重试时触发的操作
            loadsir.showLoading()
            requestViewModel.getTemplateList(paperId)
        }

        //初始化recyclerView
        recyclerView.init(LinearLayoutManager(this), catalogAdapter).let {
            it.addItemDecoration(SpaceItemDecoration(0, ConvertUtils.dp2px(0f)))
        }
        val list = arrayListOf<QuestionCatalogEntity>()
        catalogAdapter.data = list
        //初始化 SwipeRefreshLayout
        swipeRefresh.init {
            //触发刷新监听时请求数据
            requestViewModel.getTemplateList(paperId)
        }
        catalogAdapter.addChildClickViewIds(R.id.question_type_operation)

        requestViewModel.getTemplateList(paperId)
        catalogAdapter.run {
            setOnItemClickListener { adapter, view, position ->
                val info: QuestionCatalogEntity =
                    adapter.getItem(position) as QuestionCatalogEntity

                val intent = Intent(this@TemplateListActivity, ChapterActivity::class.java)
                intent.putExtra("id", paperId)
                intent.putExtra("title", info.templateName)
                intent.putExtra("templateId", info.id)
                intent.putExtra("from", 1)
                startActivity(intent)

            }
        }
    }

    override fun createObserver() {
        requestViewModel.templateListResult.observe(this, Observer {
            loadsir.showSuccess()
            if (it.isSuccess) {
                if (it.isEmpty) {
                    loadsir.showEmpty()
                } else {
                    loadsir.showSuccess()
                    loadListData(it, catalogAdapter, loadsir, recyclerView, swipeRefresh)
                }

            } else {
                loadsir.showEmpty()
                ToastUtils.showShort(it.errMessage)
            }
        })
    }
}