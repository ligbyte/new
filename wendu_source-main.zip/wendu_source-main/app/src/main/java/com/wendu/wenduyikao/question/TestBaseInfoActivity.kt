package com.wendu.wenduyikao.question

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.bumptech.glide.Glide
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.base.BaseActivity
import com.wendu.wenduyikao.app.util.StatusBarUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.QuestionPaperEntity
import com.wendu.wenduyikao.databinding.ActivityTestBaseInfoBinding
import com.wendu.wenduyikao.viewmodel.request.RequestTestBaseViewModel
import kotlinx.android.synthetic.main.activity_test_base_info.*
import kotlinx.android.synthetic.main.content_toolbar_view.*
import me.xiaoyang.base.ext.parseState

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/13/21 4:10 PM
 * @Description: 题库详情
 */
class TestBaseInfoActivity :
    BaseActivity<RequestTestBaseViewModel, ActivityTestBaseInfoBinding>() {
    private val requestViewModel: RequestTestBaseViewModel by viewModels()
    private var paperId = ""
    private var from = "question"
    override fun layoutId() = R.layout.activity_test_base_info
    override fun initView(savedInstanceState: Bundle?) {
        StatusBarUtil.setLightMode(this)
        StatusBarUtil.setPaddingSmart(this, create_testbase_ll_content)
        tv_toolbar_title.text = "题库详情"
        img_back.setOnClickListener { finish() }
        mDatabind.click = ProxyClick()
        paperId = intent.getStringExtra("paperId").toString()
        from = intent.getStringExtra("from").toString()
        if (StringUtil.isNotBlank(paperId)) {
            requestViewModel.getQuestionPaperInfoById(paperId)
        }
        if (from == "question") {
            test_base_ll_pay.visibility = View.VISIBLE
        } else {
            test_base_ll_pay.visibility = View.GONE
        }
    }

    override fun createObserver() {
        requestViewModel.paperInfoResult.observe(this, Observer { resultState ->
            parseState(resultState, {
                if (it != null) {
                    mDatabind.info = it
                    setPaperDetailInfo(it)
                }
            })
        })
    }

    private fun setPaperDetailInfo(info: QuestionPaperEntity) {
        if (info.map != null) {
            var paperTitle = ""
            info.map.forEach {
                paperTitle += it.value + ","
            }
            test_base_type_label.text = StringUtil.convertStr(paperTitle)
            create_testbase_price.text = StringUtil.formatDoublePrice(info.officialPrice)
            create_testbase_info_price.text = StringUtil.formatDoublePrice(info.officialPrice)

        }
        Glide.with(this).load(info.url).placeholder(R.drawable.ic_default_pic1)
            .into(create_testbase_pic)

    }


    inner class ProxyClick() {
        fun goSettlementClick() {
            startActivity(
                Intent(
                    this@TestBaseInfoActivity,
                    CreateTestBaseOrderActivity::class.java
                ).putExtra("paperId", paperId)
            )
        }
    }

}