package com.wendu.wenduyikao.question.adapter;

import android.content.Context;
import android.util.Log;
import android.view.View;
import android.widget.FrameLayout;


import com.wendu.wenduyikao.app.weight.dropdownmenu.FilterUrl;
import com.wendu.wenduyikao.app.weight.dropdownmenu.adapter.MenuAdapter;
import com.wendu.wenduyikao.app.weight.dropdownmenu.adapter.SimpleTextAdapter;
import com.wendu.wenduyikao.app.weight.dropdownmenu.interfaces.OnFilterDoneListener;
import com.wendu.wenduyikao.app.weight.dropdownmenu.interfaces.OnFilterItemClickListener;
import com.wendu.wenduyikao.app.weight.dropdownmenu.typeview.SingleListView;
import com.wendu.wenduyikao.app.weight.dropdownmenu.util.UIUtil;
import com.wendu.wenduyikao.app.weight.dropdownmenu.view.FilterCheckedTextView;
import com.wendu.wenduyikao.data.BaseCode;
import com.wendu.wenduyikao.data.model.bean.CodeEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * author: baiiu
 * date: on 16/1/17 21:14
 * description:
 */
public class DropMenuAdapter implements MenuAdapter {
    private final Context mContext;
    private OnFilterDoneListener onFilterDoneListener;
    private String[] titles;
    private String title = "";
    private String value="";
    private int index=0;
    private ArrayList<CodeEntity> liftTypes=new ArrayList<CodeEntity>();
    private ArrayList<CodeEntity> paperTypes=new ArrayList<CodeEntity>();
    public DropMenuAdapter(Context context, String[] titles,ArrayList<CodeEntity>liftTypeList, ArrayList<CodeEntity>paperTypeList,  OnFilterDoneListener onFilterDoneListener) {
        this.mContext = context;
        this.titles = titles;
        this.liftTypes=liftTypeList;
        this.paperTypes=paperTypeList;
        this.onFilterDoneListener = onFilterDoneListener;
    }

    @Override
    public int getMenuCount() {
        return titles.length;
    }

    @Override
    public String getMenuTitle(int position) {
        return titles[position];
    }

    @Override
    public int getBottomMargin(int position) {
        return UIUtil.dp(mContext, 140);
    }

    @Override
    public View getView(int position, FrameLayout parentContainer) {
        View view = parentContainer.getChildAt(position);
        Log.v("yxy", "==position=" + position);
        view = createSingleListView(position);
        return view;
    }

    private View createSingleListView(int position) {
        SingleListView<CodeEntity> singleListView = new SingleListView<CodeEntity>(mContext)
                .adapter(new SimpleTextAdapter<CodeEntity>(null, mContext) {
                    @Override
                    public String provideText(CodeEntity string) {
                        return string.getLabel();
                    }

                    @Override
                    protected void initCheckedTextView(FilterCheckedTextView checkedTextView) {
                        int dp = UIUtil.dp(mContext, 15);
                        checkedTextView.setPadding(dp, dp, 0, dp);
                    }
                })
                .onItemClick(new OnFilterItemClickListener<CodeEntity>() {
                    @Override
                    public void onItemClick(CodeEntity item) {
                        FilterUrl.instance().singleListPosition = item.getType();

                        FilterUrl.instance().position = position;
                        FilterUrl.instance().positionTitle = item.getLabel();
                        title=item.getLabel();
                        value=item.getType();
                        index=position;
                        onFilterDone();
                    }
                });

        List<CodeEntity> list = new ArrayList<>();
        switch (position) {
            case 0:
                list = liftTypes;
                break;
            case 1:
                list = BaseCode.getNumFilter();
                break;
            case 2:
                list = paperTypes;
                break;
            default:
                list = liftTypes;
                break;
        }
//        if(position==2){
//            if(list.size()>0){
//                Log.v("yxy","===设置默认值==="+list.size());
//                singleListView.setList(list, 1);
//            }else {
//                singleListView.setList(list, -1);
//            }
//
//        }else{
//            singleListView.setList(list, -1);
//        }
        singleListView.setList(list, -1);
        return singleListView;
    }


    private void onFilterDone() {
        if (onFilterDoneListener != null) {
            onFilterDoneListener.onFilterDone(index, title, value);
        }
    }

}
