package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.blankj.utilcode.util.GsonUtils
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import org.litepal.LitePal

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/3/21 11:46 PM
 * @Description: 题库目录
 */
class ExamAnswerOperationAdapter(data: ArrayList<QuestionOptionEntity>) :
    BaseQuickAdapter<QuestionOptionEntity, BaseViewHolder>(
        R.layout.question_operation_item_view,
        data
    ) {
    private var mPosition = -1
    private var answerType = 1; //true 背题模式，false 答题模式
    private var isCheck = false

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    fun setIsCheck(isCheck: Boolean) {
        this.isCheck = isCheck
    }

    fun setAnswer(isanswer: Int) {
        this.answerType = isanswer
    }


    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    override fun convert(holder: BaseViewHolder, item: QuestionOptionEntity) {
        item.run {
            holder.setText(R.id.question_operation_title, content)
            holder.setText(R.id.question_operation_index, selectValue)
            holder.getView<TextView>(R.id.question_operation_title).textSize =  15 + Constants.questionTextSize
            holder.getView<TextView>(R.id.question_operation_index).textSize =  16 + Constants.questionTextSize
            val info = LitePal.where("questionId= ?", subjectId)
                .findFirst(QuestionPaperDbEntity::class.java)
            var selectId = ""
            if (info != null) {
                if (StringUtil.isNotBlank(info.wdQuestionChapterPractice)) {
                    val result = GsonUtils.fromJson(
                        info.wdQuestionChapterPractice,
                        WdQuestionChapterPracticeEntity::class.java
                    )
                    selectId = result.optionId
                }
            }

            when (subType) {
                1 -> {
//文字
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.VISIBLE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.GONE
                }
                2 -> {
//图片
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.GONE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.VISIBLE
                    Glide.with(context).load(content).placeholder(R.drawable.ic_default_pic1)
                        .into(holder.getView<ImageView>(R.id.question_operation_pic))
                }
            }


            isSelect = (mPosition == holder.adapterPosition)
            when {
                (answerType == 1 && (isSelect || isCheck) && rightFlag == 0 || (answerType != 1 && rightFlag == 0)) -> {
                    holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                    holder.setVisible(R.id.question_operation_img_result, true)
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        R.drawable.shape_bg_blue_index
                    )
                    holder.setImageResource(
                        R.id.question_operation_img_result,
                        R.mipmap.icon_answer_right
                    )
                    val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                    holder.setTextColor(R.id.question_operation_title, Color.parseColor(colorIndex))
                }

                (answerType == 1 && isSelect && rightFlag == 1 || (answerType != 1 && rightFlag == 1 && selectId == id)) -> {
                    holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                    holder.setVisible(R.id.question_operation_img_result, true)
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        R.drawable.shape_bg_red_index
                    )
                    holder.setImageResource(
                        R.id.question_operation_img_result,
                        R.mipmap.icon_answer_error
                    )
                    holder.setTextColor(R.id.question_operation_title, Color.parseColor("#FA642C"))
                }

                (!isSelect) -> {
                    isSelect = false
                    holder.setTextColor(R.id.question_operation_index,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setTextColor(R.id.question_operation_title,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        if (MultiTheme.getAppTheme() == 1) R.drawable.shape_bg_white_index_dark else R.drawable.shape_bg_white_index
                    )
                    holder.setVisible(R.id.question_operation_img_result, false)
                }
                else -> {
                    isSelect = false
                    holder.setTextColor(R.id.question_operation_index,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setTextColor(R.id.question_operation_title,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        if (MultiTheme.getAppTheme() == 1) R.drawable.shape_bg_white_index_dark else R.drawable.shape_bg_white_index
                    )
                    holder.setVisible(R.id.question_operation_img_result, false)
                }
            }

        }
    }

}


