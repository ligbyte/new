package com.wendu.wenduyikao.question.adapter;

import android.graphics.Color;

import com.chad.library.adapter.base.BaseSectionQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.data.model.bean.QuestionInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;

import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * https://github.com/CymChad/BaseRecyclerViewAdapterHelper
 */
public class ExamInformResultAdapter extends BaseSectionQuickAdapter<QuestionResultEntity, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization result.
     *
     * @param sectionHeadResId The section head layout id for each item
     * @param layoutResId      The layout resource id of each item.
     * @param data             A new list is created out of this one to avoid mutable list
     */
    public ExamInformResultAdapter(int layoutResId, int sectionHeadResId, List<QuestionResultEntity> data) {
        super(sectionHeadResId, data);
        setNormalLayout(layoutResId);

    }

    @Override
    protected void convertHeader(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        if (item.getObject() instanceof String) {
            helper.setText(R.id.header, (String) item.getObject());
        }
    }


    @Override
    protected void convert(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        QuestionInfoEntity info = (QuestionInfoEntity) item.getObject();
//        switch (helper.getLayoutPosition() % 2) {
//            case 0:
//                helper.setImageResource(R.id.iv, R.mipmap.m_img1);
//                break;
//            case 1:
//                helper.setImageResource(R.id.iv, R.mipmap.m_img2);
//                break;
//            default:
//                break;
//        }
        helper.setText(R.id.question_result, info.getName());
        if (info.getName().equals("6")) {
            helper.setTextColor(R.id.question_result, Color.parseColor("#333333"));
            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_white_index);
        } else if (info.getName().equals("9")) {
            helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_red_index);
        } else {
            helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_green_index);
        }
    }
}
