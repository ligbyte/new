package com.wendu.wenduyikao.question.adapter

import android.util.Log
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil

/**
 * ProjectName: lingjuapp
 * CreateDate: 2019-10-25
 * ClassName: ImageAdapter
 * Author: xiaoyangyan
 * note
 */
class ImageAdapter(data: MutableList<String>) :
    BaseQuickAdapter<String, BaseViewHolder>(R.layout.item_upload_img, data) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: String) {
        val imgPic = holder.itemView.findViewById<ImageView>(R.id.iv_to_upload_img)
        val imgDelete = holder.itemView.findViewById<ImageView>(R.id.iv_close)
        val position = holder.layoutPosition
        if (position < data.size) {
            //代表+号之前的需要正常显示图片
            Log.v("yxy", "picUrl$item")
            Glide.with(context).load(item).placeholder(R.drawable.ic_launcher_background).into(imgPic)
            imgDelete.visibility = View.VISIBLE
        }
        addChildClickViewIds(R.id.iv_to_upload_img, R.id.iv_close)
    }
}