package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/3/21 11:46 PM
 * @Description: 题库目录
 */
class LearnResolveOperationAdapter(data: ArrayList<QuestionOptionEntity>) :
    BaseQuickAdapter<QuestionOptionEntity, BaseViewHolder>(
        R.layout.question_operation_item_view,
        data
    ) {
    private var mPosition = -1
    private var answerType = 1; //true 背题模式，false 答题模式
    private var isCheckResult = false
    private var  questionInfo: QuestionPaperInfoEntity? =null
    private var selectList: ArrayList<QuestionOptionEntity> = arrayListOf()
    fun setPosition(position: Int) {
        this.mPosition = position
        val info = data[position]
        info.isSelect = !info.isSelect
        selectList.add(info)
    }

    fun setQuestionInfo(info: QuestionPaperInfoEntity) {
        this.questionInfo = info

    }
    fun setCheck(isCheck: Boolean) {
        this.isCheckResult = isCheck
    }

    fun setAnswer(isanswer: Int) {
        this.answerType = isanswer
    }
    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    override fun convert(holder: BaseViewHolder, item: QuestionOptionEntity) {
        item.run {
            holder.setText(R.id.question_operation_title, content)
            holder.setText(R.id.question_operation_index, selectValue)


            val question = questionInfo
//            Log.v("yxy","-question.---"+GsonUtils.toJson(question))
            var selectOptionId = ""
            var isRight=false

            if (question != null) {
                Log.v("yxy","-question.wdQuestionChapterPractice---"+question.wdQuestionChapterPractice)
                if (question.wdQuestionChapterPractice!=null) {
                    val practice =  question.wdQuestionChapterPractice
                    if(practice!=null){
                        isRight=(practice.isRight=="0")
                        selectOptionId = practice.optionId
                    }
                }
            }
            Log.v("yxy","-isRight---"+isRight)
            when (subType) {
                1 -> {
//文字
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.VISIBLE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.GONE
                }
                2 -> {
//图片
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.GONE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.VISIBLE
                    Glide.with(context).load(content).placeholder(R.drawable.ic_default_pic1)
                        .into(holder.getView<ImageView>(R.id.question_operation_pic))
                }
            }


            Log.v("yxy","======>"+answerType+"selectOptionId==="+selectOptionId+"==="+id+"======？"+selectOptionId.contains(id))
            when {
                (answerType==1&&isSelect&&rightFlag==0)||(answerType!=1&&rightFlag==0&& selectOptionId.contains(id))||  (!isCheckResult&&answerType==1&&isSelect&&rightFlag==1) -> {
                    holder.setVisible(R.id.question_operation_img_result, true)
                    holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        R.drawable.shape_bg_blue_index
                    )
                    holder.setImageResource(
                        R.id.question_operation_img_result,
                        R.mipmap.icon_answer_right
                    )
                    holder.setTextColor(R.id.question_operation_title, Color.parseColor("#3B7BFF"))
                }
                (answerType==1&&isSelect&&rightFlag==0&& !isRight)||  (answerType==1&&isCheckResult&&!isSelect&&rightFlag==0)||
                        (answerType==3 &&!isRight &&rightFlag==0 &&!selectOptionId.contains(id))-> {
                    holder.setVisible(  R.id.question_operation_img_result,true)
                    holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                    holder.setBackgroundResource( R.id.question_operation_index, R.drawable.shape_bg_red_index)
                    holder.setImageResource(R.id.question_operation_img_result, R.mipmap.icon_right_red )
                    holder.setTextColor(R.id.question_operation_title,Color.parseColor("#FA642C"))
                }

                (answerType==1&&isCheckResult&&isSelect&&rightFlag==1) ||(answerType==3&& rightFlag==1&&selectOptionId.contains(id))-> {
                    holder.setVisible(R.id.question_operation_img_result, true)
                    holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        R.drawable.shape_bg_red_index
                    )
                    holder.setImageResource(
                        R.id.question_operation_img_result,
                        R.mipmap.icon_answer_error
                    )
                    holder.setTextColor(
                        R.id.question_operation_title,
                        Color.parseColor("#FA642C")
                    )
                }
                else->{
                    holder.setTextColor(R.id.question_operation_index,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setTextColor(R.id.question_operation_title,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                    holder.setBackgroundResource(
                        R.id.question_operation_index,
                        if((MultiTheme.getAppTheme()) == 1) R.drawable.shape_bg_white_index_dark else R.drawable.shape_bg_white_index
                    )
                    holder.setVisible(R.id.question_operation_img_result, false)
                }
            }


        }


    }

}


