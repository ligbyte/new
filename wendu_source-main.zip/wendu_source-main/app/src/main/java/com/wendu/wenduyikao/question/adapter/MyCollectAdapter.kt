package com.wendu.wenduyikao.question.adapter

import android.view.View
import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.QuestionCollectEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 我的错题
 */
class MyCollectAdapter(data: ArrayList<QuestionCollectEntity>) :
    BaseQuickAdapter<QuestionCollectEntity, BaseViewHolder>(
        R.layout.question_error_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: QuestionCollectEntity) {
        item.run {
            holder.setText(R.id.question_error_tag, StringUtil.getSubjectTypeByType(liftingType))
            holder.setText(R.id.error_item_stem, stem)
            if (isCollect == 1) {
                holder.setImageResource(R.id.question_error_fav, R.mipmap.ic_fav_unselcted)
            } else {
                holder.setImageResource(R.id.question_error_fav, R.mipmap.ic_fav_selected)
            }
            holder.setText(R.id.question_error_nums, "做错${number}次")
            holder.getView<TextView>(R.id.question_error_nums).visibility = View.INVISIBLE
        }
    }

}