package com.wendu.wenduyikao.question.adapter

import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.MobileUtil
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.NoteInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 我的笔记
 */
class MyNoteAdapter(data: ArrayList<NoteInfoEntity>) :
    BaseQuickAdapter<NoteInfoEntity, BaseViewHolder>(
        R.layout.note_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: NoteInfoEntity) {
        item.run {
            holder.setText(R.id.note_title, note)
            holder.setText(R.id.note_time, createTime)
            if (StringUtil.isNotBlank(imageUrl)) {
                holder.getView<LinearLayout>(R.id.note_item_pic).visibility= View.VISIBLE
                val imgs = StringUtil.convertStrToList(imageUrl)
                holder.getView<LinearLayout>(R.id.note_item_pic).removeAllViews()
                for (url in imgs) {
                    val imageView = ImageView(context)
                    var layoutParams=LinearLayout.LayoutParams(
                        MobileUtil.getScreenWidth(context) / 4,
                        LinearLayout.LayoutParams.MATCH_PARENT
                    )
                    layoutParams.setMargins(10,0,40,0)
                    imageView.layoutParams = layoutParams
                    imageView.scaleType = ImageView.ScaleType.FIT_XY
                    val operation = RequestOptions().centerCrop().transform(RoundedCorners(10))
                    Glide.with(context).load(url).apply(operation).placeholder(R.drawable.ic_default_pic1)
                        .into(imageView)
                    holder.getView<LinearLayout>(R.id.note_item_pic).addView(imageView) //动

                }
            }else{
                holder.getView<LinearLayout>(R.id.note_item_pic).visibility= View.GONE
            }
        }
    }
}