package com.wendu.wenduyikao.question.adapter

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.PaperInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 我的笔记
 */
class PaperListAdapter(data: ArrayList<PaperInfoEntity>) :
    BaseQuickAdapter<PaperInfoEntity, BaseViewHolder>(
        R.layout.mock_exam_paper_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: PaperInfoEntity) {
        item.run {
            holder.setText(R.id.mock_exam_item_title, paperName)
            val maxTime = useTime
            val hour = maxTime / 60;
            val minute = maxTime % 60;
            var time = ""
            if (hour > 0) {
                time+= "$hour 时";
            }
            if (minute > 0) {
                time+="$minute 分";
            }

            holder.setText(R.id.mock_exam_item_nums, "${total}题")
            holder.setText(R.id.mock_exam_item_time, "考试规定用时${time}")

        }
    }

}