package com.wendu.wenduyikao.question.adapter

import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.PaperRecordEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 模拟考试记录
 */
class PaperRecordListAdapter(data: ArrayList<PaperRecordEntity>) :
    BaseQuickAdapter<PaperRecordEntity, BaseViewHolder>(
        R.layout.mock_exam_paper_record_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: PaperRecordEntity) {
        item.run {
            holder.setText(R.id.mock_exam_item_title, paperName)
            holder.setText(R.id.mock_exam_item_score, successScore)
            holder.setText(
                R.id.mock_exam_item_desc,
                StringUtil.getMockRecordType(paper_type.toInt())
            )
            if(paper_type=="1"){
                holder.setImageResource(R.id.mock_exam_item_pic,R.mipmap.ic_paper2)
            }else{
                holder.setImageResource(R.id.mock_exam_item_pic,R.mipmap.ic_paper1)
            }
            holder.setText(
                R.id.mock_exam_item_time,
                createTime
            )
        }
    }

}