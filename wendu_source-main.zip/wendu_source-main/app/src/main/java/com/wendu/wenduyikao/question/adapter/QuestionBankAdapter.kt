package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.util.Log
import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.ColorUtil
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 举一反三
 */
class QuestionBankAdapter(data: ArrayList<QuestionPaperInfoEntity>) :
    BaseQuickAdapter<QuestionPaperInfoEntity, BaseViewHolder>(
        R.layout.item_question_bank_content,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: QuestionPaperInfoEntity) {
        item.run {
            holder.setText(R.id.question_bank_result, index)
            if (item.wdQuestionChapterPractice == null) {
                holder.setTextColor(R.id.question_bank_result, Color.parseColor("#FFFFFF"))
                holder.setBackgroundResource(
                    R.id.question_bank_result,
                    R.drawable.shape_bg_half_white_index
                )
            } else {
                val tvIndex = holder.getView<TextView>(R.id.question_bank_result)
                if (tvIndex != null) {
                    tvIndex.setTextColor(ColorUtil.checkColor())
//                    tvIndex.setTextColor(Color.parseColor("#B7BFF"))
                }else{
                    Log.v("yxy","tvIndex nulll")
                }

                holder.setBackgroundResource(
                    R.id.question_bank_result,
                    R.drawable.shape_bg_white_no_line_index
                )
            }
        }
    }


}