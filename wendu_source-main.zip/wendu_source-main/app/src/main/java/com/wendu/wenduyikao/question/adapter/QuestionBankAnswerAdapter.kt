package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 举一反三
 */
class QuestionBankAnswerAdapter(data: ArrayList<QuestionPaperInfoEntity>) :
    BaseQuickAdapter<QuestionPaperInfoEntity, BaseViewHolder>(
        R.layout.item_question_bank_content,
        data
    ) {
    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: QuestionPaperInfoEntity) {
        item.run {
            holder.setText(R.id.question_bank_result, index)
            if (wdQuestionChapterPractice == null) {
                holder.setTextColor(R.id.question_bank_result,  Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333"))
                holder.setBackgroundResource(R.id.question_bank_result, if((MultiTheme.getAppTheme()) == 1) R.drawable.shape_bg_white_index_dark else R.drawable.shape_bg_white_index)
            } else {
                holder.setTextColor(R.id.question_bank_result, Color.parseColor("#ffffff"))
                holder.setBackgroundResource(R.id.question_bank_result, R.drawable.shape_bg_blue_index)
            }
        }
    }

}