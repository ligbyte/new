package com.wendu.wenduyikao.question.adapter

import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.QuestionPaperEntity

/**
 * Package:       com.changyang.wendu.question.adapter
 * ClassName:     QuestionBoutiqueAdapter
 * Author:         xiaoyangyan
 * CreateDate:    8/6/21
 * Description:精品题库适配器
 */
class QuestionBoutiqueAdapter(data: ArrayList<QuestionPaperEntity>) :
    BaseQuickAdapter<QuestionPaperEntity, BaseViewHolder>(
        R.layout.question_boutique_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: QuestionPaperEntity) {
        item.run {
            holder.setText(R.id.question_boutique_title, paperName)
            holder.setText(R.id.question_boutique_progress, "$userCount 人在做题")
            holder.setText(
                R.id.question_boutique_price,
                StringUtil.formatDoublePrice(officialPrice)
            )
            var img = holder.getView<ImageView>(R.id.question_boutique_pic)
            Glide.with(context).load(url).placeholder(R.drawable.ic_default_pic1).into(img)

                if (unlock?.isUnLock == 1) {
                    holder.setText(R.id.question_boutique_operation, "开始做题")
                    holder.setVisible(R.id.question_boutique_price, false)
                    holder.getView<TextView>(R.id.question_boutique_operation).setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
                    holder.setBackgroundResource(
                        R.id.question_boutique_operation,
                        R.mipmap.ic_btn_bg_green
                    )
                } else {
                    if (openingMode == 0){
                        holder.setText(R.id.question_boutique_operation, "未解锁")
                        holder.getView<TextView>(R.id.question_boutique_operation).setCompoundDrawablesRelativeWithIntrinsicBounds(R.mipmap.ic_unlock,0,0,0)
                        holder.setVisible(R.id.question_boutique_price, false)
                        holder.setBackgroundResource(
                            R.id.question_boutique_operation,
                            R.mipmap.ic_btn_bg_green
                        )
                    }else {
                        holder.setText(R.id.question_boutique_operation, "立即开通")
                        holder.getView<TextView>(R.id.question_boutique_operation).setCompoundDrawablesRelativeWithIntrinsicBounds(0,0,0,0)
                        holder.setVisible(R.id.question_boutique_price, true)
                        holder.setBackgroundResource(
                            R.id.question_boutique_operation,
                            R.mipmap.ic_btn_bg_orange
                        )
                    }
                }

        }

    }

}