package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.view.View
import android.widget.TextView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.QuestionCatalogEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/3/21 11:46 PM
 * @Description: 题库目录
 */
class QuestionCatalogAdapter(data: ArrayList<QuestionCatalogEntity>) :
    BaseQuickAdapter<QuestionCatalogEntity, BaseViewHolder>(
        R.layout.question_catalog_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    override fun convert(holder: BaseViewHolder, item: QuestionCatalogEntity) {
        item.run {
            holder.setText(R.id.question_type_title, templateName)
            holder.setText(R.id.question_type_do_subnum, "$doSubjectNumber")

            if (unlock?.isUnLock == 0 && (unlock?.unlockType != 2 &&  unlock?.unlockType != 9)) {
                holder.getView<RTextView>(R.id.question_type_lock).visibility = View.VISIBLE
                holder.getView<TextView>(R.id.question_type_operation).visibility = View.GONE
            } else {
                holder.getView<RTextView>(R.id.question_type_lock).visibility = View.GONE
                holder.getView<TextView>(R.id.question_type_operation).visibility = View.VISIBLE
                if (subjectNumber > 0) {
                    holder.setText(R.id.question_type_operation, "继续做题")
                    holder.setTextColor(R.id.question_type_operation, Color.parseColor("#3B7BFF"))
                    holder.setTextColor(R.id.question_type_do_subnum, Color.parseColor("#3B7BFF"))
                } else {
                    holder.setText(R.id.question_type_operation, "开始做题")
                    holder.setTextColor(R.id.question_type_operation, Color.parseColor("#333333"))
                }
            }

            holder.setText(R.id.question_type_subnum, "/$subjectNumber")
        }

    }

}


