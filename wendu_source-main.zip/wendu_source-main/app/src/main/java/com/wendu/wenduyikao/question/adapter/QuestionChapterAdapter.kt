package com.wendu.wenduyikao.question.adapter

import android.view.View
import android.widget.ImageView
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ruffian.library.RTextView
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.QuestionChapterEntity

/**
 * Package:       com.changyang.wendu.question.adapter
 * ClassName:     QuestionBoutiqueAdapter
 * Author:         xiaoyangyan
 * CreateDate:    8/6/21
 * Description: 章节练习
 */
class QuestionChapterAdapter(data: ArrayList<QuestionChapterEntity>) :
    BaseQuickAdapter<QuestionChapterEntity, BaseViewHolder>(
        R.layout.chapter_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: QuestionChapterEntity) {
        item.run {
            holder.setText(R.id.question_boutique_index, (holder.adapterPosition + 1).toString())
            holder.setText(R.id.question_boutique_title, templateName)
            holder.setText(
                R.id.question_boutique_progress,
                "共${subjectNumber}题  已做${doSubjectNumber}题"
            )

            if (isUnlock == 0) {
                holder.getView<RTextView>(R.id.question_boutique_lock).visibility = View.VISIBLE
                holder.getView<ImageView>(R.id.question_type_right).visibility = View.GONE
            } else {
                holder.getView<RTextView>(R.id.question_boutique_lock).visibility = View.GONE
                holder.getView<ImageView>(R.id.question_type_right).visibility = View.VISIBLE
            }

        }

    }

}