package com.wendu.wenduyikao.question.adapter;

import android.graphics.Color;
import android.util.Log;

import com.blankj.utilcode.util.GsonUtils;
import com.chad.library.adapter.base.BaseSectionQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.google.gson.reflect.TypeToken;
import com.ligbyte.lib.theme.MultiTheme;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.app.util.StringUtil;
import com.wendu.wenduyikao.data.model.bean.QuestionPaperInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity;
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;


public class QuestionPaperCardAdapter extends BaseSectionQuickAdapter<QuestionResultEntity, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization result.
     *
     * @param sectionHeadResId The section head layout id for each item
     * @param layoutResId      The layout resource id of each item.
     * @param data             A new list is created out of this one to avoid mutable list
     */
    public QuestionPaperCardAdapter(int layoutResId, int sectionHeadResId, List<QuestionResultEntity> data) {
        super(sectionHeadResId, data);
        setNormalLayout(layoutResId);
    }

    @Override
    protected void convertHeader(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        if (item.getObject() instanceof String) {
            helper.setText(R.id.header, (String) item.getObject());
        }
    }

    @Override
    protected void convert(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        QuestionPaperDbEntity info = (QuestionPaperDbEntity) item.getObject();

        helper.setText(R.id.question_result, info.getIndex());
        helper.setTextColor(R.id.question_result, Color.parseColor(((MultiTheme.getAppTheme()) == 1)? "#858585" :"#333333"));
        helper.setBackgroundResource(R.id.question_result, MultiTheme.getAppTheme() == 1 ? R.drawable.shape_bg_white_index_dark : R.drawable.shape_bg_white_index);

        if (StringUtil.isBlank(info.getWdQuestionChapterPractice())) {
            helper.setTextColor(R.id.question_result, Color.parseColor(((MultiTheme.getAppTheme()) == 1)? "#858585" :"#333333"));
            helper.setBackgroundResource(R.id.question_result, MultiTheme.getAppTheme() == 1 ? R.drawable.shape_bg_white_index_dark : R.drawable.shape_bg_white_index);
        } else {
            WdQuestionChapterPracticeEntity result = GsonUtils.fromJson(info.getWdQuestionChapterPractice(), WdQuestionChapterPracticeEntity.class);
            if (result != null) {
                boolean isFinish = false;
                ArrayList<QuestionPaperInfoEntity> unDoList = new ArrayList<>();
                if (StringUtil.isNotBlank(info.getWdQuestionBankList())) {
                    ArrayList<QuestionPaperInfoEntity> bankList = GsonUtils.fromJson(info.getWdQuestionBankList(), new TypeToken<ArrayList<QuestionPaperInfoEntity>>() {
                    }.getType());
                    Log.v("yxy", "index---"+info.getIndex()+"====" +bankList.size());


                   List<QuestionPaperInfoEntity> questionBankList = new ArrayList<>();
                    for (int i=0;i<bankList.size();i++) {
                        if (bankList.get(i).getWdQuestionPaperSubjectSubordinatesList().size() > 0) {
                            for (QuestionPaperInfoEntity sub:bankList.get(i).getWdQuestionPaperSubjectSubordinatesList()) {
                                questionBankList.add(sub);
                            }
                        } else {
                            questionBankList.add(bankList.get(i));
                        }
                    }
                    for (QuestionPaperInfoEntity paper : questionBankList) {
                        if (paper.getWdQuestionChapterPractice() == null) {
                            unDoList.add(paper);
                        }
                    }
                    Log.v("yxy", "index----unDoList-"+info.getIndex()+"===" +unDoList.size());
                    isFinish = unDoList.size() == 0;
                }else{
                    isFinish=true;
                }

                if (isFinish) {
                    helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                    helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_blue_index);

                } else {
                    helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                    helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_yellow_index);
                }

            } else {
                helper.setTextColor(R.id.question_result, Color.parseColor(((MultiTheme.getAppTheme()) == 1)? "#858585" :"#333333"));
                helper.setBackgroundResource(R.id.question_result, MultiTheme.getAppTheme() == 1 ? R.drawable.shape_bg_white_index_dark : R.drawable.shape_bg_white_index);
            }

        }

    }
}
