package com.wendu.wenduyikao.question.adapter;

import android.graphics.Color;
import android.util.Log;

import com.chad.library.adapter.base.BaseSectionQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.app.util.CacheUtil;
import com.wendu.wenduyikao.data.model.bean.QuestionInfoEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionPracticeEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * https://github.com/CymChad/BaseRecyclerViewAdapterHelper
 */
public class QuestionResultAdapter extends BaseSectionQuickAdapter<QuestionResultEntity, BaseViewHolder> {
    /**
     * Same as QuickAdapter#QuickAdapter(Context,int) but with
     * some initialization result.
     *
     * @param sectionHeadResId The section head layout id for each item
     * @param layoutResId      The layout resource id of each item.
     * @param data             A new list is created out of this one to avoid mutable list
     */
    public QuestionResultAdapter(int layoutResId, int sectionHeadResId, List<QuestionResultEntity> data) {
        super(sectionHeadResId, data);
        setNormalLayout(layoutResId);

    }

    @Override
    protected void convertHeader(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        if (item.getObject() instanceof String) {
            helper.setText(R.id.header, (String) item.getObject());
        }
    }


    @Override
    protected void convert(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        QuestionInfoEntity info = (QuestionInfoEntity) item.getObject();

        helper.setText(R.id.question_result, info.getIndex());
        helper.setTextColor(R.id.question_result, Color.parseColor("#333333"));
        helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_white_index);
        if (!info.isDo()) {
            helper.setTextColor(R.id.question_result, Color.parseColor("#333333"));
            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_white_index);
        } else {
            if (info.getLiftingType() == 3 || info.getLiftingType() == 4 || info.getLiftingType() == 7 || info.getLiftingType() == 8) {
                for (QuestionInfoEntity question : info.getQuestionList()) {
                    if (question.isDo()) {
                        if (question.isRight() == 0) {
                            helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_green_index);
                        } else {
                            helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                            helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_red_index);
                        }

                    } else {
                        helper.setTextColor(R.id.question_result, Color.parseColor("#333333"));
                        helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_white_index);
                    }
                }
            } else {

                if (info.isRight() == 0) {
                    helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                    helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_green_index);
                } else {
                    helper.setTextColor(R.id.question_result, Color.parseColor("#ffffff"));
                    helper.setBackgroundResource(R.id.question_result, R.drawable.shape_bg_red_index);
                }
            }

        }
    }
}
