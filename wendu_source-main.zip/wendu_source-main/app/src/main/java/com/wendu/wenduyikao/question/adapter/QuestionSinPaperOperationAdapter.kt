package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import com.blankj.utilcode.util.GsonUtils
import com.bumptech.glide.Glide
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.ligbyte.lib.theme.MultiTheme
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.Constants
import com.wendu.wenduyikao.data.model.bean.QuestionOptionEntity
import com.wendu.wenduyikao.data.model.bean.WdQuestionChapterPracticeEntity
import com.wendu.wenduyikao.data.model.db.QuestionPaperDbEntity
import org.litepal.LitePal

/**
 * Package:       com.changyang.wendu.question.adapter
 * ClassName:     QuestionBoutiqueAdapter
 * Author:         xiaoyangyan
 * CreateDate:    8/6/21
 * Description: 章节练习
 */
class QuestionSinPaperOperationAdapter(data: ArrayList<QuestionOptionEntity>) :
    BaseQuickAdapter<QuestionOptionEntity, BaseViewHolder>(
        R.layout.question_operation_item_view,
        data
    ) {
    private var mPosition = -1
    private var isAnswer = true; //true 背题模式，false 答题模式

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    fun setAnswer(isanswer: Boolean) {
        this.isAnswer = isanswer
    }


    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }

    override fun convert(holder: BaseViewHolder, item: QuestionOptionEntity) {
        item.run {
            holder.setText(R.id.question_operation_title, content)
            holder.setText(R.id.question_operation_index, selectValue)
            holder.getView<TextView>(R.id.question_operation_title).textSize =  15 + Constants.questionTextSize
            holder.getView<TextView>(R.id.question_operation_index).textSize =  16 + Constants.questionTextSize
            var index = -1
            val select = 0
            var selectOptionId = ""
            val question = LitePal.where("questionId=?", subjectId)
                .findFirst(QuestionPaperDbEntity::class.java)
            if (question != null) {
                if (StringUtil.isNotBlank(question.wdQuestionChapterPractice)) {
                    val practice = GsonUtils.fromJson<WdQuestionChapterPracticeEntity>(
                        question.wdQuestionChapterPractice,
                        WdQuestionChapterPracticeEntity::class.java
                    )
                    selectOptionId = practice.optionId
                }

            }
            Log.v("yxy","==subType=="+subType)

            when (subType) {
                1 -> {
//文字
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.VISIBLE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.GONE
                }
                2 -> {
//图片
                    holder.getView<TextView>(R.id.question_operation_title).visibility =
                        View.GONE
                    holder.getView<ImageView>(R.id.question_operation_pic).visibility =
                        View.VISIBLE
                    Glide.with(context).load(content).placeholder(R.drawable.ic_default_pic1)
                        .into(holder.getView<ImageView>(R.id.question_operation_pic))
                }
            }


            if (mPosition == holder.adapterPosition || selectOptionId == id) {
                isSelect = true
                if (question != null) {
                    question.wdQuestionChapterPractice = ""
                    question.updateAll("questionId=?", subjectId)
                }
                holder.setTextColor(R.id.question_operation_index, Color.parseColor("#ffffff"))
                holder.setBackgroundResource(
                    R.id.question_operation_index,
                    R.drawable.shape_bg_blue_index
                )
                val colorIndex = if (MultiTheme.getAppTheme() != 1) "#3B7BFF" else "#8DB4FF"
                holder.setTextColor(
                    R.id.question_operation_title,
                    Color.parseColor(colorIndex)
                )
                holder.setImageResource(
                    R.id.question_operation_img_result,
                    R.mipmap.icon_answer_right
                )


            } else {
                isSelect = false
                holder.setTextColor(R.id.question_operation_index,
                    Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333")
                )
                holder.setBackgroundResource(
                    R.id.question_operation_index,
                    if (MultiTheme.getAppTheme() == 1) R.drawable.shape_bg_white_index_dark else R.drawable.shape_bg_white_index
                )
                holder.setTextColor(
                    R.id.question_operation_title,
                    Color.parseColor(if (MultiTheme.getAppTheme() == 1) "#858585" else "#333333")
                )

            }
        }

    }

}




