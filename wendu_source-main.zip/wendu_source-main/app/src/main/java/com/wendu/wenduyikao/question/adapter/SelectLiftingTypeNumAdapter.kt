package com.wendu.wenduyikao.question.adapter

import android.util.Log
import android.widget.RelativeLayout
import com.blankj.utilcode.util.ToastUtils
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.app.util.StringUtil
import com.wendu.wenduyikao.data.model.bean.CollectNumEntity

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 我的错题
 */
class SelectLiftingTypeNumAdapter(data: ArrayList<CollectNumEntity>) :
    BaseQuickAdapter<CollectNumEntity, BaseViewHolder>(
        R.layout.select_liftingtype_num_item_view,
        data
    ) {

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: CollectNumEntity) {
        item.run {
            val total=number;
            holder.setText(R.id.liftingtype_num_tv_num, number.toString())
            if(liftingType==5){
                holder.setText(
                    R.id.liftingtype_num_tv_type,
                    StringUtil.getSubjectTypeBy5(topicCategory)
                )
            }else{
                holder.setText(
                    R.id.liftingtype_num_tv_type,
                    StringUtil.getSubjectTypeByType(liftingType)
                )
            }


            holder.getView<RelativeLayout>(R.id.liftingtype_num_minus).setOnClickListener {

                if (number > 0) {
                    number -= 1
                    holder.setText(R.id.liftingtype_num_tv_num, number.toString())
                }
            }

                holder.getView<RelativeLayout>(R.id.liftingtype_num_add).setOnClickListener {
                    Log.v("yxy","=="+number+"====="+total)
                    if(number>=total){
                        ToastUtils.showShort("选择题目数量不能大于题目总数")
                    }else{
                        number += 1
                        holder.setText(R.id.liftingtype_num_tv_num, number.toString())
                    }




            }

        }


    }

}