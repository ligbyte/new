package com.wendu.wenduyikao.question.adapter;

import android.graphics.Color;
import android.util.Log;

import com.blankj.utilcode.util.GsonUtils;
import com.chad.library.adapter.base.BaseSectionQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.wendu.wenduyikao.R;
import com.wendu.wenduyikao.data.model.bean.MajorEntity;
import com.wendu.wenduyikao.data.model.bean.QuestionResultEntity;

import org.jetbrains.annotations.NotNull;

import java.util.List;

/**
 * @Author : xiaoyangyan
 * @Time : 8/12/21 9:34 PM
 * @Description: 选择专业
 */
public class SelectMajorAdapter extends BaseSectionQuickAdapter<QuestionResultEntity, BaseViewHolder> {

    private int mPosition = -1;


    private String majorId = "";

    public SelectMajorAdapter(int layoutResId, int sectionHeadResId, List<QuestionResultEntity> data) {
        super(sectionHeadResId, data);
        setNormalLayout(layoutResId);
    }


    public void setMajorId(String majorId) {
        this.majorId = majorId;
    }

    public void setPosition(int position) {
        this.mPosition = position;
    }

    @Override
    protected void convertHeader(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        if (item.getObject() instanceof String) {
            helper.setText(R.id.header, (String) item.getObject());
        }
    }


    @Override
    protected void convert(@NotNull BaseViewHolder helper, @NotNull QuestionResultEntity item) {
        MajorEntity info =GsonUtils.fromJson(GsonUtils.toJson(item.getObject()),MajorEntity.class);
        helper.setText(R.id.major_item_name, info.getMajorName());
//        Log.v("yxy", "position" + mPosition + "==getId=" + info.getId()+"=majorId=="+majorId);
        if (mPosition == helper.getAdapterPosition() || majorId.equals(info.getId())) {
            helper.setTextColor(R.id.major_item_name, Color.parseColor("#3B7BFF"));
            helper.setBackgroundResource(R.id.major_item_name, R.drawable.shape_bg_light_blue_line_blue);
        } else {
            helper.setTextColor(R.id.major_item_name, Color.parseColor("#333333"));
            helper.setBackgroundResource(R.id.major_item_name, R.drawable.shape_bg_white_line_gray);
        }

    }
}
