package com.wendu.wenduyikao.question.adapter

import android.graphics.Color
import android.util.Log
import com.chad.library.adapter.base.BaseQuickAdapter
import com.chad.library.adapter.base.viewholder.BaseViewHolder
import com.wendu.wenduyikao.R
import com.wendu.wenduyikao.app.ext.setAdapterAnimation
import com.wendu.wenduyikao.app.util.SettingUtil
import com.wendu.wenduyikao.data.model.bean.*

/**
 * @Author     : xiaoyangyan
 * @Time       : 8/6/21 4:14 PM
 * @Description: 学习币
 */
class SelectPayAdapter(data: ArrayList<PayWayEntity>) :
    BaseQuickAdapter<PayWayEntity, BaseViewHolder>(
        R.layout.pay_way_item_view,
        data
    ) {


    private var mPosition = -1

    fun setPosition(position: Int) {
        this.mPosition = position
    }

    init {
        setAdapterAnimation(SettingUtil.getListMode())
    }


    override fun convert(holder: BaseViewHolder, item: PayWayEntity) {
        item.run {
            holder.setText(R.id.pay_way_title, label)
            holder.setImageResource(R.id.pay_way_pic,img)
            if(type=="balance"){
                holder.setVisible(R.id.pay_way_recharge,true)
            }else{
                holder.setVisible(R.id.pay_way_recharge,false)
            }
            if (mPosition == holder.adapterPosition) {
                holder.setBackgroundResource(
                    R.id.pay_way_img_check,
                    R.mipmap.ic_check_box
                )
            } else {
                holder.setBackgroundResource(
                    R.id.pay_way_img_check,
                    R.mipmap.ic_check_box_un
                )

            }
        }
    }

}